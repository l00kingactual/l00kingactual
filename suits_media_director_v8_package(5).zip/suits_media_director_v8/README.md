# $uits Media Director v8.1

Fictional GTA/FiveM / machinima media director. Predation, Sun Tzu, Janus, humour, kills, prey and predator are editorial/media-analysis tags, not real-world conduct.

## What changed in v8.1

- Downloads import is removed. The project uses the real `$uits` paths only.
- `--render` now creates complete watchable MP4 outputs, not only JSON/CSV plans.
- Complete outputs are written to `renders/final/`.
- Proof sample clips and stills are written to `renders/clips/` and `renders/stills/`.
- Patient mode is available for slower but richer cue filling.
- Hells Bells now points at `Hells Bells [GL56LY6fE0E].webm`.
- Firefox/WebUI is optional; the shell scripts can generate everything without the browser.

## Project paths

```text
/home/andy/Documents/suitsmafia/videos
/home/andy/Documents/suitsmafia/videos/disciples
/home/andy/Documents/suitsmafia/videos/disciples/youtube
/home/andy/Documents/suitsmafia/videos/suits_youtube
/home/andy/Documents/suitsmafia/videos/youtube
/home/andy/Documents/suitsmafia/music_mp4
/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8
```

## Run the three requested songs as 29s and full length

```bash
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8_package/suits_media_director_v8
./run_production_all_render.sh
```

That runs:

```text
good_4_u.webm                                 suits      29s + full
Shoot to Thrill [wLoWd2KyUro].webm            suits      29s + full
Meat Loaf - Bat Out of Hell ... [3QGMCSCFoKA].webm disciples 29s + full
```

Outputs land in:

```text
/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/<song_run>/renders/final/*.mp4
```

## Run one at a time

```bash
./run_good4u_suits_29s.sh
./run_good4u_suits_full.sh
./run_shoot_to_thrill_suits_29s.sh
./run_shoot_to_thrill_suits_full.sh
./run_bat_out_of_hell_disciples_29s.sh
./run_bat_out_of_hell_disciples_full.sh
```

Optional Hells Bells:

```bash
./run_hells_bells_disciples_29s.sh
./run_hells_bells_disciples_full.sh
```

## Important switches

```text
--song-preset good4u_suits | shoot_to_thrill_suits | bat_out_of_hell_disciples | hells_bells_disciples
--duration-mode clip29 | full | both
--clip-seconds 29
--render              render complete MP4 plus proof clips/stills
--render-final        render complete MP4 only
--render-samples      render proof clips/stills only
--analysis-depth fast | patient
--sample-render-count 24
--render-width 1280
--render-height 720
--out /path/to/output
--webui
```

## WebUI

```bash
./run_webui.sh
```

Open:

```text
http://127.0.0.1:8788
```

If Firefox has trouble, skip the WebUI and use the shell scripts. Open the generated report directly:

```text
/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/<song_run>/curated_music_cue_report.html
```

## Outputs per run

```text
media_dictionary.json
video_assets.json / video_assets.csv
music_assets.json / music_assets.csv
edit_plan.json
cue_match_plan.json / cue_match_plan.csv
run_manifest.json
curated_music_cue_report.html
renders/final/*_complete.mp4
renders/final/*_segments.csv
renders/clips/*.mp4
renders/stills/*.png
renders/ffmpeg_final.log
renders/ffmpeg_samples.log
```

## [o][o]

“Sk1nn1ng up again” means: the wee machine is peeling the footage, skinning metadata, cutting proof segments, adding music, and bringing back a plate of watchable outputs.

## Full-song render note

In the patched build, `--render` means:

- render complete final MP4 under `renders/final/`
- render sample proof clips/stills when requested
- fill every cue window by cycling ranked clips until the cue duration is covered
- add the selected music track with FFmpeg

The command output now reports effective flags:

```json
"render_final": true,
"render_samples": true
```

For a complete full song, use the `_full.sh` runner or `--duration-mode full --render --analysis-depth patient`.

For a 29 second social render, use the `_29s.sh` runner or `--duration-mode clip29 --clip-seconds 29 --render --analysis-depth patient`.

---

## 🤖 Who Made Who + Metadata Reuse Patch

This patch adds `Who Made Who` presets and a Gaia/JWST-style metadata catalogue system.

### New presets

```bash
./run_who_made_who_all_29s.sh
./run_who_made_who_all_full.sh
./run_who_made_who_suits_29s.sh
./run_who_made_who_disciples_29s.sh
```

Expected music path:

```text
/home/andy/Documents/suitsmafia/music_mp4/AC⧸DC - Who Made Who (Official HD Video) [PiZHNw1MtzI].webm
```

### Previous metadata reuse

Earlier runs produce useful hidden catalogue data:

- `video_assets.json`
- `music_assets.json`
- `edit_plan.json`
- `cue_match_plan.json`
- `cue_match_plan.csv`
- human feedback CSVs / event CSVs when present

Use:

```bash
--reuse-previous \
--previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8
```

The run writes:

```text
previous_metadata_index.json
```

That file is the background catalogue: it stores prior tags, average scores, repeated evidence, reasons, and source files. The current run then promotes that background metadata into foreground scoring.

### Upload/intake support

Extra folders can be scanned as both video and music intake:

```bash
--upload-dir /home/andy/Documents/suitsmafia/upload
```

This is useful for one-off clips before they are sorted into `videos/` or `music_mp4/`.

See `docs_metadata_predation_model.md` for the Gaia/JWST analogy, pixel-to-event abstraction, predation/prey scoring, and lyric irony model.
