#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Running 3 songs x 29s + full with patient FULL-SONG render. This can take a while."
./run_good4u_suits_29s.sh --render --analysis-depth patient
./run_good4u_suits_full.sh --render --analysis-depth patient
./run_shoot_to_thrill_suits_29s.sh --render --analysis-depth patient
./run_shoot_to_thrill_suits_full.sh --render --analysis-depth patient
./run_bat_out_of_hell_disciples_29s.sh --render --analysis-depth patient
./run_bat_out_of_hell_disciples_full.sh --render --analysis-depth patient
echo "Done. Final complete outputs:"
find /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 -path '*/renders/final/*_complete.mp4' -print
