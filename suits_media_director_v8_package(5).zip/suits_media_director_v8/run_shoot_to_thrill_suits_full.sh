#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT="/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/shoot_to_thrill_suits_full"
mkdir -p "$OUT"
# Default is patient rendered output. Pass --render-samples or other switches after the script if needed.
python3 suits_media_director_v8.py \
  --song-preset shoot_to_thrill_suits \
  --duration-mode full \
  --analysis-depth patient \
  --render \
  --sample-render-count 24 \
  --out "$OUT" "$@"
