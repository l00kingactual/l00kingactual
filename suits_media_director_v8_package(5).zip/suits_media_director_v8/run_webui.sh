#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT_DIR="${OUT_DIR:-/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8}"
mkdir -p "$OUT_DIR"
echo '$uits Media Director v8 WebUI: http://127.0.0.1:8788'
echo "Outputs: $OUT_DIR"
python3 suits_media_director_v8.py \
  --video-dir /home/andy/Documents/suitsmafia/videos \
  --video-dir /home/andy/Documents/suitsmafia/videos/disciples \
  --video-dir /home/andy/Documents/suitsmafia/videos/disciples/youtube \
  --video-dir /home/andy/Documents/suitsmafia/videos/suits_youtube \
  --video-dir /home/andy/Documents/suitsmafia/videos/youtube \
  --music-dir /home/andy/Documents/suitsmafia/music_mp4 \
  --duration-mode both \
  --out "$OUT_DIR" \
  --webui
