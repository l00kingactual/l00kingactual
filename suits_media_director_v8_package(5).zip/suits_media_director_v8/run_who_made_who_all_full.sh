#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --reuse-previous \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
  --render \
  --sample-render-count 36 \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_all_full
