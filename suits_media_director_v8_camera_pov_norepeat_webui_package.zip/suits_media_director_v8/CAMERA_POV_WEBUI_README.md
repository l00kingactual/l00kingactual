# 🎬 $uits Media Director v8 — Event Camera / No-Repeat Director Package

## ✅ What this package does

- 🎥 Loads video directories, playlists, or selected files.
- 🎵 Loads music directories, playlists, or selected files.
- ✅ Supports select all / some / none in the WebUI.
- 🎼 Auto-tunes selected video to selected music cues.
- 🚫 Enforces no repeated clips/scenes in story mode.
- 🔥 Labels kill/impact candidates.
- 🦁 Labels predation pressure types.
- 🐑 Labels prey-behaviour types.
- 😂 Labels comedy / irony / wit / bad-timing candidates.
- 🌌 Writes foreground/background model metadata.
- 🖥️ Indexes server logs when provided.
- 🎮 Indexes client logs when provided.
- 🎥 Writes `event_camera_plan.json` for future replay/spectator camera workflows.

## ⚠️ Camera POV limit

Logs can tell the processor what happened, when it likely happened, and sometimes where. They cannot recreate a camera angle that was never recorded. To get real server-side camera POV in future sessions, run a FiveM spectator/replay/capture resource that records attacker POV, defender/prey POV, wide context, impact, and aftermath around logged events.

## 🚀 Start WebUI

```bash
cd /home/andy/Documents/suitsmafia/suits_media_director_v8
chmod +x *.sh
./run_webui.sh
```

Open:

```text
http://127.0.0.1:8788
```

## 🎭 Full no-repeat story render from CLI

```bash
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --story-mode \
  --story-arc theatrical \
  --no-repeat-clips \
  --max-reuse-per-video 1 \
  --max-reuse-per-asset 1 \
  --min-reuse-gap-cues 99 \
  --prefer-unused \
  --label-kills \
  --reuse-previous \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
  --foreground-model \
  --camera-pov-model \
  --server-log-dir /home/andy/Documents/suitsmafia/server_logs \
  --client-log-dir /home/andy/Documents/suitsmafia/client_logs \
  --render \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_no_repeat_camera_story
```

## 📦 Important outputs

- 🎬 `edit_plan.json` — cue/story plan.
- 🎯 `cue_match_plan.csv/json` — ranked and labelled matches.
- 🔥 `kill_label`, `predation_type`, `prey_type`, `comedy_type` — classification columns.
- 🌌 `foreground_background_model.json` — model intent and foreground/background signals.
- 🖥️ `server_log_index.json` — parsed server event hints.
- 🎮 `client_log_index.json` — parsed client event hints.
- 🎥 `event_camera_plan.json` — camera/replay POV plan for event capture/alignment.
- 🎞️ `renders/final/*.mp4` — no-repeat story render.

## 🧠 Technical model

```text
🖥️ server/client logs       -> event truth hints
🌌 foreground/background     -> visual change model
🎵 music cue map             -> timing and mood
🔥 kill/prey/comedy labels   -> classification
🚫 no-repeat story selector  -> continuity and variety
🎬 renderer                  -> full cinematic output
```
