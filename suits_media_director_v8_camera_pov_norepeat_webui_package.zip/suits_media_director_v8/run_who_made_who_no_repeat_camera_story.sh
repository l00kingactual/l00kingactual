#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --story-mode \
  --story-arc theatrical \
  --no-repeat-clips \
  --max-reuse-per-video 1 \
  --max-reuse-per-asset 1 \
  --min-reuse-gap-cues 99 \
  --prefer-unused \
  --label-kills \
  --reuse-previous \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
  --foreground-model \
  --camera-pov-model \
  --event-camera-mode log_event_proxy \
  --server-log-dir /home/andy/Documents/suitsmafia/server_logs \
  --client-log-dir /home/andy/Documents/suitsmafia/client_logs \
  --render \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_no_repeat_camera_story
