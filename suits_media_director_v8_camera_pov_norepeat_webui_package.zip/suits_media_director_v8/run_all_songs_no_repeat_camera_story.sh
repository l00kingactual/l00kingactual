#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for preset in who_made_who_all shoot_to_thrill_suits good4u_suits bat_out_of_hell_disciples hells_bells_disciples; do
  echo "=== Rendering $preset as no-repeat theatrical story ==="
  python3 suits_media_director_v8.py \
    --song-preset "$preset" \
    --duration-mode full \
    --analysis-depth patient \
    --story-mode \
    --story-arc theatrical \
    --no-repeat-clips \
    --max-reuse-per-video 1 \
    --max-reuse-per-asset 1 \
    --min-reuse-gap-cues 99 \
    --prefer-unused \
    --label-kills \
    --reuse-previous \
    --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
    --foreground-model \
    --camera-pov-model \
    --event-camera-mode log_event_proxy \
    --server-log-dir /home/andy/Documents/suitsmafia/server_logs \
    --client-log-dir /home/andy/Documents/suitsmafia/client_logs \
    --render \
    --out "/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/${preset}_no_repeat_camera_story"
done
