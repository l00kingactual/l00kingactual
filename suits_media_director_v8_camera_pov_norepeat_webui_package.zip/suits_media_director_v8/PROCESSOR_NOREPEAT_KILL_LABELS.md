# 🎬 Processor patch: no-repeat full-song story + kill/prey labels

This patch changes the processor (`suits_media_director_v8.py`) so full-song story renders do not keep cycling the same scene.

## ✅ What changed

- 🔁 `--no-repeat-clips` now enforces strict unique source/asset selection in story mode.
- 🎭 Story cue planning selects only enough unique clips per chapter, so early cues do not consume the whole library.
- 🎞️ The final renderer no longer cycles the same selected clips in story mode.
- 🪧 If unique footage runs out, it uses a neutral story transition card instead of repeating footage.
- 🔥 `--label-kills` adds classification fields to cue plans and rendered segment CSVs.

## 🏷️ New output columns

- `kill_label`
- `predation_type`
- `prey_type`
- `comedy_type`
- `classification_confidence`
- `classification_labels`

## ▶️ Example

```bash
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --story-mode \
  --story-arc cinematic \
  --no-repeat-clips \
  --label-kills \
  --max-reuse-per-video 1 \
  --max-reuse-per-asset 1 \
  --min-reuse-gap-cues 99 \
  --prefer-unused \
  --reuse-previous \
  --foreground-model \
  --render \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_unique_story_full
```

## 🧠 Note

The WebUI calls this processor. It only needs to pass the new switches. Existing WebUI controls keep working.
