#!/usr/bin/env python3
"""$uits Media Director v8 Plus WebUI.

Local, no-dependency browser UI for selecting video/music assets, logs, labels,
no-repeat story rendering, foreground/background modelling and event-camera POV plans.
"""
from __future__ import annotations
import json, os, subprocess, sys, threading, time, uuid, urllib.parse, html
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import suits_media_director_v8 as core

ROOT = Path(__file__).resolve().parent
DEFAULT_OUT = Path(core.DEFAULT_OUT)
JOBS: dict[str, dict[str, Any]] = {}
ASSET_CACHE: dict[str, Any] = {"videos": [], "music": [], "created": 0.0, "project": "all"}

def split_lines(s: str) -> list[str]:
    return [x.strip() for x in (s or "").splitlines() if x.strip()]

def scan_assets(project: str="all", video_dirs: list[str]|None=None, music_dirs: list[str]|None=None, upload_dirs: list[str]|None=None) -> dict[str, Any]:
    if project == "suits": vdirs = list(core.SUITS_VIDEO_DIRS)
    elif project == "disciples": vdirs = list(core.DISCIPLES_VIDEO_DIRS)
    else: vdirs = list(core.DEFAULT_VIDEO_DIRS)
    mdirs = list(core.DEFAULT_MUSIC_DIRS)
    for x in video_dirs or []:
        if x and x not in vdirs: vdirs.append(x)
    for x in music_dirs or []:
        if x and x not in mdirs: mdirs.append(x)
    for u in upload_dirs or []:
        if u and u not in vdirs: vdirs.append(u)
        if u and u not in mdirs: mdirs.append(u)
    videos, music = core.build_assets(vdirs, mdirs, [], [], True, [], [])
    data = {
        "videos": [core.asdict(v) for v in videos],
        "music": [core.asdict(m) for m in music],
        "project": project,
        "created": time.time(),
        "paths": {"videos": vdirs, "music": mdirs, "outputs": str(DEFAULT_OUT)},
        "labels": sorted(set(list(core.LABEL_DICTIONARY.get("event_classes", {}).keys()) + ["kill_candidate","impact_candidate","team_play","controlled_burst","lyric_irony","previously_strong","shot","damage","aftermath"])),
        "prey": sorted(core.LABEL_DICTIONARY.get("prey_types", {}).keys()),
        "comedy": ["funny","lyric_irony","sarcasm","wit","panic_turn","poach","bad_timing","absurd_motion","odd_unusual","comedic_prey","reversal"],
        "presets": sorted(core.KNOWN_SONGS.keys()),
    }
    ASSET_CACHE.clear(); ASSET_CACHE.update(data)
    return data

def get_assets() -> dict[str, Any]:
    if not ASSET_CACHE.get("videos") and not ASSET_CACHE.get("music"):
        return scan_assets()
    return ASSET_CACHE

def write_playlist(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(r.get("path","") for r in rows if r.get("path")) + "\n", encoding="utf-8")

def slug(s: str) -> str:
    return core.safe_slug(s or "webui_story_run")[:96]

def run_job(job_id: str, payload: dict[str, Any]) -> None:
    job = JOBS[job_id]
    try:
        assets = get_assets()
        vids = set(payload.get("video_ids") or [])
        mids = set(payload.get("music_ids") or [])
        videos = [v for v in assets["videos"] if (not vids or v["asset_id"] in vids)]
        music = [m for m in assets["music"] if (not mids or m["asset_id"] in mids)]
        if not videos: raise RuntimeError("No videos selected")
        if not music and not payload.get("song_preset"): raise RuntimeError("No music selected and no preset selected")
        out_dir = DEFAULT_OUT / slug(payload.get("out_name") or f"webui_story_{job_id}")
        work = out_dir / ".webui_job"; work.mkdir(parents=True, exist_ok=True)
        vlist = work / "selected_videos.txt"; mlist = work / "selected_music.txt"
        write_playlist(vlist, videos); write_playlist(mlist, music)
        cmd = [sys.executable, str(ROOT/"suits_media_director_v8.py"),
               "--video-playlist", str(vlist),
               "--duration-mode", payload.get("duration_mode", "full"),
               "--analysis-depth", payload.get("analysis_depth", "patient"),
               "--clip-seconds", str(payload.get("clip_seconds", 29)),
               "--out", str(out_dir)]
        preset = payload.get("song_preset")
        if preset: cmd += ["--song-preset", preset]
        else: cmd += ["--music-playlist", str(mlist)]
        if payload.get("story_mode", True):
            cmd += ["--story-mode", "--story-arc", payload.get("story_arc", "cinematic"),
                    "--max-reuse-per-video", str(payload.get("max_reuse_per_video", 1)),
                    "--max-reuse-per-asset", str(payload.get("max_reuse_per_asset", 1)),
                    "--min-reuse-gap-cues", str(payload.get("min_reuse_gap_cues", 99)),
                    "--min-scene-gap-seconds", str(payload.get("min_scene_gap_seconds", 45)),
                    "--story-scene-seconds", str(payload.get("story_scene_seconds", 8))]
        if payload.get("no_repeat_clips", True): cmd.append("--no-repeat-clips")
        if payload.get("prefer_unused", True): cmd.append("--prefer-unused")
        if payload.get("label_kills", True): cmd.append("--label-kills")
        if payload.get("render", True): cmd.append("--render")
        if payload.get("reuse_previous", True): cmd += ["--reuse-previous", "--previous-out-dir", payload.get("previous_out_dir") or str(DEFAULT_OUT)]
        if payload.get("foreground_model", True): cmd += ["--foreground-model", "--foreground-model-mode", payload.get("foreground_model_mode") or "metadata_guided_delta"]
        if payload.get("camera_pov_model", True): cmd += ["--camera-pov-model", "--event-camera-mode", payload.get("event_camera_mode") or "log_event_proxy"]
        for x in payload.get("selected_labels") or []: cmd += ["--selected-label", str(x)]
        for x in payload.get("prey_types") or []: cmd += ["--prey-type", str(x)]
        for x in payload.get("comedy_classes") or []: cmd += ["--comedy-class", str(x)]
        for x in payload.get("server_log_dirs") or []:
            if x: cmd += ["--server-log-dir", str(x)]
        for x in payload.get("client_log_dirs") or []:
            if x: cmd += ["--client-log-dir", str(x)]
        job.update({"status":"running", "cmd":cmd, "out_dir":str(out_dir), "started":time.time()})
        log = out_dir / "webui_job.log"; out_dir.mkdir(parents=True, exist_ok=True)
        with log.open("w", encoding="utf-8") as fh:
            fh.write("COMMAND:\n" + " ".join(cmd) + "\n\n")
            proc = subprocess.run(cmd, cwd=str(ROOT), text=True, stdout=fh, stderr=subprocess.STDOUT)
        job.update({"status":"done" if proc.returncode==0 else "error", "returncode":proc.returncode, "finished":time.time(), "log":str(log)})
    except Exception as exc:
        job.update({"status":"error", "error":str(exc), "finished":time.time()})

HTML = r'''<!doctype html><html><head><meta charset="utf-8"><title>$uits Media Director v8 Director UI</title>
<style>
body{margin:0;background:#111b24;color:#edf6fb;font-family:Arial,sans-serif}header{position:sticky;top:0;background:#203142;border-bottom:1px solid #5e7b92;padding:16px;z-index:2}main{display:grid;grid-template-columns:360px 1fr;gap:14px;padding:14px}.card{background:#1d2b37;border:1px solid #5e7b92;border-radius:14px;padding:14px}.full{grid-column:1/-1}.scroll{max-height:360px;overflow:auto;background:#101923;border:1px solid #39566d;border-radius:10px;padding:8px}label{display:block;padding:5px;border-radius:8px}label:hover{background:#2a4053}.field{width:100%;padding:8px;border-radius:8px;border:1px solid #57748b;background:#101923;color:#edf6fb}button{border:1px solid #9acbff;background:#2869b1;color:white;border-radius:10px;padding:8px 12px;margin:3px;cursor:pointer}button.hot{background:#a65318;border-color:#ffd08a}button.ok{background:#267b48;border-color:#8aecb5}.pill{display:inline-block;background:#2f4b61;border-radius:99px;padding:3px 8px;margin:2px}pre{white-space:pre-wrap;background:#0d151e;border:1px solid #39566d;border-radius:10px;padding:10px;max-height:360px;overflow:auto}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}small{color:#b8cad6}
</style></head><body><header><h1>🎬 $uits Media Director v8 — Director UI</h1><small>📁 load directories • ✅ select all/some/none • 🎵 auto-tune music • 🔥 label kills • 🐑 prey/predation • 🚫 no repeats • 🖥️ server/client logs • 🎥 event-camera plan</small></header><main>
<section class="card"><h2>📁 Scan folders</h2><label>🎭 Project<select id="project" class="field"><option>all</option><option>suits</option><option>disciples</option></select></label><label>🎥 Extra video dirs<textarea id="videodirs" class="field" rows="3" placeholder="/home/andy/Documents/suitsmafia/videos"></textarea></label><label>🎵 Extra music dirs<textarea id="musicdirs" class="field" rows="2" placeholder="/home/andy/Documents/suitsmafia/music_mp4"></textarea></label><label>📥 Upload/intake dirs<textarea id="uploaddirs" class="field" rows="2" placeholder="/home/andy/Documents/suitsmafia/upload"></textarea></label><button onclick="scan()">🔎 Scan / refresh assets</button></section>
<section class="card"><h2>🎛️ Story render controls</h2><label>🎵 Song preset<select id="preset" class="field"><option value="">selected music</option></select></label><label>🎞 Duration<select id="duration" class="field"><option selected>full</option><option>clip29</option><option>both</option></select></label><label>🧠 Analysis<select id="depth" class="field"><option>fast</option><option selected>patient</option></select></label><label>🎭 Story arc<select id="storyarc" class="field"><option>cinematic</option><option selected>theatrical</option><option>predation</option><option>comedy</option><option>documentary</option></select></label><label>⏱ Scene seconds<input id="storysecs" class="field" value="8"></label><label>📦 Output name<input id="outname" class="field" value="webui_full_story_no_repeat"></label><label><input id="storymode" type="checkbox" checked> 🎭 story mode</label><label><input id="norepeat" type="checkbox" checked> 🚫 no repeating clips/scenes</label><label><input id="preferunused" type="checkbox" checked> 🆕 prefer unused sources</label><label><input id="labelkills" type="checkbox" checked> 🔥 label kills / prey / predation</label><label><input id="render" type="checkbox" checked> 🎬 render MP4</label></section>
<section class="card"><h2>🌌 Models and logs</h2><label><input id="reuse" type="checkbox" checked> 🗃️ reuse previous metadata</label><label>🗃️ Previous output dir<input id="prevdir" class="field" value="/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8"></label><label><input id="fg" type="checkbox" checked> 🌌 foreground/background model</label><label><input id="cam" type="checkbox" checked> 🎥 event-camera POV plan</label><label>🎥 Event camera mode<select id="cammode" class="field"><option selected>log_event_proxy</option><option>replay_director</option><option>spectator_capture_plan</option></select></label><label>🖥️ Server log dirs<textarea id="serverlogs" class="field" rows="3" placeholder="/home/andy/Documents/suitsmafia/server_logs"></textarea></label><label>🎮 Client log dirs<textarea id="clientlogs" class="field" rows="3" placeholder="/home/andy/Documents/suitsmafia/client_logs"></textarea></label></section>
<section class="card"><h2>🧠 What logs can do</h2><p><span class="pill">🖥️ server truth</span><span class="pill">🎮 client POV</span><span class="pill">⏱ timestamp hints</span><span class="pill">📍 coords hints</span><span class="pill">🎥 camera plan</span></p><small>Logs can plan/align camera POVs and improve event confidence. They cannot recreate unrecorded angles unless a FiveM camera/replay capture resource was running at the time.</small></section>
<section class="card"><h2>🎥 Videos</h2><button onclick="tog('video',true)">✅ select all</button><button onclick="tog('video',false)">⬜ none</button><div id="videos" class="scroll"></div></section>
<section class="card"><h2>🎵 Music</h2><button onclick="tog('music',true)">✅ select all</button><button onclick="tog('music',false)">⬜ none</button><div id="music" class="scroll"></div></section>
<section class="card"><h2>🔥 Events / predation</h2><button onclick="tog('label',true)">✅ all</button><button onclick="tog('label',false)">⬜ none</button><div id="labels" class="scroll"></div></section>
<section class="card"><h2>🐑 Prey + 😂 comedy</h2><div class="grid"><div><h3>🐑 Prey</h3><button onclick="tog('prey',true)">✅ all</button><button onclick="tog('prey',false)">⬜ none</button><div id="prey" class="scroll"></div></div><div><h3>😂 Comedy</h3><button onclick="tog('comedy',true)">✅ all</button><button onclick="tog('comedy',false)">⬜ none</button><div id="comedy" class="scroll"></div></div></div></section>
<section class="card full"><button class="hot" title="Auto-tune selected videos to selected music using story/no-repeat, prey/predation labels, metadata reuse, logs and foreground/background model." onclick="runJob()">🎬 Auto-tune / render selected story movie</button><button class="ok" onclick="poll(lastJob)">🔁 refresh job</button><pre id="status">ready</pre></section>
</main><script>
let assets={}, lastJob=''; const $=id=>document.getElementById(id); function lines(id){return ($(id).value||'').split(/\n/).map(x=>x.trim()).filter(Boolean)}
function checked(cls){return Array.from(document.querySelectorAll('input.'+cls+':checked')).map(x=>x.value)} function tog(cls,on){document.querySelectorAll('input.'+cls).forEach(x=>x.checked=on)} function esc(s){return (s||'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
function renderList(id,cls,rows,kind){$(id).innerHTML=rows.map(r=>`<label><input class="${cls}" type="checkbox" value="${r.asset_id||r}" checked> ${kind} ${esc(r.name||r)} <small>${r.duration_s?Math.round(r.duration_s)+'s ':''}${esc(r.path||'')}</small></label>`).join('')}
async function scan(){ $('status').textContent='scanning...'; let r=await fetch('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({project:$('project').value,video_dirs:lines('videodirs'),music_dirs:lines('musicdirs'),upload_dirs:lines('uploaddirs')})}); assets=await r.json(); $('preset').innerHTML='<option value="">selected music</option>'+assets.presets.map(p=>`<option>${p}</option>`).join(''); renderList('videos','video',assets.videos,'🎥'); renderList('music','music',assets.music,'🎵'); renderList('labels','label',assets.labels,'🔥'); renderList('prey','prey',assets.prey,'🐑'); renderList('comedy','comedy',assets.comedy,'😂'); $('status').textContent=`loaded ${assets.videos.length} videos, ${assets.music.length} music`; }
async function runJob(){ let payload={project:$('project').value,song_preset:$('preset').value,duration_mode:$('duration').value,analysis_depth:$('depth').value,story_mode:$('storymode').checked,story_arc:$('storyarc').value,story_scene_seconds:parseFloat($('storysecs').value||'8'),max_reuse_per_video:1,max_reuse_per_asset:1,min_reuse_gap_cues:99,min_scene_gap_seconds:45,no_repeat_clips:$('norepeat').checked,prefer_unused:$('preferunused').checked,label_kills:$('labelkills').checked,render:$('render').checked,reuse_previous:$('reuse').checked,previous_out_dir:$('prevdir').value,foreground_model:$('fg').checked,camera_pov_model:$('cam').checked,event_camera_mode:$('cammode').value,server_log_dirs:lines('serverlogs'),client_log_dirs:lines('clientlogs'),out_name:$('outname').value,video_ids:checked('video'),music_ids:checked('music'),selected_labels:checked('label'),prey_types:checked('prey'),comedy_classes:checked('comedy')}; $('status').textContent='starting render job...'; let r=await fetch('/api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); let j=await r.json(); lastJob=j.job_id; poll(lastJob)}
async function poll(id){ if(!id)return; let r=await fetch('/api/job?id='+encodeURIComponent(id)); let j=await r.json(); $('status').textContent=JSON.stringify(j,null,2); if(j.status==='running')setTimeout(()=>poll(id),2000)}
scan();
</script></body></html>'''

class Handler(BaseHTTPRequestHandler):
    def _send(self, obj: Any, code: int=200):
        raw = json.dumps(obj, ensure_ascii=False, indent=2).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        u=urllib.parse.urlparse(self.path)
        if u.path=='/':
            raw=HTML.encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        if u.path=='/api/assets': self._send(get_assets()); return
        if u.path=='/api/job':
            qs=urllib.parse.parse_qs(u.query); self._send(JOBS.get(qs.get('id',[''])[0], {"status":"missing"})); return
        self.send_error(404)
    def do_POST(self):
        n=int(self.headers.get('Content-Length','0') or 0); data=json.loads(self.rfile.read(n).decode('utf-8') or '{}')
        if self.path=='/api/scan': self._send(scan_assets(data.get('project','all'), data.get('video_dirs') or [], data.get('music_dirs') or [], data.get('upload_dirs') or [])); return
        if self.path=='/api/run':
            jid=uuid.uuid4().hex[:10]; JOBS[jid]={"job_id":jid,"status":"queued","created":time.time()}; threading.Thread(target=run_job,args=(jid,data),daemon=True).start(); self._send({"job_id":jid,"status":"queued"}); return
        self.send_error(404)

def main():
    ap = __import__('argparse').ArgumentParser()
    ap.add_argument('--host', default='127.0.0.1'); ap.add_argument('--port', type=int, default=8788)
    args=ap.parse_args()
    print(f"$uits Media Director v8 Director UI: http://{args.host}:{args.port}")
    ThreadingHTTPServer((args.host,args.port), Handler).serve_forever()
if __name__=='__main__': main()
