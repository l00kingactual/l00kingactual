#!/usr/bin/env bash
set -euo pipefail
ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
SITE="${SUITS_SITE:-$ROOT/susitsmafia_website}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$SITE" "$SITE/css" "$SITE/js" "$SITE/api" "$SITE/data/suits_v16_6" "$SITE/videos"
if command -v rsync >/dev/null 2>&1; then
  rsync -a "$SCRIPT_DIR/web/" "$SITE/"
  rsync -a "$SCRIPT_DIR/css/" "$SITE/css/"
  rsync -a "$SCRIPT_DIR/js/" "$SITE/js/"
  rsync -a "$SCRIPT_DIR/api/" "$SITE/api/"
else
  cp -a "$SCRIPT_DIR/web/." "$SITE/"
  cp -a "$SCRIPT_DIR/css/." "$SITE/css/"
  cp -a "$SCRIPT_DIR/js/." "$SITE/js/"
  cp -a "$SCRIPT_DIR/api/." "$SITE/api/"
fi
mkdir -p "$ROOT/tools"
cat > "$ROOT/tools/suits_v16_6_1_launch_websiteui" <<EOF
#!/usr/bin/env bash
cd "$SITE"
echo "[o][o] launching $uits v16.6.1 WebsiteUI at http://127.0.0.1:8081/suits_v16_6_dashboard.php"
php -S 127.0.0.1:8081
EOF
chmod +x "$ROOT/tools/suits_v16_6_1_launch_websiteui"
echo "[o][o] WebsiteUI installed into: $SITE"
echo "[run] $ROOT/tools/suits_v16_6_1_launch_websiteui"
