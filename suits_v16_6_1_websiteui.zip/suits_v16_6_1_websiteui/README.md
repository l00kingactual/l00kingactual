# [o][o] $uits v16.6.1 WebsiteUI

Website-only package for the Dramatic Movie Theatre. It reads JSON produced by the Python processor from:

```text
susitsmafia_website/data/suits_v16_6
```

It displays:

- full-song movie plans
- 29-second clip outputs
- full film movie render job
- grouped playlists
- chart lab
- graph lab
- video theatre

## Install

```bash
cd ~/Downloads
unzip -o suits_v16_6_1_websiteui.zip
cd suits_v16_6_1_websiteui
chmod +x scripts/*.sh
./scripts/install_websiteui.sh
```

## Launch

```bash
/home/andy/Documents/suitsmafia/tools/suits_v16_6_1_launch_websiteui
```

Open:

```text
http://127.0.0.1:8081/suits_v16_6_dashboard.php
```

## Render workflow shown by UI

The Movie Factory page reads `render_jobs.json` and shows the generated scripts:

```bash
bash outputs/.../render_song_movies_full_songs.sh
bash outputs/.../render_song_movies_29s.sh
bash outputs/.../render_full_film_movie.sh
bash outputs/.../publish_movies_to_site.sh
```
