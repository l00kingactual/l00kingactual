window.SPACE_WALES_V5_DATA = {
  "version": "5.2",
  "budget": {
    "annual_gbp": 2500000000,
    "staff_total": 25000,
    "population": 3200000,
    "horizons": [
      1,
      5,
      10,
      25
    ]
  },
  "allocations": [
    {
      "id": "compute",
      "icon": "🧠",
      "name": "Super-advanced compute + data",
      "pct": 18,
      "staff_pct": 10,
      "purpose": "data centres, HPC/AI, VDI, storage, cyber-secure evidence engines",
      "annual_gbp": 450000000,
      "staff": 2500
    },
    {
      "id": "education",
      "icon": "🏫",
      "name": "Education + lifelong learning",
      "pct": 14,
      "staff_pct": 14,
      "purpose": "schools, libraries, curriculum, astronomy, Welsh learning tools",
      "annual_gbp": 350000000,
      "staff": 3500
    },
    {
      "id": "pathway_league",
      "icon": "🎖️",
      "name": "SPACE WALE$ Pathway League",
      "pct": 5,
      "staff_pct": 8,
      "purpose": "Cubs, Brownies, Scouts, Guides, adventures, CCF-style leadership, badges and competitions",
      "annual_gbp": 125000000,
      "staff": 2000
    },
    {
      "id": "digital_farm_twins",
      "icon": "🚜",
      "name": "Digital farm twins + terrain maps",
      "pct": 3,
      "staff_pct": 4,
      "purpose": "Farming Simulator-style terrain projects, QGIS/Python/GDAL, farm maps and learner avatars",
      "annual_gbp": 75000000,
      "staff": 1000
    },
    {
      "id": "health",
      "icon": "🩺",
      "name": "Health + prevention",
      "pct": 11,
      "staff_pct": 12,
      "purpose": "GP prevention, sport-health, active lives, mental wellbeing",
      "annual_gbp": 275000000,
      "staff": 3000
    },
    {
      "id": "agrarian",
      "icon": "🌾",
      "name": "Agrarian WALE$ infrastructure",
      "pct": 10,
      "staff_pct": 10,
      "purpose": "SPACE Farmers, farms, food, water, soil, orchards, meadows",
      "annual_gbp": 250000000,
      "staff": 2500
    },
    {
      "id": "eco_energy",
      "icon": "🔋",
      "name": "Eco-fuel / school energy hives",
      "pct": 6,
      "staff_pct": 5,
      "purpose": "school solar, batteries, compost, gardens, orchards, eco-fuel hubs",
      "annual_gbp": 150000000,
      "staff": 1250
    },
    {
      "id": "transport",
      "icon": "🚌",
      "name": "Transport + service access",
      "pct": 8,
      "staff_pct": 7,
      "purpose": "bus, rail, community taxi, safe routes, emergency access",
      "annual_gbp": 200000000,
      "staff": 1750
    },
    {
      "id": "enterprise",
      "icon": "💼",
      "name": "Enterprise + apprenticeships",
      "pct": 8,
      "staff_pct": 8,
      "purpose": "SME vouchers, maker hubs, start-ups, college-to-work routes",
      "annual_gbp": 200000000,
      "staff": 2000
    },
    {
      "id": "spacegis",
      "icon": "🛰️",
      "name": "Space, GIS, sensors, astronomy",
      "pct": 6,
      "staff_pct": 6,
      "purpose": "satellite imagery, dark skies, OSGB/GPS, field sensors",
      "annual_gbp": 150000000,
      "staff": 1500
    },
    {
      "id": "animals",
      "icon": "🐑",
      "name": "Animal guilds + ecology",
      "pct": 4,
      "staff_pct": 5,
      "purpose": "bees, ducks, chickens, geese, sheep, goats, pigs, donkeys, cows, horses, fish, birds",
      "annual_gbp": 100000000,
      "staff": 1250
    },
    {
      "id": "hives",
      "icon": "🏘️",
      "name": "Hives: hamlets, villages, towns, cities",
      "pct": 3,
      "staff_pct": 4,
      "purpose": "local hubs, parks, sports fields, civic assets",
      "annual_gbp": 75000000,
      "staff": 1000
    },
    {
      "id": "cyber",
      "icon": "🔐",
      "name": "Cybersecurity + civil resilience",
      "pct": 3,
      "staff_pct": 4,
      "purpose": "identity, backup, continuity, civil data defence",
      "annual_gbp": 75000000,
      "staff": 1000
    },
    {
      "id": "evidence",
      "icon": "🧾",
      "name": "Evidence, simulation, CoRT60, audit",
      "pct": 1,
      "staff_pct": 3,
      "purpose": "ROI proof, CoRT60 cards, honey ledger, audit, governance, safeguards",
      "annual_gbp": 25000000,
      "staff": 750
    }
  ],
  "organisations": [
    {
      "id": "schools",
      "icon": "🏫",
      "name": "Schools",
      "role": "curriculum, safeguarding, evidence, badges, school farm twin"
    },
    {
      "id": "cubs_brownies",
      "icon": "🐺",
      "name": "Cubs + Brownies",
      "role": "age 8–10 responsibility, teamwork, nature, early badges"
    },
    {
      "id": "scouts_guides",
      "icon": "🧭",
      "name": "Scouts + Guides",
      "role": "adventure, map skills, service, ecology, leadership"
    },
    {
      "id": "adventures",
      "icon": "⛰️",
      "name": "Adventures + outdoor learning",
      "role": "navigation, resilience, sport, weather, terrain, safety"
    },
    {
      "id": "ccf_style",
      "icon": "🎖️",
      "name": "CCF-style leadership",
      "role": "discipline, service, first aid, logistics, communication, civil resilience"
    },
    {
      "id": "farm_hubs",
      "icon": "🌾",
      "name": "Farm hubs",
      "role": "animal husbandry, farm twins, husbandry responsibility, food and land"
    },
    {
      "id": "libraries",
      "icon": "📚",
      "name": "Libraries",
      "role": "public compute, languages, memory, evidence portfolios"
    },
    {
      "id": "clubs",
      "icon": "🏃",
      "name": "Sports clubs",
      "role": "health, coaching, teamwork, performance and participation"
    },
    {
      "id": "colleges",
      "icon": "🎓",
      "name": "Colleges",
      "role": "apprenticeship bridges, STEM, agritech, enterprise"
    }
  ],
  "subjects": [
    {
      "id": "astronomy",
      "icon": "🔭",
      "name": "Astronomy",
      "budget_bias": [
        "spacegis",
        "education"
      ],
      "roi": "wonder, navigation, physics, dark skies, satellites"
    },
    {
      "id": "sport",
      "icon": "🏃",
      "name": "Sports",
      "budget_bias": [
        "health",
        "hives"
      ],
      "roi": "wellbeing, discipline, confidence, prevention"
    },
    {
      "id": "maths",
      "icon": "➗",
      "name": "Maths",
      "budget_bias": [
        "education",
        "compute"
      ],
      "roi": "budgeting, maps, ratios, yield, ROI"
    },
    {
      "id": "physics",
      "icon": "⚛️",
      "name": "Physics",
      "budget_bias": [
        "education",
        "eco_energy"
      ],
      "roi": "energy, solar, forces, weather, optics"
    },
    {
      "id": "languages",
      "icon": "🗣️",
      "name": "Languages",
      "budget_bias": [
        "education",
        "hives"
      ],
      "roi": "Welsh/English reports, place names, presentation"
    },
    {
      "id": "chemistry",
      "icon": "🧪",
      "name": "Chemistry",
      "budget_bias": [
        "education",
        "agrarian"
      ],
      "roi": "soil pH, compost, water quality, nutrition"
    },
    {
      "id": "biology",
      "icon": "🧬",
      "name": "Biology",
      "budget_bias": [
        "animals",
        "agrarian"
      ],
      "roi": "bees, animals, plants, fish, birds, habitats"
    },
    {
      "id": "gis",
      "icon": "🗺️",
      "name": "GIS + terrain mapping",
      "budget_bias": [
        "digital_farm_twins",
        "spacegis"
      ],
      "roi": "OSGB/GPS, heightmaps, farm-twin terrain projects"
    },
    {
      "id": "enterprise",
      "icon": "💼",
      "name": "Enterprise",
      "budget_bias": [
        "enterprise",
        "digital_farm_twins"
      ],
      "roi": "pricing, co-ops, products, surplus sales"
    }
  ],
  "badges": [
    {
      "id": "hive_keeper",
      "icon": "🐝",
      "name": "Cymru Hive Keeper",
      "age": [
        "5-7",
        "8-10"
      ],
      "subjects": [
        "biology",
        "maths",
        "languages"
      ],
      "partners": [
        "schools",
        "farm_hubs"
      ],
      "evidence": [
        "hive journal",
        "pollinator drawing",
        "Welsh/English labels"
      ],
      "roi_weight": 3.2
    },
    {
      "id": "farm_twin_mapper",
      "icon": "🚜",
      "name": "Cymru Farm Twin Mapper",
      "age": [
        "11-13",
        "14-16"
      ],
      "subjects": [
        "gis",
        "maths",
        "physics",
        "languages"
      ],
      "partners": [
        "schools",
        "farm_hubs"
      ],
      "evidence": [
        "heightmap",
        "field boundary map",
        "terrain reflection"
      ],
      "roi_weight": 4.6
    },
    {
      "id": "dark_sky_navigator",
      "icon": "🔭",
      "name": "Dark Sky Navigator",
      "age": [
        "8-10",
        "11-13"
      ],
      "subjects": [
        "astronomy",
        "physics",
        "languages"
      ],
      "partners": [
        "scouts_guides",
        "adventures"
      ],
      "evidence": [
        "star map",
        "safe route plan",
        "Welsh glossary"
      ],
      "roi_weight": 4.1
    },
    {
      "id": "animal_welfare_steward",
      "icon": "🐑",
      "name": "Animal Welfare Steward",
      "age": [
        "8-10",
        "11-13",
        "14-16"
      ],
      "subjects": [
        "biology",
        "chemistry",
        "languages"
      ],
      "partners": [
        "farm_hubs",
        "schools"
      ],
      "evidence": [
        "welfare log",
        "feeding chart",
        "biosecurity checklist"
      ],
      "roi_weight": 4.4
    },
    {
      "id": "eco_energy_builder",
      "icon": "🔋",
      "name": "Eco-Energy Builder",
      "age": [
        "11-13",
        "14-16",
        "16-24"
      ],
      "subjects": [
        "physics",
        "maths",
        "chemistry"
      ],
      "partners": [
        "schools",
        "colleges"
      ],
      "evidence": [
        "solar model",
        "energy budget",
        "savings estimate"
      ],
      "roi_weight": 4.8
    },
    {
      "id": "sport_health_leader",
      "icon": "🏃",
      "name": "Sport-Health Leader",
      "age": [
        "8-10",
        "11-13",
        "14-16"
      ],
      "subjects": [
        "sport",
        "biology",
        "maths"
      ],
      "partners": [
        "clubs",
        "schools"
      ],
      "evidence": [
        "activity plan",
        "team log",
        "wellbeing reflection"
      ],
      "roi_weight": 4.0
    },
    {
      "id": "civil_resilience_cadet",
      "icon": "🎖️",
      "name": "Civil Resilience Cadet",
      "age": [
        "14-16",
        "16-24"
      ],
      "subjects": [
        "maths",
        "physics",
        "languages"
      ],
      "partners": [
        "ccf_style",
        "adventures"
      ],
      "evidence": [
        "risk card",
        "route plan",
        "team leadership record"
      ],
      "roi_weight": 4.9
    },
    {
      "id": "river_farm_scientist",
      "icon": "💧",
      "name": "River Farm Scientist",
      "age": [
        "11-13",
        "14-16"
      ],
      "subjects": [
        "chemistry",
        "biology",
        "gis"
      ],
      "partners": [
        "farm_hubs",
        "schools"
      ],
      "evidence": [
        "pH log",
        "species count",
        "water map"
      ],
      "roi_weight": 4.5
    },
    {
      "id": "welsh_enterprise_honey",
      "icon": "🍯",
      "name": "Welsh Enterprise Honey",
      "age": [
        "14-16",
        "16-24"
      ],
      "subjects": [
        "enterprise",
        "maths",
        "languages"
      ],
      "partners": [
        "schools",
        "colleges"
      ],
      "evidence": [
        "product label",
        "costing sheet",
        "surplus plan"
      ],
      "roi_weight": 4.7
    },
    {
      "id": "space_farmer_cadet",
      "icon": "🌾",
      "name": "SPACE Farmer Cadet",
      "age": [
        "16-24"
      ],
      "subjects": [
        "gis",
        "biology",
        "enterprise",
        "physics"
      ],
      "partners": [
        "farm_hubs",
        "colleges"
      ],
      "evidence": [
        "farm-twin capstone",
        "ROI case",
        "apprenticeship plan"
      ],
      "roi_weight": 5.0
    }
  ],
  "competitions": [
    {
      "id": "school_hive_art",
      "icon": "🎨",
      "name": "Bee/Hive Ecological Art Prize",
      "level": "school/county/national",
      "budget_gbp": 1210000,
      "criteria": [
        "art quality",
        "ecology evidence",
        "Welsh language",
        "teamwork"
      ]
    },
    {
      "id": "farm_twin_cup",
      "icon": "🚜",
      "name": "Digital Farm Twin Terrain Cup",
      "level": "county/national",
      "budget_gbp": 5000000,
      "criteria": [
        "terrain accuracy",
        "GIS pipeline",
        "enterprise case",
        "ecology score"
      ]
    },
    {
      "id": "dark_sky_league",
      "icon": "🌌",
      "name": "Dark Sky Astronomy League",
      "level": "school/county/national",
      "budget_gbp": 2000000,
      "criteria": [
        "observation",
        "safety",
        "physics link",
        "Welsh place story"
      ]
    },
    {
      "id": "animal_ark_award",
      "icon": "🐑",
      "name": "Welsh School Ark Award",
      "level": "county/national",
      "budget_gbp": 3000000,
      "criteria": [
        "welfare",
        "husbandry",
        "biosecurity",
        "responsibility"
      ]
    },
    {
      "id": "eco_energy_challenge",
      "icon": "🔋",
      "name": "Eco-Fuel / Energy School Challenge",
      "level": "county/national",
      "budget_gbp": 4000000,
      "criteria": [
        "energy savings",
        "STEM model",
        "ROI",
        "maintenance plan"
      ]
    },
    {
      "id": "civil_resilience_games",
      "icon": "🎖️",
      "name": "Civil Resilience Games",
      "level": "county/national",
      "budget_gbp": 3500000,
      "criteria": [
        "navigation",
        "first aid",
        "teamwork",
        "service logistics"
      ]
    }
  ],
  "population": [
    {
      "id": "age_5_7",
      "icon": "🌙",
      "name": "Ages 5–7 Wonder Bees",
      "people": 160000,
      "age": "5-7",
      "producer_capacity": 10,
      "consumer_need": 90,
      "priority": [
        "education",
        "health",
        "spacegis"
      ],
      "provides": [
        "family wonder",
        "curiosity",
        "community participation"
      ],
      "consumes": [
        "education",
        "health",
        "safe routes"
      ]
    },
    {
      "id": "age_8_10",
      "icon": "🧭",
      "name": "Ages 8–10 Explorer Bees",
      "people": 165000,
      "age": "8-10",
      "producer_capacity": 18,
      "consumer_need": 82,
      "priority": [
        "pathway_league",
        "education",
        "health"
      ],
      "provides": [
        "club energy",
        "teamwork",
        "local observation"
      ],
      "consumes": [
        "coaching",
        "transport",
        "library"
      ]
    },
    {
      "id": "age_11_13",
      "icon": "🔭",
      "name": "Ages 11–13 Team Bees",
      "people": 170000,
      "age": "11-13",
      "producer_capacity": 30,
      "consumer_need": 70,
      "priority": [
        "pathway_league",
        "spacegis",
        "digital_farm_twins",
        "animals"
      ],
      "provides": [
        "field data",
        "service projects",
        "coding evidence"
      ],
      "consumes": [
        "STEM",
        "ecology",
        "mentoring"
      ]
    },
    {
      "id": "age_14_16",
      "icon": "🛰️",
      "name": "Ages 14–16 Skill Bees",
      "people": 165000,
      "age": "14-16",
      "producer_capacity": 45,
      "consumer_need": 55,
      "priority": [
        "compute",
        "enterprise",
        "pathway_league",
        "digital_farm_twins"
      ],
      "provides": [
        "sensor work",
        "sports leadership",
        "prototype projects"
      ],
      "consumes": [
        "VDI",
        "enterprise coaching",
        "health prevention"
      ]
    },
    {
      "id": "age_16_24",
      "icon": "🌾",
      "name": "Ages 16–24 SPACE Farmer Cadets",
      "people": 330000,
      "age": "16-24",
      "producer_capacity": 70,
      "consumer_need": 50,
      "priority": [
        "enterprise",
        "compute",
        "agrarian",
        "digital_farm_twins"
      ],
      "provides": [
        "apprentice labour",
        "farm tech",
        "enterprise energy"
      ],
      "consumes": [
        "workstations",
        "college links",
        "mentors"
      ]
    },
    {
      "id": "adults",
      "icon": "⚙️",
      "name": "Adults 25–64 Work, Care + Enterprise",
      "people": 1650000,
      "age": "25-64",
      "producer_capacity": 85,
      "consumer_need": 55,
      "priority": [
        "health",
        "enterprise",
        "transport"
      ],
      "provides": [
        "tax base",
        "mentoring",
        "service work",
        "enterprise"
      ],
      "consumes": [
        "health",
        "transport",
        "skills"
      ]
    },
    {
      "id": "elders",
      "icon": "📚",
      "name": "Elders 65+ Memory + Care Bees",
      "people": 560000,
      "age": "65+",
      "producer_capacity": 45,
      "consumer_need": 80,
      "priority": [
        "health",
        "transport",
        "hives"
      ],
      "provides": [
        "memory",
        "volunteering",
        "culture",
        "mentoring"
      ],
      "consumes": [
        "care",
        "transport",
        "community support"
      ]
    }
  ],
  "auto_tunes": [
    {
      "id": "tune_01",
      "number": 1,
      "icon": "🌙",
      "name": "Moon Wonder + Family Story",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "education": 4,
        "spacegis": 4,
        "pathway_league": 2
      },
      "summary": "astronomy, story, language, family learning"
    },
    {
      "id": "tune_02",
      "number": 2,
      "icon": "🐝",
      "name": "School Hive + Pollinator Art",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "animals": 4,
        "education": 2,
        "pathway_league": 2
      },
      "summary": "hive art, pollinator meadow, observation"
    },
    {
      "id": "tune_03",
      "number": 3,
      "icon": "🏃",
      "name": "Movement + Confidence Play",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "health": 5,
        "hives": 2,
        "education": 1
      },
      "summary": "sport, play, confidence, wellbeing"
    },
    {
      "id": "tune_04",
      "number": 4,
      "icon": "📚",
      "name": "Library Language Hive",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "education": 4,
        "hives": 2,
        "pathway_league": 2
      },
      "summary": "Welsh/English words, story labels, public memory"
    },
    {
      "id": "tune_05",
      "number": 5,
      "icon": "🐺",
      "name": "Cubs/Brownies Team Play",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "pathway_league": 6,
        "health": 2,
        "transport": 2
      },
      "summary": "teamwork, badges, service and nature"
    },
    {
      "id": "tune_06",
      "number": 6,
      "icon": "🧭",
      "name": "Map + Compass Adventure",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "pathway_league": 4,
        "spacegis": 3,
        "transport": 3
      },
      "summary": "navigation, OSGB/GPS, safe routes"
    },
    {
      "id": "tune_07",
      "number": 7,
      "icon": "🐓",
      "name": "School Ark Responsibility",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "animals": 5,
        "education": 2,
        "pathway_league": 2
      },
      "summary": "animals, welfare, feeding charts, hygiene"
    },
    {
      "id": "tune_08",
      "number": 8,
      "icon": "🔋",
      "name": "Eco-Energy School Challenge",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "eco_energy": 6,
        "education": 2
      },
      "summary": "solar, energy, savings and climate literacy"
    },
    {
      "id": "tune_09",
      "number": 9,
      "icon": "🔭",
      "name": "Scouts/Guides Telescope Fieldwork",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "pathway_league": 4,
        "spacegis": 5,
        "education": 2
      },
      "summary": "dark skies, telescopes, physics, language"
    },
    {
      "id": "tune_10",
      "number": 10,
      "icon": "💧",
      "name": "River Farm Scientist",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "agrarian": 3,
        "animals": 3,
        "spacegis": 3,
        "education": 2
      },
      "summary": "water pH, biology, chemistry, GIS"
    },
    {
      "id": "tune_11",
      "number": 11,
      "icon": "🚜",
      "name": "Farm Twin Mapper I",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "digital_farm_twins": 6,
        "compute": 2,
        "spacegis": 3
      },
      "summary": "terrain map, field boundaries, school farm twin"
    },
    {
      "id": "tune_12",
      "number": 12,
      "icon": "🎨",
      "name": "County Eco-Art Evidence",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "pathway_league": 4,
        "education": 2,
        "animals": 2
      },
      "summary": "art, biodiversity, evidence and competition"
    },
    {
      "id": "tune_13",
      "number": 13,
      "icon": "🎖️",
      "name": "Civil Resilience Cadet Basics",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "pathway_league": 5,
        "transport": 2,
        "cyber": 2,
        "health": 2
      },
      "summary": "leadership, discipline, first aid, logistics"
    },
    {
      "id": "tune_14",
      "number": 14,
      "icon": "🛰️",
      "name": "Satellite GIS + Terrain",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "digital_farm_twins": 5,
        "spacegis": 5,
        "compute": 3
      },
      "summary": "satellite data, OSGB/GPS, terrain map projects"
    },
    {
      "id": "tune_15",
      "number": 15,
      "icon": "⚛️",
      "name": "Physics of Energy + Machinery",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "eco_energy": 5,
        "education": 2,
        "compute": 2
      },
      "summary": "solar, batteries, forces, farm machinery"
    },
    {
      "id": "tune_16",
      "number": 16,
      "icon": "🧪",
      "name": "Chemistry of Soil + Water",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "agrarian": 4,
        "education": 3,
        "animals": 2
      },
      "summary": "soil pH, compost, water, nutrients"
    },
    {
      "id": "tune_17",
      "number": 17,
      "icon": "💼",
      "name": "Enterprise Honey Challenge",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "enterprise": 6,
        "pathway_league": 3,
        "education": 2
      },
      "summary": "pricing, surplus, labels, co-op trading"
    },
    {
      "id": "tune_18",
      "number": 18,
      "icon": "🏥",
      "name": "Sport-Health Prevention",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "health": 7,
        "hives": 2,
        "evidence": 1
      },
      "summary": "fitness, prevention, confidence and evidence"
    },
    {
      "id": "tune_19",
      "number": 19,
      "icon": "🎓",
      "name": "College Apprenticeship Bridge",
      "cohort": "age_16_24",
      "stage": "Cadet",
      "allocation_modifiers": {
        "enterprise": 5,
        "education": 4,
        "compute": 3,
        "transport": 2
      },
      "summary": "college-to-work route and evidence portfolio"
    },
    {
      "id": "tune_20",
      "number": 20,
      "icon": "🌾",
      "name": "SPACE Farmer Capstone",
      "cohort": "age_16_24",
      "stage": "Cadet",
      "allocation_modifiers": {
        "agrarian": 7,
        "digital_farm_twins": 4,
        "enterprise": 4,
        "animals": 3
      },
      "summary": "land + sky + sport + animals + data"
    },
    {
      "id": "tune_21",
      "number": 21,
      "icon": "🧠",
      "name": "AI/ML Farm Optimiser",
      "cohort": "age_16_24",
      "stage": "Cadet",
      "allocation_modifiers": {
        "compute": 6,
        "digital_farm_twins": 4,
        "evidence": 3
      },
      "summary": "optimise farm twin budget and ecology"
    },
    {
      "id": "tune_22",
      "number": 22,
      "icon": "🐑",
      "name": "Animal Guild Husbandry",
      "cohort": "age_16_24",
      "stage": "Cadet",
      "allocation_modifiers": {
        "animals": 6,
        "agrarian": 4,
        "pathway_league": 2
      },
      "summary": "welfare, responsibility, farm hub animals"
    },
    {
      "id": "tune_23",
      "number": 23,
      "icon": "🏘️",
      "name": "Community Hive Service",
      "cohort": "adults",
      "stage": "Community",
      "allocation_modifiers": {
        "hives": 5,
        "health": 3,
        "transport": 3
      },
      "summary": "adult provider role, mentoring and service access"
    },
    {
      "id": "tune_24",
      "number": 24,
      "icon": "📚",
      "name": "Elder Memory + Welsh Culture",
      "cohort": "elders",
      "stage": "Community",
      "allocation_modifiers": {
        "hives": 4,
        "education": 3,
        "health": 2,
        "pathway_league": 2
      },
      "summary": "memory bees, Welsh culture, mentoring and language"
    }
  ],
  "hives": [
    {
      "id": "holyhead",
      "name": "Holyhead",
      "icon": "🚆",
      "x": 26,
      "y": 10,
      "type": "transport",
      "lat": 53.3103,
      "lon": -4.633
    },
    {
      "id": "bangor",
      "name": "Bangor",
      "icon": "🎓",
      "x": 44,
      "y": 13,
      "type": "education",
      "lat": 53.2274,
      "lon": -4.1293
    },
    {
      "id": "wrexham",
      "name": "Wrexham",
      "icon": "💼",
      "x": 85,
      "y": 20,
      "type": "enterprise",
      "lat": 53.0465,
      "lon": -2.9925
    },
    {
      "id": "snowdonia",
      "name": "Eryri / Snowdonia",
      "icon": "⛰️",
      "x": 39,
      "y": 25,
      "type": "pathway_league",
      "lat": 52.918,
      "lon": -3.891
    },
    {
      "id": "aberystwyth",
      "name": "Aberystwyth",
      "icon": "🔭",
      "x": 51,
      "y": 50,
      "type": "spacegis",
      "lat": 52.4153,
      "lon": -4.0829
    },
    {
      "id": "brecon",
      "name": "Brecon",
      "icon": "🌌",
      "x": 72,
      "y": 71,
      "type": "spacegis",
      "lat": 51.947,
      "lon": -3.391
    },
    {
      "id": "cardigan",
      "name": "Cardigan",
      "icon": "🐝",
      "x": 31,
      "y": 65,
      "type": "animals",
      "lat": 52.0837,
      "lon": -4.6592
    },
    {
      "id": "carmarthen",
      "name": "Carmarthen",
      "icon": "🏫",
      "x": 36,
      "y": 76,
      "type": "education",
      "lat": 51.8576,
      "lon": -4.3121
    },
    {
      "id": "swansea",
      "name": "Swansea",
      "icon": "⚙️",
      "x": 51,
      "y": 86,
      "type": "enterprise",
      "lat": 51.6214,
      "lon": -3.9436
    },
    {
      "id": "cardiff",
      "name": "Cardiff",
      "icon": "🏙️",
      "x": 74,
      "y": 93,
      "type": "hives",
      "lat": 51.4816,
      "lon": -3.1791
    },
    {
      "id": "newport",
      "name": "Newport",
      "icon": "🚆",
      "x": 82,
      "y": 88,
      "type": "transport",
      "lat": 51.5842,
      "lon": -2.9977
    },
    {
      "id": "monmouth",
      "name": "Monmouth",
      "icon": "🌳",
      "x": 90,
      "y": 78,
      "type": "animals",
      "lat": 51.8126,
      "lon": -2.7136
    },
    {
      "id": "st_davids",
      "name": "St David’s",
      "icon": "✨",
      "x": 11,
      "y": 75,
      "type": "spacegis",
      "lat": 51.882,
      "lon": -5.269
    }
  ],
  "map_asset": "assets/img/wales.jpeg",
  "value_sliders": {
    "budget_allocations": "annual allocation sliders capped to £2.5bn/year",
    "staff_allocations": "staff sliders capped to 25,000 people",
    "competition_budgets": "competition sliders capped to the current Pathway League allocation",
    "badge_roi_weights": "badge ROI-weight sliders",
    "population_provider_consumer": "producer/consumer sliders for each population cohort"
  },
  "metadata": {
    "model_name": "Cymru Hive OS v5.2 · SPACE WALE$ Pathway League",
    "release": "5.2",
    "fixes": [
      "Auto-tunes no longer advance automatically while playing.",
      "Clicking an auto-tune starts/restarts that selected tune only.",
      "Overview version and architecture metadata corrected.",
      "Analysis panels expanded with tables, lists, metadata and value-ledger summaries."
    ],
    "budget_cap_gbp_per_year": 2500000000,
    "staff_cap": 25000,
    "population_model": 3200000,
    "budget_horizons_years": [
      1,
      5,
      10,
      25
    ],
    "value_ledgers": [
      "budget allocation headings",
      "staff allocation headings",
      "competition budgets",
      "badge ROI weights",
      "population provider/consumer settings",
      "1/5/10/25-year horizons",
      "ROI outputs",
      "map hives and pathway overlays"
    ],
    "map_retained": true,
    "simulation_behaviour": "play animates the currently selected tune until the user changes tune or clicks next tune"
  },
  "architecture": {
    "layers": [
      {
        "layer": "UI",
        "items": [
          "collapsed sidebar groups",
          "zoomable Wales map",
          "slider panels",
          "analysis panels"
        ]
      },
      {
        "layer": "Value control",
        "items": [
          "budget sliders",
          "staff sliders",
          "competition sliders",
          "badge ROI sliders",
          "provider/consumer sliders"
        ]
      },
      {
        "layer": "Pathway League",
        "items": [
          "Cubs/Brownies",
          "Scouts/Guides",
          "adventures",
          "CCF-style leadership",
          "schools",
          "farm hubs"
        ]
      },
      {
        "layer": "Education",
        "items": [
          "astronomy",
          "sport",
          "maths",
          "physics",
          "languages",
          "chemistry",
          "biology",
          "GIS"
        ]
      },
      {
        "layer": "Digital agrarian",
        "items": [
          "digital farm twins",
          "terrain maps",
          "animal guilds",
          "eco-energy",
          "school hives"
        ]
      },
      {
        "layer": "Evidence",
        "items": [
          "ROI score",
          "horizon budgets",
          "badge matrix",
          "metadata export",
          "SQL",
          "Neo4j"
        ]
      }
    ],
    "state_objects": [
      "values",
      "staffValues",
      "competitionValues",
      "badgeWeights",
      "cohortValues",
      "tune",
      "horizons",
      "roi"
    ],
    "exports": [
      "JSON scenario export",
      "data/space_wales_v5_2_data.json",
      "schema/cymru_hive_os_v5_2_metadata.sql",
      "graph/cymru_hive_os_v5_2_metadata.cypher"
    ]
  }
};
