# Cymru Hive OS v5.2 · Fixed Tune Playback + Enhanced Panels

This version fixes the V5.1 playback issue and expands the analysis panels.

## Fixed

- Auto-tunes no longer step through all 24 while playing.
- The selected auto-tune now keeps playing until the user changes it.
- Clicking an auto-tune starts/restarts that specific selected tune.
- Overview now reports the correct version: **5.2**.
- Added architecture and metadata panels.

## Retained from V5.1

- Collapsed dropdowns on load
- Zoomable / pannable Wales map
- £2.5bn/year capped budget sliders
- 25,000 staff sliders
- Competition budget sliders
- Badge ROI sliders
- Provider/consumer population sliders
- 2D and pseudo-3D charting
- JSON export

## Enhanced panels

- Overview: corrected version and playback behaviour
- Architecture: layers, state objects and exports
- Metadata: version facts, fixes and value ledgers
- Chart index: all plotted ledgers
- Value sliders: allocation/staff/budget table
- Staff: staff table and metadata
- ROI: score metadata and badge scoring
- Budgets: 1, 5, 10 and 25-year horizons

## Run locally

```bash
cd cymru_hive_os_v5_2_fixed_tune_enhanced_panels
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Apache

```bash
sudo rsync -av --delete ./ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
```

Open:

```text
http://localhost/
```
