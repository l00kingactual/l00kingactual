# Cymru Hive OS v4 · Bio-AI Budget Sliders

Functional planning-grade WebUI for non-weaponised Welsh civil-resilience defence.

Includes:
- £2.5bn/year budget
- 1, 5, 10, 25-year horizons
- budget sliders normalised to 100%
- 2D and pseudo-3D charting updated by sliders
- ACO, BCO, PSO, GA, ANN surrogate, Bayesian risk
- predator/prey fish and birds simulation
- cellular automata ecology grid
- 24 auto-tunes
- SQL and Neo4j seeds

Run:
```bash
python3 -m http.server 8088
```
Open http://127.0.0.1:8088/
