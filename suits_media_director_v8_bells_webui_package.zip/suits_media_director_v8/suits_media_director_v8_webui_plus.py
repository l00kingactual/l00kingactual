#!/usr/bin/env python3
"""$uits Media Director v8 Plus WebUI

A no-dependency local WebUI for selecting video/music assets, predation/prey/comedy
labels, foreground/background settings, previous metadata reuse, logs, and FFmpeg render jobs.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
import time
import uuid
import html
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import suits_media_director_v8 as core

ROOT = Path(__file__).resolve().parent
DEFAULT_OUT = Path(core.DEFAULT_OUT)
JOBS: dict[str, dict[str, Any]] = {}
ASSET_CACHE: dict[str, Any] = {"videos": [], "music": [], "created": 0.0}


def scan_assets(project: str = "all", upload_dirs: list[str] | None = None) -> dict[str, Any]:
    if project == "suits":
        video_dirs = core.SUITS_VIDEO_DIRS.copy()
    elif project == "disciples":
        video_dirs = core.DISCIPLES_VIDEO_DIRS.copy()
    else:
        video_dirs = core.DEFAULT_VIDEO_DIRS.copy()
    music_dirs = core.DEFAULT_MUSIC_DIRS.copy()
    for u in upload_dirs or []:
        if u and u not in video_dirs:
            video_dirs.append(u)
        if u and u not in music_dirs:
            music_dirs.append(u)
    videos, music = core.build_assets(video_dirs, music_dirs, [], [], True, [], [])
    data = {
        "videos": [core.asdict(v) for v in videos],
        "music": [core.asdict(m) for m in music],
        "project": project,
        "created": time.time(),
        "paths": {
            "videos": video_dirs,
            "music": music_dirs,
            "outputs": str(DEFAULT_OUT),
            "upload": "/home/andy/Documents/suitsmafia/upload",
            "server_logs": "/home/andy/Documents/suitsmafia/server_logs",
            "client_logs": "/home/andy/Documents/suitsmafia/client_logs",
        },
        "labels": list(core.LABEL_DICTIONARY.get("event_classes", {}).keys()) + ["kill_candidate", "wounding", "winging", "team_play", "controlled_burst", "lyric_irony", "previous_metadata", "previously_strong"],
        "prey": list(core.LABEL_DICTIONARY.get("prey_types", {}).keys()),
        "comedy": ["funny", "lyric_irony", "sarcasm", "wit", "panic_turn", "poach", "bad_timing", "absurd_motion", "odd_unusual", "comedic_prey"],
        "presets": sorted(core.KNOWN_SONGS.keys()),
    }
    ASSET_CACHE.update(data)
    return data


def get_assets() -> dict[str, Any]:
    if not ASSET_CACHE.get("videos") and not ASSET_CACHE.get("music"):
        return scan_assets()
    return ASSET_CACHE


def write_playlist(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(r["path"] for r in rows if r.get("path")) + "\n", encoding="utf-8")


def slug(s: str) -> str:
    return core.safe_slug(s)[:96]


def run_job(job_id: str, payload: dict[str, Any]) -> None:
    job = JOBS[job_id]
    try:
        assets = get_assets()
        video_ids = set(payload.get("video_ids") or [])
        music_ids = set(payload.get("music_ids") or [])
        videos = [v for v in assets["videos"] if not video_ids or v["asset_id"] in video_ids]
        music = [m for m in assets["music"] if not music_ids or m["asset_id"] in music_ids]
        if not videos:
            raise RuntimeError("No videos selected")
        if not music and not payload.get("song_preset"):
            raise RuntimeError("No music selected")
        out_name = payload.get("out_name") or f"webui_plus_{job_id}"
        out_dir = DEFAULT_OUT / slug(out_name)
        work = out_dir / ".webui_job"
        work.mkdir(parents=True, exist_ok=True)
        vlist = work / "selected_videos.txt"
        mlist = work / "selected_music.txt"
        write_playlist(vlist, videos)
        write_playlist(mlist, music)
        cmd = [sys.executable, str(ROOT / "suits_media_director_v8.py"),
               "--video-playlist", str(vlist),
               "--duration-mode", payload.get("duration_mode", "full"),
               "--analysis-depth", payload.get("analysis_depth", "patient"),
               "--clip-seconds", str(payload.get("clip_seconds", 29)),
               "--out", str(out_dir)]
        if payload.get("song_preset"):
            cmd += ["--song-preset", payload["song_preset"]]
        else:
            cmd += ["--music-playlist", str(mlist)]
        if payload.get("render"):
            cmd.append("--render")
        if payload.get("reuse_previous", True):
            cmd += ["--reuse-previous", "--previous-out-dir", payload.get("previous_out_dir") or str(DEFAULT_OUT)]
        for x in payload.get("selected_labels") or []:
            cmd += ["--selected-label", str(x)]
        for x in payload.get("prey_types") or []:
            cmd += ["--prey-type", str(x)]
        for x in payload.get("comedy_classes") or []:
            cmd += ["--comedy-class", str(x)]
        if payload.get("foreground_model", True):
            cmd += ["--foreground-model", "--foreground-model-mode", payload.get("foreground_model_mode") or "metadata_guided_delta"]
        for x in payload.get("server_log_dirs") or []:
            if x:
                cmd += ["--server-log-dir", x]
        for x in payload.get("client_log_dirs") or []:
            if x:
                cmd += ["--client-log-dir", x]
        job.update({"status": "running", "cmd": cmd, "out_dir": str(out_dir), "started": time.time()})
        log = out_dir / "webui_plus_job.log"
        with log.open("w", encoding="utf-8") as fh:
            fh.write("COMMAND:\n" + " ".join(cmd) + "\n\n")
            proc = subprocess.run(cmd, cwd=str(ROOT), text=True, stdout=fh, stderr=subprocess.STDOUT)
        job.update({"status": "done" if proc.returncode == 0 else "error", "returncode": proc.returncode, "finished": time.time(), "log": str(log)})
    except Exception as exc:
        job.update({"status": "error", "error": str(exc), "finished": time.time()})


HTML_PAGE = r"""<!doctype html>
<html><head><meta charset="utf-8"><title>$uits Media Director v8 Plus</title>
<style>
:root{--bg:#121b24;--panel:#1d2b37;--panel2:#243747;--line:#5b7891;--text:#eef6fb;--muted:#b5c7d4;--accent:#4aa3ff;--hot:#ffb84a;--ok:#52d273}*{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#101923,#1c2935);color:var(--text);font-family:Arial,sans-serif}header{padding:18px 24px;background:#203141;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:3}h1{margin:0}.sub{color:var(--muted)}main{display:grid;grid-template-columns:340px 1fr;gap:14px;padding:14px}.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px;box-shadow:0 4px 16px #0005}.full{grid-column:1/-1}.scroll{max-height:380px;overflow:auto;background:#111b24;border:1px solid #39566d;border-radius:10px;padding:8px}label{display:block;padding:5px;border-radius:8px}label:hover{background:#2b4154}input,select,button{font:inherit}button,.btn{border:1px solid #95c5ff;background:#2869b1;color:white;border-radius:10px;padding:9px 12px;margin:3px;cursor:pointer;text-decoration:none;display:inline-block}button.hot{background:#ad5d14;border-color:#ffd27c}button.ok{background:#227a48;border-color:#80e7ad}button.alt{background:#344a5e}small,.hint{color:var(--muted)}pre{white-space:pre-wrap;background:#0e1720;border:1px solid #35546b;border-radius:10px;padding:10px;max-height:300px;overflow:auto}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.pill{display:inline-block;background:#2e4a60;border-radius:99px;padding:3px 8px;margin:2px}.toolbar{position:sticky;top:86px;background:var(--panel);z-index:2;padding-bottom:8px}.field{width:100%;padding:8px;border-radius:8px;border:1px solid #557088;background:#111b24;color:var(--text)}
</style></head><body><header><h1>🎬 $uits Media Director v8 Plus WebUI</h1><div class="sub">Video + music selection • prey/predation checkboxes • comedy/irony • previous metadata • server/client logs • foreground/background model • render jobs</div></header>
<main>
<section class="card"><h2>⚙️ Run controls</h2>
<label>🎵 Preset<select id="preset" class="field"><option value="">selected music</option></select></label>
<label>🎞 Mode<select id="duration" class="field"><option value="clip29">29s social</option><option value="full" selected>full song</option><option value="both">both</option></select></label>
<label>⏱ Clip seconds<input id="clipsec" class="field" value="29"></label>
<label>🧠 Analysis<select id="depth" class="field"><option>fast</option><option selected>patient</option></select></label>
<label>📦 Output name<input id="outname" class="field" value="webui_plus_run"></label>
<label><input id="render" type="checkbox" checked> 🎬 render MP4 outputs</label>
<label><input id="reuse" type="checkbox" checked> 🗃️ reuse previous metadata</label>
<label><input id="fg" type="checkbox" checked> 🌌 foreground/background sidecar</label>
<label>🖥️ Server logs<input id="serverlogs" class="field" value="/home/andy/Documents/suitsmafia/server_logs"></label>
<label>🎮 Client logs<input id="clientlogs" class="field" value="/home/andy/Documents/suitsmafia/client_logs"></label>
<div class="toolbar"><button class="ok" onclick="runJob()" title="🎬 Render selected music/video using checked labels and metadata">🎬 Render selected</button><button onclick="refreshAssets()" title="🔄 Rescan all configured project folders">🔄 Refresh</button><button class="alt" onclick="jobs()">📋 Jobs</button></div><pre id="status">ready</pre></section>
<section class="card"><h2>🌌 Foreground/background calculus</h2><p>Pixels alone are bright dots or black play. Accuracy improves when foreground deltas are judged against expected background, previous scans, cue history, and log truth.</p><span class="pill">centre patch delta</span><span class="pill">red impact proxy</span><span class="pill">motion vector</span><span class="pill">route deviation</span><span class="pill">metadata catalogue</span><span class="pill">server truth</span><span class="pill">beat/cue fit</span></section>
<section class="card full"><h2>🎛 Assets</h2><div><button onclick="setAll('video',true)">✅ all videos</button><button class="alt" onclick="setAll('video',false)">⬜ no videos</button><button onclick="setAll('music',true)">✅ all music</button><button class="alt" onclick="setAll('music',false)">⬜ no music</button></div><div class="grid2"><div><h3>🎥 Videos <small id="vc"></small></h3><div id="videos" class="scroll"></div></div><div><h3>🎵 Music <small id="mc"></small></h3><div id="music" class="scroll"></div></div></div></section>
<section class="card"><h2>🔥 Predation / events</h2><div><button onclick="setAll('label',true)">✅ all</button><button class="alt" onclick="setAll('label',false)">⬜ none</button></div><div id="labels" class="scroll"></div></section>
<section class="card"><h2>🐑 Prey behaviour</h2><div><button onclick="setAll('prey',true)">✅ all</button><button class="alt" onclick="setAll('prey',false)">⬜ none</button></div><div id="prey" class="scroll"></div></section>
<section class="card"><h2>😂 Comedy / irony</h2><div><button onclick="setAll('comedy',true)">✅ all</button><button class="alt" onclick="setAll('comedy',false)">⬜ none</button></div><div id="comedy" class="scroll"></div></section>
<section class="card"><h2>📁 Paths</h2><pre id="paths"></pre></section>
<section class="card full"><h2>🕴️ [o][o]</h2><p>Static stars in the back, chaos in the front. Tick the behaviours, choose the tune, press render, and let the wee machine ask: shot, prey, panic, poach, or Dougie being a twat?</p></section>
</main><script>
let DATA={videos:[],music:[],labels:[],prey:[],comedy:[],presets:[],paths:{}};
function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
async function refreshAssets(){status('scanning...'); let r=await fetch('/api/assets'); DATA=await r.json(); renderLists(); status('loaded '+DATA.videos.length+' videos and '+DATA.music.length+' music files')}
function renderLists(){document.getElementById('vc').textContent='('+DATA.videos.length+')';document.getElementById('mc').textContent='('+DATA.music.length+')';document.getElementById('videos').innerHTML=DATA.videos.map(x=>`<label title="${esc(x.path)}"><input class="video" type="checkbox" value="${x.asset_id}"> 🎥 ${esc(x.name)} <small>${(x.duration_s||0).toFixed(1)}s</small></label>`).join('');document.getElementById('music').innerHTML=DATA.music.map(x=>`<label title="${esc(x.path)}"><input class="music" type="checkbox" value="${x.asset_id}"> 🎵 ${esc(x.name)} <small>${(x.duration_s||0).toFixed(1)}s</small></label>`).join('');document.getElementById('labels').innerHTML=DATA.labels.map(x=>`<label><input class="label" type="checkbox" value="${esc(x)}"> 🔥 ${esc(x)}</label>`).join('');document.getElementById('prey').innerHTML=DATA.prey.map(x=>`<label><input class="prey" type="checkbox" value="${esc(x)}"> 🐑 ${esc(x)}</label>`).join('');document.getElementById('comedy').innerHTML=DATA.comedy.map(x=>`<label><input class="comedy" type="checkbox" value="${esc(x)}"> 😂 ${esc(x)}</label>`).join('');document.getElementById('preset').innerHTML='<option value="">selected music</option>'+DATA.presets.map(x=>`<option>${esc(x)}</option>`).join('');document.getElementById('paths').textContent=JSON.stringify(DATA.paths,null,2)}
function ids(cls){return Array.from(document.querySelectorAll('input.'+cls+':checked')).map(x=>x.value)}
function setAll(cls,val){document.querySelectorAll('input.'+cls).forEach(x=>x.checked=val)}
function lines(id){return document.getElementById(id).value.split(/[,\n]/).map(x=>x.trim()).filter(Boolean)}
function status(x){document.getElementById('status').textContent=typeof x==='string'?x:JSON.stringify(x,null,2)}
async function runJob(){let payload={song_preset:document.getElementById('preset').value,duration_mode:document.getElementById('duration').value,clip_seconds:parseFloat(document.getElementById('clipsec').value||'29'),analysis_depth:document.getElementById('depth').value,out_name:document.getElementById('outname').value,render:document.getElementById('render').checked,reuse_previous:document.getElementById('reuse').checked,foreground_model:document.getElementById('fg').checked,server_log_dirs:lines('serverlogs'),client_log_dirs:lines('clientlogs'),video_ids:ids('video'),music_ids:ids('music'),selected_labels:ids('label'),prey_types:ids('prey'),comedy_classes:ids('comedy')}; status('starting job...');let r=await fetch('/api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});let j=await r.json();status(j); poll(j.job_id)}
async function poll(id){for(let i=0;i<999;i++){await new Promise(r=>setTimeout(r,1500));let r=await fetch('/api/job?id='+encodeURIComponent(id));let j=await r.json();status(j);if(['done','error'].includes(j.status))break}}
async function jobs(){let r=await fetch('/api/jobs');status(await r.json())}
refreshAssets();
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args: Any) -> None:
        return
    def send_json(self, data: Any, status: int = 200) -> None:
        raw = json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8")
        self.send_response(status); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self) -> None:
        url = urllib.parse.urlparse(self.path)
        if url.path == "/":
            raw = HTML_PAGE.encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        if url.path == "/api/assets":
            return self.send_json(scan_assets())
        if url.path == "/api/jobs":
            return self.send_json(JOBS)
        if url.path == "/api/job":
            q = urllib.parse.parse_qs(url.query); jid = (q.get("id") or [""])[0]
            return self.send_json(JOBS.get(jid, {"status":"missing"}))
        if url.path.startswith("/outputs/"):
            rel = url.path[len("/outputs/"):]
            fp = (DEFAULT_OUT / rel).resolve()
            if not str(fp).startswith(str(DEFAULT_OUT.resolve())) or not fp.exists() or not fp.is_file():
                self.send_error(404); return
            raw = fp.read_bytes(); self.send_response(200); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        self.send_error(404)
    def do_POST(self) -> None:
        if self.path != "/api/run":
            self.send_error(404); return
        length = int(self.headers.get("Content-Length") or "0")
        payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        jid = uuid.uuid4().hex[:10]
        JOBS[jid] = {"job_id": jid, "status": "queued", "created": time.time(), "payload": payload}
        th = threading.Thread(target=run_job, args=(jid, payload), daemon=True)
        th.start()
        self.send_json({"ok": True, "job_id": jid, "status": "queued"})


def main() -> int:
    ap = argparse.ArgumentParser(description="$uits Media Director v8 Plus WebUI")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8788)
    args = ap.parse_args()
    scan_assets()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"$uits Media Director v8 Plus WebUI: http://{args.host}:{args.port}")
    print(f"Outputs: {DEFAULT_OUT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping WebUI.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
