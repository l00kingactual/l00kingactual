(function(){
"use strict";
const $ = id => document.getElementById(id);
let services=[], caps=[], features=[], currentImageUrl="", lastRemotePayload=null;
let localLayers=[], activeLocalLayers=new Set(["major_roads","railways","forest_woodland","dark_sky_sites","hospitals","fire_stations","libraries"]);
let hitItems=[];

function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function status(s){$("status").textContent=s;}
function service(){return services.find(x=>x.id===$("serviceSelect").value);}
function bbox(){return {minLon:Number($("minLon").value),minLat:Number($("minLat").value),maxLon:Number($("maxLon").value),maxLat:Number($("maxLat").value)};}
function proxy(mode, extra={}){return "api/ows_proxy.php?"+new URLSearchParams({id:$("serviceSelect").value,mode,...extra}).toString();}
function requestUrl(mode, extra={}){
  if($("requestPath").value==="proxy")return proxy(mode,extra);
  const svc=service();
  if(mode==="capabilities")return svc.capabilities_url;
  const sep=svc.base_url.includes("?")?"&":"?";
  return svc.base_url+sep+new URLSearchParams(extra).toString();
}
function firstCoord(coords){
  if(!Array.isArray(coords))return null;
  if(typeof coords[0]==="number")return coords;
  for(const c of coords){const r=firstCoord(c);if(r)return r;}
  return null;
}
function project(lon,lat){
  const b=bbox(),c=$("map");
  return {x:(lon-b.minLon)/(b.maxLon-b.minLon||1)*c.width,y:c.height-(lat-b.minLat)/(b.maxLat-b.minLat||1)*c.height};
}
function inBox(lon,lat){
  const b=bbox();
  return lon>=b.minLon&&lon<=b.maxLon&&lat>=b.minLat&&lat<=b.maxLat;
}

async function loadServices(){
  const r=await fetch("data/ows_services.json",{cache:"no-store"});
  services=await r.json();
  $("serviceSelect").innerHTML=services.map(s=>`<option value="${s.id}">${s.kind} · ${esc(s.label)}</option>`).join("");
  try{
    const lr=await fetch("data/local_overlay_layers.json",{cache:"no-store"});
    const lj=await lr.json();
    localLayers=lj.layers||[];
    activeLocalLayers = new Set(localLayers.filter(l=>l.defaultVisible!==false).map(l=>l.id));
  }catch(e){
    localLayers=[];
    console.warn("Local overlay load failed", e);
  }
  renderLocalLayerToggles();
  drawBase(); describe();
}
function updateToolbarLayerButtons(){
  document.querySelectorAll("[data-layer-button]").forEach(btn=>{
    btn.classList.toggle("activeLayer", activeLocalLayers.has(btn.dataset.layerButton));
  });
}
function renderLocalLayerToggles(){
  const box=$("localLayerToggles");
  if(!box)return;
  box.innerHTML=localLayers.map(l=>`<label class="layerToggle">
    <input type="checkbox" data-local-layer="${esc(l.id)}" ${activeLocalLayers.has(l.id)?"checked":""}>
    <span><strong>${esc(l.icon||"•")} ${esc(l.name)}</strong><small>${esc(l.kind)} · ${l.features?.length||0} features</small></span>
  </label>`).join("") || "<p>No local overlays loaded.</p>";
  document.querySelectorAll("[data-local-layer]").forEach(cb=>cb.onchange=()=>{
    if(cb.checked)activeLocalLayers.add(cb.dataset.localLayer); else activeLocalLayers.delete(cb.dataset.localLayer);
    updateToolbarLayerButtons();
    drawBase();
  });
  updateToolbarLayerButtons();
}
function describe(){
  const s=service();
  $("serviceInfo").textContent=JSON.stringify(s,null,2);
  $("layerSelect").innerHTML='<option value="">load capabilities first</option>';
  caps=[]; features=[]; $("capCount").textContent="0"; $("featureCount").textContent="0";
  drawBase();
}

function drawBase(){
  const c=$("map"),ctx=c.getContext("2d"),b=bbox();
  hitItems=[];
  ctx.clearRect(0,0,c.width,c.height);
  const bg=ctx.createLinearGradient(0,0,0,c.height);bg.addColorStop(0,"#081426");bg.addColorStop(1,"#101c2f");ctx.fillStyle=bg;ctx.fillRect(0,0,c.width,c.height);
  ctx.strokeStyle="rgba(255,255,255,.14)";
  for(let i=0;i<=8;i++){ctx.beginPath();ctx.moveTo(i*c.width/8,0);ctx.lineTo(i*c.width/8,c.height);ctx.stroke();ctx.beginPath();ctx.moveTo(0,i*c.height/8);ctx.lineTo(c.width,i*c.height/8);ctx.stroke();}
  ctx.fillStyle="rgba(49,71,94,.55)";ctx.strokeStyle="#eaf2ff";ctx.lineWidth=3;ctx.beginPath();
  const poly=[[-4.7,53.45],[-4.15,53.35],[-3.0,53.1],[-2.85,52.75],[-3.35,52.3],[-3.05,51.9],[-2.85,51.58],[-3.25,51.42],[-4.1,51.52],[-4.85,51.75],[-5.25,51.92],[-4.7,52.18],[-4.3,52.65],[-4.7,53.45]];
  poly.forEach((p,i)=>{const q=project(p[0],p[1]);i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y);});ctx.closePath();ctx.fill();ctx.stroke();

  drawLocalOverlays(ctx);
  drawWfsFeatures(ctx);

  ctx.fillStyle="#b9cbe2";ctx.font="13px system-ui";ctx.textAlign="left";
  ctx.fillText(`bbox ${b.minLon}, ${b.minLat}, ${b.maxLon}, ${b.maxLat}`,18,c.height-18);
}

function addHit(item){ hitItems.push(item); }

function drawLocalOverlays(ctx){
  const legend=[];
  for(const layer of localLayers){
    if(!activeLocalLayers.has(layer.id))continue;
    const st=layer.style||{};
    legend.push(`${layer.icon||"•"} ${layer.name}`);
    if(layer.kind==="line"){
      ctx.strokeStyle=st.stroke||"#facc15";ctx.lineWidth=st.width||3;ctx.setLineDash(st.dash || (layer.id==="railways"?[8,5]:[]));
      for(const f of layer.features||[]){
        const pts=f.coords||[];
        ctx.beginPath();
        pts.forEach((pt,i)=>{const q=project(pt[0],pt[1]); i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y);});
        ctx.stroke();
        for(let i=1;i<pts.length;i++){
          const a=project(pts[i-1][0],pts[i-1][1]), b=project(pts[i][0],pts[i][1]);
          addHit({kind:"line", layer, feature:f, x1:a.x, y1:a.y, x2:b.x, y2:b.y});
        }
        if(pts.length){const mid=pts[Math.floor(pts.length/2)],q=project(mid[0],mid[1]);label(ctx,f.name,q.x,q.y,st.stroke||"#fff");}
      }
      ctx.setLineDash([]);
    }else if(layer.kind==="polygon"){
      for(const f of layer.features||[]){
        ctx.fillStyle=st.fill||"rgba(74,222,128,.25)";ctx.strokeStyle=st.stroke||"#4ade80";ctx.lineWidth=st.width||2;
        for(const ring of f.coords||[]){
          const projected=ring.map(pt=>project(pt[0],pt[1]));
          ctx.beginPath();
          projected.forEach((q,i)=>{i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y);});
          ctx.closePath();ctx.fill();ctx.stroke();
          const xs=projected.map(p=>p.x), ys=projected.map(p=>p.y);
          addHit({kind:"polygon", layer, feature:f, minX:Math.min(...xs), maxX:Math.max(...xs), minY:Math.min(...ys), maxY:Math.max(...ys), points:projected});
        }
        const ring=(f.coords||[])[0]||[]; if(ring.length){const mid=ring[Math.floor(ring.length/2)],q=project(mid[0],mid[1]);label(ctx,f.name,q.x,q.y,st.stroke||"#4ade80");}
      }
    }else if(layer.kind==="point"){
      for(const f of layer.features||[]){
        if(!inBox(f.lon,f.lat))continue;
        const q=project(f.lon,f.lat), r=st.radius||8;
        ctx.fillStyle=st.fill||"#a78bfa";ctx.strokeStyle=st.stroke||"#fff";ctx.lineWidth=2;
        ctx.beginPath();ctx.arc(q.x,q.y,r,0,Math.PI*2);ctx.fill();ctx.stroke();
        ctx.fillStyle="#fff";ctx.font="15px system-ui";ctx.textAlign="center";ctx.fillText(layer.icon||"•",q.x,q.y+5);
        label(ctx,f.name,q.x,q.y+18,st.fill||"#a78bfa");
        addHit({kind:"point", layer, feature:f, x:q.x, y:q.y, r:r+8});
      }
    }
  }
  ctx.fillStyle="#eaf2ff";ctx.font="12px system-ui";ctx.textAlign="left";
  ctx.fillText("Local layers: "+(legend.join(" · ")||"none"),18,24);
}
function label(ctx,text,x,y,color){
  ctx.save();
  ctx.font="11px system-ui";ctx.textAlign="center";ctx.fillStyle="rgba(2,6,23,.82)";
  const short=String(text||"").slice(0,42);
  const w=Math.min(230,ctx.measureText(short).width+10);
  ctx.fillRect(x-w/2,y+4,w,17);
  ctx.fillStyle=color||"#fff";ctx.fillText(short,x,y+17);
  ctx.restore();
}
function drawWfsFeatures(ctx){
  features.forEach((f,i)=>{
    if(f.geometry){
      const coord=firstCoord(f.geometry.coordinates);
      if(coord&&inBox(coord[0],coord[1])){
        const q=project(coord[0],coord[1]);
        ctx.fillStyle="#4ade80";ctx.beginPath();ctx.arc(q.x,q.y,5,0,Math.PI*2);ctx.fill();
        addHit({kind:"wfs", layer:{name:"WFS remote feature", icon:"📍"}, feature:{id:f.id||("wfs_"+i), name:f.properties?.name || f.properties?.Name || f.id || "WFS feature", class:f.geometry?.type, planning_use:"remote WFS feature", properties:f.properties||{}}, x:q.x, y:q.y, r:10});
      }
    }
  });
}

function pointLineDistance(px,py,x1,y1,x2,y2){
  const A=px-x1,B=py-y1,C=x2-x1,D=y2-y1;
  const dot=A*C+B*D,len=C*C+D*D;
  let t=len?dot/len:0;t=Math.max(0,Math.min(1,t));
  const x=x1+t*C,y=y1+t*D;
  return Math.hypot(px-x,py-y);
}
function pointInPoly(x,y,points){
  let inside=false;
  for(let i=0,j=points.length-1;i<points.length;j=i++){
    const xi=points[i].x, yi=points[i].y, xj=points[j].x, yj=points[j].y;
    const intersect=((yi>y)!=(yj>y))&&(x<(xj-xi)*(y-yi)/(yj-yi+0.000001)+xi);
    if(intersect)inside=!inside;
  }
  return inside;
}
function findHit(x,y){
  for(let i=hitItems.length-1;i>=0;i--){
    const it=hitItems[i];
    if(it.kind==="point"||it.kind==="wfs"){
      if(Math.hypot(x-it.x,y-it.y)<=it.r)return it;
    }else if(it.kind==="line"){
      if(pointLineDistance(x,y,it.x1,it.y1,it.x2,it.y2)<=8)return it;
    }else if(it.kind==="polygon"){
      if(x>=it.minX&&x<=it.maxX&&y>=it.minY&&y<=it.maxY&&pointInPoly(x,y,it.points))return it;
    }
  }
  return null;
}
function showMetadataCard(hit, clientX, clientY){
  const card=$("metadataCard"); if(!card)return;
  if(!hit){card.hidden=true; return;}
  const f=hit.feature||{}, l=hit.layer||{};
  const props=f.properties?`<details><summary>properties</summary><pre>${esc(JSON.stringify(f.properties,null,2)).slice(0,1600)}</pre></details>`:"";
  card.innerHTML=`<h3>${esc(l.icon||"•")} ${esc(f.name||f.id||l.name)}</h3>
    <p><strong>Layer:</strong> ${esc(l.name||"")}</p>
    <p><strong>Type:</strong> ${esc(hit.kind)} · ${esc(f.class||l.kind||"")}</p>
    <p><strong>Planning use:</strong> ${esc(f.planning_use||"planning evidence")}</p>
    <p><strong>ID:</strong> <code>${esc(f.id||"")}</code></p>${props}`;
  const box=$("map").getBoundingClientRect();
  card.style.left=Math.min(box.width-380, Math.max(8, clientX-box.left+14))+"px";
  card.style.top=Math.min(box.height-220, Math.max(8, clientY-box.top+14))+"px";
  card.hidden=false;
}

async function loadCaps(){
  const s=service(); status("Fetching capabilities…");
  const url=requestUrl("capabilities");
  $("urlOut").textContent=url;
  try{
    const r=await fetch(url,{cache:"no-store"});const txt=await r.text();
    if(!r.ok)throw new Error(txt.slice(0,1200));
    const xml=new DOMParser().parseFromString(txt,"application/xml");
    const names=[...xml.getElementsByTagName("Name")].map(x=>x.textContent.trim()).filter(Boolean);
    const titles=[...xml.getElementsByTagName("Title")].map(x=>x.textContent.trim()).filter(Boolean);
    caps=[...new Set(names)].filter(x=>!["WMS","WFS","WPS"].includes(x)).slice(0,500);
    $("layerSelect").innerHTML=caps.length?caps.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join(""):'<option value="">no names found</option>';
    $("capCount").textContent=caps.length;
    $("capsOut").textContent=JSON.stringify({service:s.label,kind:s.kind,names:caps,titles:titles.slice(0,100)},null,2);
    lastRemotePayload={type:"capabilities",service:s,caps,titles};
    status(`Capabilities loaded: ${caps.length} names.`);
  }catch(e){$("capsOut").textContent=String(e);status("Capabilities failed. Use Apache/PHP proxy mode and check internet.");}
}
function drawWms(){
  const s=service(); if(s.kind!=="WMS"){status("Choose a WMS service.");return;}
  const layer=$("layerSelect").value;if(!layer){status("Load capabilities and choose a layer.");return;}
  const b=bbox(),w=$("map").width,h=$("map").height,version=$("wmsVersion").value;
  const params=version==="1.3.0"?
    {SERVICE:"WMS",VERSION:"1.3.0",REQUEST:"GetMap",LAYERS:layer,STYLES:"",CRS:"EPSG:4326",BBOX:`${b.minLat},${b.minLon},${b.maxLat},${b.maxLon}`,WIDTH:w,HEIGHT:h,FORMAT:"image/png",TRANSPARENT:"TRUE"}:
    {SERVICE:"WMS",VERSION:"1.1.1",REQUEST:"GetMap",LAYERS:layer,STYLES:"",SRS:"EPSG:4326",BBOX:`${b.minLon},${b.minLat},${b.maxLon},${b.maxLat}`,WIDTH:w,HEIGHT:h,FORMAT:"image/png",TRANSPARENT:"TRUE"};
  const url=$("requestPath").value==="proxy"?proxy("wms",{layer,wmsVersion:version,width:w,height:h,...b}):requestUrl("wms",params);
  $("urlOut").textContent=url; currentImageUrl=url;
  const img=$("wmsOverlay"); img.style.display="block"; img.style.opacity=$("opacity").value; img.onload=()=>status("WMS image loaded."); img.onerror=()=>status("WMS failed: try another layer or version."); img.src=url+(url.includes("?")?"&":"?")+"_t="+Date.now();
}
async function loadWfs(){
  const s=service(); if(s.kind!=="WFS"){status("Choose a WFS service.");return;}
  const typeName=$("layerSelect").value;if(!typeName){status("Load capabilities and choose a feature type.");return;}
  const b=bbox();
  const params={SERVICE:"WFS",VERSION:"1.1.0",REQUEST:"GetFeature",TYPENAME:typeName,OUTPUTFORMAT:"application/json",SRSNAME:"EPSG:4326",BBOX:`${b.minLon},${b.minLat},${b.maxLon},${b.maxLat},EPSG:4326`,MAXFEATURES:$("maxFeatures").value};
  const url=$("requestPath").value==="proxy"?proxy("wfs",{typeName,maxFeatures:$("maxFeatures").value,...b}):requestUrl("wfs",params);
  $("urlOut").textContent=url; status("Fetching WFS features…");
  try{
    const r=await fetch(url,{cache:"no-store"});const txt=await r.text(); if(!r.ok)throw new Error(txt.slice(0,1200));
    let parsed=null; try{parsed=JSON.parse(txt);}catch(e){}
    if(parsed&&parsed.features){features=parsed.features;$("wfsOut").textContent=JSON.stringify({type:"GeoJSON",count:features.length,sample:features.slice(0,3)},null,2);}
    else{const xml=new DOMParser().parseFromString(txt,"application/xml");const members=[...xml.getElementsByTagNameNS("*","featureMember")];features=members.slice(0,200).map((m,i)=>({id:i,text:m.textContent.slice(0,400)}));$("wfsOut").textContent=JSON.stringify({type:"XML/GML summary",count:features.length,sample:features.slice(0,3)},null,2);}
    $("featureCount").textContent=features.length; lastRemotePayload={type:"wfs",service:s,typeName,features}; drawBase(); status(`WFS fetched: ${features.length} features.`);
  }catch(e){$("wfsOut").textContent=String(e);status("WFS failed. Try a smaller bbox or proxy mode.");}
}
async function loadWpsCaps(){
  const s=service(); if(s.kind!=="WPS"){status("Choose a WPS service.");return;}
  const url=$("requestPath").value==="proxy"?proxy("wps_capabilities"):s.capabilities_url;
  $("urlOut").textContent=url; status("Fetching WPS capabilities…");
  try{
    const r=await fetch(url,{cache:"no-store"});const txt=await r.text();if(!r.ok)throw new Error(txt.slice(0,1200));
    const xml=new DOMParser().parseFromString(txt,"application/xml");
    const ids=[...xml.getElementsByTagNameNS("*","Identifier")].map(x=>x.textContent.trim()).filter(Boolean);
    $("wpsOut").textContent=JSON.stringify({identifiers:[...new Set(ids)].slice(0,200),rawSize:txt.length},null,2);
    $("layerSelect").innerHTML=[...new Set(ids)].slice(0,200).map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join("")||'<option value="">no process identifiers found</option>';
    status("WPS capabilities received. If identifiers are empty, WPS is probably unavailable or not enabled.");
  }catch(e){$("wpsOut").textContent=String(e);status("WPS failed. DataMapWales may not expose WPS; use local Python processing over WFS instead.");}
}
async function describeWps(){
  const s=service(); if(s.kind!=="WPS"){status("Choose a WPS service.");return;}
  const identifier=$("layerSelect").value;if(!identifier){status("Choose a WPS process identifier.");return;}
  const url=$("requestPath").value==="proxy"?proxy("wps_describe",{identifier}):requestUrl("wps",{SERVICE:"WPS",VERSION:"1.0.0",REQUEST:"DescribeProcess",IDENTIFIER:identifier});
  $("urlOut").textContent=url; status("Fetching WPS DescribeProcess…");
  try{const r=await fetch(url,{cache:"no-store"});const txt=await r.text();if(!r.ok)throw new Error(txt.slice(0,1200));$("wpsOut").textContent=txt.slice(0,6000);status("WPS DescribeProcess received.");}
  catch(e){$("wpsOut").textContent=String(e);status("WPS DescribeProcess failed.");}
}
function scoreRemote(){
  const s=service(); const text=[s.label,s.theme,s.notes,$("layerSelect").value,[...activeLocalLayers].join(" ")].join(" ").toLowerCase();
  let score=0;
  if(text.includes("roads")||text.includes("rail"))score+=22;
  if(text.includes("hospital")||text.includes("fire")||text.includes("libraries")||text.includes("library"))score+=30;
  if(text.includes("dark")||text.includes("sky"))score+=18;
  if(text.includes("habitat")||text.includes("ecolog")||text.includes("protected")||text.includes("woodland")||text.includes("forest"))score+=35;
  if(text.includes("agric")||text.includes("land")||text.includes("farm"))score+=30;
  if(text.includes("lidar")||text.includes("terrain"))score+=30;
  if(text.includes("wfs"))score+=15;
  score+=Math.min(20,caps.length/10)+Math.min(20,features.length/10)+activeLocalLayers.size*4;
  score=Math.round(score);
  $("remoteScore").textContent=score;
  $("scoreOut").textContent=JSON.stringify({service:s.id,layer:$("layerSelect").value,localLayers:[...activeLocalLayers],caps:caps.length,features:features.length,score,meaning:"planning score for farm-twin/ecology/emergency/astronomy usefulness"},null,2);
}
function exportJson(){
  const payload={version:"v5.4+v6-remote-ows-v3-toolbar-metadata",service:service(),selected:$("layerSelect").value,bbox:bbox(),localLayers:[...activeLocalLayers],currentImageUrl,caps,featuresCount:features.length,lastRemotePayload,exportedAt:new Date().toISOString()};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="cymru_hive_remote_ows_toolbar_metadata_export.json"; a.click(); URL.revokeObjectURL(a.href);
}
function bind(){
  $("serviceSelect").onchange=describe;
  $("loadCaps").onclick=loadCaps; $("drawWms").onclick=drawWms; $("loadWfs").onclick=loadWfs; $("loadWpsCaps").onclick=loadWpsCaps; $("describeWps").onclick=describeWps; $("scoreRemote").onclick=scoreRemote; $("exportJson").onclick=exportJson;
  $("opacity").oninput=()=>{$("wmsOverlay").style.opacity=$("opacity").value;};
  $("allLocalLayers").onclick=()=>{activeLocalLayers=new Set(localLayers.map(l=>l.id));renderLocalLayerToggles();drawBase();};
  $("clearLocalLayers").onclick=()=>{activeLocalLayers.clear();renderLocalLayerToggles();drawBase();};
  const tbAll=$("toolbarAllLocalLayers"); if(tbAll)tbAll.onclick=()=>{activeLocalLayers=new Set(localLayers.map(l=>l.id));renderLocalLayerToggles();drawBase();};
  const tbClear=$("toolbarClearLocalLayers"); if(tbClear)tbClear.onclick=()=>{activeLocalLayers.clear();renderLocalLayerToggles();drawBase();};
  document.querySelectorAll("[data-layer-button]").forEach(btn=>btn.onclick=()=>{
    const id=btn.dataset.layerButton;
    if(activeLocalLayers.has(id))activeLocalLayers.delete(id); else activeLocalLayers.add(id);
    renderLocalLayerToggles(); drawBase();
  });
  document.querySelectorAll("[data-bbox]").forEach(b=>b.onclick=()=>{const v=JSON.parse(b.dataset.bbox);$("minLon").value=v[0];$("minLat").value=v[1];$("maxLon").value=v[2];$("maxLat").value=v[3];drawBase();});
  ["minLon","minLat","maxLon","maxLat"].forEach(id=>$(id).oninput=drawBase);
  const canvas=$("map");
  canvas.addEventListener("mousemove", e=>{
    const rect=canvas.getBoundingClientRect();
    const x=(e.clientX-rect.left)*(canvas.width/rect.width);
    const y=(e.clientY-rect.top)*(canvas.height/rect.height);
    showMetadataCard(findHit(x,y), e.clientX, e.clientY);
  });
  canvas.addEventListener("mouseleave", ()=>showMetadataCard(null,0,0));
}
document.addEventListener("DOMContentLoaded",async()=>{await loadServices();bind();});
})();