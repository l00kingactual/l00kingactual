<?php
// Cymru Hive OS V5.4+ OWS proxy. Local development only.
// It uses an allow-list in data/ows_services.json and refuses arbitrary URLs.
$services = json_decode(file_get_contents(__DIR__ . '/../data/ows_services.json'), true);
$id = $_GET['id'] ?? '';
$mode = $_GET['mode'] ?? 'capabilities';
$svc = null;
foreach ($services as $s) {
    if ($s['id'] === $id) { $svc = $s; break; }
}
if ($svc === null) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(400);
    echo json_encode(['error'=>'Unknown service id','allowed'=>array_map(fn($x)=>$x['id'],$services)], JSON_PRETTY_PRINT);
    exit;
}
function append_params($base, $params) {
    $sep = strpos($base, '?') === false ? '?' : '&';
    return $base . $sep . http_build_query($params);
}
$url = $svc['capabilities_url'];
$contentType = 'application/xml; charset=utf-8';

if ($mode === 'capabilities') {
    $url = $svc['capabilities_url'];
} elseif ($mode === 'wms') {
    if ($svc['kind'] !== 'WMS') { http_response_code(400); echo 'Selected service is not WMS'; exit; }
    $layer = $_GET['layer'] ?? '';
    $version = $_GET['wmsVersion'] ?? '1.1.1';
    $width = max(64, min(4096, intval($_GET['width'] ?? 1120)));
    $height = max(64, min(4096, intval($_GET['height'] ?? 720)));
    $minLon = floatval($_GET['minLon'] ?? -5.85); $minLat = floatval($_GET['minLat'] ?? 51.25);
    $maxLon = floatval($_GET['maxLon'] ?? -2.55); $maxLat = floatval($_GET['maxLat'] ?? 53.55);
    if ($version === '1.3.0') {
        $params = ['SERVICE'=>'WMS','VERSION'=>'1.3.0','REQUEST'=>'GetMap','LAYERS'=>$layer,'STYLES'=>'','CRS'=>'EPSG:4326','BBOX'=>"$minLat,$minLon,$maxLat,$maxLon",'WIDTH'=>$width,'HEIGHT'=>$height,'FORMAT'=>'image/png','TRANSPARENT'=>'TRUE'];
    } else {
        $params = ['SERVICE'=>'WMS','VERSION'=>'1.1.1','REQUEST'=>'GetMap','LAYERS'=>$layer,'STYLES'=>'','SRS'=>'EPSG:4326','BBOX'=>"$minLon,$minLat,$maxLon,$maxLat",'WIDTH'=>$width,'HEIGHT'=>$height,'FORMAT'=>'image/png','TRANSPARENT'=>'TRUE'];
    }
    $url = append_params($svc['base_url'], $params);
    $contentType = 'image/png';
} elseif ($mode === 'wfs') {
    if ($svc['kind'] !== 'WFS') { http_response_code(400); echo 'Selected service is not WFS'; exit; }
    $typeName = $_GET['typeName'] ?? '';
    $maxFeatures = max(1, min(1000, intval($_GET['maxFeatures'] ?? 100)));
    $minLon = floatval($_GET['minLon'] ?? -5.85); $minLat = floatval($_GET['minLat'] ?? 51.25);
    $maxLon = floatval($_GET['maxLon'] ?? -2.55); $maxLat = floatval($_GET['maxLat'] ?? 53.55);
    $params = ['SERVICE'=>'WFS','VERSION'=>'1.1.0','REQUEST'=>'GetFeature','TYPENAME'=>$typeName,'OUTPUTFORMAT'=>'application/json','SRSNAME'=>'EPSG:4326','BBOX'=>"$minLon,$minLat,$maxLon,$maxLat,EPSG:4326",'MAXFEATURES'=>$maxFeatures];
    $url = append_params($svc['base_url'], $params);
    $contentType = 'application/json; charset=utf-8';
} elseif ($mode === 'wps_capabilities') {
    if ($svc['kind'] !== 'WPS') { http_response_code(400); echo 'Selected service is not WPS'; exit; }
    $url = append_params($svc['base_url'], ['SERVICE'=>'WPS','VERSION'=>'1.0.0','REQUEST'=>'GetCapabilities']);
} elseif ($mode === 'wps_describe') {
    if ($svc['kind'] !== 'WPS') { http_response_code(400); echo 'Selected service is not WPS'; exit; }
    $identifier = $_GET['identifier'] ?? '';
    $url = append_params($svc['base_url'], ['SERVICE'=>'WPS','VERSION'=>'1.0.0','REQUEST'=>'DescribeProcess','IDENTIFIER'=>$identifier]);
} else {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(400);
    echo json_encode(['error'=>'Unknown mode'], JSON_PRETTY_PRINT);
    exit;
}

$context = stream_context_create(['http'=>['timeout'=>35,'header'=>"User-Agent: Cymru-Hive-OS-V54-Remote-OWS/1.0\r\n"]]);
$data = @file_get_contents($url, false, $context);
if ($data === false) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(502);
    echo json_encode(['error'=>'Upstream fetch failed','url'=>$url], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}
if ($mode === 'wfs') {
    $trim = ltrim($data);
    $contentType = (strlen($trim) && $trim[0] === '{') ? 'application/json; charset=utf-8' : 'application/xml; charset=utf-8';
}
header('Content-Type: '.$contentType);
echo $data;
?>