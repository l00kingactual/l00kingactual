#!/usr/bin/env python3
"""
SPACE WALE$ maths engine placeholder: use this to migrate heavy JS maths into Python.

This module intentionally mirrors the JS concepts:
- knapsack
- subset sum
- coverage
- ACO
- BCO
- predator/prey
- ROI composition
"""
from __future__ import annotations
from dataclasses import dataclass
from math import radians, sin, cos, asin, sqrt, log10
from typing import Iterable

def knapsack(items: list[dict], budget: int, scale: int = 100_000) -> dict:
    cap = budget // scale
    dp = [0.0] * (cap + 1)
    keep = [[] for _ in range(cap + 1)]
    for it in items:
        w = max(1, round(it["cost"] / scale))
        v = float(it.get("value", 0))
        for c in range(cap, w - 1, -1):
            cand = dp[c - w] + v
            if cand > dp[c]:
                dp[c] = cand
                keep[c] = keep[c - w] + [it["id"]]
    ids = keep[cap]
    return {"selectedIds": ids, "value": round(dp[cap], 3), "cost": sum(i["cost"] for i in items if i["id"] in ids)}

def subset_sum_near(items: list[dict], target: int, scale: int = 100_000) -> dict:
    cap = target // scale
    states = {0: []}
    for it in items:
        w = max(1, round(it["cost"] / scale))
        new = dict(states)
        for total, ids in states.items():
            nt = total + w
            if nt <= cap and nt not in new:
                new[nt] = ids + [it["id"]]
        states = new
    best = max(states)
    ids = states[best]
    spend = sum(i["cost"] for i in items if i["id"] in ids)
    return {"selectedIds": ids, "spend": spend, "remaining": target - spend}

if __name__ == "__main__":
    demo = [{"id":"education","cost":1_200_000,"value":90},{"id":"health","cost":1_600_000,"value":88},{"id":"farm","cost":900_000,"value":76}]
    print("knapsack", knapsack(demo, 2_500_000))
    print("subset", subset_sum_near(demo, 2_500_000))
