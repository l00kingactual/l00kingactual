#!/usr/bin/env python3
"""
Cymru Hive OS V5.4+ remote OWS fetcher.

Fetches WMS/WFS/WPS capabilities and optionally WFS GeoJSON using only Python stdlib.
Use for server-side remote-data tests when browser/CORS/PHP are difficult.
"""
from __future__ import annotations
import argparse, json, sys, urllib.parse, urllib.request, xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
SERVICES = json.loads((ROOT / "data" / "ows_services.json").read_text(encoding="utf-8"))

def find_service(service_id: str) -> dict:
    for s in SERVICES:
        if s["id"] == service_id:
            return s
    raise SystemExit(f"Unknown service id: {service_id}")

def fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Cymru-Hive-OS-Remote-OWS-Python/1.0"})
    with urllib.request.urlopen(req, timeout=35) as r:
        return r.read()

def append_params(base: str, params: dict) -> str:
    sep = "&" if "?" in base else "?"
    return base + sep + urllib.parse.urlencode(params)

def names_from_xml(data: bytes) -> dict:
    out = {"names": [], "titles": []}
    try:
        root = ET.fromstring(data)
        for el in root.iter():
            tag = el.tag.split("}")[-1]
            if tag == "Name" and el.text:
                out["names"].append(el.text.strip())
            elif tag == "Title" and el.text:
                out["titles"].append(el.text.strip())
            elif tag == "Identifier" and el.text:
                out["names"].append(el.text.strip())
    except Exception as exc:
        out["parse_error"] = str(exc)
    out["names"] = sorted(set(out["names"]))
    out["titles"] = sorted(set(out["titles"]))[:200]
    return out

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--service", required=True, help="service id from data/ows_services.json")
    ap.add_argument("--mode", choices=["capabilities","wfs","wps_capabilities","wps_describe"], default="capabilities")
    ap.add_argument("--typename", default="")
    ap.add_argument("--identifier", default="")
    ap.add_argument("--bbox", default="-5.85,51.25,-2.55,53.55")
    ap.add_argument("--maxfeatures", type=int, default=100)
    ap.add_argument("--out", type=Path, default=ROOT / "data" / "remote_cache")
    args = ap.parse_args()

    svc = find_service(args.service)
    url = svc["capabilities_url"]
    if args.mode == "wfs":
        if svc["kind"] != "WFS":
            raise SystemExit("selected service is not WFS")
        url = append_params(svc["base_url"], {
            "SERVICE":"WFS","VERSION":"1.1.0","REQUEST":"GetFeature",
            "TYPENAME":args.typename,"OUTPUTFORMAT":"application/json",
            "SRSNAME":"EPSG:4326","BBOX":args.bbox + ",EPSG:4326",
            "MAXFEATURES":str(args.maxfeatures),
        })
    elif args.mode == "wps_capabilities":
        url = append_params(svc["base_url"], {"SERVICE":"WPS","VERSION":"1.0.0","REQUEST":"GetCapabilities"})
    elif args.mode == "wps_describe":
        url = append_params(svc["base_url"], {"SERVICE":"WPS","VERSION":"1.0.0","REQUEST":"DescribeProcess","IDENTIFIER":args.identifier})

    args.out.mkdir(parents=True, exist_ok=True)
    data = fetch(url)
    stem = f"{args.service}_{args.mode}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    raw = args.out / f"{stem}.raw"
    raw.write_bytes(data)
    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "service": svc,
        "mode": args.mode,
        "url": url,
        "bytes": len(data),
        "raw_file": raw.name,
    }
    if args.mode in ("capabilities","wps_capabilities","wps_describe"):
        summary.update(names_from_xml(data))
    else:
        try:
            geo = json.loads(data.decode("utf-8"))
            summary["json_type"] = geo.get("type")
            summary["feature_count"] = len(geo.get("features", []))
        except Exception as exc:
            summary["json_parse_error"] = str(exc)

    summary_path = args.out / f"{stem}.summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
