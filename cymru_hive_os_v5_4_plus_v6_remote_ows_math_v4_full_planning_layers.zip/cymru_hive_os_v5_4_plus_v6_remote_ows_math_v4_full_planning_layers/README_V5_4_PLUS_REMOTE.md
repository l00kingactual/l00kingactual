# Cymru Hive OS V5.4+ V6 Remote OWS + Maths

This package uses **V5.4 as the forward WebUI base**.

Added:

- `remote_data_lab.html`
- `api/ows_proxy.php`
- `data/ows_services.json`
- `assets/js/ows_remote_lab.js`
- `assets/js/space_wales_math_plus.js`
- `tools/ows_fetch.py`
- `tools/space_wales_math_engine.py`

## Run ordinary static mode

```bash
./scripts/run_local.sh
```

Open:

```text
http://127.0.0.1:8088/
```

Static mode can open the main V5.4 WebUI. Remote lab direct-browser mode may work for some services, but CORS can block it.

## Run remote-data mode

Use Apache/PHP:

```bash
sudo bash scripts/install_apache.sh
```

Open the printed URL, then:

```text
remote_data_lab.html
```

## WMS/WFS/WPS rule

- WMS = visual map image.
- WFS = remote feature data.
- WPS = optional process discovery; not guaranteed on DataMapWales.

If WPS is unavailable, use Python processing over WFS data.

## V2 selectable local layers

`remote_data_lab.html` now includes built-in toggle layers:

- major roads
- railways
- forest / woodland
- dark sky places / sites

These are schematic planning overlays, not official survey-grade data. Use official WMS/WFS/OS datasets for production decisions.

## V3 toolbar + metadata cards

`remote_data_lab.html` now has map-toolbar buttons directly above the map:

- roads
- rail
- woodland
- dark sky
- hospitals
- fire stations
- libraries
- all
- clear

Mouse over roads, railways, woodland polygons, dark-sky sites, hospitals, fire stations, libraries or WFS features to show a metadata card.

Additional planning layers staged for the next build:

- schools
- GP surgeries
- ambulance stations
- farms / school-farm twins
- rivers / reservoirs / flood risk
- energy grid / renewables
