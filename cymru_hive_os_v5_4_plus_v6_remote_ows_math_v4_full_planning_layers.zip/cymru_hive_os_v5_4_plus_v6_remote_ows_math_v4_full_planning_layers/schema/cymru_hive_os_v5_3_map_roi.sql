-- Cymru Hive OS v5.3 · Map Key + Eco-ROI Movement
CREATE TABLE IF NOT EXISTS map_key (
  icon TEXT,
  name TEXT,
  movement TEXT,
  roi TEXT
);

CREATE TABLE IF NOT EXISTS map_roi_model (
  key TEXT PRIMARY KEY,
  value TEXT
);

INSERT INTO map_roi_model VALUES ('version', '5.3');
INSERT INTO map_roi_model VALUES ('base_tune_roi_rate', '1.25');
INSERT INTO map_roi_model VALUES ('movement_components', 'ACO route score, BCO scout score, predator/prey ecology, farm twin movement, tune value');
INSERT INTO map_roi_model VALUES ('calibration_note', 'Planning-grade demonstrator; requires Welsh datasets for calibrated decision use.');
INSERT INTO map_key VALUES ('🐝', 'BCO bee / learner', 'Scout/recruit movement toward high-value hives', 'Opportunity discovery and participation value');
INSERT INTO map_key VALUES ('🍯', 'Honey bee / output carrier', 'Returns between provider cohorts and honey-output hives', 'Visible honey, evidence and civic value');
INSERT INTO map_key VALUES ('🐜', 'ACO ant / route memory', 'Travels service routes and reinforces pheromone trails', 'Access, logistics, transport and route-efficiency value');
INSERT INTO map_key VALUES ('🦅', 'PSO bird / strategic scout', 'Flocks toward best current weighted hives', 'Scenario search and high-level opportunity detection');
INSERT INTO map_key VALUES ('🐟', 'Fish / water ecology', 'Moves along rivers/coast routes', 'Water quality, food-web and ecological resilience value');
INSERT INTO map_key VALUES ('🐁', 'Prey / biodiversity base', 'Forages and avoids predators', 'Biodiversity, animal-guild and habitat value');
INSERT INTO map_key VALUES ('🦊', 'Predator / pressure', 'Pursues prey around animal and agrarian hives', 'Balance signal; too much or too little pressure reduces ecology score');
INSERT INTO map_key VALUES ('🚜', 'Farm twin tractor', 'Moves between school, farm, terrain-map and agrarian hives', 'Digital farm twin, terrain map and agritech value');
INSERT INTO map_key VALUES ('🎖️', 'Pathway cadet', 'Moves between adventure, school, transport and leadership hives', 'Leadership, discipline, service and civil-resilience value');
INSERT INTO map_key VALUES ('🔭', 'Astronomy/GIS scout', 'Moves toward dark-sky, satellite, GIS and education hives', 'STEM, astronomy, GIS and navigation value');
