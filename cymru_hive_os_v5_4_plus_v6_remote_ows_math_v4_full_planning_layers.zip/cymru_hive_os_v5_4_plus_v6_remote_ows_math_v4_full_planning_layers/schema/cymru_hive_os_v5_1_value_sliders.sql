-- Cymru Hive OS v5.1 · value sliders and charting extension
CREATE TABLE IF NOT EXISTS value_slider_definition (
  id TEXT PRIMARY KEY,
  ledger TEXT NOT NULL,
  label TEXT NOT NULL,
  unit TEXT NOT NULL,
  cap_value NUMERIC,
  notes TEXT
);
CREATE TABLE IF NOT EXISTS staff_slider_snapshot (
  run_id TEXT,
  allocation_heading TEXT,
  staff_value INTEGER,
  PRIMARY KEY(run_id, allocation_heading)
);
CREATE TABLE IF NOT EXISTS competition_slider_snapshot (
  run_id TEXT,
  competition_id TEXT,
  budget_gbp NUMERIC,
  PRIMARY KEY(run_id, competition_id)
);
CREATE TABLE IF NOT EXISTS badge_roi_slider_snapshot (
  run_id TEXT,
  badge_id TEXT,
  roi_weight REAL,
  PRIMARY KEY(run_id, badge_id)
);
CREATE TABLE IF NOT EXISTS cohort_provider_consumer_snapshot (
  run_id TEXT,
  cohort_id TEXT,
  producer_capacity REAL,
  consumer_need REAL,
  PRIMARY KEY(run_id, cohort_id)
);
INSERT INTO value_slider_definition VALUES ('budget_allocations','budget','Budget allocation sliders','GBP',2500000000,'Annual allocation cap');
INSERT INTO value_slider_definition VALUES ('staff_allocations','staff','Staff allocation sliders','staff',25000,'Staff plan cap');
INSERT INTO value_slider_definition VALUES ('competition_budgets','competition','Competition budget sliders','GBP',NULL,'Capped to current Pathway League allocation');
INSERT INTO value_slider_definition VALUES ('badge_roi_weights','badge','Badge ROI-weight sliders','score',10,'Per-badge ROI strength');
INSERT INTO value_slider_definition VALUES ('cohort_provider_consumer','population','Population provider/consumer sliders','score',100,'Per-cohort producer and consumer values');
