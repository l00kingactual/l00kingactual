-- Cymru Hive OS v5.2 · Metadata + Fixed Tune Playback
CREATE TABLE IF NOT EXISTS model_metadata (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS architecture_layer (
  layer_id TEXT PRIMARY KEY,
  items_json TEXT
);

INSERT INTO model_metadata VALUES ('version', '5.2');
INSERT INTO model_metadata VALUES ('model_name', 'Cymru Hive OS v5.2 · SPACE WALE$ Pathway League');
INSERT INTO model_metadata VALUES ('playback', 'Selected auto-tune plays until user changes it; automatic stepping removed.');
INSERT INTO model_metadata VALUES ('annual_budget_cap_gbp', '2500000000');
INSERT INTO model_metadata VALUES ('staff_cap', '25000');
INSERT INTO model_metadata VALUES ('value_ledgers', 'budget, staff, competitions, badge ROI weights, provider/consumer cohorts, horizons, ROI, map hives');
INSERT INTO architecture_layer VALUES ('ui', '["collapsed sidebar groups", "zoomable Wales map", "slider panels", "analysis panels"]');
INSERT INTO architecture_layer VALUES ('value_control', '["budget sliders", "staff sliders", "competition sliders", "badge ROI sliders", "provider/consumer sliders"]');
INSERT INTO architecture_layer VALUES ('pathway_league', '["Cubs/Brownies", "Scouts/Guides", "adventures", "CCF-style leadership", "schools", "farm hubs"]');
INSERT INTO architecture_layer VALUES ('education', '["astronomy", "sport", "maths", "physics", "languages", "chemistry", "biology", "GIS"]');
INSERT INTO architecture_layer VALUES ('digital_agrarian', '["digital farm twins", "terrain maps", "animal guilds", "eco-energy", "school hives"]');
INSERT INTO architecture_layer VALUES ('evidence', '["ROI score", "horizon budgets", "badge matrix", "metadata export", "SQL", "Neo4j"]');
