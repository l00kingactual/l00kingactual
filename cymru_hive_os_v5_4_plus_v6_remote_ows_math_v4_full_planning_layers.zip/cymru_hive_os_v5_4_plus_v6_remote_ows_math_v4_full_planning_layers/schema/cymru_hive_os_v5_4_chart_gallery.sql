-- Cymru Hive OS v5.4 · 64 Charting + Animated Graph Lab
CREATE TABLE IF NOT EXISTS chart_gallery_64 (
  chart_id TEXT PRIMARY KEY,
  icon TEXT,
  name TEXT,
  mode TEXT,
  category TEXT,
  description TEXT
);

CREATE TABLE IF NOT EXISTS chart_export_event (
  event_id TEXT PRIMARY KEY,
  chart_id TEXT,
  source_mode TEXT,
  snapshot_json TEXT,
  created_at TEXT
);
INSERT INTO chart_gallery_64 VALUES ('budget_bar_2d', '📊', 'Budget allocation bars', '2D', 'budget', 'Annual £ by allocation heading');
INSERT INTO chart_gallery_64 VALUES ('budget_stacked_2d', '🧱', 'Budget stacked wall', '2D', 'budget', 'One £2.5bn wall split across headings');
INSERT INTO chart_gallery_64 VALUES ('staff_bar_2d', '👥', 'Staff allocation bars', '2D', 'staff', '25,000 staff by heading');
INSERT INTO chart_gallery_64 VALUES ('competition_bar_2d', '🏆', 'Competition budget bars', '2D', 'competition', 'County/national prize budgets');
INSERT INTO chart_gallery_64 VALUES ('badge_roi_bar_2d', '🎖️', 'Badge ROI bars', '2D', 'badge', 'ROI weight by badge');
INSERT INTO chart_gallery_64 VALUES ('provider_consumer_2d', '🐝', 'Provider vs consumer', '2D', 'population', 'Cohort provider/consumer values');
INSERT INTO chart_gallery_64 VALUES ('horizon_bar_2d', '📆', '1/5/10/25 horizon bars', '2D', 'budget', 'Welsh defence horizon totals');
INSERT INTO chart_gallery_64 VALUES ('roi_radar_2d', '🎯', 'ROI radar', '2D', 'roi', 'Financial/time/effort/resources/staff/honey');
INSERT INTO chart_gallery_64 VALUES ('map_roi_bar_2d', '🗺️', 'Map movement ROI bars', '2D', 'map', 'ACO, BCO, ecology, farm twin and tune value');
INSERT INTO chart_gallery_64 VALUES ('aco_pheromone_2d', '🐜', 'ACO pheromone plot', '2D', 'agent', 'Route memory strength between hives');
INSERT INTO chart_gallery_64 VALUES ('bco_scout_2d', '🐝', 'BCO scout plot', '2D', 'agent', 'Opportunity scout attraction by hive');
INSERT INTO chart_gallery_64 VALUES ('predator_prey_2d', '🦊', 'Predator/prey balance', '2D', 'ecology', 'Ecology balance over model time');
INSERT INTO chart_gallery_64 VALUES ('farm_twin_flow_2d', '🚜', 'Farm twin flow', '2D', 'farm', 'School-farm-terrain movement flow');
INSERT INTO chart_gallery_64 VALUES ('badge_subject_matrix_2d', '🔲', 'Badge × subject matrix', '2D', 'education', 'Badge links to astronomy/sport/STEM/languages');
INSERT INTO chart_gallery_64 VALUES ('subject_heatmap_2d', '🔥', 'Subject investment heatmap', '2D', 'education', 'Subject strength from budget bias');
INSERT INTO chart_gallery_64 VALUES ('organisation_network_2d', '🕸️', 'Organisation network', '2D', 'pathway', 'Schools, Cubs, Scouts, Guides, cadets, farms');
INSERT INTO chart_gallery_64 VALUES ('pathway_timeline_2d', '⏳', '24 auto-tune timeline', '2D', 'time', 'Age-stage pathway sequence');
INSERT INTO chart_gallery_64 VALUES ('competition_pareto_2d', '📈', 'Competition Pareto', '2D', 'competition', 'Largest prize budgets first');
INSERT INTO chart_gallery_64 VALUES ('roi_waterfall_2d', '💧', 'ROI waterfall', '2D', 'roi', 'Base rate plus tune and movement contributions');
INSERT INTO chart_gallery_64 VALUES ('risk_return_2d', '⚖️', 'Risk-return plane', '2D', 'roi', 'Scenario risk and return scatter');
INSERT INTO chart_gallery_64 VALUES ('hive_map_values_2d', '🏘️', 'Hive value map', '2D', 'map', 'Hive marker values by current budget');
INSERT INTO chart_gallery_64 VALUES ('skills_ladder_2d', '🪜', 'Skills ladder', '2D', 'education', 'Age-stage skills progression');
INSERT INTO chart_gallery_64 VALUES ('language_glossary_2d', '🗣️', 'Language glossary counts', '2D', 'languages', 'Welsh/English evidence outputs');
INSERT INTO chart_gallery_64 VALUES ('eco_energy_2d', '🔋', 'Eco-energy savings', '2D', 'energy', 'Solar, battery, compost and eco-fuel value');
INSERT INTO chart_gallery_64 VALUES ('animal_guild_2d', '🐑', 'Animal guild values', '2D', 'animals', 'School ark, farm hub and predator/prey values');
INSERT INTO chart_gallery_64 VALUES ('digital_twin_2d', '🚜', 'Digital farm twin score', '2D', 'farm', 'Terrain, GIS and simulator project score');
INSERT INTO chart_gallery_64 VALUES ('staff_vs_budget_2d', '📉', 'Staff vs budget scatter', '2D', 'staff', 'Staff intensity by budget heading');
INSERT INTO chart_gallery_64 VALUES ('honey_output_2d', '🍯', 'Honey-output ledger', '2D', 'honey', 'Knowledge, health, jobs, ecology, civic pride');
INSERT INTO chart_gallery_64 VALUES ('sankey_2d', '🌊', 'Budget-to-honey Sankey', '2D', 'flow', 'Allocation to honey-output bands');
INSERT INTO chart_gallery_64 VALUES ('chord_2d', '⭕', 'Subject-badge chord', '2D', 'flow', 'Subject/badge circular relationships');
INSERT INTO chart_gallery_64 VALUES ('cort_wheel_2d', '🎡', 'CoRT strategy wheel', '2D', 'strategy', 'PMI, CAF, C&S, FIP, APC, OPV, PISCO');
INSERT INTO chart_gallery_64 VALUES ('porter_chain_2d', '🔗', 'Porter value chain', '2D', 'strategy', 'Sport-health-learning-enterprise-honey chain');
INSERT INTO chart_gallery_64 VALUES ('budget_columns_3d', '🏛️', '3D budget columns', '3D', 'budget', 'Isometric columns by allocation heading');
INSERT INTO chart_gallery_64 VALUES ('staff_columns_3d', '👥', '3D staff columns', '3D', 'staff', 'Isometric staff towers');
INSERT INTO chart_gallery_64 VALUES ('competition_columns_3d', '🏆', '3D competition towers', '3D', 'competition', 'Prize budget towers');
INSERT INTO chart_gallery_64 VALUES ('badge_roi_3d', '🎖️', '3D badge ROI towers', '3D', 'badge', 'Badge ROI weight towers');
INSERT INTO chart_gallery_64 VALUES ('provider_consumer_3d', '🐝', '3D provider/consumer ridges', '3D', 'population', 'Cohort ridges by provider/consumer');
INSERT INTO chart_gallery_64 VALUES ('horizon_3d', '📆', '3D horizon steps', '3D', 'budget', '1/5/10/25-year budget steps');
INSERT INTO chart_gallery_64 VALUES ('roi_surface_3d', '⛰️', '3D ROI surface', '3D', 'roi', 'Pseudo terrain of ROI components');
INSERT INTO chart_gallery_64 VALUES ('map_roi_3d', '🗺️', '3D map movement surface', '3D', 'map', 'Movement ROI terrain');
INSERT INTO chart_gallery_64 VALUES ('aco_pheromone_3d', '🐜', '3D pheromone ridges', '3D', 'agent', 'Route reinforcement surface');
INSERT INTO chart_gallery_64 VALUES ('bco_scout_3d', '🐝', '3D BCO scout field', '3D', 'agent', 'Hive opportunity attraction terrain');
INSERT INTO chart_gallery_64 VALUES ('predator_prey_3d', '🦊', '3D predator/prey field', '3D', 'ecology', 'Ecology pressure surface');
INSERT INTO chart_gallery_64 VALUES ('farm_twin_3d', '🚜', '3D farm-twin terrain', '3D', 'farm', 'School/farm/terrain score surface');
INSERT INTO chart_gallery_64 VALUES ('badge_subject_cube_3d', '🎲', '3D badge-subject cube', '3D', 'education', 'Badge and subject voxel relationships');
INSERT INTO chart_gallery_64 VALUES ('subject_heat_3d', '🔥', '3D subject heat blocks', '3D', 'education', 'Subject investment heightmap');
INSERT INTO chart_gallery_64 VALUES ('organisation_network_3d', '🕸️', '3D organisation constellation', '3D', 'pathway', 'Pseudo-3D partner network');
INSERT INTO chart_gallery_64 VALUES ('pathway_spiral_3d', '🌀', '3D pathway spiral', '3D', 'time', '24 auto-tunes in developmental spiral');
INSERT INTO chart_gallery_64 VALUES ('competition_pareto_3d', '📈', '3D competition Pareto', '3D', 'competition', 'Sorted prize towers');
INSERT INTO chart_gallery_64 VALUES ('roi_waterfall_3d', '💧', '3D ROI waterfall', '3D', 'roi', 'Step towers for ROI components');
INSERT INTO chart_gallery_64 VALUES ('risk_return_3d', '⚖️', '3D risk-return scatter', '3D', 'roi', 'Impact, risk and investment perspective plot');
INSERT INTO chart_gallery_64 VALUES ('hive_map_3d', '🏘️', '3D hive map columns', '3D', 'map', 'Hive value columns over Wales');
INSERT INTO chart_gallery_64 VALUES ('skills_ladder_3d', '🪜', '3D skills ladder', '3D', 'education', 'Age-stage skill tower sequence');
INSERT INTO chart_gallery_64 VALUES ('language_3d', '🗣️', '3D language evidence', '3D', 'languages', 'Bilingual evidence columns');
INSERT INTO chart_gallery_64 VALUES ('eco_energy_3d', '🔋', '3D eco-energy terrain', '3D', 'energy', 'Energy savings surface');
INSERT INTO chart_gallery_64 VALUES ('animal_guild_3d', '🐑', '3D animal guild terrain', '3D', 'animals', 'Animal/welfare/ecology surface');
INSERT INTO chart_gallery_64 VALUES ('digital_twin_3d', '🚜', '3D digital twin terrain', '3D', 'farm', 'Terrain-map capability surface');
INSERT INTO chart_gallery_64 VALUES ('staff_budget_3d', '📉', '3D staff-budget plane', '3D', 'staff', 'Staff/budget intensity plane');
INSERT INTO chart_gallery_64 VALUES ('honey_3d', '🍯', '3D honey terrain', '3D', 'honey', 'Honey-output terrain');
INSERT INTO chart_gallery_64 VALUES ('sankey_3d', '🌊', '3D budget-to-honey flow', '3D', 'flow', 'Pseudo-3D flow ribbons');
INSERT INTO chart_gallery_64 VALUES ('chord_3d', '⭕', '3D chord ring', '3D', 'flow', 'Raised circular relationships');
INSERT INTO chart_gallery_64 VALUES ('cort_wheel_3d', '🎡', '3D CoRT wheel', '3D', 'strategy', 'Raised strategic sectors');
INSERT INTO chart_gallery_64 VALUES ('porter_chain_3d', '🔗', '3D Porter chain', '3D', 'strategy', 'Value-chain blocks');
INSERT INTO chart_gallery_64 VALUES ('thirteen_s_cube_3d', '🧊', '3D 13S synergy cube', '3D', 'strategy', '13S strategic alignment cube');
