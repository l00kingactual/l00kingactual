// Cymru Hive OS v5.1 · value slider graph extension
MERGE (:ValueSliderLedger {id:'budget_allocations', label:'Budget allocation sliders', unit:'GBP', cap_value:2500000000});
MERGE (:ValueSliderLedger {id:'staff_allocations', label:'Staff allocation sliders', unit:'staff', cap_value:25000});
MERGE (:ValueSliderLedger {id:'competition_budgets', label:'Competition budget sliders', unit:'GBP'});
MERGE (:ValueSliderLedger {id:'badge_roi_weights', label:'Badge ROI-weight sliders', unit:'score', cap_value:10});
MERGE (:ValueSliderLedger {id:'cohort_provider_consumer', label:'Population provider/consumer sliders', unit:'score', cap_value:100});
