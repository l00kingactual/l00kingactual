# Cymru Hive OS V5.4+ V6 Remote OWS + V4 Full Planning Layers

V5.4 remains the forward WebUI base. The remote lab is now offline-first, so the main map and local planning layers appear even when WMS/WFS/WPS fails.

Open `remote_data_lab.html`. Use `remote_lab_diagnostics.html` if anything appears empty.

Local layers: major_roads, railways, forest_woodland, flood_zones, railway_stations, bus_stations, gp_surgeries, ambulance_stations, fire_stations, police_stations, libraries, schools, sports_fields, markets_enterprise, community_hives, dark_sky_sites, hospitals, universities_colleges, farms_school_twins, animal_guild_farms, rivers_reservoirs, ports, airports, energy_grid_renewables, telecoms_datacentres, food_distribution, waste_recycling, coastguard_lifeboat
