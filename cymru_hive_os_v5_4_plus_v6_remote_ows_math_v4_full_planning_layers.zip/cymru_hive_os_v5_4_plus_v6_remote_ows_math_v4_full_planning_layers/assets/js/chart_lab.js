(function(){
const D = window.SPACE_WALES_V5_DATA;
const E = window.SpaceWalesV5Engine;
const $ = id => document.getElementById(id);
let chartId = 'budget_bar_2d', animating = true, t = 0, lastSnapshot = null;
const gallery = D.chart_gallery_64 || [];

function money(n){ return E && E.money ? E.money(n) : '£'+Math.round(n).toLocaleString(); }
function clear(g){ const c=g.canvas; g.clearRect(0,0,c.width,c.height); const bg=g.createLinearGradient(0,0,0,c.height); bg.addColorStop(0,'#081426'); bg.addColorStop(1,'#101c2f'); g.fillStyle=bg; g.fillRect(0,0,c.width,c.height); }
function text(g,s,x,y,size=13,color='#eaf2ff',align='left'){ g.fillStyle=color; g.font=size+'px system-ui'; g.textAlign=align; g.fillText(String(s),x,y); }
function colour(i,n){ return `hsl(${190+i*210/Math.max(1,n)},88%,58%)`; }

function getBaseValues(){
  // Prefer live exported global if app exposes later; otherwise derive from data baseline.
  const alloc = D.allocations || [];
  const values = {};
  alloc.forEach(a => values[a.id] = a.annual_gbp || (D.budget.annual_gbp*a.pct/100));
  const staff = {};
  alloc.forEach(a => staff[a.id] = a.staff || Math.round((D.budget.staff_total||25000)*(a.staff_pct||a.pct)/100));
  const competition = {};
  (D.competitions||[]).forEach(c => competition[c.id] = c.budget_gbp || 1000000);
  const badges = {};
  (D.badges||[]).forEach(b => badges[b.id] = b.roi_weight || 3);
  const cohorts = {};
  (D.population||[]).forEach(p => cohorts[p.id] = {producer_capacity:p.producer_capacity||50, consumer_need:p.consumer_need||50});
  return {values, staff, competition, badges, cohorts};
}
function snapshot(){
  const base = getBaseValues();
  const source = $('chartAnimSource')?.value || 'live';
  const speed = Number($('chartSpeed')?.value || 45);
  const amp = source === 'static' ? 0 : source === 'model' ? 0.28 : 0.14;
  const phase = t * (0.01 + speed/4200);
  function vary(v,i){ return Math.max(0, v * (1 + amp*Math.sin(phase+i*.73))); }
  const values = {...base.values}, staff={...base.staff}, competition={...base.competition}, badges={...base.badges}, cohorts=JSON.parse(JSON.stringify(base.cohorts));
  Object.keys(values).forEach((k,i)=>values[k]=vary(values[k],i));
  Object.keys(staff).forEach((k,i)=>staff[k]=vary(staff[k],i+3));
  Object.keys(competition).forEach((k,i)=>competition[k]=vary(competition[k],i+6));
  Object.keys(badges).forEach((k,i)=>badges[k]=vary(badges[k],i+9));
  Object.keys(cohorts).forEach((k,i)=>{cohorts[k].producer_capacity=Math.min(100,vary(cohorts[k].producer_capacity,i+12));cohorts[k].consumer_need=Math.min(100,vary(cohorts[k].consumer_need,i+15));});
  const map = window.SpaceMap && window.SpaceMap.metrics ? window.SpaceMap.metrics() : {routeScore:50,scoutScore:50,ecologyScore:50,farmTwinScore:50,tuneValue:50,movementROI:.25,totalTuneMovementRate:1.5};
  lastSnapshot={values,staff,competition,badges,cohorts,map,phase,source};
  return lastSnapshot;
}
function rowsFor(category,s){
  const alloc = D.allocations || [];
  if(category==='budget') return alloc.map(a=>({id:a.id,label:a.icon+' '+a.name,value:s.values[a.id]||0,fmt:money(s.values[a.id]||0)}));
  if(category==='staff') return alloc.map(a=>({id:a.id,label:a.icon+' '+a.name,value:s.staff[a.id]||0,fmt:Math.round(s.staff[a.id]||0)+' staff'}));
  if(category==='competition') return (D.competitions||[]).map(c=>({id:c.id,label:c.icon+' '+c.name,value:s.competition[c.id]||0,fmt:money(s.competition[c.id]||0)}));
  if(category==='badge') return (D.badges||[]).map(b=>({id:b.id,label:b.icon+' '+b.name,value:s.badges[b.id]||0,fmt:Number(s.badges[b.id]||0).toFixed(1)}));
  if(category==='population') return (D.population||[]).map(p=>({id:p.id,label:p.icon+' '+p.name,value:(s.cohorts[p.id]?.producer_capacity||0)+(s.cohorts[p.id]?.consumer_need||0),fmt:'P '+Math.round(s.cohorts[p.id]?.producer_capacity||0)+' / C '+Math.round(s.cohorts[p.id]?.consumer_need||0)}));
  if(category==='map') return [
    {id:'aco',label:'🐜 ACO route',value:s.map.routeScore||50,fmt:Math.round(s.map.routeScore||50)+'/100'},
    {id:'bco',label:'🐝 BCO scout',value:s.map.scoutScore||50,fmt:Math.round(s.map.scoutScore||50)+'/100'},
    {id:'eco',label:'🐟🦊 Ecology',value:s.map.ecologyScore||50,fmt:Math.round(s.map.ecologyScore||50)+'/100'},
    {id:'farm',label:'🚜 Farm twin',value:s.map.farmTwinScore||50,fmt:Math.round(s.map.farmTwinScore||50)+'/100'},
    {id:'tune',label:'🎚️ Tune value',value:s.map.tuneValue||50,fmt:Math.round(s.map.tuneValue||50)+'/100'},
  ];
  if(category==='agent') return rowsFor('map',s);
  if(category==='education') return (D.subjects||[]).map((x,i)=>({id:x.id,label:x.icon+' '+x.name,value:45+35*Math.sin(s.phase+i),fmt:Math.round(45+35*Math.sin(s.phase+i))+'/100'}));
  if(category==='farm') return [
    {label:'🚜 terrain maps',value:70+20*Math.sin(s.phase),fmt:'terrain'},
    {label:'🌾 farm hub',value:62+22*Math.cos(s.phase*.8),fmt:'hub'},
    {label:'🛰️ GIS',value:66+18*Math.sin(s.phase*1.2),fmt:'GIS'},
    {label:'💼 enterprise',value:58+25*Math.cos(s.phase*1.4),fmt:'enterprise'},
  ];
  if(category==='ecology') return [
    {label:'🐟 fish',value:60+22*Math.sin(s.phase),fmt:'fish'},
    {label:'🐁 prey',value:55+28*Math.cos(s.phase*.8),fmt:'prey'},
    {label:'🦊 predators',value:42+18*Math.sin(s.phase*1.3),fmt:'pred'},
    {label:'🐝 pollinators',value:68+14*Math.cos(s.phase*1.6),fmt:'poll'},
  ];
  if(category==='strategy') return ['PMI','CAF','C&S','FIP','APC','OPV','PISCO','AGO'].map((x,i)=>({label:x,value:50+35*Math.sin(s.phase+i),fmt:Math.round(50+35*Math.sin(s.phase+i))}));
  if(category==='roi') return [
    {label:'base ROI',value:62,fmt:'1.25x'},
    {label:'tune value',value:s.map.tuneValue||50,fmt:Math.round(s.map.tuneValue||50)+'/100'},
    {label:'movement add',value:(s.map.movementROI||.25)*100,fmt:(s.map.movementROI||.25).toFixed(2)+'x'},
    {label:'staff fit',value:58+20*Math.sin(s.phase),fmt:'staff'},
    {label:'honey',value:65+20*Math.cos(s.phase),fmt:'honey'},
  ];
  return rowsFor('budget',s);
}
function drawBars(g,rows,title){
  clear(g); text(g,title,40,38,24,'#facc15'); const w=g.canvas.width,h=g.canvas.height,p=56,max=Math.max(...rows.map(r=>r.value),1);
  rows.slice(0,18).forEach((r,i)=>{const y=70+i*((h-110)/Math.min(18,rows.length)); const bw=(w-250)*(r.value/max); const gr=g.createLinearGradient(p,y,p+bw,y); gr.addColorStop(0,'#39d5ff'); gr.addColorStop(.65,'#facc15'); gr.addColorStop(1,'#4ade80'); g.fillStyle=gr; g.fillRect(p,y,bw,12); text(g,r.label,p,y-5,12); text(g,r.fmt||Math.round(r.value),w-55,y+11,12,'#facc15','right');});
}
function iso(x,y,z){ return {x: 560+(x-y)*38, y: 505+(x+y)*18-z*1.8}; }
function block(g,x,y,h,c){ const p=iso(x,y,0),a=iso(x+1,y,0),b=iso(x+1,y+1,0),d=iso(x,y+1,0),p2=iso(x,y,h),a2=iso(x+1,y,h),b2=iso(x+1,y+1,h),d2=iso(x,y+1,h); g.fillStyle=c; g.beginPath(); g.moveTo(p2.x,p2.y); g.lineTo(a2.x,a2.y); g.lineTo(b2.x,b2.y); g.lineTo(d2.x,d2.y); g.closePath(); g.fill(); g.fillStyle='rgba(255,255,255,.12)'; g.beginPath(); g.moveTo(p.x,p.y); g.lineTo(a.x,a.y); g.lineTo(a2.x,a2.y); g.lineTo(p2.x,p2.y); g.closePath(); g.fill(); g.fillStyle='rgba(0,0,0,.25)'; g.beginPath(); g.moveTo(a.x,a.y); g.lineTo(b.x,b.y); g.lineTo(b2.x,b2.y); g.lineTo(a2.x,a2.y); g.closePath(); g.fill(); }
function draw3DColumns(g,rows,title){
  clear(g); text(g,title,40,38,24,'#facc15'); const max=Math.max(...rows.map(r=>r.value),1);
  rows.slice(0,32).forEach((r,i)=>{const x=(i%8)-4,y=Math.floor(i/8)-1.5,h=12+(r.value/max)*150; block(g,x,y,h,colour(i,rows.length)); const p=iso(x+.5,y+.5,h+10); text(g,(r.label||'').split(' ')[0],p.x,p.y,18,'#fff','center');});
}
function drawRadar(g,rows,title){
  clear(g); text(g,title,40,38,24,'#facc15'); const cx=560,cy=335,R=210,keys=rows.slice(0,10); for(let ring=1;ring<=5;ring++){g.strokeStyle='rgba(255,255,255,.13)';g.beginPath();keys.forEach((r,i)=>{const a=-Math.PI/2+i*2*Math.PI/keys.length,rr=R*ring/5,x=cx+Math.cos(a)*rr,y=cy+Math.sin(a)*rr;i?g.lineTo(x,y):g.moveTo(x,y)});g.closePath();g.stroke()} g.beginPath(); const max=Math.max(...keys.map(r=>r.value),1);keys.forEach((r,i)=>{const a=-Math.PI/2+i*2*Math.PI/keys.length,rr=R*r.value/max,x=cx+Math.cos(a)*rr,y=cy+Math.sin(a)*rr;i?g.lineTo(x,y):g.moveTo(x,y);text(g,(r.label||r.id).slice(0,16),cx+Math.cos(a)*(R+55),cy+Math.sin(a)*(R+55),11,'#eaf2ff','center')});g.closePath();g.fillStyle='rgba(57,213,255,.3)';g.fill();g.strokeStyle='#facc15';g.stroke();}
function drawHeat(g,rows,title){
  clear(g); text(g,title,40,38,24,'#facc15'); const cols=Math.ceil(Math.sqrt(rows.length)); rows.forEach((r,i)=>{const x=90+(i%cols)*90,y=90+Math.floor(i/cols)*66,v=Math.min(100,r.value); g.fillStyle=`hsl(${210-v*1.4},85%,${28+v/2}%)`;g.fillRect(x,y,72,45);text(g,(r.label||r.id).slice(0,6),x+36,y+27,11,'#07111f','center')});}
function drawNetwork(g,rows,title,three=false){
  clear(g); text(g,title,40,38,24,'#facc15'); const cx=560,cy=335,R=230; const pts=rows.slice(0,18).map((r,i)=>({r,x:cx+Math.cos(i*2*Math.PI/Math.min(18,rows.length))*R*(three?1+.15*Math.sin(t/30+i):1),y:cy+Math.sin(i*2*Math.PI/Math.min(18,rows.length))*R*(three?1+.1*Math.cos(t/35+i):1)}));
  pts.forEach((p,i)=>pts.forEach((q,j)=>{if(i<j&&(i+j)%4===0){g.strokeStyle='rgba(57,213,255,.16)';g.beginPath();g.moveTo(p.x,p.y);g.lineTo(q.x,q.y);g.stroke();}}));
  pts.forEach((p,i)=>{g.fillStyle=colour(i,pts.length);g.beginPath();g.arc(p.x,p.y,three?12+(i%5):12,0,Math.PI*2);g.fill();text(g,(p.r.label||'•').split(' ')[0],p.x,p.y+5,14,'#07111f','center')});
}
function drawSpiral(g,rows,title){ clear(g); text(g,title,40,38,24,'#facc15'); const cx=560,cy=335; rows.slice(0,32).forEach((r,i)=>{const a=i*.7+t*.012,R=25+i*7,x=cx+Math.cos(a)*R,y=cy+Math.sin(a)*R-i*1.2;g.fillStyle=colour(i,rows.length);g.beginPath();g.arc(x,y,7+i/12,0,Math.PI*2);g.fill();text(g,(r.label||'').split(' ')[0],x,y-13,13,'#fff','center')});}
function drawWheel(g,rows,title,raised=false){ clear(g); text(g,title,40,38,24,'#facc15'); const cx=560,cy=335,R=230; rows.slice(0,12).forEach((r,i)=>{const a1=i*2*Math.PI/Math.min(12,rows.length)-Math.PI/2,a2=(i+1)*2*Math.PI/Math.min(12,rows.length)-Math.PI/2;g.fillStyle=colour(i,rows.length);g.beginPath();g.moveTo(cx,cy);g.arc(cx,cy,R+(raised?20*Math.sin(t/30+i):0),a1,a2);g.closePath();g.fill();text(g,(r.label||r.id).slice(0,12),cx+Math.cos((a1+a2)/2)*140,cy+Math.sin((a1+a2)/2)*140,13,'#07111f','center')});}
function render(){
  const canvas=$('advancedChartCanvas'); if(!canvas) return; const g=canvas.getContext('2d'); const def=gallery.find(x=>x.id===chartId)||gallery[0]; const s=snapshot();
  $('chartTitle').textContent = `${def.icon} ${def.name}`; $('chartDescription').textContent=def.description; $('chartKind').textContent=`${def.mode} · ${def.category}`; $('chartMetaPills').innerHTML=`<span class="pill">${def.mode}</span><span class="pill">${def.category}</span><span class="pill">${def.id}</span>`;
  const rows=rowsFor(def.category,s);
  if(def.id.includes('radar')) drawRadar(g,rows,def.name);
  else if(def.id.includes('matrix')||def.id.includes('heat')) drawHeat(g,rows,def.name);
  else if(def.id.includes('network')||def.id.includes('chord')||def.id.includes('sankey')) drawNetwork(g,rows,def.name,def.mode==='3D');
  else if(def.id.includes('spiral')) drawSpiral(g,rows,def.name);
  else if(def.id.includes('wheel')||def.id.includes('chain')) drawWheel(g,rows,def.name,def.mode==='3D');
  else if(def.mode==='3D') draw3DColumns(g,rows,def.name);
  else drawBars(g,rows,def.name);
  $('chartRuntime').innerHTML = `<span class="pill">source: ${s.source}</span><span class="pill">t=${Math.round(t)}</span><span class="pill">save-ready PNG</span><span class="pill">${gallery.length} charts</span>`;
}
function populate(){
  const select=$('chartSelect'), grid=$('chartButtonGrid'); if(!select||!grid)return;
  const filter=$('chartFilter')?.value||'all';
  const list=gallery.filter(c=>filter==='all'||c.mode===filter||c.category===filter);
  select.innerHTML=list.map(c=>`<option value="${c.id}">${c.icon} ${c.name}</option>`).join('');
  if(!list.find(c=>c.id===chartId)) chartId=list[0]?.id||gallery[0].id;
  select.value=chartId;
  grid.innerHTML=list.map(c=>`<button class="side-card mini-chart ${c.id===chartId?'active':''}" data-chart="${c.id}"><strong>${c.icon} ${c.name}</strong><small>${c.mode} · ${c.category}</small></button>`).join('');
  document.querySelectorAll('[data-chart]').forEach(b=>b.onclick=()=>{chartId=b.dataset.chart;populate();render();});
}
function savePNG(){
  const canvas=$('advancedChartCanvas'); if(!canvas)return;
  const def=gallery.find(x=>x.id===chartId)||gallery[0];
  const a=document.createElement('a'); a.href=canvas.toDataURL('image/png'); a.download=`space_wales_${def.id}.png`; a.click();
}
function exportJSON(){
  const def=gallery.find(x=>x.id===chartId)||gallery[0];
  const payload={version:'5.4',chart:def,snapshot:lastSnapshot,generated_at:new Date().toISOString()};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`space_wales_${def.id}.json`; a.click(); URL.revokeObjectURL(a.href);
}
function loop(){ if(animating){t += 1 + Number($('chartSpeed')?.value||45)/20; render();} requestAnimationFrame(loop); }
function init(){
  if(!$('advancedChartCanvas')) return;
  populate(); render();
  $('chartSelect').onchange=()=>{chartId=$('chartSelect').value;populate();render();};
  $('chartFilter').onchange=()=>{populate();render();};
  $('chartAnimSource').onchange=render;
  $('chartPlayBtn').onclick=()=>{animating=!animating;$('chartPlayBtn').textContent=animating?'▶ chart animation':'⏸ chart paused';$('chartPlayBtn').classList.toggle('active',animating);};
  $('chartSaveBtn').onclick=savePNG; $('chartExportBtn').onclick=exportJSON;
  loop();
}
window.SpaceChartLab={render,savePNG,exportJSON,charts:gallery};
document.addEventListener('DOMContentLoaded',init);
})();