(function(){
"use strict";
const EPS = 1e-9;
const clamp=(v,lo=0,hi=1)=>Math.max(lo,Math.min(hi,Number(v)||0));
const sum=(arr,fn=x=>x)=>(arr||[]).reduce((a,x,i)=>a+(Number(fn(x,i))||0),0);
const round=(n,dp=3)=>Math.round((Number(n)||0)*10**dp)/10**dp;

function knapsack(items,budget,scale=100000){
  items=items||[];
  const cap=Math.max(0,Math.floor((Number(budget)||0)/scale));
  const dp=Array(cap+1).fill(0);
  const keep=Array.from({length:cap+1},()=>[]);
  for(const it of items){
    const w=Math.max(1,Math.round((Number(it.cost)||0)/scale));
    const v=Number(it.value)||0;
    for(let c=cap;c>=w;c--){
      const cand=dp[c-w]+v;
      if(cand>dp[c]){dp[c]=cand;keep[c]=keep[c-w].concat(it.id);}
    }
  }
  const selectedIds=keep[cap]||[];
  return {algorithm:"0/1 knapsack",selectedIds,value:round(dp[cap]),cost:sum(selectedIds,id=>items.find(x=>x.id===id)?.cost||0)};
}
function subsetSumNear(items,target,scale=100000){
  items=items||[];
  const cap=Math.max(0,Math.floor((Number(target)||0)/scale));
  let states=new Map([[0,[]]]);
  for(const it of items){
    const w=Math.max(1,Math.round((Number(it.cost)||0)/scale));
    const next=new Map(states);
    for(const [t,ids] of states.entries()){
      const nt=t+w;
      if(nt<=cap&&!next.has(nt))next.set(nt,ids.concat(it.id));
    }
    states=next;
  }
  const best=Math.max(...states.keys());
  const selectedIds=states.get(best)||[];
  const spend=sum(selectedIds,id=>items.find(x=>x.id===id)?.cost||0);
  return {algorithm:"near-target subset sum",selectedIds,spend,remaining:(Number(target)||0)-spend};
}
function haversineKm(a,b){
  if(!a||!b||typeof a.lat!=="number"||typeof b.lat!=="number")return 0;
  const R=6371.0088,p1=a.lat*Math.PI/180,p2=b.lat*Math.PI/180,dp=(b.lat-a.lat)*Math.PI/180,dl=(b.lon-a.lon)*Math.PI/180;
  const q=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
  return 2*R*Math.asin(Math.sqrt(q));
}
function coverage(assets,stations,budget,opts={}){
  assets=assets||[];stations=stations||[];
  const threshold=opts.thresholdMinutes??18,speed=opts.speedKmh??55,turnout=opts.turnoutMinutes??2;
  const selectedIds=[],covered=new Set();let spend=0;const remaining=new Map(stations.map(s=>[s.id,s]));
  const assetValue=a=>{
    const pop=Math.log10((Number(a.people)||1000)+10),risk=Number(a.risk??.5);
    const typeMul={hospital:1.45,gp:1.25,school:1.18,university:1.12,library:.86,education:1.1,animals:.96,agrarian:1,spacegis:1.05,transport:1.2}[String(a.type||"").toLowerCase()]||1;
    return typeMul*((Number(a.value)||60)*.55+risk*100*.35+pop*7.5);
  };
  const mins=(s,a)=>turnout+(haversineKm(s,a)/Math.max(1,speed))*60;
  while(remaining.size){
    let best=null,bestScore=-Infinity;
    for(const st of remaining.values()){
      if(spend+st.cost>budget)continue;
      let gain=0;
      for(const a of assets)if(!covered.has(a.id)&&mins(st,a)<=threshold)gain+=assetValue(a)*(Number(st.readiness??.82));
      const score=gain/Math.max(1,st.cost);
      if(gain>0&&score>bestScore){best=st;bestScore=score;}
    }
    if(!best)break;
    selectedIds.push(best.id);spend+=best.cost;remaining.delete(best.id);
    for(const a of assets)if(mins(best,a)<=threshold)covered.add(a.id);
  }
  const totalValue=sum(assets,assetValue),coveredValue=sum(assets.filter(a=>covered.has(a.id)),assetValue);
  return {algorithm:"greedy maximal coverage",selectedIds,spend,coveredAssetIds:[...covered],coveragePct:round(100*covered.size/Math.max(1,assets.length),2),valuePct:round(100*coveredValue/Math.max(EPS,totalValue),2),roiScore:round(coveredValue/Math.max(1,spend/1_000_000),3)};
}
function acoRoute(nodes,pheromone={},opts={}){
  nodes=(nodes||[]).filter(n=>typeof n.lat==="number"&&typeof n.lon==="number");
  if(!nodes.length)return {algorithm:"ACO",route:[],lengthKm:0,pheromone};
  const alpha=opts.alpha??1.1,beta=opts.beta??2.1,evap=opts.evaporation??.06,start=opts.start||nodes[0].id;
  const byId=Object.fromEntries(nodes.map(n=>[n.id,n]));const route=[start];const unvisited=new Set(nodes.map(n=>n.id).filter(id=>id!==start));
  const dist=(a,b)=>Math.max(.01,haversineKm(byId[a],byId[b]));
  while(unvisited.size){
    const cur=route[route.length-1];
    const choices=[...unvisited].map(id=>{const tau=pheromone[cur+">"+id]??1,eta=1/dist(cur,id);return {id,score:Math.pow(tau,alpha)*Math.pow(eta,beta)};});
    const total=sum(choices,x=>x.score)||1;let r=Math.random()*total,pick=choices[0].id;
    for(const c of choices){r-=c.score;if(r<=0){pick=c.id;break;}}
    route.push(pick);unvisited.delete(pick);
  }
  const lengthKm=sum(route.slice(1),(id,i)=>dist(route[i],id));
  for(const k of Object.keys(pheromone))pheromone[k]*=(1-evap);
  for(let i=1;i<route.length;i++){const k=route[i-1]+">"+route[i];pheromone[k]=(pheromone[k]??1)+100/Math.max(1,lengthKm);}
  return {algorithm:"ACO pheromone route construction",route,lengthKm:round(lengthKm,2),pheromone};
}
function bcoAllocate(projects,bees=100){
  projects=projects||[];
  const scored=projects.map(p=>{const nectar=(Number(p.value||p.quality)||1)/Math.max(1,Math.sqrt((Number(p.cost)||1)/1_000_000))*(1-(Number(p.risk)||0)*.24);return {...p,nectar};}).sort((a,b)=>b.nectar-a.nectar);
  const total=sum(scored,x=>x.nectar)||1;
  return scored.map(p=>({id:p.id,label:p.label||p.name||p.id,bees:Math.round(p.nectar/total*bees),nectar:round(p.nectar)}));
}
function psoStep(particles,objective){
  particles=particles||[];
  if(!particles.length)return {algorithm:"PSO",particles:[],globalBest:{position:[],score:0}};
  const w=.62,c1=1.35,c2=1.55;let globalBest=particles[0].best||{position:particles[0].position.slice(),score:-Infinity};
  for(const p of particles){const score=objective(p.position);if(!p.best||score>p.best.score)p.best={position:p.position.slice(),score};if(p.best.score>globalBest.score)globalBest={position:p.best.position.slice(),score:p.best.score};}
  for(const p of particles){p.velocity=p.velocity.map((v,i)=>w*v+c1*Math.random()*(p.best.position[i]-p.position[i])+c2*Math.random()*(globalBest.position[i]-p.position[i]));p.position=p.position.map((x,i)=>clamp(x+p.velocity[i],0,1));}
  return {algorithm:"PSO update",particles,globalBest};
}
function predatorPreyStep(state={},dt=.045){
  const prey=Math.max(0,state.prey??80),pred=Math.max(0,state.predator??20);
  const a=state.preyGrowth??1.1,b=state.predation??.018,c=state.predatorDeath??.65,d=state.predatorEfficiency??.011;
  const np=Math.max(0,prey+(a*prey-b*prey*pred)*dt),ny=Math.max(0,pred+(d*prey*pred-c*pred)*dt);
  const balance=100/(1+Math.abs((np/(ny+EPS))-4));
  return {...state,prey:round(np),predator:round(ny),balance:round(balance,2)};
}
function mandelbrotIterations(cx,cy,maxIter=64){let x=0,y=0,iter=0;while(x*x+y*y<=4&&iter<maxIter){const xt=x*x-y*y+cx;y=2*x*y+cy;x=xt;iter++;}return iter;}
function fractalPruneScore({urgency=.4,risk=.5,zoom=.5,roi=.7,mandelX=-.745,mandelY=.113}={}){
  const mandel=mandelbrotIterations(mandelX,mandelY,64)/64;
  const depth=Math.round(1+9*clamp(.25*urgency+.25*risk+.2*zoom+.2*roi+.1*mandel));
  return {algorithm:"Mandelbrot/fractal behaviour-tree pruning",depth,prune:round(1-depth/10,3),mandelbrot:round(mandel,3)};
}
function composeROI(values={},weights={finance:.18,access:.14,skills:.18,ecology:.18,resilience:.14,enterprise:.1,time:.08}){
  const weighted=Object.entries(weights).reduce((a,[k,w])=>a+(Number(values[k])||0)*w,0);
  return {algorithm:"weighted ROI composition",weightedScore:round(weighted),multiple:round(1.15+(weighted/100)*3.8,3)};
}
window.SpaceWalesMathPlus={clamp,sum,round,knapsack,subsetSumNear,haversineKm,coverage,acoRoute,bcoAllocate,psoStep,predatorPreyStep,mandelbrotIterations,fractalPruneScore,composeROI};
})();