(function(){
const D=window.SPACE_WALES_V5_DATA;
const CAP=D.budget.annual_gbp, STAFF=D.budget.staff_total;
const ids=D.allocations.map(a=>a.id);
const money=n=>n>=1e9?'£'+(n/1e9).toFixed(2).replace(/\.00$/,'')+'bn':n>=1e6?'£'+(n/1e6).toFixed(1).replace(/\.0$/,'')+'m':'£'+Math.round(n).toLocaleString();
const clamp=(v,min=0,max=100)=>Math.max(min,Math.min(max,v));
function baseline(){return Object.fromEntries(D.allocations.map(a=>[a.id,a.annual_gbp]))}
function baselineStaff(){return Object.fromEntries(D.allocations.map(a=>[a.id,a.staff||Math.round(STAFF*(a.staff_pct||0)/100)]))}
function baselineCompetition(){return Object.fromEntries(D.competitions.map(c=>[c.id,c.budget_gbp||0]))}
function baselineBadges(){return Object.fromEntries(D.badges.map(b=>[b.id,b.roi_weight||1]))}
function baselineCohorts(){return Object.fromEntries(D.population.map(p=>[p.id,{consumer_need:p.consumer_need,producer_capacity:p.producer_capacity}]))}
function normaliseToCap(values, keys, cap){const total=keys.reduce((s,k)=>s+(+values[k]||0),0); if(total<=cap) return {...values}; const scale=cap/total,out={}; keys.forEach(k=>out[k]=Math.round((+values[k]||0)*scale)); return out}
function normaliseBudget(values){return normaliseToCap(values,ids,CAP)}
function normaliseStaff(values){return normaliseToCap(values,ids,STAFF)}
function normaliseCompetitions(values,cap){return normaliseToCap(values,D.competitions.map(c=>c.id),Math.max(1,cap||CAP))}
function applyTune(values,tune){const out={...values}; Object.entries(tune.allocation_modifiers||{}).forEach(([k,v])=>{if(k in out)out[k]=(out[k]||0)+v*7500000}); return normaliseBudget(out)}
function totals(values){const total=ids.reduce((s,k)=>s+(+values[k]||0),0); return{total,remaining:CAP-total,over:Math.max(0,total-CAP)}}
function staffTotals(values){const total=ids.reduce((s,k)=>s+(+values[k]||0),0); return{total,remaining:STAFF-total,over:Math.max(0,total-STAFF)}}
function competitionTotals(values){const keys=D.competitions.map(c=>c.id); const total=keys.reduce((s,k)=>s+(+values[k]||0),0); return {total}}
function pct(values,k){return((values[k]||0)/CAP)*100}
function staffPct(staff,k){return((staff[k]||0)/STAFF)*100}
function staffFromBudget(values){const total=ids.reduce((s,k)=>s+(+values[k]||0),0)||1,out={};ids.forEach(k=>out[k]=Math.round(STAFF*((values[k]||0)/total)));let diff=STAFF-Object.values(out).reduce((a,b)=>a+b,0);if(diff!==0)out[ids[0]]+=diff;return out}
function cohort(tune){return D.population.find(p=>p.id===tune.cohort)||D.population[0]}
function cohortSettingsFor(cohortValues, id){return (cohortValues&&cohortValues[id]) || baselineCohorts()[id]}
function providerConsumer(tune,values,cohortValues){const c=cohort(tune), cv=cohortSettingsFor(cohortValues,c.id);const prioritySpend=c.priority.reduce((s,k)=>s+(values[k]||0),0);const consumerDemand=(cv.consumer_need/100)*(c.people/D.budget.population)*(prioritySpend/CAP)*100;const providerValue=(cv.producer_capacity/100)*(c.people/D.budget.population)*(Object.values(values).reduce((a,b)=>a+b,0)/CAP)*160;return{cohort:c,consumerDemand:clamp(consumerDemand*10),providerValue:clamp(providerValue*10),prioritySpend,settings:cv}}
function badgeScore(values,tune,badgeWeights){const c=cohort(tune);const eligible=D.badges.filter(b=>b.age.includes(c.age));return eligible.map(b=>{let s=(badgeWeights?.[b.id] ?? b.roi_weight ?? 1)*12;b.subjects.forEach(sub=>{const so=D.subjects.find(x=>x.id===sub);if(so)so.budget_bias.forEach(k=>s+=pct(values,k)*.32)});return{...b,roi_weight:(badgeWeights?.[b.id]??b.roi_weight),score:clamp(s)}}).sort((a,b)=>b.score-a.score)}
function roi(values,tune,badgeWeights,cohortValues,staffValues){const pc=providerConsumer(tune,values,cohortValues),badges=badgeScore(values,tune,badgeWeights);const multi=(pct(values,'pathway_league')+pct(values,'digital_farm_twins')+pct(values,'education')+pct(values,'enterprise'))/4;const res=(pct(values,'cyber')+pct(values,'health')+pct(values,'eco_energy'))/3;const staffBalance=staffValues?Math.min(1,staffTotals(staffValues).total/STAFF):1;const score=clamp(1.1+multi/18+res/28+(badges[0]?.score||0)/85+staffBalance*.12,0,8);return{multiple:score,pc,badges,financialValue:score*totals(values).total}}
function horizons(values){return D.budget.horizons.map(y=>({years:y,total:Object.values(values).reduce((a,b)=>a+b,0)*y,perPerson:Object.values(values).reduce((a,b)=>a+b,0)*y/D.budget.population}))}
window.SpaceWalesV5Engine={ids,money,clamp,baseline,baselineStaff,baselineCompetition,baselineBadges,baselineCohorts,normaliseBudget,normaliseStaff,normaliseCompetitions,applyTune,totals,staffTotals,competitionTotals,pct,staffPct,staffFromBudget,cohort,providerConsumer,badgeScore,roi,horizons};
})();