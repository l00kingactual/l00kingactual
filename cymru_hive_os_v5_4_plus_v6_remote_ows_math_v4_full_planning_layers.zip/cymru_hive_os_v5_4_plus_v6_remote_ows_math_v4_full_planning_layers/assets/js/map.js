(function(){
const D=window.SPACE_WALES_V5_DATA;
let canvas,ctx,img=new Image(),scale=1,panX=0,panY=0,drag=false,last={x:0,y:0},selected=null;
let agents=[], pher={}, tick=0, lastValues={}, lastTune=null;
let metricState={routeScore:50,scoutScore:50,ecologyScore:50,farmTwinScore:50,tuneValue:0,baseTuneRate:1.25,movementROI:0,totalTuneMovementRate:1.25};

function init(){
 canvas=document.getElementById('walesMap'); if(!canvas)return; ctx=canvas.getContext('2d');
 img.src=D.map_asset; img.onload=draw; img.onerror=draw;
 makeAgents(); resetPheromones();
 canvas.addEventListener('wheel',e=>{e.preventDefault();const before=screenToWorld(e.offsetX,e.offsetY);scale*=e.deltaY<0?1.12:.88;scale=Math.max(.55,Math.min(5,scale));const after=screenToWorld(e.offsetX,e.offsetY);panX+=(after.x-before.x)*scale;panY+=(after.y-before.y)*scale;draw()},{passive:false});
 canvas.addEventListener('mousedown',e=>{drag=true;last={x:e.offsetX,y:e.offsetY}});
 canvas.addEventListener('mouseup',()=>drag=false); canvas.addEventListener('mouseleave',()=>drag=false);
 canvas.addEventListener('mousemove',e=>{if(drag){panX+=e.offsetX-last.x;panY+=e.offsetY-last.y;last={x:e.offsetX,y:e.offsetY};draw()}});
 canvas.addEventListener('click',e=>{const p=screenToWorld(e.offsetX,e.offsetY);const hit=D.hives.find(h=>Math.hypot(p.x-h.x*canvas.width/100,p.y-h.y*canvas.height/100)<24/scale);if(hit){selected=hit;renderSelected(hit);draw()}});
 const zi=document.getElementById('zoomInBtn'),zo=document.getElementById('zoomOutBtn'),zr=document.getElementById('resetMapBtn');
 if(zi)zi.onclick=()=>{scale=Math.min(5,scale*1.2);draw()};
 if(zo)zo.onclick=()=>{scale=Math.max(.55,scale/1.2);draw()};
 if(zr)zr.onclick=()=>{scale=1;panX=0;panY=0;draw()};
 renderKey();
}
function makeAgents(){
 const mk=(kind,icon,n)=>Array.from({length:n},()=>({kind,icon,x:Math.random()*980,y:Math.random()*680,tx:Math.random()*980,ty:Math.random()*680,node:Math.floor(Math.random()*D.hives.length),energy:45+Math.random()*55,speed:.45+Math.random()*1.1}));
 agents=[
   ...mk('bco_bee','🐝',34), ...mk('honey','🍯',14), ...mk('aco_ant','🐜',24),
   ...mk('pso_bird','🦅',10), ...mk('fish','🐟',12), ...mk('prey','🐁',18),
   ...mk('predator','🦊',8), ...mk('farm_twin','🚜',10), ...mk('cadet','🎖️',8), ...mk('astro','🔭',8)
 ];
}
function resetPheromones(){pher={}; for(const a of D.hives)for(const b of D.hives)if(a.id!==b.id)pher[a.id+'>'+b.id]=1}
function screenToWorld(x,y){return{x:(x-panX)/scale,y:(y-panY)/scale}}
function hivePoint(h){return{x:h.x*canvas.width/100,y:h.y*canvas.height/100}}
function valueForHive(h,values,tune){
 const budget=(values&&values[h.type])||0, max=(D.budget&&D.budget.annual_gbp)||2500000000;
 const modifier=(tune&&tune.allocation_modifiers&&tune.allocation_modifiers[h.type])||0;
 return Math.max(1, budget/max*100 + modifier*4 + (selected&&selected.id===h.id?8:0));
}
function chooseHiveFor(kind,values,tune){
 let candidates=D.hives.map(h=>({h,score:valueForHive(h,values,tune)+Math.random()*10}));
 if(kind==='bco_bee'||kind==='honey') candidates=candidates.filter(x=>['pathway_league','education','animals','hives','enterprise','agrarian'].includes(x.h.type)||Math.random()<.35);
 if(kind==='farm_twin') candidates=candidates.filter(x=>['digital_farm_twins','agrarian','education','enterprise'].includes(x.h.type)||Math.random()<.2);
 if(kind==='astro') candidates=candidates.filter(x=>['spacegis','education','digital_farm_twins'].includes(x.h.type)||Math.random()<.25);
 if(kind==='cadet') candidates=candidates.filter(x=>['pathway_league','transport','health','cyber'].includes(x.h.type)||Math.random()<.25);
 if(kind==='fish') candidates=candidates.filter(x=>['animals','agrarian','spacegis'].includes(x.h.type)||Math.random()<.2);
 if(kind==='prey') candidates=candidates.filter(x=>['animals','agrarian','hives'].includes(x.h.type)||Math.random()<.2);
 if(kind==='predator') candidates=candidates.filter(x=>['animals','agrarian'].includes(x.h.type)||Math.random()<.2);
 if(!candidates.length) candidates=D.hives.map(h=>({h,score:1}));
 candidates.sort((a,b)=>b.score-a.score);
 return candidates[Math.floor(Math.random()*Math.min(4,candidates.length))].h;
}
function acoNext(agent,values,tune){
 const current=D.hives[agent.node % D.hives.length];
 const opts=D.hives.filter(h=>h.id!==current.id).map(h=>({h,score:(pher[current.id+'>'+h.id]||1)*1.4 + valueForHive(h,values,tune)}));
 opts.sort((a,b)=>b.score-a.score);
 const pick=opts[Math.floor(Math.random()*Math.min(5,opts.length))].h;
 pher[current.id+'>'+pick.id]=(pher[current.id+'>'+pick.id]||1)+0.6+valueForHive(pick,values,tune)/60;
 agent.node=D.hives.findIndex(h=>h.id===pick.id);
 return pick;
}
function step(tune,values){
 if(!canvas)return; tick++; lastValues=values||lastValues; lastTune=tune||lastTune;
 for(const k in pher) pher[k]*=.996;
 for(const a of agents){
   let target=null;
   if(Math.hypot(a.tx-a.x,a.ty-a.y)<10 || tick%360===0){
     if(a.kind==='aco_ant') target=acoNext(a,lastValues,lastTune);
     else target=chooseHiveFor(a.kind,lastValues,lastTune);
     const p=hivePoint(target); a.tx=p.x+(Math.random()-.5)*38; a.ty=p.y+(Math.random()-.5)*38;
   }
   if(a.kind==='predator'){
     const prey=nearest(a,agents.filter(x=>x.kind==='prey'||x.kind==='fish'));
     if(prey){a.tx=prey.x;a.ty=prey.y;if(Math.hypot(a.x-prey.x,a.y-prey.y)<14){prey.x=Math.random()*canvas.width;prey.y=Math.random()*canvas.height;prey.energy-=8;a.energy+=5}}
   }
   if(a.kind==='prey'||a.kind==='fish'){
     const pred=nearest(a,agents.filter(x=>x.kind==='predator'||x.kind==='pso_bird'));
     if(pred&&Math.hypot(a.x-pred.x,a.y-pred.y)<90){a.tx=a.x+(a.x-pred.x)*1.8;a.ty=a.y+(a.y-pred.y)*1.8}
   }
   if(a.kind==='pso_bird'){
     const best=D.hives.slice().sort((x,y)=>valueForHive(y,lastValues,lastTune)-valueForHive(x,lastValues,lastTune))[0];
     const p=hivePoint(best); a.tx=a.tx*.992+p.x*.008; a.ty=a.ty*.992+p.y*.008;
   }
   const dx=a.tx-a.x, dy=a.ty-a.y, d=Math.hypot(dx,dy)||1;
   const speed=a.speed*(a.kind==='pso_bird'?1.35:a.kind==='aco_ant'?1.15:1);
   a.x+=dx/d*speed; a.y+=dy/d*speed;
   if(a.x<0||a.x>canvas.width)a.tx=Math.random()*canvas.width;
   if(a.y<0||a.y>canvas.height)a.ty=Math.random()*canvas.height;
 }
 updateMetrics(lastTune,lastValues); draw();
}
function nearest(a,list){let best=null,bd=Infinity;for(const x of list){const d=Math.hypot(a.x-x.x,a.y-x.y);if(d<bd){bd=d;best=x}}return best}
function updateMetrics(tune,values){
 const highPher=Math.max(...Object.values(pher));
 const routeScore=Math.min(100,38+highPher*10);
 const bees=agents.filter(a=>a.kind==='bco_bee'||a.kind==='honey');
 let scoutScore=0; for(const b of bees){const h=D.hives.slice().sort((x,y)=>Math.hypot(b.x-x.x*canvas.width/100,b.y-x.y*canvas.height/100)-Math.hypot(b.x-y.x*canvas.width/100,b.y-y.y*canvas.height/100))[0]; scoutScore+=valueForHive(h,values,tune)} scoutScore=Math.min(100,scoutScore/(bees.length||1)*4);
 const prey=agents.filter(a=>a.kind==='prey'||a.kind==='fish').length, pred=agents.filter(a=>a.kind==='predator'||a.kind==='pso_bird').length;
 const animalPct=((values&&values.animals)||0)/((D.budget&&D.budget.annual_gbp)||2500000000)*100;
 const ecologyScore=Math.max(0,Math.min(100,50 + animalPct*2 + Math.min(18,prey/(pred||1)*4) - Math.abs(prey/(pred||1)-2.2)*6));
 const farmTwinScore=Math.min(100,((values&&values.digital_farm_twins)||0)/((D.budget&&D.budget.annual_gbp)||2500000000)*220 + ((values&&values.agrarian)||0)/((D.budget&&D.budget.annual_gbp)||2500000000)*80);
 let tuneValue=0; if(tune&&tune.allocation_modifiers) for(const [k,v] of Object.entries(tune.allocation_modifiers)) tuneValue += (((values&&values[k])||0)/((D.budget&&D.budget.annual_gbp)||2500000000))*v*12;
 tuneValue=Math.min(100,Math.max(0,tuneValue));
 const movementROI=(routeScore*.22+scoutScore*.24+ecologyScore*.22+farmTwinScore*.2+tuneValue*.12)/100*.75;
 const baseTuneRate=(D.map_roi&&D.map_roi.base_tune_roi_rate)||1.25;
 metricState={routeScore,scoutScore,ecologyScore,farmTwinScore,tuneValue,baseTuneRate,movementROI,totalTuneMovementRate:baseTuneRate+(tuneValue/100*.55)+movementROI};
 renderMapMetrics();
}
function metrics(){return {...metricState}}
function renderSelected(h){
 const el=document.getElementById('selectedHive'); if(el)el.textContent=h.icon+' '+h.name;
 const txt=document.getElementById('selectedHiveText'); if(txt)txt.innerHTML=`<strong>${h.type}</strong> hive<br>GPS ${h.lat.toFixed(4)}, ${h.lon.toFixed(4)}<br>Movement value follows budget + tune modifiers.`;
 renderMapMetrics();
}
function bar(label,val,txt){return`<div class="barrow"><strong>${label}</strong><span class="bar"><i style="width:${Math.max(1,Math.min(100,val))}%"></i></span><span>${txt||Math.round(val)}</span></div>`}
function renderMapMetrics(){
 const m=metricState, box=document.getElementById('mapMetrics'); if(box) box.innerHTML=
   bar('🐜 ACO route',m.routeScore,Math.round(m.routeScore)+'/100')+
   bar('🐝 BCO scout',m.scoutScore,Math.round(m.scoutScore)+'/100')+
   bar('🐟🦊 ecology balance',m.ecologyScore,Math.round(m.ecologyScore)+'/100')+
   bar('🚜 farm twin',m.farmTwinScore,Math.round(m.farmTwinScore)+'/100')+
   bar('🎚️ tune value',m.tuneValue,Math.round(m.tuneValue)+'/100')+
   `<p><strong>Base tune ROI:</strong> ${m.baseTuneRate.toFixed(2)}x<br><strong>Movement ROI add:</strong> ${m.movementROI.toFixed(2)}x<br><strong>Total tune/movement rate:</strong> ${m.totalTuneMovementRate.toFixed(2)}x</p>`;
 const mini=document.getElementById('mapKeyMini'); if(mini) mini.innerHTML=(D.map_key||[]).slice(0,5).map(k=>`<span class="pill">${k.icon} ${k.name.split('/')[0]}</span>`).join(' ');
}
function renderKey(){
 const box=document.getElementById('mapKeyPanel'); if(!box||!D.map_key)return;
 box.innerHTML=D.map_key.map(k=>`<div class="key-card"><strong>${k.icon} ${k.name}</strong><small><b>Movement:</b> ${k.movement}<br><b>ROI:</b> ${k.roi}</small></div>`).join('');
 renderMapMetrics();
}
function draw(){
 if(!canvas)return; ctx.clearRect(0,0,canvas.width,canvas.height); ctx.save(); ctx.translate(panX,panY); ctx.scale(scale,scale);
 const W=canvas.width,H=canvas.height; ctx.fillStyle='#081426';ctx.fillRect(0,0,W,H);
 if(img.complete&&img.naturalWidth){ctx.globalAlpha=.78;ctx.drawImage(img,0,0,W,H);ctx.globalAlpha=1}else{ctx.fillStyle='#31475e';ctx.fillRect(120,40,520,590);ctx.fillStyle='#eaf2ff';ctx.font='32px system-ui';ctx.fillText('WALES MAP',260,330)}
 drawPheromones();
 D.hives.forEach(h=>{const x=h.x*W/100,y=h.y*H/100;ctx.fillStyle=selected&&selected.id===h.id?'#facc15':'rgba(7,17,31,.88)';ctx.beginPath();ctx.arc(x,y,18,0,Math.PI*2);ctx.fill();ctx.fillStyle=selected&&selected.id===h.id?'#07111f':'#fff';ctx.font='18px system-ui';ctx.textAlign='center';ctx.fillText(h.icon,x,y+7);ctx.font='11px system-ui';ctx.fillStyle='#fff';ctx.fillText(h.name,x,y+34)});
 agents.forEach(a=>{ctx.font=(a.kind==='pso_bird'||a.kind==='farm_twin')?'18px system-ui':'15px system-ui';ctx.fillText(a.icon,a.x,a.y)});
 ctx.restore(); const mi=document.getElementById('mapInfo'); if(mi)mi.textContent=`zoom ${scale.toFixed(2)}× · pan ${Math.round(panX)}, ${Math.round(panY)} · movement ROI ${metricState.totalTuneMovementRate.toFixed(2)}x`;
}
function drawPheromones(){
 const entries=Object.entries(pher).sort((a,b)=>b[1]-a[1]).slice(0,28);
 for(const [edge,val] of entries){if(val<1.4)continue;const [a,b]=edge.split('>'),ha=D.hives.find(h=>h.id===a),hb=D.hives.find(h=>h.id===b);if(!ha||!hb)continue;const pa=hivePoint(ha),pb=hivePoint(hb);ctx.strokeStyle=`rgba(250,204,21,${Math.min(.45,val/18)})`;ctx.lineWidth=Math.min(5,val/4);ctx.beginPath();ctx.moveTo(pa.x,pa.y);ctx.lineTo(pb.x,pb.y);ctx.stroke();}
}
window.SpaceMap={init,step,draw,metrics,renderKey};
document.addEventListener('DOMContentLoaded',init);
})();