#!/usr/bin/env bash
set -e
TARGET="${1:-/var/www/html/cymru-hive-v54-plus-remote}"
cd "$(dirname "$0")/.."
sudo mkdir -p "$TARGET"
sudo rsync -av ./ "$TARGET/"
sudo chown -R www-data:www-data "$TARGET"
echo "Open: http://localhost/$(basename "$TARGET")/"
echo "Remote lab: http://localhost/$(basename "$TARGET")/remote_data_lab.html"
