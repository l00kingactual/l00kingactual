# Cymru Hive OS V5.4+ Remote OWS Plan

## Rule

V5.4 remains the forward WebUI base.

Remote data is an add-on, not a replacement.

## Services

- WMS: image overlay for the WebUI map.
- WFS: vector features; use small bounding boxes first.
- WPS: optional processing-service discovery only. DataMapWales may not expose WPS; if not, use local Python processing over WFS data.

## Why WPS is cautious

WPS can execute server-side geoprocessing. This package supports `GetCapabilities` and `DescribeProcess`. It does not blindly execute arbitrary WPS processes.

## Local/PHP mode

Install under Apache/PHP and use:

```text
http://localhost/<folder>/remote_data_lab.html
```

## Python mode

```bash
python3 tools/ows_fetch.py --service datamap_habitat_wales_wfs --mode capabilities
python3 tools/ows_fetch.py --service datamap_habitat_wales_wfs --mode wfs --typename <feature_type_from_capabilities> --bbox -4.2,53.0,-4.0,53.3
```
