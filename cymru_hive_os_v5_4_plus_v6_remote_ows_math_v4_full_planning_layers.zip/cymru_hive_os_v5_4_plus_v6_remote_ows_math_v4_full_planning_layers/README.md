# Cymru Hive OS v5.4 · 64 Charts + Animated Graph Lab

Adds a dedicated charting / plotting / graphing WebUI.

## Added

- 32 2D chart / plot / graph types
- 32 pseudo-3D chart / plot / graph types
- animated charting
- live/model/static chart data modes
- save current graph as PNG
- export current chart snapshot as JSON
- chart selector, category filter and chart button grid
- chart metadata table
- SQL, Neo4j, CSV and JSON chart-gallery exports

## Animation modes

- **live WebUI/model state**: uses the current WebUI model and map movement state where available
- **synthetic model time**: creates time-varying model curves/surfaces
- **static snapshot**: freezes the current chart state

## Run

```bash
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

The charting lab is on the main page and also has a `Charting Lab` analysis panel.
