# Cymru Hive OS v5.5 · Old WebUI JS Mathematics Update

This build goes back to the working old WebUI and leaves out the broken web-service map path.

## Added

- `assets/js/math_engine.js`
- `assets/js/math_lab.js`
- Mathematics Engine WebUI section
- Mathematics Engine analysis panel
- SQL/Cypher registry for JS maths functions

## Mathematics now in JS

- 0/1 knapsack
- near-target subset sum
- facility coverage
- ACO route probability and pheromone reinforcement
- BCO colony allocation
- PSO update
- predator/prey difference equation
- Mandelbrot/fractal pruning
- weighted ROI composition

## Run

```bash
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Apache

```bash
sudo rsync -av ./ /var/www/html/cymru-hive-os-v5-5/
sudo chown -R www-data:www-data /var/www/html/cymru-hive-os-v5-5/
```

Open:

```text
http://localhost/cymru-hive-os-v5-5/
```

## Note

This is the old WebUI base with better maths.  
The DataMapWales WMS/WFS package is not used in this build.
