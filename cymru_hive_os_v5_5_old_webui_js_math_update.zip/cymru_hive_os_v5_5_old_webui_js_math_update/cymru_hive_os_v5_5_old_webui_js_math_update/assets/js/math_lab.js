(function(){
'use strict';
const D = window.SPACE_WALES_V5_DATA;
const MATH = window.SpaceWalesMath;
const $ = id => document.getElementById(id);

let pheromone = {};
let predatorState = {prey:80, predator:20, preyGrowth:1.1, predation:.018, predatorDeath:.65, predatorEfficiency:.011};
let psoParticles = Array.from({length:18},()=>({
  position:[Math.random(),Math.random(),Math.random()],
  velocity:[0,0,0]
}));
let lastResult = null;

function money(n){ return n>=1e9 ? '£'+(n/1e9).toFixed(2)+'bn' : n>=1e6 ? '£'+(n/1e6).toFixed(2)+'m' : '£'+Math.round(n).toLocaleString(); }
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function out(obj){ const el=$('mathOut'); if(el) el.textContent = JSON.stringify(obj,null,2); lastResult=obj; }
function row(label,value,txt){return `<div class="barrow"><strong>${label}</strong><span class="bar"><i style="width:${Math.max(1,Math.min(100,value))}%"></i></span><span>${txt||Math.round(value)}</span></div>`;}

function demoProjects(){
  return D.allocations.map((a,i)=>({
    id:a.id,
    label:a.icon+' '+a.name,
    cost: Math.max(500000, Math.round(a.annual_gbp * (.025 + (i%5)*.01))),
    value: 45 + a.pct*4 + ((a.id==='pathway_league'||a.id==='digital_farm_twins'||a.id==='education'||a.id==='health')?28:0),
    risk: (i%7)/14
  }));
}
function demoHives(){
  return D.hives.map((h,i)=>({id:h.id,label:h.icon+' '+h.name, lat:h.lat, lon:h.lon, value:45+(i%5)*9, risk:(i%6)/12, people:1000+i*2500, type:h.type}));
}
function demoStations(){
  return D.hives.map((h,i)=>({id:"station_"+h.id, label:"🚑 "+h.name+" response node", lat:h.lat, lon:h.lon, cost:1_200_000+(i%6)*450_000, readiness:.72+(i%5)*.045, capacity:2+(i%4)}));
}

function drawBars(rows,title){
  const c=$('mathCanvas'); if(!c) return;
  const ctx=c.getContext('2d');
  ctx.clearRect(0,0,c.width,c.height);
  const bg=ctx.createLinearGradient(0,0,0,c.height); bg.addColorStop(0,'#081426'); bg.addColorStop(1,'#101c2f');
  ctx.fillStyle=bg; ctx.fillRect(0,0,c.width,c.height);
  ctx.fillStyle='#facc15'; ctx.font='24px system-ui'; ctx.fillText(title,36,38);
  const max=Math.max(...rows.map(r=>r.value),1), p=44;
  rows.slice(0,18).forEach((r,i)=>{
    const y=72+i*((c.height-110)/Math.min(rows.length,18));
    const w=(c.width-240)*(r.value/max);
    const g=ctx.createLinearGradient(p,y,p+w,y); g.addColorStop(0,'#39d5ff'); g.addColorStop(.65,'#facc15'); g.addColorStop(1,'#4ade80');
    ctx.fillStyle=g; ctx.fillRect(p,y,w,13);
    ctx.fillStyle='#eaf2ff'; ctx.font='12px system-ui'; ctx.textAlign='left'; ctx.fillText(r.label,p,y-5);
    ctx.fillStyle='#facc15'; ctx.textAlign='right'; ctx.fillText(r.fmt||Math.round(r.value),c.width-34,y+12);
  });
}
function updateMetrics(result){
  const el=$('mathMetrics'); if(!el) return;
  const entries = [];
  if(result.knapsack) entries.push(['🧮 knapsack', result.knapsack.value/4, result.knapsack.selectedIds.length+' items']);
  if(result.subset) entries.push(['🧩 subset spend', result.subset.spend/(result.subset.spend+Math.max(1,result.subset.remaining))*100, money(result.subset.spend)]);
  if(result.coverage) entries.push(['🚑 coverage', result.coverage.coveragePct, result.coverage.coveragePct+'%']);
  if(result.aco) entries.push(['🐜 ACO route', Math.max(1,100-result.aco.lengthKm/8), result.aco.lengthKm+' km']);
  if(result.pso) entries.push(['🦅 PSO best', result.pso.globalBest.score*100, result.pso.globalBest.score.toFixed(3)]);
  if(result.predatorPrey) entries.push(['🦊 ecology balance', result.predatorPrey.balance, result.predatorPrey.balance+'/100']);
  if(result.prune) entries.push(['🧬 tree depth', result.prune.depth*10, 'depth '+result.prune.depth]);
  if(result.roi) entries.push(['£ ROI', Math.min(100,result.roi.multiple*18), result.roi.multiple+'x']);
  el.innerHTML = entries.map(e=>row(e[0],e[1],e[2])).join('');
}
function runKnapsack(){
  const cap = Number($('mathBudget')?.value || 12500000);
  const items = demoProjects();
  const k = MATH.knapsack(items, cap, {scale:100000});
  const s = MATH.subsetSumNear(items, cap, {scale:100000});
  drawBars(k.selectedIds.map(id=>{const it=items.find(x=>x.id===id);return {label:it.label,value:it.value,fmt:money(it.cost)}}), "Knapsack selected projects");
  const result={knapsack:k, subset:s, items};
  updateMetrics(result); out(result);
}
function runCoverage(){
  const assets = demoHives();
  const stations = demoStations();
  const budget = Number($('mathBudget')?.value || 12500000);
  const coverage = MATH.facilityCoverage(assets,stations,budget,{thresholdMinutes:18,speedKmh:52,turnoutMinutes:2});
  drawBars(coverage.selectedIds.map(id=>{const st=stations.find(x=>x.id===id);return {label:st.label,value:st.readiness*100,fmt:money(st.cost)}}), "Greedy emergency/farm-hub coverage");
  const result={coverage, assets, stations};
  updateMetrics(result); out(result);
}
function runSwarm(){
  const nodes = demoHives();
  const aco = MATH.acoRoute(nodes,{pheromone,start:nodes[0].id});
  pheromone = aco.pheromone;
  const bco = MATH.bcoAllocate(demoProjects().map(p=>({id:p.id,label:p.label,quality:p.value,cost:p.cost,risk:p.risk})),100);
  const objective = pos => {
    const [education, ecology, enterprise] = pos;
    return Math.min(1, .42*education + .36*ecology + .22*enterprise - Math.abs(education-ecology)*.08);
  };
  const pso = MATH.psoStep(psoParticles, objective);
  psoParticles = pso.particles;
  drawBars([
    ...bco.slice(0,8).map(x=>({label:x.label,value:x.bees,fmt:x.bees+' bees'})),
    {label:'🐜 ACO route quality',value:Math.max(1,100-aco.lengthKm/8),fmt:aco.lengthKm+' km'},
    {label:'🦅 PSO score',value:pso.globalBest.score*100,fmt:pso.globalBest.score.toFixed(3)}
  ], "ACO / BCO / PSO mathematics");
  const result={aco,bco,pso:{globalBest:pso.globalBest}};
  updateMetrics(result); out(result);
}
function runEcology(){
  const steps = [];
  for(let i=0;i<48;i++){
    predatorState = MATH.predatorPreyStep(predatorState,.045);
    steps.push({...predatorState, step:i});
  }
  const prune = MATH.fractalPruneScore({
    urgency:Number($('mathUrgency')?.value || .45),
    risk:Number($('mathRisk')?.value || .55),
    zoom:Number($('mathZoom')?.value || .5),
    roi:Number($('mathRoiWeight')?.value || .7),
    mandelX:-.745 + (Math.random()-.5)*.02,
    mandelY:.113 + (Math.random()-.5)*.02
  });
  drawBars([
    {label:'🐁 prey',value:predatorState.prey,fmt:predatorState.prey},
    {label:'🦊 predator',value:predatorState.predator,fmt:predatorState.predator},
    {label:'⚖ ecology balance',value:predatorState.balance,fmt:predatorState.balance+'/100'},
    {label:'🧬 Mandelbrot complexity',value:prune.mandelbrot*100,fmt:Math.round(prune.mandelbrot*100)+'/100'},
    {label:'🌳 behaviour-tree depth',value:prune.depth*10,fmt:prune.depth}
  ], "Predator/prey + fractal pruning");
  const result={predatorPrey:predatorState, history:steps, prune};
  updateMetrics(result); out(result);
}
function runAll(){
  const cap = Number($('mathBudget')?.value || 12500000);
  const items = demoProjects(), assets = demoHives(), stations = demoStations();
  const knapsack = MATH.knapsack(items, cap, {scale:100000});
  const subset = MATH.subsetSumNear(items, cap, {scale:100000});
  const coverage = MATH.facilityCoverage(assets,stations,cap,{thresholdMinutes:18,speedKmh:52,turnoutMinutes:2});
  const aco = MATH.acoRoute(assets,{pheromone,start:assets[0].id});
  pheromone=aco.pheromone;
  const bco = MATH.bcoAllocate(items.map(p=>({id:p.id,label:p.label,quality:p.value,cost:p.cost,risk:p.risk})),100);
  const pso = MATH.psoStep(psoParticles, pos=>Math.min(1,.42*pos[0]+.36*pos[1]+.22*pos[2]-Math.abs(pos[0]-pos[1])*.08));
  psoParticles=pso.particles;
  predatorState = MATH.predatorPreyStep(predatorState,.045);
  const prune = MATH.fractalPruneScore({urgency:.55,risk:.45,zoom:.66,roi:.72});
  const roi = MATH.composeROI({base:1.18,range:3.8,values:{
    finance:knapsack.value/3,
    time:Math.max(1,100-aco.lengthKm/10),
    effort:coverage.coveragePct,
    skills:bco.slice(0,4).reduce((a,b)=>a+b.bees,0),
    ecology:predatorState.balance,
    access:coverage.valuePct,
    resilience:prune.depth*10
  }});
  drawBars([
    {label:'🧮 knapsack value',value:knapsack.value/4,fmt:knapsack.selectedIds.length+' items'},
    {label:'🧩 subset spend',value:subset.spend/cap*100,fmt:money(subset.spend)},
    {label:'🚑 coverage',value:coverage.coveragePct,fmt:coverage.coveragePct+'%'},
    {label:'🐜 ACO route',value:Math.max(1,100-aco.lengthKm/8),fmt:aco.lengthKm+' km'},
    {label:'🐝 BCO top allocation',value:bco[0]?.bees||0,fmt:(bco[0]?.bees||0)+' bees'},
    {label:'🦅 PSO score',value:pso.globalBest.score*100,fmt:pso.globalBest.score.toFixed(3)},
    {label:'🦊 ecology balance',value:predatorState.balance,fmt:predatorState.balance+'/100'},
    {label:'🧬 pruning depth',value:prune.depth*10,fmt:'depth '+prune.depth},
    {label:'£ composed ROI',value:Math.min(100,roi.multiple*18),fmt:roi.multiple+'x'}
  ], "Combined JS mathematics engine");
  const result={knapsack,subset,coverage,aco,bco,pso:{globalBest:pso.globalBest},predatorPrey:predatorState,prune,roi};
  updateMetrics(result); out(result);
}
function exportResult(){
  const payload = lastResult || {note:"Run a math model first."};
  const blob = new Blob([JSON.stringify({version:"5.5",generatedAt:new Date().toISOString(),mathResult:payload},null,2)], {type:"application/json"});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'cymru_hive_os_v5_5_js_math_result.json';
  a.click(); URL.revokeObjectURL(a.href);
}
function savePng(){
  const c=$('mathCanvas'); if(!c) return;
  const a=document.createElement('a'); a.href=c.toDataURL('image/png'); a.download='cymru_hive_os_v5_5_math_chart.png'; a.click();
}
function bind(){
  const pairs = [
    ['mathRunAll',runAll],['mathRunKnapsack',runKnapsack],['mathRunCoverage',runCoverage],
    ['mathRunSwarm',runSwarm],['mathRunEcology',runEcology],['mathExport',exportResult],['mathSavePng',savePng]
  ];
  pairs.forEach(([id,fn])=>{ const el=$(id); if(el) el.onclick=fn; });
  ['mathBudget','mathUrgency','mathRisk','mathZoom','mathRoiWeight'].forEach(id=>{ const el=$(id); if(el) el.oninput=runAll; });
  setTimeout(runAll,200);
}
document.addEventListener('DOMContentLoaded', bind);
window.SpaceWalesMathLab = {runAll,runKnapsack,runCoverage,runSwarm,runEcology,exportResult};
})();