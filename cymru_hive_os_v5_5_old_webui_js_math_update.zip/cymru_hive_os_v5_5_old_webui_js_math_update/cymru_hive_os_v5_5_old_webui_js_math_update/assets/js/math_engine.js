(function(){
'use strict';

const EPS = 1e-9;

function clamp(v, min=0, max=1){ return Math.max(min, Math.min(max, v)); }
function sum(arr, f=x=>x){ return arr.reduce((a,x)=>a+(Number(f(x))||0),0); }
function stableRound(n, dp=6){ const f=Math.pow(10,dp); return Math.round((Number(n)||0)*f)/f; }
function normaliseToCap(values, cap){
  const out = {...values};
  const total = Object.values(out).reduce((a,b)=>a+(Number(b)||0),0);
  if(total <= cap + EPS) return out;
  const scale = cap / Math.max(total, EPS);
  Object.keys(out).forEach(k => out[k] = Math.round((Number(out[k])||0) * scale));
  return out;
}
function weightedNormalise(weights, cap){
  const total = Object.values(weights).reduce((a,b)=>a+(Number(b)||0),0) || 1;
  const out = {};
  Object.keys(weights).forEach(k => out[k] = Math.round((Number(weights[k])||0) / total * cap));
  return out;
}
function haversineKm(lat1, lon1, lat2, lon2){
  const R=6371.0088;
  const p1=lat1*Math.PI/180, p2=lat2*Math.PI/180;
  const dp=(lat2-lat1)*Math.PI/180, dl=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dp/2)**2 + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
  return 2*R*Math.asin(Math.sqrt(a));
}
function responseMinutes(km, speedKmh=55, turnoutMinutes=2){
  return turnoutMinutes + (km/Math.max(1,speedKmh))*60;
}

function knapsack(items, cap, opts={}){
  const scale = opts.scale || 100000;
  const capacity = Math.max(0, Math.floor(cap/scale));
  const dp = Array(capacity+1).fill(0);
  const keep = Array.from({length:capacity+1},()=>[]);
  items.forEach(item => {
    const w = Math.max(1, Math.round((Number(item.cost)||0)/scale));
    const v = Number(item.value)||0;
    for(let c=capacity; c>=w; c--){
      const cand = dp[c-w] + v;
      if(cand > dp[c]){
        dp[c] = cand;
        keep[c] = keep[c-w].concat(item.id);
      }
    }
  });
  const ids = keep[capacity];
  return {
    selectedIds: ids,
    value: stableRound(dp[capacity],3),
    cost: ids.reduce((a,id)=>a+(Number(items.find(x=>x.id===id)?.cost)||0),0),
    algorithm: "0/1 dynamic-programming knapsack"
  };
}

function subsetSumNear(items, target, opts={}){
  const scale = opts.scale || 100000;
  const targetUnits = Math.max(0, Math.floor(target/scale));
  let states = new Map([[0, []]]);
  items.forEach(item => {
    const w = Math.max(1, Math.round((Number(item.cost)||0)/scale));
    const next = new Map(states);
    for(const [total, ids] of states.entries()){
      const nt = total + w;
      if(nt <= targetUnits && !next.has(nt)) next.set(nt, ids.concat(item.id));
    }
    states = next;
  });
  const best = Math.max(...states.keys());
  const ids = states.get(best) || [];
  const cost = ids.reduce((a,id)=>a+(Number(items.find(x=>x.id===id)?.cost)||0),0);
  return {selectedIds:ids, spend:cost, remaining:target-cost, algorithm:"near-target subset sum"};
}

function facilityCoverage(assets, stations, budget, opts={}){
  const threshold = opts.thresholdMinutes || 15;
  const speed = opts.speedKmh || 55;
  const turnout = opts.turnoutMinutes || 2;
  const selected = [];
  let spend = 0;
  const covered = new Set();
  const remaining = new Map(stations.map(s=>[s.id,s]));
  function assetValue(a){
    const pop = Math.log10((Number(a.people)||0)+10);
    const risk = Number(a.risk)||0.5;
    const strategic = Number(a.value)||50;
    const typeMul = {hospital:1.45,gp:1.25,school:1.18,university:1.12,library:.86,farm_hub:.92}[String(a.type||"").toLowerCase()] || 1;
    return typeMul * (strategic*.55 + risk*100*.35 + pop*7.5);
  }
  function covers(st,a){
    const km = haversineKm(st.lat, st.lon, a.lat, a.lon);
    const mins = responseMinutes(km, speed, turnout);
    return {covered: mins <= threshold, km, mins, value: assetValue(a) * (Number(st.readiness)||.8)};
  }
  while(remaining.size){
    let best=null, bestScore=-Infinity, bestGain=0;
    for(const st of remaining.values()){
      if(spend + st.cost > budget) continue;
      let gain = 0;
      assets.forEach(a => {
        if(!covered.has(a.id)){
          const rec = covers(st,a);
          if(rec.covered) gain += rec.value;
        }
      });
      const score = gain / Math.max(1, st.cost);
      if(gain>0 && score>bestScore){ best=st; bestScore=score; bestGain=gain; }
    }
    if(!best) break;
    selected.push(best.id);
    spend += best.cost;
    remaining.delete(best.id);
    assets.forEach(a => { if(covers(best,a).covered) covered.add(a.id); });
  }
  const totalValue = sum(assets, assetValue);
  const coveredValue = sum(assets.filter(a=>covered.has(a.id)), assetValue);
  return {
    selectedIds:selected,
    spend,
    coveredAssetIds:[...covered],
    coveragePct: stableRound(100*covered.size/Math.max(1,assets.length),2),
    valuePct: stableRound(100*coveredValue/Math.max(EPS,totalValue),2),
    roiScore: stableRound(coveredValue/Math.max(1,spend/1_000_000),3),
    algorithm:"greedy maximal coverage"
  };
}

function acoRoute(nodes, opts={}){
  const alpha = opts.alpha ?? 1.2, beta = opts.beta ?? 2.2, evaporation = opts.evaporation ?? 0.08;
  const pheromone = opts.pheromone || {};
  const start = opts.start || nodes[0]?.id;
  const route = [start];
  const unvisited = new Set(nodes.map(n=>n.id).filter(id=>id!==start));
  function dist(a,b){
    const A=nodes.find(n=>n.id===a), B=nodes.find(n=>n.id===b);
    return Math.max(0.01, haversineKm(A.lat,A.lon,B.lat,B.lon));
  }
  while(unvisited.size){
    const current = route[route.length-1];
    const candidates = [...unvisited].map(id => {
      const tau = pheromone[current+">"+id] ?? 1;
      const eta = 1 / dist(current,id);
      const val = Math.pow(tau,alpha)*Math.pow(eta,beta);
      return {id,val};
    });
    const total = sum(candidates,x=>x.val) || 1;
    let r = Math.random()*total, pick = candidates[0].id;
    for(const c of candidates){ r -= c.val; if(r<=0){pick=c.id;break;} }
    route.push(pick); unvisited.delete(pick);
  }
  const length = route.slice(1).reduce((a,id,i)=>a+dist(route[i],id),0);
  Object.keys(pheromone).forEach(k=> pheromone[k] *= (1-evaporation));
  route.slice(1).forEach((id,i)=>{
    const k=route[i]+">"+id;
    pheromone[k]=(pheromone[k]??1)+100/Math.max(1,length);
  });
  return {route, lengthKm:stableRound(length,3), pheromone, algorithm:"ACO probabilistic route construction"};
}

function bcoAllocate(projects, totalBees=100, opts={}){
  const abandon = opts.abandonThreshold ?? 0.18;
  const scored = projects.map(p => {
    const quality = Number(p.quality) || Number(p.value) || 1;
    const cost = Number(p.cost) || 1;
    const risk = Number(p.risk) || .5;
    const nectar = quality / Math.max(1, Math.sqrt(cost/1_000_000)) * (1-risk*.28);
    return {...p, nectar};
  }).filter(p => p.nectar >= abandon);
  const total = sum(scored,p=>p.nectar) || 1;
  return scored.map(p => ({
    id:p.id,
    label:p.label || p.name || p.id,
    bees: Math.round(p.nectar/total*totalBees),
    nectar: stableRound(p.nectar,3)
  })).sort((a,b)=>b.bees-a.bees);
}

function psoStep(particles, objective, opts={}){
  const w=opts.inertia??.62, c1=opts.cognitive??1.35, c2=opts.social??1.55;
  let globalBest = particles[0].best || {position:particles[0].position.slice(), score:-Infinity};
  particles.forEach(p=>{
    const score = objective(p.position);
    if(!p.best || score>p.best.score) p.best={position:p.position.slice(), score};
    if(p.best.score>globalBest.score) globalBest={position:p.best.position.slice(), score:p.best.score};
  });
  particles.forEach(p=>{
    p.velocity = p.velocity.map((v,i)=> w*v + c1*Math.random()*(p.best.position[i]-p.position[i]) + c2*Math.random()*(globalBest.position[i]-p.position[i]));
    p.position = p.position.map((x,i)=> clamp(x+p.velocity[i],0,1));
  });
  return {particles, globalBest, algorithm:"PSO velocity-position update"};
}

function predatorPreyStep(state, dt=.04){
  const x=Math.max(0, state.prey ?? 80), y=Math.max(0, state.predator ?? 20);
  const a=state.preyGrowth ?? 1.1, b=state.predation ?? .018, c=state.predatorDeath ?? .65, d=state.predatorEfficiency ?? .011;
  const nx = Math.max(0, x + (a*x - b*x*y)*dt);
  const ny = Math.max(0, y + (d*x*y - c*y)*dt);
  return {...state, prey:stableRound(nx,3), predator:stableRound(ny,3), balance:stableRound(100/(1+Math.abs((nx/(ny+EPS))-4)),3)};
}

function mandelbrotIterations(cx,cy,maxIter=48){
  let x=0,y=0,iter=0;
  while(x*x+y*y<=4 && iter<maxIter){
    const xt=x*x-y*y+cx;
    y=2*x*y+cy; x=xt; iter++;
  }
  return iter;
}
function fractalPruneScore({urgency=.2, risk=.2, zoom=.5, roi=.5, mandelX=-.7, mandelY=.27015}={}){
  const m = mandelbrotIterations(mandelX, mandelY, 64)/64;
  const depth = Math.round(1 + 9*clamp(.25*urgency + .25*risk + .2*zoom + .2*roi + .1*m));
  const prune = clamp(1-depth/10);
  return {depth, prune, mandelbrot:m, algorithm:"fractal behaviour-tree pruning"};
}

function composeROI(parts){
  const weights = parts.weights || {finance:.2,time:.12,effort:.1,skills:.18,ecology:.18,access:.12,resilience:.1};
  const values = parts.values || {};
  const weighted = Object.entries(weights).reduce((a,[k,w])=>a+(Number(values[k])||0)*w,0);
  const base = parts.base ?? 1.15;
  const multiple = base + weighted/100 * (parts.range ?? 3.5);
  return {multiple:stableRound(multiple,3), weightedScore:stableRound(weighted,3), algorithm:"weighted multi-component ROI"};
}

window.SpaceWalesMath = {
  clamp, sum, stableRound, normaliseToCap, weightedNormalise,
  haversineKm, responseMinutes,
  knapsack, subsetSumNear, facilityCoverage,
  acoRoute, bcoAllocate, psoStep, predatorPreyStep,
  mandelbrotIterations, fractalPruneScore, composeROI
};
})();