# Cymru Hive OS v5.5 · Old WebUI JS Mathematics Update

This version returns to the old working WebUI base and does not depend on DataMapWales web-service loading.

## Added JavaScript mathematics

- 0/1 knapsack
- near-target subset sum
- facility coverage
- ACO route construction
- BCO colony allocation
- PSO update
- predator/prey difference equation
- Mandelbrot/fractal pruning
- weighted ROI composition

## Main files

- `assets/js/math_engine.js`
- `assets/js/math_lab.js`

## Why

The WebUI map and charts should keep working locally without WMS/WFS.  
The maths is now explicit and exportable, ready to be moved into Python later if it becomes too heavy.
