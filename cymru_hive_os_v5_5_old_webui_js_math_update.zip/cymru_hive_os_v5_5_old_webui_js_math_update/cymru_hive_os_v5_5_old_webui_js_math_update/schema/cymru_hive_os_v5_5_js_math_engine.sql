-- Cymru Hive OS v5.5 · JS Mathematics Engine Registry
CREATE TABLE IF NOT EXISTS js_math_function (
  function_id TEXT PRIMARY KEY,
  category TEXT,
  description TEXT,
  implementation_file TEXT
);

INSERT INTO js_math_function VALUES ('knapsack','optimisation','0/1 budget/value optimiser','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('subset_sum_near','optimisation','near-target budget packing','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('facility_coverage','emergency/access','greedy maximal coverage over hives/assets/stations','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('aco_route','swarm','ACO probabilistic route construction with pheromone reinforcement','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('bco_allocate','swarm','BCO colony allocation by nectar/profitability','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('pso_step','swarm','PSO particle velocity-position update','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('predator_prey_step','ecology','Lotka-Volterra style predator/prey difference equation','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('fractal_prune_score','behaviour-tree','Mandelbrot-influenced fractal pruning depth','assets/js/math_engine.js');
INSERT INTO js_math_function VALUES ('compose_roi','roi','weighted multi-component ROI composition','assets/js/math_engine.js');
