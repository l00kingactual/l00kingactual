// Cymru Hive OS v5.5 · JS Mathematics Engine Graph
MERGE (m:MathEngine {id:'js_math_v5_5', version:'5.5', file:'assets/js/math_engine.js'});
UNWIND [
  ['knapsack','optimisation'],
  ['subset_sum_near','optimisation'],
  ['facility_coverage','emergency/access'],
  ['aco_route','swarm'],
  ['bco_allocate','swarm'],
  ['pso_step','swarm'],
  ['predator_prey_step','ecology'],
  ['fractal_prune_score','behaviour-tree'],
  ['compose_roi','roi']
] AS row
MERGE (f:MathFunction {id:row[0], category:row[1]})
WITH f
MATCH (m:MathEngine {id:'js_math_v5_5'})
MERGE (m)-[:IMPLEMENTS]->(f);
