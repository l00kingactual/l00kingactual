/* JANUS Wales Outline Strategy Map V4.4 · JavaScript zipped only */
'use strict';
(() => {
  const DATA = {"generated_at": "2026-05-28T20:30:49Z", "project": "JANUS Wales Outline Strategy Map V4.4", "image": {"width": 713, "height": 861, "mode": "RGB", "source_path": "/mnt/data/wales.jpeg"}, "map_mode": "uploaded outline image at maximum zoom-out", "coordinate_bounds": {"lon_min": -5.55, "lon_max": -2.58, "lat_min": 51.33, "lat_max": 53.43}, "autotune_count": 42, "autotunes": [{"id": "balanced_wales", "risk": 28, "coverage": 78, "route": 76, "mountain": 42, "coast": 36, "ir": 44, "pollination": 66, "biodiversity": 66, "civic": 62, "actorPulse": 1.0, "pheromonePulse": 1.0, "heatPulse": 0.35, "strategy": "balanced colony/ecology workbench"}, {"id": "storm_flood", "risk": 76, "coverage": 62, "route": 52, "mountain": 70, "coast": 82, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.75, "pheromonePulse": 1.55, "heatPulse": 0.85, "strategy": "storm/flood resilience, route pressure and safe-service staging"}, {"id": "coastal_surge", "risk": 66, "coverage": 74, "route": 58, "mountain": 38, "coast": 88, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.45, "pheromonePulse": 1.35, "heatPulse": 0.4, "strategy": "coastal pressure, water safety, ports and visitor corridors"}, {"id": "mountain_access", "risk": 70, "coverage": 74, "route": 50, "mountain": 92, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.55, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "upland access, search corridors and terrain penalty"}, {"id": "pollinator_recovery", "risk": 50, "coverage": 76, "route": 72, "mountain": 50, "coast": 34, "ir": 42, "pollination": 84, "biodiversity": 86, "civic": 58, "actorPulse": 1.22, "pheromonePulse": 1.36, "heatPulse": 0.4, "strategy": "food, forage, pesticide, pollinator and biodiversity recovery"}, {"id": "urban_demand", "risk": 24, "coverage": 74, "route": 70, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.0, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "balanced colony/ecology workbench"}, {"id": "sport_performance", "risk": 52, "coverage": 72, "route": 76, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 72, "actorPulse": 1.25, "pheromonePulse": 1.28, "heatPulse": 0.4, "strategy": "visitor, sport, heritage and public-space service balancing"}, {"id": "cyber_cni_stress", "risk": 72, "coverage": 66, "route": 60, "mountain": 38, "coast": 34, "ir": 64, "pollination": 62, "biodiversity": 60, "civic": 68, "actorPulse": 1.42, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "critical infrastructure, cyber/CNI and energy resilience"}, {"id": "national_surge", "risk": 78, "coverage": 84, "route": 74, "mountain": 72, "coast": 76, "ir": 72, "pollination": 62, "biodiversity": 60, "civic": 82, "actorPulse": 2.0, "pheromonePulse": 1.85, "heatPulse": 0.9, "strategy": "whole-nation exercise, multi-layer surge and full workbench stress test"}, {"id": "health_surge", "risk": 64, "coverage": 68, "route": 70, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 76, "actorPulse": 1.35, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "health, care-density, disease and civic support routing"}, {"id": "school_term_morning", "risk": 44, "coverage": 82, "route": 78, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 84, "actorPulse": 1.18, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "education, youth, libraries and community learning nodes"}, {"id": "school_term_afternoon", "risk": 44, "coverage": 82, "route": 78, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 84, "actorPulse": 1.18, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "education, youth, libraries and community learning nodes"}, {"id": "summer_tourism", "risk": 52, "coverage": 72, "route": 76, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 72, "actorPulse": 1.25, "pheromonePulse": 1.28, "heatPulse": 0.4, "strategy": "visitor, sport, heritage and public-space service balancing"}, {"id": "winter_resilience", "risk": 24, "coverage": 74, "route": 70, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.0, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "balanced colony/ecology workbench"}, {"id": "industrial_incident_abstraction", "risk": 72, "coverage": 66, "route": 60, "mountain": 38, "coast": 34, "ir": 64, "pollination": 62, "biodiversity": 60, "civic": 68, "actorPulse": 1.42, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "critical infrastructure, cyber/CNI and energy resilience"}, {"id": "agricultural_harvest", "risk": 50, "coverage": 76, "route": 72, "mountain": 50, "coast": 34, "ir": 42, "pollination": 84, "biodiversity": 86, "civic": 58, "actorPulse": 1.22, "pheromonePulse": 1.36, "heatPulse": 0.4, "strategy": "food, forage, pesticide, pollinator and biodiversity recovery"}, {"id": "library_learning_push", "risk": 44, "coverage": 82, "route": 78, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 84, "actorPulse": 1.18, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "education, youth, libraries and community learning nodes"}, {"id": "college_apprenticeship_push", "risk": 70, "coverage": 82, "route": 78, "mountain": 92, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 84, "actorPulse": 1.18, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "education, youth, libraries and community learning nodes"}, {"id": "youth_uniformed_services", "risk": 70, "coverage": 82, "route": 78, "mountain": 92, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 84, "actorPulse": 1.18, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "education, youth, libraries and community learning nodes"}, {"id": "fire_risk_dry_spell", "risk": 82, "coverage": 60, "route": 70, "mountain": 58, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.7, "pheromonePulse": 1.0, "heatPulse": 0.9, "strategy": "fire-weather, heat health and water-refuge response"}, {"id": "floodplain_watch", "risk": 76, "coverage": 62, "route": 52, "mountain": 70, "coast": 82, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.75, "pheromonePulse": 1.55, "heatPulse": 0.85, "strategy": "storm/flood resilience, route pressure and safe-service staging"}, {"id": "snow_ice_access", "risk": 70, "coverage": 74, "route": 50, "mountain": 92, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.55, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "upland access, search corridors and terrain penalty"}, {"id": "heat_health", "risk": 82, "coverage": 60, "route": 70, "mountain": 58, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 76, "actorPulse": 1.7, "pheromonePulse": 1.0, "heatPulse": 0.9, "strategy": "fire-weather, heat health and water-refuge response"}, {"id": "air_quality_pollution", "risk": 24, "coverage": 74, "route": 70, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.0, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "balanced colony/ecology workbench"}, {"id": "pesticide_watch", "risk": 50, "coverage": 76, "route": 72, "mountain": 50, "coast": 34, "ir": 42, "pollination": 84, "biodiversity": 86, "civic": 58, "actorPulse": 1.22, "pheromonePulse": 1.36, "heatPulse": 0.4, "strategy": "food, forage, pesticide, pollinator and biodiversity recovery"}, {"id": "disease_outbreak_abstraction", "risk": 64, "coverage": 68, "route": 70, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 76, "actorPulse": 1.35, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "health, care-density, disease and civic support routing"}, {"id": "transport_disruption", "risk": 60, "coverage": 60, "route": 48, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 72, "actorPulse": 1.35, "pheromonePulse": 1.28, "heatPulse": 0.4, "strategy": "route scarcity, rural access and low-resource service allocation"}, {"id": "major_event_sports", "risk": 52, "coverage": 72, "route": 76, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 72, "actorPulse": 1.25, "pheromonePulse": 1.28, "heatPulse": 0.4, "strategy": "visitor, sport, heritage and public-space service balancing"}, {"id": "coastal_water_safety", "risk": 66, "coverage": 74, "route": 58, "mountain": 38, "coast": 88, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.45, "pheromonePulse": 1.35, "heatPulse": 0.4, "strategy": "coastal pressure, water safety, ports and visitor corridors"}, {"id": "mountain_rescue_training", "risk": 70, "coverage": 74, "route": 50, "mountain": 92, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.55, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "upland access, search corridors and terrain penalty"}, {"id": "rural_access", "risk": 60, "coverage": 60, "route": 58, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.35, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "route scarcity, rural access and low-resource service allocation"}, {"id": "urban_care_density", "risk": 64, "coverage": 68, "route": 70, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 76, "actorPulse": 1.35, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "health, care-density, disease and civic support routing"}, {"id": "low_resource", "risk": 60, "coverage": 60, "route": 58, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.35, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "route scarcity, rural access and low-resource service allocation"}, {"id": "night_shift", "risk": 58, "coverage": 65, "route": 70, "mountain": 38, "coast": 34, "ir": 86, "pollination": 62, "biodiversity": 60, "civic": 58, "actorPulse": 1.3, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "night visibility, IR/thermal proxy and reduced service confidence"}, {"id": "weekend_visitor_load", "risk": 52, "coverage": 72, "route": 76, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 72, "actorPulse": 1.25, "pheromonePulse": 1.28, "heatPulse": 0.4, "strategy": "visitor, sport, heritage and public-space service balancing"}, {"id": "heritage_conservation", "risk": 52, "coverage": 72, "route": 76, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 72, "actorPulse": 1.25, "pheromonePulse": 1.28, "heatPulse": 0.4, "strategy": "visitor, sport, heritage and public-space service balancing"}, {"id": "standing_stones_tourism", "risk": 52, "coverage": 72, "route": 76, "mountain": 38, "coast": 34, "ir": 42, "pollination": 62, "biodiversity": 60, "civic": 72, "actorPulse": 1.25, "pheromonePulse": 1.28, "heatPulse": 0.4, "strategy": "visitor, sport, heritage and public-space service balancing"}, {"id": "forage_expansion", "risk": 50, "coverage": 76, "route": 72, "mountain": 50, "coast": 34, "ir": 42, "pollination": 84, "biodiversity": 86, "civic": 58, "actorPulse": 1.22, "pheromonePulse": 1.36, "heatPulse": 0.4, "strategy": "food, forage, pesticide, pollinator and biodiversity recovery"}, {"id": "biodiversity_recovery", "risk": 50, "coverage": 76, "route": 72, "mountain": 50, "coast": 34, "ir": 42, "pollination": 84, "biodiversity": 86, "civic": 58, "actorPulse": 1.22, "pheromonePulse": 1.36, "heatPulse": 0.4, "strategy": "food, forage, pesticide, pollinator and biodiversity recovery"}, {"id": "food_security", "risk": 50, "coverage": 76, "route": 72, "mountain": 50, "coast": 34, "ir": 42, "pollination": 84, "biodiversity": 86, "civic": 58, "actorPulse": 1.22, "pheromonePulse": 1.36, "heatPulse": 0.4, "strategy": "food, forage, pesticide, pollinator and biodiversity recovery"}, {"id": "energy_resilience", "risk": 72, "coverage": 66, "route": 60, "mountain": 38, "coast": 34, "ir": 64, "pollination": 62, "biodiversity": 60, "civic": 68, "actorPulse": 1.42, "pheromonePulse": 1.0, "heatPulse": 0.4, "strategy": "critical infrastructure, cyber/CNI and energy resilience"}, {"id": "full_nation_exercise", "risk": 78, "coverage": 84, "route": 74, "mountain": 72, "coast": 76, "ir": 72, "pollination": 62, "biodiversity": 60, "civic": 82, "actorPulse": 2.0, "pheromonePulse": 1.85, "heatPulse": 0.9, "strategy": "whole-nation exercise, multi-layer surge and full workbench stress test"}], "towns": [{"id": "cardiff", "name": "Cardiff", "lon": -3.1791, "lat": 51.4816, "class": "capital", "role": "primary hive"}, {"id": "swansea", "name": "Swansea", "lon": -3.9436, "lat": 51.6214, "class": "city", "role": "coastal service hive"}, {"id": "newport", "name": "Newport", "lon": -2.9916, "lat": 51.5842, "class": "city", "role": "eastern gateway hive"}, {"id": "wrexham", "name": "Wrexham", "lon": -2.9938, "lat": 53.0465, "class": "city", "role": "north-east hive"}, {"id": "bangor", "name": "Bangor", "lon": -4.1293, "lat": 53.2274, "class": "city", "role": "north-west hive"}, {"id": "holyhead", "name": "Holyhead", "lon": -4.6333, "lat": 53.3095, "class": "port", "role": "port hive"}, {"id": "caernarfon", "name": "Caernarfon", "lon": -4.2769, "lat": 53.1395, "class": "town", "role": "heritage hive"}, {"id": "rhyl", "name": "Rhyl", "lon": -3.489, "lat": 53.319, "class": "town", "role": "coastal hive"}, {"id": "colwyn_bay", "name": "Colwyn Bay", "lon": -3.726, "lat": 53.293, "class": "town", "role": "coastal hive"}, {"id": "aberystwyth", "name": "Aberystwyth", "lon": -4.0829, "lat": 52.4153, "class": "town", "role": "mid-west hive"}, {"id": "cardigan", "name": "Cardigan", "lon": -4.66, "lat": 52.084, "class": "town", "role": "west hive"}, {"id": "st_davids", "name": "St David’s", "lon": -5.267, "lat": 51.8824, "class": "city", "role": "heritage/coastal hive"}, {"id": "milford_haven", "name": "Milford Haven", "lon": -5.034, "lat": 51.714, "class": "port", "role": "energy/port hive"}, {"id": "carmarthen", "name": "Carmarthen", "lon": -4.305, "lat": 51.856, "class": "town", "role": "food/market hive"}, {"id": "llanelli", "name": "Llanelli", "lon": -4.162, "lat": 51.682, "class": "town", "role": "south-west hive"}, {"id": "port_talbot", "name": "Port Talbot", "lon": -3.783, "lat": 51.592, "class": "town", "role": "industrial hive"}, {"id": "merthyr", "name": "Merthyr Tydfil", "lon": -3.378, "lat": 51.748, "class": "town", "role": "valleys hive"}, {"id": "brecon", "name": "Brecon", "lon": -3.388, "lat": 51.947, "class": "town", "role": "mountain-service hive"}, {"id": "llandrindod", "name": "Llandrindod Wells", "lon": -3.378, "lat": 52.24, "class": "town", "role": "mid-Wales civic hive"}, {"id": "welshpool", "name": "Welshpool", "lon": -3.147, "lat": 52.66, "class": "town", "role": "border/route hive"}, {"id": "monmouth", "name": "Monmouth", "lon": -2.713, "lat": 51.812, "class": "town", "role": "eastern civic hive"}, {"id": "cwmbran", "name": "Cwmbran", "lon": -3.026, "lat": 51.654, "class": "town", "role": "south-east hive"}, {"id": "rhondda", "name": "Rhondda", "lon": -3.43, "lat": 51.65, "class": "valley", "role": "valleys service hive"}], "routes": [["cardiff", "newport"], ["cardiff", "cwmbran"], ["newport", "monmouth"], ["cardiff", "merthyr"], ["merthyr", "brecon"], ["cardiff", "swansea"], ["swansea", "port_talbot"], ["swansea", "llanelli"], ["llanelli", "carmarthen"], ["carmarthen", "milford_haven"], ["milford_haven", "st_davids"], ["carmarthen", "cardigan"], ["cardigan", "aberystwyth"], ["aberystwyth", "llandrindod"], ["llandrindod", "brecon"], ["llandrindod", "welshpool"], ["welshpool", "wrexham"], ["wrexham", "rhyl"], ["rhyl", "colwyn_bay"], ["colwyn_bay", "bangor"], ["bangor", "caernarfon"], ["bangor", "holyhead"], ["caernarfon", "aberystwyth"]], "strategic_guide": {"source_title": "Janus BCO WebUI Extended Worlds Climate Weather", "summary_count": 34, "core_sections": ["Run / export / import / screenshot / recording", "Scale marker + simulation controls", "Complete climate, pollution and pesticide controls + iso-charts", "Bee colony objective metrics", "BCO / ACO / best plan metrics", "Ecology auto-tunes", "Potential enhancements + pressure explorer", "Detailed JSON export/import schema", "JS → Python → C conversion plan", "ROI / 13S / Six Value Medals", "Map geography + predator key", "Predator visibility + unique pressure lens", "Key", "Bubble Kernel · Algorithm Registry · Janus Strategy Map", "Drucker × Strategic Thinkers Console", "Simulation view + hover inspector", "Bee visibility + unique layers", "Strategic bubble ecology", "Algorithm Lab: ACO / GA / SA route intelligence", "Integrated factors + 2D/3D plots", "Drucker + bee-customer competitive bubbles", "Strategic bubble ecology", "Algorithm Lab: route intelligence", "Drucker + bee-customer competitive bubbles", "Worlds, geographies, climate and weather bubbles", "Pivotal charts / plots / graphs", "Drucker scenario cards · set the business", "Full chart atlas · all plots / graphs", "Evaluation metrics / clustering", "🏫 Civic / service customer modes", "🏙️ Universal civic/service logic bubble expansion", "📈 Universal evaluation metrics + all chart types", "🚦 Mode-specific agent icons + behaviour", "🐄 Animated animals / livestock script layer"], "integration_principle": "Use the uploaded Janus BCO cockpit as guide for sidebar structure, pressure logic, auto-tunes, BCO/ACO metrics, Janus/bubble strategy and strategic thinker framing."}, "js_policy": "No loose JavaScript files. Runtime JS is shipped only in downloads/outline_map_js_bundle.zip."};
  const ROLES = [
    {id:'scout',label:'Scout bee',colour:'#38bdf8',emoji:'🔵',task:'discovers pressure and safe corridors'},
    {id:'forager',label:'Forager bee',colour:'#facc15',emoji:'🟡',task:'routes pollination/resource work'},
    {id:'guard',label:'Guard bee',colour:'#ef4444',emoji:'🔴',task:'defends hives and marks predator pressure'},
    {id:'nurse',label:'Nurse bee',colour:'#fb7185',emoji:'🌹',task:'brood/health support'},
    {id:'water_runner',label:'Water runner',colour:'#60a5fa',emoji:'💧',task:'water/cooling support'},
    {id:'hygienic_worker',label:'Hygienic worker',colour:'#22c55e',emoji:'🟢',task:'disease/pesticide suppression'},
    {id:'thermoregulator',label:'Thermoregulator',colour:'#fb923c',emoji:'🟠',task:'climate regulation'},
    {id:'strategist',label:'Strategist bee',colour:'#a78bfa',emoji:'🧠',task:'Janus/BCO/ACO workbench logic'}
  ];
  const $ = s => document.querySelector(s);
  const canvas = $('#mapCanvas'), ctx = canvas.getContext('2d', {alpha:false});
  const metricCanvas = $('#metricCanvas'), mctx = metricCanvas.getContext('2d');
  const img = new Image();
  img.src = '../assets/wales_outline_max_zoom.jpeg';
  const bounds = DATA.coordinate_bounds;
  const state = {
    running:true, tick:0, time:0, tune:'balanced_wales', dpr:1, fit:null,
    layers:{image:true,hives:true,routes:true,pheromone:true,actors:true,pressure:true,labels:true,strategic:true},
    actors:[], pheromone:{}, metrics:{risk:28,coverage:78,route:76,mountain:42,coast:36,ir:44,pollination:66,biodiversity:66,civic:62}
  };
  const profiles = new Map(DATA.autotunes.map(p => [p.id, p]));
  function clamp(v,a=0,b=1){return Math.max(a,Math.min(b,v));}
  function lerp(a,b,t){return a+(b-a)*t;}
  function profile(){return profiles.get(state.tune)||profiles.get('balanced_wales')||DATA.autotunes[0];}
  function resize(){
    state.dpr=Math.min(devicePixelRatio||1,2);
    const r=canvas.getBoundingClientRect();
    canvas.width=Math.floor(r.width*state.dpr); canvas.height=Math.floor(r.height*state.dpr);
    ctx.setTransform(state.dpr,0,0,state.dpr,0,0);
  }
  function fitImage(){
    const w=canvas.width/state.dpr, h=canvas.height/state.dpr;
    const iw=img.naturalWidth||DATA.image.width, ih=img.naturalHeight||DATA.image.height;
    const scale=Math.min(w/iw,h/ih)*0.985; // maximum zoom-out: full outline visible.
    const dw=iw*scale, dh=ih*scale;
    state.fit={x:(w-dw)/2,y:(h-dh)/2,w:dw,h:dh,scale,iw,ih};
    return state.fit;
  }
  function lonLatToXY(lon,lat){
    const f=state.fit||fitImage();
    const x=(lon-bounds.lon_min)/(bounds.lon_max-bounds.lon_min);
    const y=(bounds.lat_max-lat)/(bounds.lat_max-bounds.lat_min);
    return {x:f.x+x*f.w,y:f.y+y*f.h};
  }
  function town(id){return DATA.towns.find(t=>t.id===id);}
  function seedActors(n=360){
    state.actors=[];
    for(let i=0;i<n;i++){
      const home=DATA.towns[i%DATA.towns.length], target=DATA.towns[(i*7+5)%DATA.towns.length], role=ROLES[i%ROLES.length];
      const p=lonLatToXY(home.lon,home.lat);
      state.actors.push({x:p.x+(Math.random()-.5)*20,y:p.y+(Math.random()-.5)*20,vx:(Math.random()-.5)*.8,vy:(Math.random()-.5)*.8,target:target.id,role:role.id,colour:role.colour,energy:.6+Math.random()*.4});
    }
  }
  function initPheromones(){
    state.pheromone={};
    for(const [a,b] of DATA.routes) state.pheromone[a+'>'+b]=.26+Math.random()*.34;
  }
  function applyTune(id,source='selection'){
    state.tune=id; state.running=true;
    const p=profile();
    for(const k in state.pheromone) state.pheromone[k]=clamp(state.pheromone[k]+0.12*(p.pheromonePulse||1),.05,1);
    $('#tuneStatus').textContent=`auto-started ${id} · ${source} · tick ${state.tick}`;
    $('#btnPause').textContent='Pause';
    $('#profileView').textContent=JSON.stringify(p,null,2);
  }
  function step(){
    state.tick++; state.time += .016;
    const p=profile();
    for(const key of ['risk','coverage','route','mountain','coast','ir','pollination','biodiversity','civic']) {
      state.metrics[key] += ((p[key]??state.metrics[key])-state.metrics[key])*.018;
    }
    for(const k in state.pheromone) state.pheromone[k]=clamp(state.pheromone[k]*.996 + .0025*(p.pheromonePulse||1)*Math.max(0,Math.sin(state.time*1.8+k.length)),.05,1);
    for(const a of state.actors){
      const t=town(a.target)||DATA.towns[0], tp=lonLatToXY(t.lon,t.lat);
      const dx=tp.x-a.x, dy=tp.y-a.y, d=Math.hypot(dx,dy)||1;
      const pulse=p.actorPulse||1;
      a.vx=a.vx*.985 + dx/d*.030*pulse + (Math.random()-.5)*.035*pulse;
      a.vy=a.vy*.985 + dy/d*.030*pulse + (Math.random()-.5)*.035*pulse;
      a.x+=a.vx; a.y+=a.vy;
      a.energy=clamp(a.energy+(Math.random()-.51)*.01);
      if(d<10) a.target = DATA.towns[Math.floor(Math.random()*DATA.towns.length)].id;
    }
  }
  function draw(){
    const w=canvas.width/state.dpr, h=canvas.height/state.dpr;
    ctx.fillStyle='#9fb3bf'; ctx.fillRect(0,0,w,h);
    const f=fitImage();
    if(state.layers.image && img.complete) ctx.drawImage(img,f.x,f.y,f.w,f.h);
    if(state.layers.pressure) drawPressure(w,h);
    if(state.layers.routes||state.layers.pheromone) drawRoutes();
    if(state.layers.hives) drawHives();
    if(state.layers.actors) drawActors();
    if(state.layers.strategic) drawStrategicOverlay(w,h);
    drawMetrics();
    $('#hudLine').textContent=`maximum zoom-out · ${DATA.towns.length} hives · ${DATA.routes.length} routes · 42 tunes · current ${state.tune} · ${state.running?'running':'paused'}`;
    $('#metricsView').textContent=JSON.stringify({tick:state.tick,tune:state.tune,metrics:Object.fromEntries(Object.entries(state.metrics).map(([k,v])=>[k,Number(v.toFixed(2))])),imageFit:f},null,2);
  }
  function drawPressure(w,h){
    const p=profile();
    const centres=[
      ['mountain', .45,.32, state.metrics.mountain, '#a78bfa'],
      ['coast', .25,.78, state.metrics.coast, '#38bdf8'],
      ['risk', .70,.70, state.metrics.risk, '#ef4444'],
      ['ir', .55,.55, state.metrics.ir, '#fb7185'],
      ['pollination', .40,.62, state.metrics.pollination, '#22c55e']
    ];
    const f=state.fit||fitImage();
    ctx.save(); ctx.globalCompositeOperation='multiply';
    for(const [name,u,v,val,col] of centres){
      const x=f.x+u*f.w, y=f.y+v*f.h, r=70+val*1.5+(p.heatPulse||.4)*30;
      const g=ctx.createRadialGradient(x,y,3,x,y,r); g.addColorStop(0,col.replace(')',',.22)').replace('rgb','rgba')); g.addColorStop(1,'rgba(255,255,255,0)');
      ctx.fillStyle=g; ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fill();
    }
    ctx.restore();
  }
  function drawRoutes(){
    ctx.save(); ctx.lineCap='round';
    for(const [a,b] of DATA.routes){
      const ta=town(a), tb=town(b); if(!ta||!tb) continue;
      const pa=lonLatToXY(ta.lon,ta.lat), pb=lonLatToXY(tb.lon,tb.lat), ph=state.pheromone[a+'>'+b]||.35;
      const mx=(pa.x+pb.x)/2+Math.sin((pa.x+pb.y)*.013)*18, my=(pa.y+pb.y)/2+Math.cos((pa.y+pb.x)*.013)*14;
      if(state.layers.routes){ctx.strokeStyle='rgba(15,23,42,.28)';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(pa.x,pa.y);ctx.quadraticCurveTo(mx,my,pb.x,pb.y);ctx.stroke();}
      if(state.layers.pheromone){ctx.strokeStyle=`rgba(250,204,21,${.13+ph*.60})`;ctx.lineWidth=1+ph*5;ctx.beginPath();ctx.moveTo(pa.x,pa.y);ctx.quadraticCurveTo(mx,my,pb.x,pb.y);ctx.stroke();}
    }
    ctx.restore();
  }
  function drawHives(){
    ctx.save();
    for(const t of DATA.towns){
      const p=lonLatToXY(t.lon,t.lat), r=t.class==='capital'?10:t.class==='city'?7:t.class==='port'?6:4.8;
      const col=t.class==='capital'?'#facc15':t.class==='city'?'#38bdf8':t.class==='port'?'#60a5fa':'#111827';
      ctx.fillStyle=col; ctx.strokeStyle='rgba(255,255,255,.95)'; ctx.lineWidth=2;
      ctx.beginPath(); ctx.arc(p.x,p.y,r,0,Math.PI*2); ctx.fill(); ctx.stroke();
      ctx.strokeStyle='rgba(250,204,21,.30)'; ctx.lineWidth=1; ctx.beginPath(); ctx.arc(p.x,p.y,r+10,0,Math.PI*2); ctx.stroke();
      if(state.layers.labels && (t.class==='capital'||t.class==='city'||t.class==='port')) {
        ctx.font='11px Consolas'; const label=t.name, tw=ctx.measureText(label).width+10;
        ctx.fillStyle='rgba(255,255,255,.88)'; roundRect(ctx,p.x+8,p.y-11,tw,18,6); ctx.fill();
        ctx.fillStyle='#111827'; ctx.fillText(label,p.x+13,p.y+2);
      }
    }
    ctx.restore();
  }
  function drawActors(){
    ctx.save();
    for(const a of state.actors){
      ctx.globalAlpha=.44+.42*a.energy; ctx.fillStyle=a.colour;
      ctx.beginPath(); ctx.arc(a.x,a.y,a.role==='strategist'?3.3:2.25,0,Math.PI*2); ctx.fill();
      if(a.role==='guard'||a.role==='strategist'){ctx.globalAlpha=.18;ctx.strokeStyle=a.colour;ctx.beginPath();ctx.arc(a.x,a.y,9,0,Math.PI*2);ctx.stroke();}
    }
    ctx.globalAlpha=1; ctx.restore();
  }
  function drawStrategicOverlay(w,h){
    ctx.save();
    ctx.fillStyle='rgba(255,255,255,.86)'; ctx.strokeStyle='rgba(15,23,42,.20)'; ctx.lineWidth=1;
    roundRect(ctx,16,h-112,340,86,14); ctx.fill(); ctx.stroke();
    ctx.fillStyle='#111827'; ctx.font='700 13px Consolas'; ctx.fillText('Strategic guide: BCO × ACO × Janus',32,h-84);
    ctx.font='10px Consolas'; ctx.fillStyle='#334155';
    ctx.fillText(`Drucker question: what is the right ecological job?`,32,h-62);
    ctx.fillText(`BCO allocates actors · ACO strengthens routes`,32,h-46);
    ctx.fillText(`Auto-tune changes pressure, pheromone and civic metrics`,32,h-30);
    ctx.restore();
  }
  function roundRect(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}
  function drawMetrics(){
    const r=metricCanvas.getBoundingClientRect(), dpr=Math.min(devicePixelRatio||1,2);
    metricCanvas.width=Math.floor(Math.max(1,r.width)*dpr); metricCanvas.height=Math.floor(Math.max(1,r.height)*dpr);
    mctx.setTransform(dpr,0,0,dpr,0,0);
    const w=metricCanvas.width/dpr,h=metricCanvas.height/dpr;
    mctx.fillStyle='#07111f';mctx.fillRect(0,0,w,h);
    const vals=Object.entries(state.metrics);
    vals.forEach(([k,v],i)=>{
      const x=18+i*(w-36)/vals.length, bw=(w-52)/vals.length, bh=(h-42)*v/100;
      const grad=mctx.createLinearGradient(0,h-20-bh,0,h-20); grad.addColorStop(0,'#facc15'); grad.addColorStop(1,'#22c55e');
      mctx.fillStyle=grad; roundRect(mctx,x,h-20-bh,bw*.66,bh,5); mctx.fill();
      mctx.fillStyle='#cbd5e1';mctx.font='10px Consolas';mctx.save();mctx.translate(x+3,h-6);mctx.rotate(-Math.PI/5);mctx.fillText(k,0,0);mctx.restore();
    });
  }
  function bind(){
    $('#rolesView').innerHTML=ROLES.map(r=>`<div class="roleCard"><b><span style="color:${r.colour}">●</span> ${r.emoji} ${r.label}</b>${r.task}</div>`).join('');
    document.querySelectorAll('[data-layer]').forEach(el=>el.onchange=e=>state.layers[e.target.dataset.layer]=e.target.checked);
    $('#tune').onchange=e=>applyTune(e.target.value,'selection');
    $('#btnMaxZoom').onclick=()=>{fitImage(); $('#tuneStatus').textContent='reset to maximum zoom-out';};
    $('#btnPause').onclick=()=>{state.running=!state.running; $('#btnPause').textContent=state.running?'Pause':'Start';};
    $('#btnCollapse').onclick=()=>document.querySelectorAll('details').forEach(d=>d.open=false);
    $('#btnExport').onclick=()=>download('janus_wales_outline_strategy_state.json',JSON.stringify({metadata:DATA,state:{...state,fit:null}},null,2),'application/json');
  }
  function download(filename,text,mime){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:mime||'text/plain'}));a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);}
  function loop(){if(state.running) step(); draw(); requestAnimationFrame(loop);}
  window.addEventListener('resize',()=>{resize(); fitImage(); seedActors(state.actors.length||360);});
  img.onload=()=>{resize(); fitImage(); initPheromones(); seedActors(360); bind(); applyTune('balanced_wales','page-load'); loop();};
  if(img.complete) img.onload();
})();
