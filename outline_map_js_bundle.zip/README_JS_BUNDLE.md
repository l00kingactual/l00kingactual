# Outline Strategy Map JS Bundle

Extract at the package root:

```bash
unzip downloads/outline_map_js_bundle.zip
```

Creates:

```text
webui/js/outline_strategy_map.js
```

The HTML page then runs:

```text
webui/outline_strategy_map.html
```
