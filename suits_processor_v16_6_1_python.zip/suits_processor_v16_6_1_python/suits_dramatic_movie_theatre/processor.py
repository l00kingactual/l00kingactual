#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, datetime as dt, hashlib, html, json, math, os, re, shutil, sqlite3, subprocess, sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

VERSION='v16.6.1'
SCHEMA='suits_dramatic_movie_theatre_v16_6'
DEFAULT_ROOT=Path('/home/andy/Documents/suitsmafia')
DEFAULT_SITE=DEFAULT_ROOT/'susitsmafia_website'
DEFAULT_OUT=DEFAULT_ROOT/'outputs'/'suits_processor_v16_6_dramatic_movie_theatre'
SKIP_DIRS={'.git','__pycache__','.cache','.venv','venv','node_modules','site-packages','dist-info','build','tmp','temp','old_broken_tools'}
AUDIO_EXT={'.mp3','.wav','.flac','.m4a','.aac','.ogg','.webm','.mp4','.mkv','.mov'}
VIDEO_EXT={'.mp4','.webm','.mkv','.mov','.avi'}
IMAGE_EXT={'.png','.jpg','.jpeg','.webp','.gif','.apng','.svg'}
DATA_EXT={'.json','.jsonl','.csv','.html','.htm','.md','.txt','.log','.sql','.cypher','.php','.js','.css','.py','.sh','.ps1'}

ANIMAL_TAXONOMY={
 'lone_wolf':{'icon':'🐺','group':'predator','traits':['isolated','patient','flank','high-risk solo'], 'win':'isolates prey', 'blunder':'overextends alone'},
 'tiger_stalk':{'icon':'🐯','group':'predator','traits':['stealth','patience','burst strike'], 'win':'ambush lands', 'blunder':'revealed early'},
 'lion_pack_pressure':{'icon':'🦁','group':'predator','traits':['crew pressure','surround','territory'], 'win':'boxes prey in', 'blunder':'pack blocks itself'},
 'shark_pursuit':{'icon':'🦈','group':'predator','traits':['relentless','chase','blood-in-water'], 'win':'pressure never drops', 'blunder':'tunnel vision'},
 'crocodile_chokepoint':{'icon':'🐊','group':'predator','traits':['waits','bridge/door bend','forced lane'], 'win':'prey enters lane', 'blunder':'prey refuses lane'},
 'hawk_strike':{'icon':'🦅','group':'predator','traits':['speed','precision','single hit'], 'win':'fast decisive action', 'blunder':'misses timing'},
 'eagle_overwatch':{'icon':'🦅','group':'observer','traits':['height','vision','command'], 'win':'sees pattern first', 'blunder':'detached from ground'},
 'raven_aftermath':{'icon':'🐦‍⬛','group':'aftermath','traits':['evidence','memory','dark ending'], 'win':'explains consequence', 'blunder':'arrives too late'},
 'owl_intelligence':{'icon':'🦉','group':'observer','traits':['night vision','pattern memory','patience'], 'win':'predicts next route', 'blunder':'analysis paralysis'},
 'fox_deception':{'icon':'🦊','group':'deception','traits':['feint','bait','lure'], 'win':'opponent commits wrong', 'blunder':'trick exposed'},
 'cuckoo_deception':{'icon':'🐦','group':'deception','traits':['wrong nest','false identity','misdirection'], 'win':'causes wrong assumption', 'blunder':'identity exposed'},
 'spider_web_control':{'icon':'🕷️','group':'control','traits':['trap network','route control'], 'win':'prey self-entangles', 'blunder':'web too static'},
 'sheep_flock_panic':{'icon':'🐑','group':'prey','traits':['crowd panic','herd cover','funnel'], 'win':'survives in group', 'blunder':'herd runs into trap'},
 'goat_stubborn_luck':{'icon':'🐐','group':'comedy','traits':['stubborn','awkward survival','refuses route'], 'win':'survives by resilience', 'blunder':'charges danger'},
 'duck_waddle_escape':{'icon':'🦆','group':'comedy','traits':['clumsy','slow','improbable escape'], 'win':'survives by timing', 'blunder':'walks into line'},
 'swan_grace_escape':{'icon':'🦢','group':'comedy','traits':['elegant','smooth avoidance'], 'win':'clean escape', 'blunder':'overconfident glide'},
 'comedy_anomaly':{'icon':'😂','group':'comedy','traits':['bad timing','physics joke','pattern break'], 'win':'laugh release', 'blunder':'ruins serious tone'},
}

TONE_TERMS={
 'shot_fired':['shot','shoot','gun','fire','bullet','clip','kill'],
 'hit_confirmed':['hit','down','dead','kill','impact','blood'],
 'predation_pressure':['predation','pressure','hunt','chase','war','fight','vs','ambush','route'],
 'chase_escape':['chase','escape','run','vehicle','pursuit','racing'],
 'comedy_blunder':['funny','comedy','fail','blunder','panic','dumb','luck','goat','duck'],
 'dark_aftermath':['aftermath','dark','hell','bells','grave','raven','night'],
 'hero_intro':['intro','hero','suits','mafia','family','dougie','samington'],
 'team_play':['team','crew','chapter','family','pack','disciples'],
 'graphic_intensity_review':['graphic','intense','gore','blood','hit','impact'],
 'music_video_sync':['music','song','official','full','audio','album'],
}
SONG_MOOD={
 'dramatic':['hell','bells','thunder','war','battle','black','back','shoot','thrill','bat','hell','poison','numb'],
 'heroic':['hero','who made who','suits','mafia','family','rise','victory'],
 'comedic':['good 4 u','funny','yellow','black','panic','duck','goat'],
 'dark':['hell','grave','night','black','raven','aftermath'],
 'fast':['thrill','shoot','speed','run','back in black','rock'],
}

def now(): return dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00','Z')
def slug(s:str)->str: return re.sub(r'[^a-zA-Z0-9]+','_',s).strip('_')[:110] or 'asset'
def sha_path(p:Path)->str: return hashlib.sha1(str(p).encode()).hexdigest()[:16]
def relpath(p:Path, root:Path)->str:
    try: return str(p.relative_to(root))
    except Exception: return str(p)
def infer_kind(ext:str)->str:
    ext=ext.lower()
    if ext in VIDEO_EXT: return 'video'
    if ext in AUDIO_EXT: return 'audio'
    if ext in IMAGE_EXT: return 'image'
    if ext in DATA_EXT: return 'data'
    return 'other'
def score_terms(name:str, terms:List[str])->int:
    n=name.lower().replace('_',' ').replace('-',' ')
    return sum(1 for t in terms if t in n)
def classify_tones(name:str)->List[str]:
    scores=[(k,score_terms(name,v)) for k,v in TONE_TERMS.items()]
    out=[k for k,s in scores if s>0]
    return out[:5] or ['dramatic']
def classify_animal(name:str, tones:List[str])->str:
    n=name.lower()
    direct=[('wolf','lone_wolf'),('tiger','tiger_stalk'),('lion','lion_pack_pressure'),('sheep','sheep_flock_panic'),('goat','goat_stubborn_luck'),('duck','duck_waddle_escape'),('swan','swan_grace_escape'),('eagle','eagle_overwatch'),('hawk','hawk_strike'),('raven','raven_aftermath'),('cuckoo','cuckoo_deception'),('fox','fox_deception'),('shark','shark_pursuit'),('croc','crocodile_chokepoint'),('spider','spider_web_control')]
    for key,val in direct:
        if key in n: return val
    if 'comedy_blunder' in tones: return 'comedy_anomaly'
    if 'team_play' in tones: return 'lion_pack_pressure'
    if 'chase_escape' in tones: return 'shark_pursuit'
    if 'dark_aftermath' in tones: return 'raven_aftermath'
    if 'shot_fired' in tones or 'hit_confirmed' in tones: return 'hawk_strike'
    if 'predation_pressure' in tones: return 'tiger_stalk'
    return 'owl_intelligence'
def mood_for_song(name:str)->str:
    vals=[(k,score_terms(name,v)) for k,v in SONG_MOOD.items()]
    vals=sorted(vals,key=lambda x:x[1],reverse=True)
    return vals[0][0] if vals and vals[0][1]>0 else 'dramatic'
def ffprobe_duration(p:Path, timeout:int=4)->float|None:
    try:
        r=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(p)],capture_output=True,text=True,timeout=timeout)
        if r.returncode==0 and r.stdout.strip(): return round(float(r.stdout.strip()),3)
    except Exception: return None
    return None

def scan(root:Path, args)->List[Dict[str,Any]]:
    assets=[]; visited=0
    print(f'[scan] recursive scan started root={root}', flush=True)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:]=[d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            p=Path(dirpath)/fn
            ext=p.suffix.lower(); kind=infer_kind(ext)
            if kind=='other' and args.skip_other: continue
            try: st=p.stat()
            except Exception: continue
            visited+=1
            if args.smoke and visited>args.limit_files: break
            if args.limit_files and visited>args.limit_files: break
            duration=None
            if not args.no_probe_media and kind in {'audio','video'}: duration=ffprobe_duration(p)
            tones=classify_tones(fn+' '+str(p.parent))
            animal=classify_animal(fn+' '+str(p.parent), tones)
            site_url=None
            if DEFAULT_SITE in p.parents:
                site_url='/' + relpath(p,DEFAULT_SITE).replace(os.sep,'/')
            assets.append({'asset_id':sha_path(p),'path':str(p),'rel_path':relpath(p,root),'name':fn,'ext':ext,'kind':kind,'size_bytes':st.st_size,'mtime_utc':dt.datetime.fromtimestamp(st.st_mtime,dt.timezone.utc).isoformat().replace('+00:00','Z'),'duration_s':duration,'tones':tones,'animal_class':animal,'animal_icon':ANIMAL_TAXONOMY.get(animal,{}).get('icon','◇'),'song_mood':mood_for_song(fn) if kind=='audio' else None,'site_url':site_url,'mime':mime_for(p)})
            if visited % args.progress_every==0: print(f'[scan] visited={visited} assets={len(assets)} last={relpath(p,root)}', flush=True)
        if (args.smoke and visited>args.limit_files) or (args.limit_files and visited>args.limit_files): break
    print(f'[scan] complete assets={len(assets)}', flush=True)
    return assets

def mime_for(p:Path)->str:
    e=p.suffix.lower()
    return {'.mp4':'video/mp4','.webm':'video/webm','.mkv':'video/x-matroska','.mov':'video/quicktime','.mp3':'audio/mpeg','.wav':'audio/wav','.flac':'audio/flac','.m4a':'audio/mp4','.png':'image/png','.apng':'image/apng','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.svg':'image/svg+xml','.json':'application/json','.csv':'text/csv','.html':'text/html'}.get(e,'application/octet-stream')

def build_events(videos:List[Dict[str,Any]], images:List[Dict[str,Any]])->List[Dict[str,Any]]:
    ev=[]
    for i,a in enumerate(videos[:1500]):
        tones=a['tones']; animal=a['animal_class']
        evtype=tones[0] if tones else 'dramatic'
        score=round(0.45+0.08*len(tones)+min(0.25,a['size_bytes']/500_000_000),3)
        ev.append({'event_id':f'ev_{i:05d}_{a["asset_id"]}','asset_id':a['asset_id'],'name':a['name'],'path':a['path'],'site_url':a.get('site_url'),'event_type':evtype,'tones':tones,'animal_class':animal,'animal_icon':a['animal_icon'],'story_role':story_role(evtype,animal),'confidence':min(0.99,score),'de_bono_lens':debono_lens(evtype,animal),'strategy_lens':strategy_lens(evtype,animal)})
    return ev

def story_role(evtype, animal):
    if evtype in ('dark_aftermath','graphic_intensity_review') or animal=='raven_aftermath': return 'aftermath'
    if evtype in ('comedy_blunder',) or animal in ('duck_waddle_escape','goat_stubborn_luck','swan_grace_escape','comedy_anomaly'): return 'reversal'
    if evtype in ('hero_intro','music_video_sync'): return 'opening'
    if evtype in ('shot_fired','hit_confirmed','hawk_strike'): return 'impact'
    return 'pressure'

def debono_lens(evtype, animal):
    return {'PMI':{'plus':'strong story signal','minus':'needs human review for context','interesting':'may work as alternative sequence'},'CAF':['audio mood','visual action','animal analogy','member story','audience fit'],'AGO':'turn raw footage into story value','C&S':'render, publish, review, learn','OPV':['viewer','editor','member','rival','processor'],'PO':['reverse the outcome','use as comedy beat','move aftermath to opening','make song contradict action']}

def strategy_lens(evtype,animal):
    group=ANIMAL_TAXONOMY.get(animal,{}).get('group','unknown')
    return {'mckinsey_13s':{'strategy':0.75,'structure':0.55,'systems':0.7,'shared_values':0.62,'style':0.8,'staff':0.5,'skills':0.64,'signal':0.82,'story':0.78,'speed':0.66,'scope':0.6,'stewardship':0.52,'synergy':0.7 if group in {'predator','control'} else 0.45},'porter':{'value_chain_stage':'classify_to_story','advantage':'domain-specific GTARP event intelligence'},'drucker':{'effectiveness':'story contribution','priority':'review high signal clips first'},'mintzberg':{'mode':'emergent' if evtype in {'comedy_blunder','chase_escape'} else 'deliberate'},'kotler':{'segment':'action/comedy/lore audience','positioning':'cinematic GTARP story'}}

def match_song_action(songs, events, max_matches=1200):
    matches=[]
    for s in songs[:500]:
        mood=s.get('song_mood') or mood_for_song(s['name'])
        for ev in events[:400]:
            bonus=0
            if mood=='comedic' and ev['event_type']=='comedy_blunder': bonus+=0.3
            if mood=='dark' and ev['story_role']=='aftermath': bonus+=0.25
            if mood=='fast' and ev['event_type'] in ('shot_fired','chase_escape','hit_confirmed'): bonus+=0.25
            if mood=='heroic' and ev['story_role']=='opening': bonus+=0.2
            base=0.45+0.04*len(ev['tones'])+bonus
            matches.append({'match_id':f'match_{sha_path(Path(s["path"]))}_{ev["event_id"][-8:]}','song_asset_id':s['asset_id'],'song_name':s['name'],'song_path':s['path'],'song_site_url':s.get('site_url'),'song_mood':mood,'event_id':ev['event_id'],'video_asset_id':ev['asset_id'],'video_name':ev['name'],'video_path':ev['path'],'video_site_url':ev.get('site_url'),'event_type':ev['event_type'],'animal_class':ev['animal_class'],'animal_icon':ev['animal_icon'],'story_role':ev['story_role'],'score':round(min(0.99,base),3)})
    matches.sort(key=lambda x:x['score'], reverse=True)
    return matches[:max_matches]

def build_grouped_playlists(matches):
    groups={}
    for m in matches:
        key=f'{m["song_mood"]}_{m["animal_class"]}'
        g=groups.setdefault(key,{'playlist_id':slug(key),'title':f'{m["song_mood"].title()} / {m["animal_class"]}','song_mood':m['song_mood'],'animal_class':m['animal_class'],'animal_icon':m['animal_icon'],'items':[],'songs':{},'videos':{}})
        if len(g['items'])<18: g['items'].append(m)
        g['songs'][m['song_asset_id']]={'name':m['song_name'],'path':m['song_path'],'site_url':m.get('song_site_url')}
        g['videos'][m['video_asset_id']]={'name':m['video_name'],'path':m['video_path'],'site_url':m.get('video_site_url')}
    return list(groups.values())[:80]

def build_movies(playlists, n=12):
    movies=[]
    for i,p in enumerate(playlists[:n]):
        items=p['items'][:8]
        if not items: continue
        song=next(iter(p['songs'].values())) if p['songs'] else {'path':''}
        movies.append({'movie_id':f'movie_{i+1:02d}_{p["playlist_id"]}','title':f'$uit$ Story {i+1:02d}: {p["title"]}','playlist_id':p['playlist_id'],'song':song,'clips':[{'name':it['video_name'],'path':it['video_path'],'event_type':it['event_type'],'animal_class':it['animal_class'],'role':it['story_role']} for it in items],'story_arc':['opening','pressure','reversal','impact','aftermath'],'render_output':f'renders_v16_6/{i+1:02d}_{p["playlist_id"]}.mp4'})
    return movies

def build_charts(assets, events, matches, playlists):
    from collections import Counter
    def rows(counter): return [{'category':k,'count':v} for k,v in counter.most_common()]
    charts=[]
    counters={
      'asset_kind_population':Counter(a['kind'] for a in assets),
      'animal_class_population':Counter(e['animal_class'] for e in events),
      'event_type_population':Counter(e['event_type'] for e in events),
      'song_mood_population':Counter(a.get('song_mood') for a in assets if a.get('song_mood')),
      'story_role_population':Counter(e['story_role'] for e in events),
      'playlist_animal_population':Counter(p['animal_class'] for p in playlists),
    }
    for cid,c in counters.items():
        charts.append({'chart_id':cid,'chart_group':'population','click_target':cid.replace('_population',''),'chartType':'bar','meta':{'title':cid.replace('_',' ').title(),'description':'Generated server-resource population chart.'},'xKey':'category','series':[{'dataKey':'count','label':'Count','valueFormat':'integer'}],'data':rows(c)})
    # Fill to 64 with useful repeats/filtered views
    base=list(charts)
    i=0
    while len(charts)<64:
        b=base[i%len(base)].copy(); b=dict(b); b['chart_id']=f'{b["chart_id"]}_{len(charts)+1:02d}'; b['meta']=dict(b['meta']); b['meta']['title']=f'{b["meta"]["title"]} Lens {len(charts)+1:02d}'; b['chart_group']=['assets','audio','video','predation','comedy','strategy','playlists','graph'][len(charts)%8]; charts.append(b); i+=1
    return charts[:64]

def write_json(p:Path, obj:Any): p.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
def write_csv(p:Path, rows:List[Dict[str,Any]]):
    if not rows: p.write_text('',encoding='utf-8'); return
    keys=list(rows[0].keys())
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore'); w.writeheader(); w.writerows(rows)

def build_sqlite(db:Path, assets, events, matches, playlists, movies):
    if db.exists(): db.unlink()
    conn=sqlite3.connect(db); cur=conn.cursor()
    cur.execute('CREATE TABLE asset(asset_id TEXT PRIMARY KEY,path TEXT,name TEXT,kind TEXT,ext TEXT,mime TEXT,duration_s REAL,animal_class TEXT,tones_json TEXT,site_url TEXT)')
    cur.execute('CREATE TABLE action_event(event_id TEXT PRIMARY KEY,asset_id TEXT,event_type TEXT,animal_class TEXT,story_role TEXT,confidence REAL,lens_json TEXT)')
    cur.execute('CREATE TABLE song_action_match(match_id TEXT PRIMARY KEY,song_asset_id TEXT,video_asset_id TEXT,event_id TEXT,score REAL,song_mood TEXT,animal_class TEXT,story_role TEXT)')
    cur.execute('CREATE TABLE playlist(playlist_id TEXT PRIMARY KEY,title TEXT,song_mood TEXT,animal_class TEXT,items_json TEXT)')
    cur.execute('CREATE TABLE movie_plan(movie_id TEXT PRIMARY KEY,title TEXT,playlist_id TEXT,song_json TEXT,clips_json TEXT,render_output TEXT)')
    for a in assets:
        cur.execute('INSERT OR REPLACE INTO asset VALUES(?,?,?,?,?,?,?,?,?,?)',(a['asset_id'],a['path'],a['name'],a['kind'],a['ext'],a['mime'],a.get('duration_s'),a.get('animal_class'),json.dumps(a.get('tones',[])),a.get('site_url')))
    for e in events:
        cur.execute('INSERT OR REPLACE INTO action_event VALUES(?,?,?,?,?,?,?)',(e['event_id'],e['asset_id'],e['event_type'],e['animal_class'],e['story_role'],e['confidence'],json.dumps({'de_bono':e['de_bono_lens'],'strategy':e['strategy_lens']})))
    for m in matches:
        cur.execute('INSERT OR REPLACE INTO song_action_match VALUES(?,?,?,?,?,?,?,?)',(m['match_id'],m['song_asset_id'],m['video_asset_id'],m['event_id'],m['score'],m['song_mood'],m['animal_class'],m['story_role']))
    for p in playlists:
        cur.execute('INSERT OR REPLACE INTO playlist VALUES(?,?,?,?,?)',(p['playlist_id'],p['title'],p['song_mood'],p['animal_class'],json.dumps(p['items'])))
    for m in movies:
        cur.execute('INSERT OR REPLACE INTO movie_plan VALUES(?,?,?,?,?,?)',(m['movie_id'],m['title'],m['playlist_id'],json.dumps(m['song']),json.dumps(m['clips']),m['render_output']))
    conn.commit(); conn.close()

def build_graph(events,matches,playlists):
    nodes=[]; edges=[]; seen=set()
    def node(id,label,kind,**kw):
        if id in seen: return
        seen.add(id); d={'id':id,'label':label,'kind':kind}; d.update(kw); nodes.append(d)
    def edge(s,t,rel,**kw): edges.append({'source':s,'target':t,'rel':rel,**kw})
    for e in events[:800]:
        node(e['event_id'],e['event_type'],'event',animal_class=e['animal_class'])
        ac='animal:'+e['animal_class']; node(ac,e['animal_icon']+' '+e['animal_class'],'animal_class'); edge(e['event_id'],ac,'CLASSIFIED_AS')
    for m in matches[:800]:
        sid='song:'+m['song_asset_id']; vid='video:'+m['video_asset_id']
        node(sid,m['song_name'],'song',song_mood=m['song_mood']); node(vid,m['video_name'],'video')
        edge(sid,m['event_id'],'SCORES_ACTION',score=m['score']); edge(vid,m['event_id'],'HAS_EVENT')
    for p in playlists[:80]:
        pid='playlist:'+p['playlist_id']; node(pid,p['title'],'playlist')
        for it in p['items'][:8]: edge(pid,it['event_id'],'CONTAINS')
    return nodes,edges

def cypher(nodes,edges):
    lines=['// $uits v16.6 Neo4j import','CREATE CONSTRAINT suits_node_id IF NOT EXISTS FOR (n:SuitsNode) REQUIRE n.id IS UNIQUE;']
    for n in nodes:
        props=json.dumps(n,ensure_ascii=False).replace("'","\\'")
        lines.append(f"MERGE (n:SuitsNode {{id: '{n['id']}'}}) SET n += apoc.convert.fromJsonMap('{props}');")
    for e in edges:
        props=json.dumps(e,ensure_ascii=False).replace("'","\\'")
        lines.append(f"MATCH (a:SuitsNode {{id:'{e['source']}'}}),(b:SuitsNode {{id:'{e['target']}'}}) MERGE (a)-[r:SUITS_REL {{rel:'{e['rel']}'}}]->(b) SET r += apoc.convert.fromJsonMap('{props}');")
    return '\n'.join(lines)+'\n'

def _shq(s):
    return "'" + str(s).replace("'", "'\\''") + "'"

def render_scripts(out, movies, site):
    render_dir=out/'renders_v16_6'; render_dir.mkdir(exist_ok=True)
    full_song_dir=render_dir/'full_song_movies'; full_song_dir.mkdir(exist_ok=True)
    clip29_dir=render_dir/'clip29_movies'; clip29_dir.mkdir(exist_ok=True)
    film_dir=render_dir/'full_film'; film_dir.mkdir(exist_ok=True)

    # One base concat list per movie, plus metadata fields for the WebsiteUI.
    for idx,m in enumerate(movies,1):
        listfile=out/f'{m["movie_id"]}_clips.txt'
        clip_lines=[]
        for c in m.get('clips',[]):
            safe=c['path'].replace("'","'\\''")
            clip_lines.append(f"file '{safe}'")
        listfile.write_text('\n'.join(clip_lines)+'\n',encoding='utf-8')
        m['render_scripts']={
            'clip_list':str(listfile),
            'full_song_output':str(full_song_dir/f'{idx:02d}_{slug(m["title"])}_full_song.mp4'),
            'clip29_output':str(clip29_dir/f'{idx:02d}_{slug(m["title"])}_29s.mp4')
        }

    helper=['#!/usr/bin/env bash','set -euo pipefail','',
        'dur(){ ffprobe -v error -show_entries format=duration -of default=nk=1:nw=1 "$1" 2>/dev/null | awk \'{printf "%d", ($1>0?$1:0)}\'; }',
        'loop_concat(){',
        '  base="$1"; out="$2"; audio="$3"',
        '  audio_dur=$(dur "$audio"); [ "$audio_dur" -gt 0 ] || audio_dur=240',
        '  clip_dur=0',
        '  while IFS= read -r line; do',
        '    f=${line#file }; f=${f#\'}; f=${f%\'}',
        '    d=$(dur "$f"); clip_dur=$((clip_dur+d))',
        '  done < "$base"',
        '  [ "$clip_dur" -gt 0 ] || clip_dur=20',
        '  reps=$((audio_dur / clip_dur + 2))',
        '  : > "$out"',
        '  for i in $(seq 1 "$reps"); do cat "$base" >> "$out"; done',
        '}',
        '']

    full_lines=helper+['mkdir -p '+_shq(full_song_dir),'echo "[o][o] rendering full-song song movies"']
    clip29_lines=helper+['mkdir -p '+_shq(clip29_dir),'echo "[o][o] rendering 29-second song clips"']
    for idx,m in enumerate(movies,1):
        base=out/f'{m["movie_id"]}_clips.txt'
        song=m.get('song',{}).get('path') or ''
        full_out=Path(m['render_scripts']['full_song_output'])
        clip_out=Path(m['render_scripts']['clip29_output'])
        looplist=out/f'{m["movie_id"]}_looped_for_full_song.txt'
        if song:
            full_lines += [
                'loop_concat '+_shq(base)+' '+_shq(looplist)+' '+_shq(song),
                'ffmpeg -y -f concat -safe 0 -i '+_shq(looplist)+' -i '+_shq(song)+' -map 0:v:0 -map 1:a:0 -shortest -c:v libx264 -pix_fmt yuv420p -c:a aac -b:a 192k '+_shq(full_out)+' || true'
            ]
            clip29_lines += [
                'loop_concat '+_shq(base)+' '+_shq(looplist)+' '+_shq(song),
                'ffmpeg -y -f concat -safe 0 -i '+_shq(looplist)+' -i '+_shq(song)+' -t 29 -map 0:v:0 -map 1:a:0 -shortest -c:v libx264 -pix_fmt yuv420p -c:a aac -b:a 192k '+_shq(clip_out)+' || true'
            ]
        else:
            full_lines.append('ffmpeg -y -f concat -safe 0 -i '+_shq(base)+' -c copy '+_shq(full_out)+' || true')
            clip29_lines.append('ffmpeg -y -f concat -safe 0 -i '+_shq(base)+' -t 29 -c:v libx264 -pix_fmt yuv420p '+_shq(clip_out)+' || true')

    full_script=out/'render_song_movies_full_songs.sh'
    clip_script=out/'render_song_movies_29s.sh'
    full_script.write_text('\n'.join(full_lines)+'\n',encoding='utf-8'); os.chmod(full_script,0o755)
    clip_script.write_text('\n'.join(clip29_lines)+'\n',encoding='utf-8'); os.chmod(clip_script,0o755)

    film_list=out/'full_film_movie_concat.txt'
    film_out=film_dir/'suits_full_film_movie.mp4'
    film_lines=['#!/usr/bin/env bash','set -euo pipefail','mkdir -p '+_shq(film_dir),'echo "[o][o] rendering full film movie from full-song movies"','bash '+_shq(full_script),': > '+_shq(film_list)]
    for m in movies:
        film_lines.append('if [ -f '+_shq(m['render_scripts']['full_song_output'])+' ]; then echo "file '+m['render_scripts']['full_song_output'].replace("'","'\\''")+'" >> '+_shq(film_list)+'; fi')
    film_lines.append('ffmpeg -y -f concat -safe 0 -i '+_shq(film_list)+' -c copy '+_shq(film_out)+' || ffmpeg -y -f concat -safe 0 -i '+_shq(film_list)+' -c:v libx264 -pix_fmt yuv420p -c:a aac -b:a 192k '+_shq(film_out)+' || true')
    film_script=out/'render_full_film_movie.sh'
    film_script.write_text('\n'.join(film_lines)+'\n',encoding='utf-8'); os.chmod(film_script,0o755)

    # Backwards-compatible all-in-one script.
    all_script=out/'render_grouped_dramatic_movies.sh'
    all_script.write_text('\n'.join(['#!/usr/bin/env bash','set -euo pipefail','bash '+_shq(full_script),'bash '+_shq(clip_script),'bash '+_shq(film_script)])+'\n',encoding='utf-8'); os.chmod(all_script,0o755)

    pub=['#!/usr/bin/env bash','set -euo pipefail',f'SITE="{site}"','mkdir -p "$SITE/videos"',f'cp -v "{render_dir}"/**/*.mp4 "$SITE/videos/" 2>/dev/null || true',f'cp -v "{render_dir}"/*.mp4 "$SITE/videos/" 2>/dev/null || true','echo "[o][o] copied rendered movies into website videos"']
    pub_script=out/'publish_movies_to_site.sh'
    pub_script.write_text('\n'.join(pub)+'\n',encoding='utf-8'); os.chmod(pub_script,0o755)

    write_json(out/'render_jobs.json',{
        'full_song_script':str(full_script),
        'clip29_script':str(clip_script),
        'full_film_script':str(film_script),
        'publish_script':str(pub_script),
        'full_film_output':str(film_out),
        'movies':movies
    })

def report(out, summary):
    body=f"""<!doctype html><html><head><meta charset='utf-8'><title>$uits v16.6 Report</title><style>body{{background:#07111f;color:#dbeafe;font-family:system-ui;padding:24px}}pre{{background:#0f1e33;padding:16px;border-radius:12px;white-space:pre-wrap}}a{{color:#93c5fd}}</style></head><body><h1>[o][o] $uits v16.6 Dramatic Movie Theatre</h1><pre>{html.escape(json.dumps(summary,indent=2))}</pre></body></html>"""
    (out/'report.html').write_text(body,encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default=str(DEFAULT_ROOT)); ap.add_argument('--site',default=str(DEFAULT_SITE)); ap.add_argument('--out',default=str(DEFAULT_OUT))
    ap.add_argument('--smoke',action='store_true'); ap.add_argument('--limit-files',type=int,default=700 if '--smoke' in sys.argv else 0)
    ap.add_argument('--progress-every',type=int,default=250); ap.add_argument('--no-probe-media',action='store_true'); ap.add_argument('--skip-other',action='store_true',default=True)
    ap.add_argument('--ml-update',action='store_true'); ap.add_argument('--build-webui',action='store_true'); ap.add_argument('--build-graphs',action='store_true'); ap.add_argument('--build-charts',action='store_true'); ap.add_argument('--plan-movies',action='store_true')
    args=ap.parse_args(); root=Path(args.root); site=Path(args.site); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    print('[o][o] $uits Processor v16.6 Dramatic Movie Theatre', flush=True); print('SCHEMA='+SCHEMA, flush=True); print('ROOT='+str(root), flush=True); print('OUT='+str(out), flush=True); print('SITE='+str(site), flush=True)
    assets=scan(root,args); songs=[a for a in assets if a['kind']=='audio']; videos=[a for a in assets if a['kind']=='video']; images=[a for a in assets if a['kind']=='image']; data=[a for a in assets if a['kind']=='data']
    print('[stage] building events / classifications', flush=True); events=build_events(videos,images)
    print('[stage] building song/action and action/song indexes', flush=True); matches=match_song_action(songs,events)
    action_song=list(sorted(matches,key=lambda x:(x['event_type'], -x['score'])))
    print('[stage] building grouped playlists and movie plans', flush=True); playlists=build_grouped_playlists(matches); movies=build_movies(playlists,12)
    charts=build_charts(assets,events,matches,playlists); nodes,edges=build_graph(events,matches,playlists)
    summary={'schema':SCHEMA,'version':VERSION,'created_utc':now(),'root':str(root),'site':str(site),'out':str(out),'counts':{'assets':len(assets),'music':len(songs),'videos':len(videos),'images':len(images),'data':len(data),'events':len(events),'matches':len(matches),'playlists':len(playlists),'movies':len(movies),'charts':len(charts),'graph_nodes':len(nodes),'graph_edges':len(edges)},'recommendation':'Use the server WebUI to select grouped song/action playlists, then render dramatic movies.'}
    print('[stage] writing resources', flush=True)
    for name,obj in [('summary.json',summary),('media_manifest.json',assets),('music_profile_index.json',songs),('video_profile_index.json',videos),('image_profile_index.json',images),('action_events.json',events),('song_action_recommendations.json',matches),('action_song_recommendations.json',action_song),('grouped_playlists.json',playlists),('movie_factory_12.json',movies),('chart_specs_64.json',charts),('graph_nodes.json',nodes),('graph_edges.json',edges),('predation_comedy_taxonomy.json',ANIMAL_TAXONOMY)]: write_json(out/name,obj)
    (out/'sql').mkdir(exist_ok=True); (out/'neo4j').mkdir(exist_ok=True)
    write_csv(out/'sql'/'source_files.csv', assets); write_csv(out/'sql'/'action_events.csv', events); write_csv(out/'sql'/'song_action_recommendations.csv', matches); write_csv(out/'sql'/'movie_factory_12.csv', movies)
    build_sqlite(out/'sql'/'suits_v16_6_dramatic_movie_theatre.sqlite3',assets,events,matches,playlists,movies)
    write_csv(out/'neo4j'/'neo4j_nodes.csv',nodes); write_csv(out/'neo4j'/'neo4j_edges.csv',edges); (out/'neo4j'/'suits_v16_6_import.cypher').write_text(cypher(nodes,edges),encoding='utf-8')
    render_scripts(out,movies,site); report(out,summary)
    if args.build_webui:
        data_dir=site/'data'/'suits_v16_6'; data_dir.mkdir(parents=True,exist_ok=True)
        for f in out.glob('*.json'): shutil.copy2(f,data_dir/f.name)
        print('[stage] copied WebUI data to '+str(data_dir), flush=True)
    print('[o][o] Done', flush=True); print('REPORT='+str(out/'report.html'), flush=True)
if __name__=='__main__': main()
