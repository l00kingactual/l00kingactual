# [o][o] $uits Processor v16.6.1 Python

Python-only processor package. It scans media, builds grouped song/action playlists, and writes render scripts for:

- full-song song movies
- 29-second song clips
- one full film movie stitched from the full-song movies

## Install

```bash
cd ~/Downloads
unzip -o suits_processor_v16_6_1_python.zip
cd suits_processor_v16_6_1_python
chmod +x scripts/*.sh
./scripts/install_python_processor.sh
```

## Run

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_6_1 \
  --ml-update --build-webui --build-graphs --build-charts --plan-movies \
  --no-probe-media --progress-every 250
```

## Render after run

```bash
OUT=/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre
bash "$OUT/render_song_movies_full_songs.sh"
bash "$OUT/render_song_movies_29s.sh"
bash "$OUT/render_full_film_movie.sh"
bash "$OUT/publish_movies_to_site.sh"
```

## py -m style

After install, the launcher runs:

```bash
.venv/bin/python -m suits_dramatic_movie_theatre
```
