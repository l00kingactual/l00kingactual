#!/usr/bin/env bash
set -euo pipefail
ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
PROC="$ROOT/processors/suits_processor_v16_6_1_python"
TOOLS="$ROOT/tools"
mkdir -p "$PROC" "$TOOLS" "$ROOT/outputs"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if command -v rsync >/dev/null 2>&1; then rsync -a "$SCRIPT_DIR/" "$PROC/"; else cp -a "$SCRIPT_DIR/." "$PROC/"; fi
python3 -m venv "$PROC/.venv"
"$PROC/.venv/bin/python" -m pip install --upgrade pip wheel setuptools
"$PROC/.venv/bin/python" -m pip install -r "$PROC/requirements.txt" || true
cat > "$TOOLS/suits_processor_v16_6_1" <<EOF
#!/usr/bin/env bash
"$PROC/.venv/bin/python" -m suits_dramatic_movie_theatre "\$@"
EOF
chmod +x "$TOOLS/suits_processor_v16_6_1"
echo "[o][o] installed python processor: $TOOLS/suits_processor_v16_6_1"
echo "[run] $TOOLS/suits_processor_v16_6_1 --ml-update --build-webui --build-graphs --build-charts --plan-movies --no-probe-media --progress-every 250"
