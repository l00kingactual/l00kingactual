#!/usr/bin/env bash
set -euo pipefail
ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
"$ROOT/tools/suits_processor_v16_6_1" --smoke --limit-files 900 --ml-update --build-webui --build-graphs --build-charts --plan-movies --no-probe-media --progress-every 100
