param(
  [string]$InstallRoot = "$env:USERPROFILE\Documents\suitsmafia-client",
  [string]$RemoteBaseUrl = "https://217.154.62.118"
)

Write-Host "[o][o] Starting $uits Windows client" -ForegroundColor Cyan
if (!(Test-Path $InstallRoot)) {
  Write-Error "InstallRoot does not exist: $InstallRoot"
  exit 1
}

$urls = @(
  "$RemoteBaseUrl/suits_v16_6_dashboard.php",
  "$RemoteBaseUrl/suits_v16_6_theatre.php",
  "$RemoteBaseUrl/suits_v16_6_playlists.php",
  "$RemoteBaseUrl/suits_v16_6_movies.php"
)
foreach ($u in $urls) { Start-Process $u }
Start-Process explorer.exe $InstallRoot

$fivem = "$env:LOCALAPPDATA\FiveM\FiveM.app"
if (Test-Path $fivem) {
  Write-Host "FiveM folder found: $fivem" -ForegroundColor Green
} else {
  Write-Warning "FiveM folder not found at default path. Install/run FiveM once, then rerun."
}
