param(
  [string]$InstallRoot = "$env:USERPROFILE\Documents\suitsmafia-client",
  [string]$RemoteBaseUrl = "https://217.154.62.118",
  [switch]$Wsl
)

Write-Host "[o][o] Installing $uits Windows client workspace" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
New-Item -ItemType Directory -Force -Path "$InstallRoot\logs", "$InstallRoot\downloads", "$InstallRoot\fiveM", "$InstallRoot\playlists", "$InstallRoot\renders" | Out-Null

if (Get-Command winget -ErrorAction SilentlyContinue) {
  winget install --id Python.Python.3.12 -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
  winget install --id Git.Git -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
  winget install --id Gyan.FFmpeg -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
} else {
  Write-Warning "winget not found. Install Python 3, Git and FFmpeg manually."
}

$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) {
  Push-Location $InstallRoot
  py -3 -m venv .venv
  .\.venv\Scripts\python.exe -m pip install --upgrade pip wheel setuptools
  @"
numpy
pandas
plotly
networkx
pillow
opencv-python
moviepy
requests
fastapi
uvicorn
python-dotenv
rich
tqdm
"@ | Set-Content -Path "$InstallRoot\requirements-client.txt" -Encoding UTF8
  .\.venv\Scripts\python.exe -m pip install -r requirements-client.txt
  Pop-Location
}

@"
SUITS_REMOTE_BASE_URL=$RemoteBaseUrl
SUITS_CLIENT_ROOT=$InstallRoot
FIVEM_APPDATA=$env:LOCALAPPDATA\FiveM\FiveM.app
"@ | Set-Content -Path "$InstallRoot\.env" -Encoding UTF8

@"
# $uits Windows Client

Remote UI: $RemoteBaseUrl
Local root: $InstallRoot

Folders:
- fiveM: client-side GTA/FiveM notes, logs and exports
- playlists: downloaded playlist JSON
- renders: local render scratch
- logs: client script logs

Do not store server root passwords here.
"@ | Set-Content -Path "$InstallRoot\README_CLIENT.md" -Encoding UTF8

Write-Host "[o][o] Windows client workspace ready: $InstallRoot" -ForegroundColor Green
Write-Host "[next] run windows\start_suits_windows_client.ps1 -RemoteBaseUrl $RemoteBaseUrl"
