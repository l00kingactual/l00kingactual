# $uits Remote Dramatic Movie Theatre Install Pack

This pack prepares a Debian 13 + Plesk VPS as a secure remote server for the $uits Mafia processor resources and WebUI, and prepares a Windows gaming/client machine to connect to it.

Important: do not put root passwords, Plesk license keys, or FTP credentials into these scripts. Use SSH keys and rotate any password/license that has been pasted into chat or logs.

## Contents

- `scripts/debian13_plesk_server_install.sh` - Debian 13/Plesk server bootstrap.
- `scripts/install_processor_package.sh` - installs an uploaded processor ZIP on the server.
- `scripts/suits_remote_env_template` - environment template, no secrets included.
- `server/suits-theatre-api.service` - optional systemd unit for a Python API/service.
- `server/suits-theatre-worker.service` - optional systemd unit for background processor jobs.
- `windows/install_suits_windows_client.ps1` - Windows client/workbench setup.
- `windows/start_suits_windows_client.ps1` - opens remote UI and local folders.
- `config/requirements.txt` - copied from your uploaded requirements where available.

## Safe architecture

Server VPS:

```text
/opt/suitsmafia
  processors/
  outputs/
  website/
  venv/
  logs/
  data/
```

Plesk/website:

```text
/var/www/vhosts/<domain>/httpdocs
```

The scripts default to `/opt/suitsmafia` and do not overwrite Plesk virtual hosts unless you explicitly set `SUITS_SITE_ROOT`.

## Recommended flow

1. SSH in as root once.
2. Create a non-root admin user and SSH key.
3. Rotate the initial password.
4. Upload this ZIP and the latest processor ZIP.
5. Run `debian13_plesk_server_install.sh`.
6. Run `install_processor_package.sh /path/to/suits_processor_v16_6_dramatic_movie_theatre_webui_package.zip`.
7. Use Windows PowerShell installer on the gaming PC.

