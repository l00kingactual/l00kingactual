# Security first

You pasted a root password and Plesk license details in chat. Treat them as exposed.

Recommended immediate actions:

1. Change the VPS root password in the provider console or over SSH.
2. Create a non-root `suits` or admin account and use SSH keys.
3. Disable root SSH password login after keys are tested.
4. Rotate or protect the Plesk admin password/license details.
5. Do not expose Python API ports directly; bind to `127.0.0.1` and proxy through Plesk/nginx with HTTPS.
6. Keep Neo4j bound to localhost unless there is a specific secured reason to expose it.

Suggested `/etc/ssh/sshd_config` after key login works:

```text
PermitRootLogin prohibit-password
PasswordAuthentication no
PubkeyAuthentication yes
```

Then:

```bash
systemctl restart ssh
```
