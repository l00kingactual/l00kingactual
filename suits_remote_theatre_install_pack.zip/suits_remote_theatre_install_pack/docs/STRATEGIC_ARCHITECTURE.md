# Strategy

Server = processor factory and resource builder.
Windows client = GTA/FiveM gaming workstation and theatre controller.
Website UI = public/private theatre, playlists, story review, chart lab and graph lab.

Server responsibilities:
- scan recursively
- profile media
- classify action videos
- group songs and actions
- build playlists
- plan/render movies
- export SQLite/JSON/CSV/Neo4j/Cypher/chart specs
- serve WebUI data

Windows responsibilities:
- browse theatre
- operate playlists
- review clips
- collect local FiveM/GTA notes/log paths
- optionally upload selected local media to server through secure channel later

No script should create a covert remote shell. Use SSH, HTTPS, Plesk, and explicit services only.
