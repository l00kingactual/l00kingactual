#!/usr/bin/env bash
set -euo pipefail

# $uits Mafia Debian 13 + Plesk remote server bootstrap.
# Run as root on the VPS.
# This script avoids storing secrets and avoids overwriting Plesk vhosts.

if [ "${EUID}" -ne 0 ]; then
  echo "[error] run as root on the VPS" >&2
  exit 1
fi

SUITS_USER="${SUITS_USER:-suits}"
SUITS_ROOT="${SUITS_ROOT:-/opt/suitsmafia}"
SUITS_SITE_ROOT="${SUITS_SITE_ROOT:-$SUITS_ROOT/website}"
SUITS_OUTPUT_ROOT="${SUITS_OUTPUT_ROOT:-$SUITS_ROOT/outputs}"
SUITS_PROCESSOR_ROOT="${SUITS_PROCESSOR_ROOT:-$SUITS_ROOT/processors}"
SUITS_DATA_ROOT="${SUITS_DATA_ROOT:-$SUITS_ROOT/data}"
SUITS_LOG_ROOT="${SUITS_LOG_ROOT:-$SUITS_ROOT/logs}"
SUITS_PORT="${SUITS_PORT:-8096}"

printf '[o][o] $uits Debian/Plesk server bootstrap\n'
printf '[info] root=%s user=%s site=%s\n' "$SUITS_ROOT" "$SUITS_USER" "$SUITS_SITE_ROOT"

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  python3 python3-venv python3-pip python3-dev \
  build-essential pkg-config \
  ffmpeg mediainfo imagemagick webp \
  sqlite3 unzip zip rsync curl wget git jq acl \
  ca-certificates gnupg lsb-release \
  nginx apache2-utils ufw fail2ban \
  php-cli php-sqlite3 php-json php-curl php-mbstring php-xml php-zip \
  nodejs npm

if ! id "$SUITS_USER" >/dev/null 2>&1; then
  adduser --disabled-password --gecos "Suits Mafia Service" "$SUITS_USER"
fi

mkdir -p "$SUITS_ROOT" "$SUITS_SITE_ROOT" "$SUITS_OUTPUT_ROOT" "$SUITS_PROCESSOR_ROOT" "$SUITS_DATA_ROOT" "$SUITS_LOG_ROOT" /etc/suitsmafia
chown -R "$SUITS_USER:$SUITS_USER" "$SUITS_ROOT"
chmod 750 "$SUITS_ROOT"

if [ ! -f /etc/suitsmafia/suits.env ]; then
  cat >/etc/suitsmafia/suits.env <<ENV
SUITS_ROOT=$SUITS_ROOT
SUITS_SITE_ROOT=$SUITS_SITE_ROOT
SUITS_OUTPUT_ROOT=$SUITS_OUTPUT_ROOT
SUITS_PROCESSOR_ROOT=$SUITS_PROCESSOR_ROOT
SUITS_DATA_ROOT=$SUITS_DATA_ROOT
SUITS_LOG_ROOT=$SUITS_LOG_ROOT
SUITS_PYTHON=$SUITS_ROOT/venv/bin/python
SUITS_HOST=127.0.0.1
SUITS_PORT=$SUITS_PORT
SUITS_PUBLIC_BASE_URL=https://your-domain.example
NEO4J_URI=bolt://127.0.0.1:7687
NEO4J_USER=neo4j
ENV
  chmod 640 /etc/suitsmafia/suits.env
fi

sudo -u "$SUITS_USER" python3 -m venv "$SUITS_ROOT/venv"
sudo -u "$SUITS_USER" "$SUITS_ROOT/venv/bin/python" -m pip install --upgrade pip wheel setuptools

REQ_SRC="${REQ_SRC:-}"
if [ -n "$REQ_SRC" ] && [ -f "$REQ_SRC" ]; then
  cp "$REQ_SRC" "$SUITS_ROOT/requirements.txt"
else
  cat >"$SUITS_ROOT/requirements.txt" <<'REQ'
numpy
pandas
matplotlib
plotly
networkx
scikit-learn
pillow
opencv-python-headless
moviepy
python-magic
fastapi
uvicorn[standard]
flask
jinja2
neo4j
pydantic
python-dotenv
rich
tqdm
REQ
fi
chown "$SUITS_USER:$SUITS_USER" "$SUITS_ROOT/requirements.txt"
sudo -u "$SUITS_USER" "$SUITS_ROOT/venv/bin/python" -m pip install -r "$SUITS_ROOT/requirements.txt" || true

# Optional Neo4j install. Set INSTALL_NEO4J=1 to enable.
if [ "${INSTALL_NEO4J:-0}" = "1" ]; then
  if ! command -v neo4j >/dev/null 2>&1; then
    wget -O - https://debian.neo4j.com/neotechnology.gpg.key | gpg --dearmor -o /usr/share/keyrings/neo4j.gpg
    echo "deb [signed-by=/usr/share/keyrings/neo4j.gpg] https://debian.neo4j.com stable latest" >/etc/apt/sources.list.d/neo4j.list
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y neo4j
  fi
  systemctl enable neo4j
  systemctl start neo4j || true
  echo "[note] Set Neo4j password manually with: cypher-shell -u neo4j -p neo4j"
fi

# Firewall baseline: preserve SSH/HTTP/HTTPS/Plesk. Do not expose Python API publicly by default.
ufw allow OpenSSH || true
ufw allow 80/tcp || true
ufw allow 443/tcp || true
ufw allow 8443/tcp || true
ufw --force enable || true
systemctl enable fail2ban || true
systemctl restart fail2ban || true

cat >"$SUITS_ROOT/server_health_check.py" <<'PY'
from pathlib import Path
import json, os
root=Path(os.environ.get('SUITS_ROOT','/opt/suitsmafia'))
site=Path(os.environ.get('SUITS_SITE_ROOT',str(root/'website')))
out=Path(os.environ.get('SUITS_OUTPUT_ROOT',str(root/'outputs')))
print(json.dumps({
  'root': str(root), 'site': str(site), 'outputs': str(out),
  'root_exists': root.exists(), 'site_exists': site.exists(), 'outputs_exists': out.exists()
}, indent=2))
PY
chown "$SUITS_USER:$SUITS_USER" "$SUITS_ROOT/server_health_check.py"

printf '[o][o] Server bootstrap complete.\n'
printf '[next] rotate initial root password, add SSH keys, then install processor package.\n'
printf '[check] sudo -u %s %s/venv/bin/python %s/server_health_check.py\n' "$SUITS_USER" "$SUITS_ROOT" "$SUITS_ROOT"
