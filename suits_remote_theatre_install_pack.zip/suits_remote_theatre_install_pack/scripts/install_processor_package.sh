#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   sudo ./install_processor_package.sh /path/to/suits_processor_v16_6_dramatic_movie_theatre_webui_package.zip

if [ "${EUID}" -ne 0 ]; then
  echo "[error] run as root" >&2
  exit 1
fi

PKG="${1:-}"
if [ -z "$PKG" ] || [ ! -f "$PKG" ]; then
  echo "[error] supply processor zip path" >&2
  exit 1
fi

. /etc/suitsmafia/suits.env
SUITS_USER="${SUITS_USER:-suits}"
WORK="/tmp/suits_processor_install_$$"
mkdir -p "$WORK"
unzip -o "$PKG" -d "$WORK"

# Find the first directory with an install script.
INSTALL_DIR="$(find "$WORK" -maxdepth 3 -type f -name 'install_v16_6.sh' -printf '%h\n' | head -1 || true)"
if [ -z "$INSTALL_DIR" ]; then
  INSTALL_DIR="$(find "$WORK" -maxdepth 2 -type d -name 'suits_processor_*' | head -1 || true)"
fi
if [ -z "$INSTALL_DIR" ]; then
  echo "[error] could not locate processor install directory" >&2
  exit 1
fi

mkdir -p "$SUITS_PROCESSOR_ROOT"
DEST="$SUITS_PROCESSOR_ROOT/$(basename "$INSTALL_DIR")"
rsync -a --delete "$INSTALL_DIR/" "$DEST/"
chown -R "$SUITS_USER:$SUITS_USER" "$DEST"
chmod +x "$DEST"/*.sh "$DEST"/scripts/*.sh "$DEST"/tools/*.py 2>/dev/null || true

# If the package has its own installer, run it as suits where possible.
if [ -x "$DEST/scripts/install_v16_6.sh" ]; then
  sudo -u "$SUITS_USER" bash -lc "cd '$DEST' && ./scripts/install_v16_6.sh"
elif [ -x "$DEST/run_v16_6_dramatic_movie_theatre.sh" ]; then
  true
fi

cat >/usr/local/bin/suits-v16-6-smoke <<'RUN'
#!/usr/bin/env bash
set -euo pipefail
. /etc/suitsmafia/suits.env
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_6_dramatic_movie_theatre \
  --smoke --limit-files 900 --ml-update --build-webui --build-graphs --build-charts --plan-movies --no-probe-media --progress-every 100
RUN
chmod +x /usr/local/bin/suits-v16-6-smoke

printf '[o][o] Processor package installed into %s\n' "$DEST"
printf '[next] run the installed launcher or adapt /usr/local/bin/suits-v16-6-smoke to server path.\n'
rm -rf "$WORK"
