#!/usr/bin/env python3
import argparse, csv, datetime as dt, hashlib, html, json, os, re, shutil, subprocess, sys
from pathlib import Path

VERSION = "v16.2.1"
SCHEMA = "suits_cinematic_song_story_v16_2_1"
DEFAULT_ROOT = Path('/home/andy/Documents/suitsmafia')
DEFAULT_AUDIO_DIR = DEFAULT_ROOT / 'audio'
DEFAULT_MUSIC_MP4_DIR = DEFAULT_ROOT / 'music_mp4'
DEFAULT_VIDEO_DIR = DEFAULT_ROOT / 'videos'
DEFAULT_OUTPUTS_DIR = DEFAULT_ROOT / 'outputs'
DEFAULT_OUT = DEFAULT_OUTPUTS_DIR / 'suits_processor_v16_2_1_cinematic_song_story'

AUDIO_EXTS = {'.mp3','.wav','.flac','.m4a','.aac','.opus','.ogg'}
VIDEO_EXTS = {'.mp4','.mkv','.webm','.mov','.m4v','.avi'}
IMAGE_EXTS = {'.png','.jpg','.jpeg','.webp','.gif','.apng'}

STORY_VARIANTS = [
 'predation_pressure','shot_fired','hit_confirmed','chase_escape','comedy_blunder','dark_aftermath',
 'hero_intro','vehicle_pressure','ambush_trap','route_prey','pack_pressure','lone_predator',
 'survival_by_luck','bad_timing','graphic_intensity_review','music_video_sync','no_repeat_story','finale_collapse'
]

TERM_WEIGHTS = {
 'shot':8,'shoot':7,'gun':6,'hit':8,'kill':10,'death':7,'blood':8,'gore':6,'graphic':6,'intensity':5,
 'funny':7,'comedy':7,'stupid':5,'dumb':5,'chaos':5,'blunder':8,
 'war':7,'mafia':7,'crips':7,'disciples':6,'suits':6,'fight':6,'battle':6,
 'chase':6,'pursuit':6,'vehicle':5,'car':4,'ambush':8,'trap':7,'predation':8,'prey':7,
 'dramatic':7,'team':5,'play':3,'route':4,'paint':2,'black':2,'hell':5,'bells':4,'thrill':6,'bad':3
}

TONE_BUCKETS = {
 'shot_fired':['shot','shoot','gun','thrill','trigger'],
 'hit_confirmed':['hit','blood','damage','impact'],
 'graphic_intensity_review':['gore','graphic','intensity','brutal','kill','death'],
 'comedy_blunder':['funny','comedy','stupid','dumb','blunder','worst'],
 'predation_pressure':['predation','prey','predator','pressure','mafia','war'],
 'chase_escape':['chase','pursuit','vehicle','car','route'],
 'dark_aftermath':['hell','bells','dark','death','fallout'],
 'hero_intro':['hero','intro','joins','official','trailer'],
}

def now(): return dt.datetime.now(dt.UTC).isoformat().replace('+00:00','Z')
def safe_slug(s):
    s = re.sub(r'\.[A-Za-z0-9]+$','',s)
    s = re.sub(r'[^A-Za-z0-9]+','_',s).strip('_').lower()
    return s[:96] or 'asset'
def sha_path(p): return hashlib.sha1(str(p).encode('utf-8','ignore')).hexdigest()[:12]
def ffprobe_duration(path):
    if not shutil.which('ffprobe'):
        return None
    cmd = ['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, timeout=12).decode().strip()
        return float(out) if out else None
    except Exception:
        return None

def asset_score(name):
    s = name.lower()
    score = 0
    hits = []
    for term,w in TERM_WEIGHTS.items():
        if term in s:
            score += w
            hits.append(term)
    return score, hits

def tone_scores(name):
    s = name.lower()
    out = {}
    for tone, terms in TONE_BUCKETS.items():
        out[tone] = sum(1 for t in terms if t in s)
    return out

def scan_assets(dirs, exts, limit=0):
    rows=[]
    seen=set()
    for d in dirs:
        d=Path(d)
        if not d.exists():
            continue
        for p in d.rglob('*'):
            if not p.is_file():
                continue
            if p.suffix.lower() not in exts:
                continue
            if str(p) in seen:
                continue
            seen.add(str(p))
            score, hits = asset_score(p.name + ' ' + str(p.parent))
            rows.append({
                'asset_id': sha_path(p), 'path': str(p), 'name': p.name, 'slug': safe_slug(p.name),
                'ext': p.suffix.lower(), 'size_bytes': p.stat().st_size, 'duration_s': ffprobe_duration(p),
                'term_score': score, 'term_hits': '|'.join(hits), 'tone_scores': tone_scores(p.name + ' ' + str(p.parent)),
                'mtime_utc': dt.datetime.fromtimestamp(p.stat().st_mtime, dt.UTC).isoformat().replace('+00:00','Z')
            })
            if limit and len(rows) >= limit:
                return rows
    return rows

def score_pair(song, video):
    st = song['tone_scores']; vt = video['tone_scores']
    tone_overlap = sum(min(st.get(k,0), vt.get(k,0)) for k in set(st)|set(vt))
    name_score = song['term_score']*0.25 + video['term_score']*0.75
    dur_bonus = 0
    sd = song.get('duration_s') or 0
    vd = video.get('duration_s') or 0
    if sd and vd:
        if vd >= 29: dur_bonus += 4
        if vd >= min(sd, 180): dur_bonus += 6
    return round(tone_overlap*10 + name_score + dur_bonus, 3)

def choose_variant(song, video, rank):
    ts = video['tone_scores']
    preferred = sorted(ts.items(), key=lambda kv: kv[1], reverse=True)
    for k,v in preferred:
        if v>0 and k in STORY_VARIANTS:
            return k
    return STORY_VARIANTS[(rank-1) % len(STORY_VARIANTS)]

def write_csv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not fields:
        fields = list(rows[0].keys()) if rows else []
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader(); w.writerows(rows)

def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')

def build_render_jobs(outdir, plan, full=False):
    script = outdir / ('render_jobs_full_song.sh' if full else 'render_jobs_29s.sh')
    render_dir = outdir / ('renders_full_song' if full else 'renders_29s')
    lines = ['#!/usr/bin/env bash','set -euo pipefail',f'mkdir -p "{render_dir}"','']
    for row in plan:
        if full and row['story_rank'] != 1:
            continue
        if (not full) and row['story_rank'] > 3:
            continue
        song = row['song_path']; video = row['video_path']; slug = row['render_slug']
        dur = row['song_duration_s'] if full and row.get('song_duration_s') else 29
        dur = max(5, min(float(dur or 29), 900 if full else 29))
        out = render_dir / f"{slug}_{'full' if full else '29s'}.mp4"
        lines.append(f'echo "[o][o] rendering {slug}"')
        lines.append('ffmpeg -y -hide_banner -loglevel warning \\\n  -stream_loop -1 -i '+json.dumps(video)+' \\\n  -i '+json.dumps(song)+' \\\n  -t '+str(round(dur,3))+' \\\n  -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1" \\\n  -map 0:v:0 -map 1:a:0 -shortest -c:v libx264 -preset veryfast -crf 23 -c:a aac -b:a 192k '+json.dumps(str(out)))
        lines.append('')
    script.write_text('\n'.join(lines), encoding='utf-8')
    script.chmod(0o755)


def report_html(outdir, songs, videos, matches):
    top = matches[:200]
    rows = []
    for m in top:
        rows.append('<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>'.format(
            html.escape(str(m['match_score'])), html.escape(m['story_variant']), html.escape(m['song_name']), html.escape(m['video_name']), html.escape(m['suggested_use'])
        ))
    html_text = f"""<!doctype html><html><head><meta charset='utf-8'><title>$uits v16.2.1 Cinematic Song Story</title>
<style>body{{background:#07111f;color:#e8f4ff;font-family:Arial,sans-serif}}.wrap{{max-width:1300px;margin:30px auto}}h1{{color:#9dd7ff}}.card{{background:#0d1b2f;border:1px solid #284766;border-radius:16px;padding:18px;margin:14px 0}}table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid #20364f;padding:8px;text-align:left}}th{{color:#9dd7ff}}</style></head><body><div class='wrap'>
<h1>[o][o] $uits Processor v16.2.1 — Cinematic Song Story</h1>
<div class='card'><b>Songs:</b> {len(songs)} &nbsp; <b>Videos:</b> {len(videos)} &nbsp; <b>Matches:</b> {len(matches)}</div>
<div class='card'><h2>Top song/video story matches</h2><table><tr><th>Score</th><th>Story</th><th>Song</th><th>Video</th><th>Use</th></tr>{''.join(rows)}</table></div>
</div></body></html>"""
    (outdir/'cinematic_song_story_report.html').write_text(html_text, encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(description='$uits v16.2.1 cinematic song story planner')
    ap.add_argument('--root', default=str(DEFAULT_ROOT))
    ap.add_argument('--audio-dir', action='append', default=[])
    ap.add_argument('--music-mp4-dir', action='append', default=[])
    ap.add_argument('--video-dir', action='append', default=[])
    ap.add_argument('--previous-out-dir', action='append', default=[])
    ap.add_argument('--out', default=str(DEFAULT_OUT))
    ap.add_argument('--limit-songs', type=int, default=0)
    ap.add_argument('--limit-videos', type=int, default=0)
    ap.add_argument('--top-videos-per-song', type=int, default=18)
    ap.add_argument('--make-render-jobs', action='store_true')
    ap.add_argument('--smoke', action='store_true')
    args=ap.parse_args()
    root=Path(args.root); outdir=Path(args.out); outdir.mkdir(parents=True, exist_ok=True)
    audio_dirs = [Path(x) for x in args.audio_dir] or [root/'audio']
    music_dirs = [Path(x) for x in args.music_mp4_dir] or [root/'music_mp4', root/'videos'/'youtube_music']
    video_dirs = [Path(x) for x in args.video_dir] or [root/'videos']
    if args.smoke:
        args.limit_songs = args.limit_songs or 12
        args.limit_videos = args.limit_videos or 40
        args.top_videos_per_song = min(args.top_videos_per_song, 6)
    print(f"[o][o] $uits Processor {VERSION}")
    print(f"SCRIPT=suits_cinematic_song_story_v16_2_1.py")
    print(f"SCHEMA={SCHEMA}")
    print(f"OUT={outdir}")
    songs = scan_assets(audio_dirs + music_dirs, AUDIO_EXTS | VIDEO_EXTS, args.limit_songs)
    # Mark videos from music dirs as music candidates too; use all video sources separately.
    videos = scan_assets(video_dirs, VIDEO_EXTS, args.limit_videos)
    matches=[]; plan=[]
    for song in songs:
        ranked=[]
        for video in videos:
            if song['path'] == video['path']:
                continue
            ranked.append((score_pair(song,video), video))
        ranked.sort(key=lambda x:x[0], reverse=True)
        for i,(score,video) in enumerate(ranked[:args.top_videos_per_song],1):
            variant = choose_variant(song, video, i)
            use = 'full_song_story' if i==1 else ('29s_trailer' if i<=3 else 'alternate_story_variant')
            row = {
                'song_id':song['asset_id'], 'song_name':song['name'], 'song_path':song['path'], 'song_duration_s':song.get('duration_s'),
                'video_id':video['asset_id'], 'video_name':video['name'], 'video_path':video['path'], 'video_duration_s':video.get('duration_s'),
                'story_rank':i, 'story_variant':variant, 'match_score':score, 'suggested_use':use,
                'render_slug':safe_slug(song['name'])[:42]+'__'+safe_slug(variant)+'__'+str(i).zfill(2)
            }
            matches.append(row); plan.append(row)
    matches.sort(key=lambda r:(r['song_name'], r['story_rank']))
    write_csv(outdir/'music_profile.csv', songs, ['asset_id','path','name','slug','ext','size_bytes','duration_s','term_score','term_hits','mtime_utc'])
    write_json(outdir/'music_profile.json', songs)
    write_csv(outdir/'video_profile.csv', videos, ['asset_id','path','name','slug','ext','size_bytes','duration_s','term_score','term_hits','mtime_utc'])
    write_json(outdir/'video_profile.json', videos)
    fields=['song_id','song_name','song_path','song_duration_s','video_id','video_name','video_path','video_duration_s','story_rank','story_variant','match_score','suggested_use','render_slug']
    write_csv(outdir/'song_video_match_plan.csv', matches, fields)
    write_json(outdir/'song_video_match_plan.json', matches)
    write_csv(outdir/'song_story_plan.csv', plan, fields)
    write_json(outdir/'song_story_plan.json', plan)
    write_json(outdir/'webui_song_story_index.json', {'schema':SCHEMA,'version':VERSION,'created_utc':now(),'songs':songs,'videos':videos,'matches':matches[:1000]})
    if args.make_render_jobs:
        build_render_jobs(outdir, plan, full=False)
        build_render_jobs(outdir, plan, full=True)
    else:
        # still write scripts with comments
        (outdir/'render_jobs_29s.sh').write_text('#!/usr/bin/env bash\necho "rerun with --make-render-jobs to generate ffmpeg jobs"\n', encoding='utf-8'); (outdir/'render_jobs_29s.sh').chmod(0o755)
        (outdir/'render_jobs_full_song.sh').write_text('#!/usr/bin/env bash\necho "rerun with --make-render-jobs to generate ffmpeg jobs"\n', encoding='utf-8'); (outdir/'render_jobs_full_song.sh').chmod(0o755)
    report_html(outdir, songs, videos, matches)
    print(f"[o][o] songs={len(songs)} videos={len(videos)} matches={len(matches)}")
    print(f"[o][o] report={outdir/'cinematic_song_story_report.html'}")

if __name__ == '__main__':
    main()
