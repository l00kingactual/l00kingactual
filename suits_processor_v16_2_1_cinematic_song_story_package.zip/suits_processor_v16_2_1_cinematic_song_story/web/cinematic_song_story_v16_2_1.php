<?php
$dataPath = __DIR__ . '/data/cinematic_song_story_v16_2_1/webui_song_story_index.json';
$altPath = '/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_2_1_cinematic_song_story/webui_song_story_index.json';
if (!file_exists($dataPath) && file_exists($altPath)) { $dataPath = $altPath; }
$data = file_exists($dataPath) ? json_decode(file_get_contents($dataPath), true) : null;
$matches = $data['matches'] ?? [];
$q = strtolower($_GET['q'] ?? '');
$story = strtolower($_GET['story'] ?? '');
$rows = [];
foreach ($matches as $m) {
  $hay = strtolower(($m['song_name'] ?? '').' '.($m['video_name'] ?? '').' '.($m['story_variant'] ?? ''));
  if ($q && strpos($hay,$q) === false) continue;
  if ($story && strtolower($m['story_variant'] ?? '') !== $story) continue;
  $rows[] = $m;
  if (count($rows) >= 300) break;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>$uits Cinematic Song Story v16.2.1</title><link rel="stylesheet" href="css/suits_cinematic_story_v16_2_1.css"></head>
<body><main><h1>[o][o] $uits Cinematic Song Story v16.2.1</h1>
<form class="bar"><input name="q" value="<?=htmlspecialchars($q)?>" placeholder="song, video, story..."><select name="story"><option value="">all stories</option><?php foreach(['predation_pressure','shot_fired','hit_confirmed','chase_escape','comedy_blunder','dark_aftermath','hero_intro','vehicle_pressure','ambush_trap','route_prey','pack_pressure','lone_predator','survival_by_luck','bad_timing','graphic_intensity_review','music_video_sync','no_repeat_story','finale_collapse'] as $s){$sel=$story===$s?'selected':''; echo "<option $sel value=\"$s\">$s</option>";} ?></select><button>Search</button></form>
<section class="grid"><?php foreach($rows as $m): ?><article class="card"><b><?=htmlspecialchars($m['song_name'] ?? '')?></b><small><?=htmlspecialchars($m['story_variant'] ?? '')?> · score <?=htmlspecialchars($m['match_score'] ?? '')?></small><p><?=htmlspecialchars($m['video_name'] ?? '')?></p><code><?=htmlspecialchars($m['suggested_use'] ?? '')?></code></article><?php endforeach; ?></section>
<?php if(!$data): ?><p class="warn">No WebUI index found yet. Run the processor, then copy/symlink webui_song_story_index.json into site data, or leave it in the default outputs folder.</p><?php endif; ?>
</main></body></html>
