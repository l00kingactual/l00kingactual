# Cinematic Song Story Strategy

v16.2.1 reads the media library as a directing surface:

- audio and music video assets are tone sources
- `/videos` and previous rendered outputs are scene sources
- shot/hit/kill/graphic-intensity/comedy/predation terms become story labels
- each song receives one full-song plan, three 29-second trailer priorities, and up to 18 alternate cinematic story variants

The package writes render jobs rather than immediately creating every MP4 so the editor can inspect and avoid huge accidental renders.
