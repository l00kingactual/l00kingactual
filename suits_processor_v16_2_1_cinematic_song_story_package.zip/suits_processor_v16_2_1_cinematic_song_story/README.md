# $uits Processor v16.2.1 — Cinematic Song Story Planner

Profiles `/home/andy/Documents/suitsmafia/audio`, `/home/andy/Documents/suitsmafia/music_mp4`, and `/home/andy/Documents/suitsmafia/videos`, then builds full-song and 29-second cinematic story plans from the existing generated media, v8/v9/v13/v16 outputs, and shot/kill/graphic-intensity/comedy/predation vocabulary.

This package is intentionally a **planner and render-job generator** first. It does not automatically render thousands of movies until you review the plan and run the generated render scripts.

## Install

```bash
cd /home/andy/Downloads
unzip -o /mnt/data/suits_processor_v16_2_1_cinematic_song_story_package.zip
cd suits_processor_v16_2_1_cinematic_song_story
chmod +x *.sh scripts/*.sh tools/*.py
```

## Run

Smoke test:

```bash
./run_v16_2_1_plan_song_movies_smoke.sh
```

Full planning run:

```bash
./run_v16_2_1_plan_song_movies.sh
```

## Outputs

Default output folder:

```text
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_2_1_cinematic_song_story
```

Files:

```text
music_profile.csv/json
video_profile.csv/json
song_video_match_plan.csv/json
song_story_plan.csv/json
render_jobs_29s.sh
render_jobs_full_song.sh
cinematic_song_story_report.html
webui_song_story_index.json
```

## Optional render

After reviewing the report:

```bash
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_2_1_cinematic_song_story/render_jobs_29s.sh
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_2_1_cinematic_song_story/render_jobs_full_song.sh
```

## WebUI

```bash
SITE=/home/andy/Documents/suitsmafia/susitsmafia_website
rsync -av web/ "$SITE/"
rsync -av api/ "$SITE/api/"
rsync -av css/ "$SITE/css/"
```

Open:

```text
http://127.0.0.1:8081/cinematic_song_story_v16_2_1.php
```
