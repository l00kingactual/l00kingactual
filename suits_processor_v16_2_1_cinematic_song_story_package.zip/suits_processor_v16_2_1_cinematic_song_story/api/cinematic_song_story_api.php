<?php
header('Content-Type: application/json');
$p = '/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_2_1_cinematic_song_story/webui_song_story_index.json';
if (!file_exists($p)) { echo json_encode(['ok'=>false,'error'=>'webui_song_story_index.json not found']); exit; }
echo file_get_contents($p);
