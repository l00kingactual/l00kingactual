#!/usr/bin/env bash
set -euo pipefail
python3 tools/suits_cinematic_song_story_v16_2_1.py \
  --root /home/andy/Documents/suitsmafia \
  --audio-dir /home/andy/Documents/suitsmafia/audio \
  --music-mp4-dir /home/andy/Documents/suitsmafia/music_mp4 \
  --music-mp4-dir /home/andy/Documents/suitsmafia/videos/youtube_music \
  --video-dir /home/andy/Documents/suitsmafia/videos \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs \
  --out /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_2_1_cinematic_song_story_smoke \
  --smoke \
  --make-render-jobs
