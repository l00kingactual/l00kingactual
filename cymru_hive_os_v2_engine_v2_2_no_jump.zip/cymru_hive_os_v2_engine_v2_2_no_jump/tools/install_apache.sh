#!/usr/bin/env bash
set -euo pipefail
TARGET="/var/www/html"
sudo rsync -av --delete "$(dirname "$0")/../" "$TARGET/"
sudo chown -R www-data:www-data "$TARGET"
echo "Open: http://localhost/"
