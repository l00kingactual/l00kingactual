-- Cymru Hive OS v2 3NF seed schema
CREATE TABLE hive (
  hive_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  place_scale TEXT NOT NULL,
  gps_lat REAL,
  gps_lon REAL,
  osgb_easting INTEGER,
  osgb_northing INTEGER,
  map_x_percent REAL,
  map_y_percent REAL,
  capacity INTEGER,
  risk INTEGER,
  notes TEXT
);
CREATE TABLE service (service_id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT);
CREATE TABLE hive_service (hive_id TEXT REFERENCES hive(hive_id), service_id TEXT REFERENCES service(service_id), PRIMARY KEY(hive_id, service_id));
CREATE TABLE bee (bee_id TEXT PRIMARY KEY, age_stage TEXT, home_scale TEXT, current_hive_id TEXT REFERENCES hive(hive_id), role_id TEXT);
CREATE TABLE metric_key (metric_group TEXT, metric_key TEXT, PRIMARY KEY(metric_group, metric_key));
CREATE TABLE bee_metric (bee_id TEXT REFERENCES bee(bee_id), metric_group TEXT, metric_key TEXT, value REAL, PRIMARY KEY(bee_id, metric_group, metric_key));
CREATE TABLE auto_tune (tune_id TEXT PRIMARY KEY, tune_index INTEGER, age TEXT, name TEXT, age_stage TEXT, home_scale TEXT, description TEXT);
CREATE TABLE auto_tune_delta (tune_id TEXT REFERENCES auto_tune(tune_id), metric_group TEXT, metric_key TEXT, delta REAL, PRIMARY KEY(tune_id, metric_group, metric_key));
CREATE TABLE bee_event (event_id INTEGER PRIMARY KEY AUTOINCREMENT, bee_id TEXT, event_time TEXT, event_type TEXT, hive_id TEXT, tune_id TEXT, payload_json TEXT);
