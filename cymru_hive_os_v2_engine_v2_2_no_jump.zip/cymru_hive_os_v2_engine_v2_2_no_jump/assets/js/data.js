window.CYMRU_HIVE_DATA = {
  "hives": [
    {
      "id": "holyhead",
      "name": "Holyhead",
      "map": {
        "xPercent": 26,
        "yPercent": 10
      },
      "type": "transport",
      "icon": "🚆",
      "placeScale": "town",
      "gps": {
        "lat": 53.3103,
        "lon": -4.633
      },
      "osgb36": {
        "easting": 224678,
        "northing": 382496,
        "crs": "EPSG:27700"
      },
      "services": [
        "train",
        "bus",
        "taxi"
      ],
      "nectarTags": [
        "transport",
        "enterprise"
      ],
      "capacity": 64,
      "risk": 22,
      "notes": "Holyhead seed hive node for Cymru Hive OS."
    },
    {
      "id": "bangor",
      "name": "Bangor",
      "map": {
        "xPercent": 44,
        "yPercent": 13
      },
      "type": "education",
      "icon": "🎓",
      "placeScale": "city",
      "gps": {
        "lat": 53.2274,
        "lon": -4.1293
      },
      "osgb36": {
        "easting": 257956,
        "northing": 372156,
        "crs": "EPSG:27700"
      },
      "services": [
        "university",
        "library",
        "train",
        "bus",
        "hospital"
      ],
      "nectarTags": [
        "education",
        "learning",
        "astronomy"
      ],
      "capacity": 86,
      "risk": 16,
      "notes": "Bangor seed hive node for Cymru Hive OS."
    },
    {
      "id": "caernarfon",
      "name": "Caernarfon",
      "map": {
        "xPercent": 43,
        "yPercent": 17
      },
      "type": "culture",
      "icon": "🏰",
      "placeScale": "town",
      "gps": {
        "lat": 53.1396,
        "lon": -4.2769
      },
      "osgb36": {
        "easting": 247794,
        "northing": 362694,
        "crs": "EPSG:27700"
      },
      "services": [
        "school",
        "library",
        "bus",
        "park"
      ],
      "nectarTags": [
        "education",
        "learning",
        "civicPride"
      ],
      "capacity": 70,
      "risk": 18,
      "notes": "Caernarfon seed hive node for Cymru Hive OS."
    },
    {
      "id": "colwyn-bay",
      "name": "Colwyn Bay",
      "map": {
        "xPercent": 58,
        "yPercent": 10
      },
      "type": "health",
      "icon": "🩺",
      "placeScale": "town",
      "gps": {
        "lat": 53.2948,
        "lon": -3.7267
      },
      "osgb36": {
        "easting": 285010,
        "northing": 378929,
        "crs": "EPSG:27700"
      },
      "services": [
        "GP",
        "hospital",
        "bus",
        "sportsField"
      ],
      "nectarTags": [
        "health",
        "sport"
      ],
      "capacity": 72,
      "risk": 18,
      "notes": "Colwyn Bay seed hive node for Cymru Hive OS."
    },
    {
      "id": "rhyl",
      "name": "Rhyl",
      "map": {
        "xPercent": 70,
        "yPercent": 9
      },
      "type": "sport",
      "icon": "🏃",
      "placeScale": "town",
      "gps": {
        "lat": 53.3191,
        "lon": -3.4916
      },
      "osgb36": {
        "easting": 300735,
        "northing": 381279,
        "crs": "EPSG:27700"
      },
      "services": [
        "sportsField",
        "park",
        "train",
        "GP"
      ],
      "nectarTags": [
        "sport",
        "health"
      ],
      "capacity": 68,
      "risk": 26,
      "notes": "Rhyl seed hive node for Cymru Hive OS."
    },
    {
      "id": "wrexham",
      "name": "Wrexham",
      "map": {
        "xPercent": 85,
        "yPercent": 20
      },
      "type": "enterprise",
      "icon": "💼",
      "placeScale": "city",
      "gps": {
        "lat": 53.0465,
        "lon": -2.9925
      },
      "osgb36": {
        "easting": 333561,
        "northing": 350376,
        "crs": "EPSG:27700"
      },
      "services": [
        "college",
        "library",
        "hospital",
        "train",
        "bus",
        "sportsField"
      ],
      "nectarTags": [
        "enterprise",
        "education",
        "sport"
      ],
      "capacity": 90,
      "risk": 18,
      "notes": "Wrexham seed hive node for Cymru Hive OS."
    },
    {
      "id": "harlech",
      "name": "Harlech",
      "map": {
        "xPercent": 46,
        "yPercent": 26
      },
      "type": "adventure",
      "icon": "🏔️",
      "placeScale": "village",
      "gps": {
        "lat": 52.8604,
        "lon": -4.109
      },
      "osgb36": {
        "easting": 258110,
        "northing": 331297,
        "crs": "EPSG:27700"
      },
      "services": [
        "park",
        "bus",
        "school"
      ],
      "nectarTags": [
        "sport",
        "ecology",
        "astronomy"
      ],
      "capacity": 58,
      "risk": 30,
      "notes": "Harlech seed hive node for Cymru Hive OS."
    },
    {
      "id": "welshpool",
      "name": "Welshpool",
      "map": {
        "xPercent": 75,
        "yPercent": 39
      },
      "type": "transport",
      "icon": "🚌",
      "placeScale": "town",
      "gps": {
        "lat": 52.6597,
        "lon": -3.147
      },
      "osgb36": {
        "easting": 322517,
        "northing": 307504,
        "crs": "EPSG:27700"
      },
      "services": [
        "bus",
        "train",
        "school",
        "GP"
      ],
      "nectarTags": [
        "transport",
        "learning"
      ],
      "capacity": 60,
      "risk": 22,
      "notes": "Welshpool seed hive node for Cymru Hive OS."
    },
    {
      "id": "aberystwyth",
      "name": "Aberystwyth",
      "map": {
        "xPercent": 51,
        "yPercent": 50
      },
      "type": "astronomy",
      "icon": "🔭",
      "placeScale": "town",
      "gps": {
        "lat": 52.4153,
        "lon": -4.0829
      },
      "osgb36": {
        "easting": 258436,
        "northing": 281742,
        "crs": "EPSG:27700"
      },
      "services": [
        "university",
        "library",
        "train",
        "bus",
        "sportsField"
      ],
      "nectarTags": [
        "astronomy",
        "education",
        "ecology"
      ],
      "capacity": 84,
      "risk": 18,
      "notes": "Aberystwyth seed hive node for Cymru Hive OS."
    },
    {
      "id": "cardigan",
      "name": "Cardigan",
      "map": {
        "xPercent": 31,
        "yPercent": 65
      },
      "type": "ecology",
      "icon": "🐝",
      "placeScale": "town",
      "gps": {
        "lat": 52.0837,
        "lon": -4.6592
      },
      "osgb36": {
        "easting": 217893,
        "northing": 246154,
        "crs": "EPSG:27700"
      },
      "services": [
        "school",
        "library",
        "park",
        "bus"
      ],
      "nectarTags": [
        "ecology",
        "food",
        "learning"
      ],
      "capacity": 62,
      "risk": 24,
      "notes": "Cardigan seed hive node for Cymru Hive OS."
    },
    {
      "id": "llandrindod-wells",
      "name": "Llandrindod Wells",
      "map": {
        "xPercent": 70,
        "yPercent": 58
      },
      "type": "health",
      "icon": "🏥",
      "placeScale": "town",
      "gps": {
        "lat": 52.2419,
        "lon": -3.3787
      },
      "osgb36": {
        "easting": 305959,
        "northing": 261308,
        "crs": "EPSG:27700"
      },
      "services": [
        "hospital",
        "GP",
        "bus",
        "train",
        "park"
      ],
      "nectarTags": [
        "health",
        "learning"
      ],
      "capacity": 66,
      "risk": 20,
      "notes": "Llandrindod Wells seed hive node for Cymru Hive OS."
    },
    {
      "id": "brecon",
      "name": "Brecon",
      "map": {
        "xPercent": 72,
        "yPercent": 71
      },
      "type": "astronomy",
      "icon": "🌌",
      "placeScale": "town",
      "gps": {
        "lat": 51.947,
        "lon": -3.391
      },
      "osgb36": {
        "easting": 304491,
        "northing": 228526,
        "crs": "EPSG:27700"
      },
      "services": [
        "school",
        "library",
        "bus",
        "park"
      ],
      "nectarTags": [
        "astronomy",
        "ecology",
        "sport"
      ],
      "capacity": 71,
      "risk": 22,
      "notes": "Brecon seed hive node for Cymru Hive OS."
    },
    {
      "id": "carmarthen",
      "name": "Carmarthen",
      "map": {
        "xPercent": 36,
        "yPercent": 76
      },
      "type": "education",
      "icon": "🏫",
      "placeScale": "town",
      "gps": {
        "lat": 51.8576,
        "lon": -4.3121
      },
      "osgb36": {
        "easting": 240872,
        "northing": 220196,
        "crs": "EPSG:27700"
      },
      "services": [
        "school",
        "college",
        "library",
        "hospital",
        "train"
      ],
      "nectarTags": [
        "education",
        "learning",
        "health"
      ],
      "capacity": 82,
      "risk": 18,
      "notes": "Carmarthen seed hive node for Cymru Hive OS."
    },
    {
      "id": "llanelli",
      "name": "Llanelli",
      "map": {
        "xPercent": 44,
        "yPercent": 84
      },
      "type": "sport",
      "icon": "⚽",
      "placeScale": "town",
      "gps": {
        "lat": 51.6809,
        "lon": -4.1602
      },
      "osgb36": {
        "easting": 250749,
        "northing": 200225,
        "crs": "EPSG:27700"
      },
      "services": [
        "sportsField",
        "park",
        "train",
        "GP"
      ],
      "nectarTags": [
        "sport",
        "health",
        "enterprise"
      ],
      "capacity": 72,
      "risk": 23,
      "notes": "Llanelli seed hive node for Cymru Hive OS."
    },
    {
      "id": "swansea",
      "name": "Swansea",
      "map": {
        "xPercent": 51,
        "yPercent": 86
      },
      "type": "enterprise",
      "icon": "⚙️",
      "placeScale": "city",
      "gps": {
        "lat": 51.6214,
        "lon": -3.9436
      },
      "osgb36": {
        "easting": 265547,
        "northing": 193187,
        "crs": "EPSG:27700"
      },
      "services": [
        "university",
        "college",
        "hospital",
        "train",
        "library",
        "sportsField"
      ],
      "nectarTags": [
        "enterprise",
        "education",
        "learning",
        "health"
      ],
      "capacity": 94,
      "risk": 17,
      "notes": "Swansea seed hive node for Cymru Hive OS."
    },
    {
      "id": "merthyr-tydfil",
      "name": "Merthyr Tydfil",
      "map": {
        "xPercent": 73,
        "yPercent": 78
      },
      "type": "health",
      "icon": "🚑",
      "placeScale": "town",
      "gps": {
        "lat": 51.7487,
        "lon": -3.3816
      },
      "osgb36": {
        "easting": 304718,
        "northing": 206459,
        "crs": "EPSG:27700"
      },
      "services": [
        "hospital",
        "GP",
        "bus",
        "sportsField",
        "park"
      ],
      "nectarTags": [
        "health",
        "sport",
        "service"
      ],
      "capacity": 67,
      "risk": 25,
      "notes": "Merthyr Tydfil seed hive node for Cymru Hive OS."
    },
    {
      "id": "cardiff",
      "name": "Cardiff",
      "map": {
        "xPercent": 74,
        "yPercent": 93
      },
      "type": "city",
      "icon": "🏙️",
      "placeScale": "city",
      "gps": {
        "lat": 51.4816,
        "lon": -3.1791
      },
      "osgb36": {
        "easting": 318218,
        "northing": 176509,
        "crs": "EPSG:27700"
      },
      "services": [
        "university",
        "college",
        "hospital",
        "train",
        "bus",
        "library",
        "sportsField",
        "park",
        "zoo"
      ],
      "nectarTags": [
        "education",
        "enterprise",
        "health",
        "sport"
      ],
      "capacity": 100,
      "risk": 15,
      "notes": "Cardiff seed hive node for Cymru Hive OS."
    },
    {
      "id": "newport",
      "name": "Newport",
      "map": {
        "xPercent": 82,
        "yPercent": 88
      },
      "type": "transport",
      "icon": "🚆",
      "placeScale": "city",
      "gps": {
        "lat": 51.5842,
        "lon": -2.9977
      },
      "osgb36": {
        "easting": 330970,
        "northing": 187732,
        "crs": "EPSG:27700"
      },
      "services": [
        "train",
        "bus",
        "college",
        "hospital",
        "library"
      ],
      "nectarTags": [
        "transport",
        "enterprise",
        "learning"
      ],
      "capacity": 84,
      "risk": 18,
      "notes": "Newport seed hive node for Cymru Hive OS."
    },
    {
      "id": "monmouth",
      "name": "Monmouth",
      "map": {
        "xPercent": 90,
        "yPercent": 78
      },
      "type": "ecology",
      "icon": "🌳",
      "placeScale": "town",
      "gps": {
        "lat": 51.8126,
        "lon": -2.7136
      },
      "osgb36": {
        "easting": 350902,
        "northing": 212904,
        "crs": "EPSG:27700"
      },
      "services": [
        "school",
        "library",
        "park",
        "bus"
      ],
      "nectarTags": [
        "ecology",
        "learning",
        "civicPride"
      ],
      "capacity": 60,
      "risk": 19,
      "notes": "Monmouth seed hive node for Cymru Hive OS."
    },
    {
      "id": "st-davids",
      "name": "St David’s",
      "map": {
        "xPercent": 11,
        "yPercent": 75
      },
      "type": "astronomy",
      "icon": "✨",
      "placeScale": "village",
      "gps": {
        "lat": 51.882,
        "lon": -5.269
      },
      "osgb36": {
        "easting": 175111,
        "northing": 225435,
        "crs": "EPSG:27700"
      },
      "services": [
        "school",
        "bus",
        "park"
      ],
      "nectarTags": [
        "astronomy",
        "ecology",
        "civicPride"
      ],
      "capacity": 56,
      "risk": 27,
      "notes": "St David’s seed hive node for Cymru Hive OS."
    },
    {
      "id": "milford-haven",
      "name": "Milford Haven",
      "map": {
        "xPercent": 15,
        "yPercent": 82
      },
      "type": "transport",
      "icon": "⚓",
      "placeScale": "town",
      "gps": {
        "lat": 51.714,
        "lon": -5.0341
      },
      "osgb36": {
        "easting": 190496,
        "northing": 206055,
        "crs": "EPSG:27700"
      },
      "services": [
        "bus",
        "train",
        "school",
        "GP"
      ],
      "nectarTags": [
        "transport",
        "enterprise",
        "ecology"
      ],
      "capacity": 63,
      "risk": 23,
      "notes": "Milford Haven seed hive node for Cymru Hive OS."
    }
  ],
  "conceptualHives": [
    {
      "id": "household-cell",
      "name": "Household Cell",
      "placeScale": "household",
      "type": "home",
      "icon": "🏠",
      "services": [
        "familyCare",
        "sleep",
        "food"
      ],
      "nectarTags": [
        "health",
        "learning",
        "care"
      ]
    },
    {
      "id": "hamlet-cell",
      "name": "Hamlet Cell",
      "placeScale": "hamlet",
      "type": "community",
      "icon": "🏡",
      "services": [
        "neighbourCare",
        "taxi",
        "localPark"
      ],
      "nectarTags": [
        "service",
        "ecology",
        "confidence"
      ]
    }
  ],
  "autoTunes": [
    {
      "id": "tune-01",
      "index": 1,
      "emoji": "🌙",
      "name": "Moon Wonder",
      "age": 5,
      "ageStage": "Little Bee",
      "homeScale": "household",
      "activeHiveTypes": [
        "astronomy",
        "education"
      ],
      "description": "Start from wonder: Moon diary, safe looking, drawing and family sky language.",
      "nectarDelta": {
        "education": 4,
        "sport": 0,
        "health": 2,
        "learning": 5,
        "enterprise": 0,
        "ecology": 0,
        "astronomy": 9
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 8,
        "discipline": 0,
        "care": 2,
        "skill": 0,
        "confidence": 3,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 8,
        "hamlet": 0,
        "village": 2,
        "town": 0,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 2,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 3,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 4,
        "knowledge": 5,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 2
      }
    },
    {
      "id": "tune-02",
      "index": 2,
      "emoji": "🌑",
      "name": "Safe Darkness",
      "age": 5,
      "ageStage": "Little Bee",
      "homeScale": "household",
      "activeHiveTypes": [
        "astronomy",
        "health"
      ],
      "description": "Darkness is habitat and safety practice, not fear.",
      "nectarDelta": {
        "education": 0,
        "sport": 0,
        "health": 4,
        "learning": 3,
        "enterprise": 0,
        "ecology": 3,
        "astronomy": 7
      },
      "traitDelta": {
        "courage": 4,
        "curiosity": 5,
        "discipline": 0,
        "care": 4,
        "skill": 0,
        "confidence": 0,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 7,
        "hamlet": 0,
        "village": 3,
        "town": 0,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 2,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 1,
        "hospital": 0,
        "sportsField": 0,
        "park": 4,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 6,
        "knowledge": 3,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 2,
        "civicPride": 0
      }
    },
    {
      "id": "tune-03",
      "index": 3,
      "emoji": "☀️",
      "name": "Sun and Shadow Clock",
      "age": 6,
      "ageStage": "Little Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "education",
        "sport"
      ],
      "description": "Use shadows, play and outdoor observation to understand time.",
      "nectarDelta": {
        "education": 5,
        "sport": 3,
        "health": 0,
        "learning": 5,
        "enterprise": 0,
        "ecology": 0,
        "astronomy": 5
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 6,
        "discipline": 2,
        "care": 0,
        "skill": 3,
        "confidence": 0,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 4,
        "hamlet": 0,
        "village": 5,
        "town": 0,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 5,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 4,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 3,
        "knowledge": 5,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 2
      }
    },
    {
      "id": "tune-04",
      "index": 4,
      "emoji": "🌳",
      "name": "Park Play and Nature",
      "age": 6,
      "ageStage": "Little Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "sport",
        "ecology"
      ],
      "description": "Parks become first ecology and physical-literacy combs.",
      "nectarDelta": {
        "education": 0,
        "sport": 6,
        "health": 5,
        "learning": 2,
        "enterprise": 0,
        "ecology": 4,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 4,
        "curiosity": 0,
        "discipline": 0,
        "care": 3,
        "skill": 0,
        "confidence": 5,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 6,
        "town": 1,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 2,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 0,
        "hospital": 0,
        "sportsField": 4,
        "park": 7,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 7,
        "knowledge": 0,
        "sport": 5,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 2,
        "civicPride": 0
      }
    },
    {
      "id": "tune-05",
      "index": 5,
      "emoji": "⭐",
      "name": "Story Constellations",
      "age": 7,
      "ageStage": "Little Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "astronomy",
        "education"
      ],
      "description": "Welsh stories and sky patterns become memory and language.",
      "nectarDelta": {
        "education": 5,
        "sport": 0,
        "health": 0,
        "learning": 6,
        "enterprise": 0,
        "ecology": 2,
        "astronomy": 8
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 7,
        "discipline": 0,
        "care": 0,
        "skill": 0,
        "confidence": 4,
        "service": 2,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 3,
        "hamlet": 0,
        "village": 6,
        "town": 0,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 5,
        "college": 0,
        "university": 0,
        "library": 5,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 2,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 7,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 1,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 4
      }
    },
    {
      "id": "tune-06",
      "index": 6,
      "emoji": "🩺",
      "name": "Family Health Hive",
      "age": 7,
      "ageStage": "Explorer Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "health",
        "sport"
      ],
      "description": "Prevention starts before crisis: family health and movement.",
      "nectarDelta": {
        "education": 2,
        "sport": 4,
        "health": 7,
        "learning": 2,
        "enterprise": 0,
        "ecology": 0,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 0,
        "discipline": 3,
        "care": 6,
        "skill": 0,
        "confidence": 3,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 5,
        "hamlet": 0,
        "village": 5,
        "town": 0,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 4,
        "hospital": 0,
        "sportsField": 0,
        "park": 3,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 8,
        "knowledge": 0,
        "sport": 3,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 2
      }
    },
    {
      "id": "tune-07",
      "index": 7,
      "emoji": "🤝",
      "name": "Cubs Brownies Team Play",
      "age": 8,
      "ageStage": "Explorer Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "sport",
        "education"
      ],
      "description": "Youth groups and sports clubs create team confidence.",
      "nectarDelta": {
        "education": 4,
        "sport": 7,
        "health": 3,
        "learning": 3,
        "enterprise": 0,
        "ecology": 0,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 5,
        "curiosity": 0,
        "discipline": 5,
        "care": 0,
        "skill": 0,
        "confidence": 5,
        "service": 3,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 6,
        "town": 2,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 2,
        "train": 0,
        "school": 4,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 0,
        "hospital": 0,
        "sportsField": 6,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 5,
        "knowledge": 0,
        "sport": 7,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 3
      }
    },
    {
      "id": "tune-08",
      "index": 8,
      "emoji": "📚",
      "name": "Library Stars",
      "age": 8,
      "ageStage": "Explorer Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "education",
        "astronomy"
      ],
      "description": "Library is a public memory comb: books, digital, sky and stories.",
      "nectarDelta": {
        "education": 6,
        "sport": 0,
        "health": 0,
        "learning": 7,
        "enterprise": 1,
        "ecology": 0,
        "astronomy": 6
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 7,
        "discipline": 2,
        "care": 0,
        "skill": 3,
        "confidence": 0,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 5,
        "town": 3,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 2,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 8,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 8,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 2,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 3
      }
    },
    {
      "id": "tune-09",
      "index": 9,
      "emoji": "🧭",
      "name": "Map North Navigation",
      "age": 9,
      "ageStage": "Explorer Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "adventure",
        "astronomy"
      ],
      "description": "Navigation links sport, sky and place.",
      "nectarDelta": {
        "education": 4,
        "sport": 4,
        "health": 0,
        "learning": 5,
        "enterprise": 0,
        "ecology": 3,
        "astronomy": 6
      },
      "traitDelta": {
        "courage": 5,
        "curiosity": 5,
        "discipline": 0,
        "care": 0,
        "skill": 5,
        "confidence": 0,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 3,
        "town": 5,
        "city": 0,
        "Wales": 1
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 3,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 4,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 4,
        "knowledge": 5,
        "sport": 3,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 0
      }
    },
    {
      "id": "tune-10",
      "index": 10,
      "emoji": "⚽",
      "name": "Sports Field Confidence",
      "age": 9,
      "ageStage": "Explorer Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "sport",
        "health"
      ],
      "description": "Sport is a confidence engine and prevention pathway.",
      "nectarDelta": {
        "education": 0,
        "sport": 8,
        "health": 5,
        "learning": 2,
        "enterprise": 1,
        "ecology": 0,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 4,
        "curiosity": 0,
        "discipline": 6,
        "care": 0,
        "skill": 0,
        "confidence": 7,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 2,
        "town": 6,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 2,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 0,
        "hospital": 0,
        "sportsField": 8,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 6,
        "knowledge": 0,
        "sport": 8,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 2
      }
    },
    {
      "id": "tune-11",
      "index": 11,
      "emoji": "🐝",
      "name": "Pollinator Garden",
      "age": 10,
      "ageStage": "Explorer Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "ecology",
        "education"
      ],
      "description": "Bees, flowers, food and service become practical ecology.",
      "nectarDelta": {
        "education": 4,
        "sport": 0,
        "health": 2,
        "learning": 4,
        "enterprise": 0,
        "ecology": 8,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 4,
        "discipline": 0,
        "care": 7,
        "skill": 3,
        "confidence": 0,
        "service": 4,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 2,
        "hamlet": 0,
        "village": 6,
        "town": 1,
        "city": 0,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 4,
        "college": 0,
        "university": 0,
        "library": 2,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 5,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 4,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 4,
        "ecologicalRepair": 8,
        "civicPride": 0
      }
    },
    {
      "id": "tune-12",
      "index": 12,
      "emoji": "🚌",
      "name": "Transport Independence",
      "age": 10,
      "ageStage": "Explorer Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "transport",
        "education"
      ],
      "description": "Transport is a nectar route. No route, no opportunity.",
      "nectarDelta": {
        "education": 3,
        "sport": 0,
        "health": 2,
        "learning": 3,
        "enterprise": 2,
        "ecology": 0,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 3,
        "curiosity": 0,
        "discipline": 3,
        "care": 0,
        "skill": 0,
        "confidence": 6,
        "service": 2,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 2,
        "town": 6,
        "city": 1,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 2,
        "ambulance": 0,
        "fire": 0,
        "bus": 7,
        "train": 3,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 2,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 4,
        "knowledge": 3,
        "sport": 0,
        "jobs": 2,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 4
      }
    },
    {
      "id": "tune-13",
      "index": 13,
      "emoji": "🔭",
      "name": "Telescope Basics",
      "age": 11,
      "ageStage": "Team Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "astronomy",
        "education"
      ],
      "description": "Telescopes teach patience, optics, evidence and wonder.",
      "nectarDelta": {
        "education": 5,
        "sport": 0,
        "health": 0,
        "learning": 7,
        "enterprise": 1,
        "ecology": 0,
        "astronomy": 9
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 8,
        "discipline": 4,
        "care": 0,
        "skill": 4,
        "confidence": 0,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 6,
        "city": 1,
        "Wales": 1
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 4,
        "college": 0,
        "university": 0,
        "library": 5,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 3,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 8,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 3,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 3
      }
    },
    {
      "id": "tune-14",
      "index": 14,
      "emoji": "💧",
      "name": "Water Weather Fieldwork",
      "age": 11,
      "ageStage": "Team Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "ecology",
        "health"
      ],
      "description": "Weather and water become field science and farm intelligence.",
      "nectarDelta": {
        "education": 0,
        "sport": 0,
        "health": 3,
        "learning": 5,
        "enterprise": 0,
        "ecology": 7,
        "astronomy": 3
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 0,
        "discipline": 3,
        "care": 5,
        "skill": 5,
        "confidence": 0,
        "service": 3,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 3,
        "town": 5,
        "city": 0,
        "Wales": 1
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 2,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 5,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 5,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 3,
        "ecologicalRepair": 7,
        "civicPride": 0
      }
    },
    {
      "id": "tune-15",
      "index": 15,
      "emoji": "🌌",
      "name": "Dark Sky Ecology",
      "age": 12,
      "ageStage": "Team Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "astronomy",
        "ecology"
      ],
      "description": "Dark skies become ecology, habitat and Welsh place identity.",
      "nectarDelta": {
        "education": 3,
        "sport": 0,
        "health": 0,
        "learning": 5,
        "enterprise": 0,
        "ecology": 7,
        "astronomy": 8
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 6,
        "discipline": 0,
        "care": 5,
        "skill": 4,
        "confidence": 0,
        "service": 4,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 4,
        "city": 0,
        "Wales": 3
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 2,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 4,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 5,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 6,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 7,
        "civicPride": 5
      }
    },
    {
      "id": "tune-16",
      "index": 16,
      "emoji": "🦉",
      "name": "Zoo Biodiversity",
      "age": 12,
      "ageStage": "Team Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "ecology",
        "education"
      ],
      "description": "Zoo and nature centres become biodiversity learning combs.",
      "nectarDelta": {
        "education": 4,
        "sport": 0,
        "health": 2,
        "learning": 4,
        "enterprise": 0,
        "ecology": 7,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 5,
        "discipline": 0,
        "care": 6,
        "skill": 0,
        "confidence": 0,
        "service": 3,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 5,
        "city": 2,
        "Wales": 1
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 3,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 2,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 0,
        "zoo": 7
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 5,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 6,
        "civicPride": 4
      }
    },
    {
      "id": "tune-17",
      "index": 17,
      "emoji": "📈",
      "name": "Coding Charts",
      "age": 13,
      "ageStage": "Skill Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "education",
        "enterprise"
      ],
      "description": "Data visualisation turns observations into evidence.",
      "nectarDelta": {
        "education": 6,
        "sport": 0,
        "health": 0,
        "learning": 8,
        "enterprise": 4,
        "ecology": 0,
        "astronomy": 3
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 4,
        "discipline": 5,
        "care": 0,
        "skill": 7,
        "confidence": 0,
        "service": 0,
        "enterprise": 3
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 5,
        "city": 2,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 4,
        "college": 2,
        "university": 0,
        "library": 5,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 7,
        "sport": 0,
        "jobs": 2,
        "apprenticeships": 0,
        "invention": 5,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 0
      }
    },
    {
      "id": "tune-18",
      "index": 18,
      "emoji": "🤲",
      "name": "Community Service",
      "age": 13,
      "ageStage": "Skill Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "health",
        "ecology"
      ],
      "description": "Service is a core trait, not an optional extra.",
      "nectarDelta": {
        "education": 0,
        "sport": 0,
        "health": 4,
        "learning": 3,
        "enterprise": 2,
        "ecology": 4,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 0,
        "discipline": 3,
        "care": 6,
        "skill": 0,
        "confidence": 4,
        "service": 8,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 3,
        "town": 5,
        "city": 0,
        "Wales": 1
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 2,
        "train": 0,
        "school": 3,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 2,
        "hospital": 0,
        "sportsField": 0,
        "park": 3,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 5,
        "knowledge": 0,
        "sport": 0,
        "jobs": 0,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 4,
        "civicPride": 8
      }
    },
    {
      "id": "tune-19",
      "index": 19,
      "emoji": "🛰️",
      "name": "Satellite GIS",
      "age": 14,
      "ageStage": "Skill Bee",
      "homeScale": "city",
      "activeHiveTypes": [
        "astronomy",
        "enterprise"
      ],
      "description": "GPS, OSGB, satellite layers and WebUI maps become technical literacy.",
      "nectarDelta": {
        "education": 0,
        "sport": 0,
        "health": 0,
        "learning": 8,
        "enterprise": 5,
        "ecology": 4,
        "astronomy": 7
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 5,
        "discipline": 4,
        "care": 0,
        "skill": 8,
        "confidence": 0,
        "service": 0,
        "enterprise": 4
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 3,
        "city": 5,
        "Wales": 3
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 3,
        "school": 3,
        "college": 3,
        "university": 0,
        "library": 4,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 7,
        "sport": 0,
        "jobs": 4,
        "apprenticeships": 0,
        "invention": 6,
        "food": 0,
        "ecologicalRepair": 4,
        "civicPride": 0
      }
    },
    {
      "id": "tune-20",
      "index": 20,
      "emoji": "🏥",
      "name": "GP Prevention Fitness",
      "age": 14,
      "ageStage": "Skill Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "health",
        "sport"
      ],
      "description": "Health, fitness and GP prevention are linked before crisis.",
      "nectarDelta": {
        "education": 2,
        "sport": 6,
        "health": 8,
        "learning": 2,
        "enterprise": 0,
        "ecology": 0,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 0,
        "discipline": 6,
        "care": 4,
        "skill": 3,
        "confidence": 5,
        "service": 0,
        "enterprise": 0
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 5,
        "city": 2,
        "Wales": 0
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 0,
        "train": 0,
        "school": 0,
        "college": 0,
        "university": 0,
        "library": 0,
        "GP": 5,
        "hospital": 2,
        "sportsField": 6,
        "park": 3,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 8,
        "knowledge": 0,
        "sport": 6,
        "jobs": 2,
        "apprenticeships": 0,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 0
      }
    },
    {
      "id": "tune-21",
      "index": 21,
      "emoji": "📡",
      "name": "Sensor Farm",
      "age": 15,
      "ageStage": "Apprentice Bee",
      "homeScale": "village",
      "activeHiveTypes": [
        "ecology",
        "enterprise"
      ],
      "description": "Sensors connect farm, water, bees, weather and skills evidence.",
      "nectarDelta": {
        "education": 0,
        "sport": 0,
        "health": 2,
        "learning": 6,
        "enterprise": 6,
        "ecology": 8,
        "astronomy": 3
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 0,
        "discipline": 5,
        "care": 0,
        "skill": 8,
        "confidence": 0,
        "service": 4,
        "enterprise": 5
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 4,
        "town": 3,
        "city": 0,
        "Wales": 2
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 2,
        "train": 0,
        "school": 0,
        "college": 3,
        "university": 0,
        "library": 2,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 3,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 0,
        "sport": 0,
        "jobs": 5,
        "apprenticeships": 0,
        "invention": 6,
        "food": 7,
        "ecologicalRepair": 7,
        "civicPride": 0
      }
    },
    {
      "id": "tune-22",
      "index": 22,
      "emoji": "💼",
      "name": "Enterprise Challenge",
      "age": 15,
      "ageStage": "Apprentice Bee",
      "homeScale": "town",
      "activeHiveTypes": [
        "enterprise",
        "education"
      ],
      "description": "Opportunity becomes service, project, venture and local value.",
      "nectarDelta": {
        "education": 3,
        "sport": 2,
        "health": 0,
        "learning": 5,
        "enterprise": 8,
        "ecology": 0,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 0,
        "discipline": 4,
        "care": 0,
        "skill": 0,
        "confidence": 5,
        "service": 3,
        "enterprise": 8
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 5,
        "city": 3,
        "Wales": 1
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 3,
        "train": 2,
        "school": 0,
        "college": 4,
        "university": 0,
        "library": 3,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 0,
        "sport": 0,
        "jobs": 7,
        "apprenticeships": 5,
        "invention": 5,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 4
      }
    },
    {
      "id": "tune-23",
      "index": 23,
      "emoji": "🎓",
      "name": "College Apprenticeship Taster",
      "age": 16,
      "ageStage": "Apprentice Bee",
      "homeScale": "city",
      "activeHiveTypes": [
        "education",
        "enterprise"
      ],
      "description": "College and transport connect young people to recognised pathways.",
      "nectarDelta": {
        "education": 5,
        "sport": 0,
        "health": 2,
        "learning": 6,
        "enterprise": 7,
        "ecology": 0,
        "astronomy": 0
      },
      "traitDelta": {
        "courage": 0,
        "curiosity": 0,
        "discipline": 5,
        "care": 0,
        "skill": 7,
        "confidence": 5,
        "service": 0,
        "enterprise": 5
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 0,
        "town": 3,
        "city": 5,
        "Wales": 2
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 3,
        "train": 4,
        "school": 0,
        "college": 8,
        "university": 0,
        "library": 3,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 0,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 0,
        "knowledge": 5,
        "sport": 0,
        "jobs": 6,
        "apprenticeships": 8,
        "invention": 0,
        "food": 0,
        "ecologicalRepair": 0,
        "civicPride": 0
      }
    },
    {
      "id": "tune-24",
      "index": 24,
      "emoji": "🌾",
      "name": "SPACE Farmer Capstone",
      "age": "16+",
      "ageStage": "SPACE Farmer",
      "homeScale": "Wales",
      "activeHiveTypes": [
        "ecology",
        "enterprise",
        "astronomy"
      ],
      "description": "Capstone: land-and-sky, sport-and-service, education-to-enterprise.",
      "nectarDelta": {
        "education": 0,
        "sport": 3,
        "health": 4,
        "learning": 7,
        "enterprise": 8,
        "ecology": 8,
        "astronomy": 7
      },
      "traitDelta": {
        "courage": 4,
        "curiosity": 0,
        "discipline": 6,
        "care": 5,
        "skill": 8,
        "confidence": 0,
        "service": 7,
        "enterprise": 7
      },
      "placeDelta": {
        "household": 0,
        "hamlet": 0,
        "village": 3,
        "town": 3,
        "city": 3,
        "Wales": 7
      },
      "serviceDelta": {
        "taxi": 0,
        "ambulance": 0,
        "fire": 0,
        "bus": 4,
        "train": 4,
        "school": 0,
        "college": 5,
        "university": 3,
        "library": 4,
        "GP": 0,
        "hospital": 0,
        "sportsField": 0,
        "park": 3,
        "zoo": 0
      },
      "honeyDelta": {
        "wellbeing": 5,
        "knowledge": 0,
        "sport": 0,
        "jobs": 7,
        "apprenticeships": 8,
        "invention": 7,
        "food": 8,
        "ecologicalRepair": 8,
        "civicPride": 8
      }
    }
  ],
  "roles": [
    {
      "id": "land_scout",
      "name": "Land Scout",
      "icon": "🧭",
      "purpose": "Find routes, hazards, opportunities and hives.",
      "primaryTraits": [
        "curiosity",
        "courage",
        "skill"
      ]
    },
    {
      "id": "wellbeing_nurse",
      "name": "Wellbeing Nurse",
      "icon": "🩺",
      "purpose": "Connect health, sport, care and recovery.",
      "primaryTraits": [
        "care",
        "service",
        "confidence"
      ]
    },
    {
      "id": "knowledge_forager",
      "name": "Knowledge Forager",
      "icon": "📚",
      "purpose": "Collect learning from school, library, sky, ecology and data.",
      "primaryTraits": [
        "curiosity",
        "discipline",
        "skill"
      ]
    },
    {
      "id": "service_guard",
      "name": "Service Guard",
      "icon": "🚒",
      "purpose": "Safeguarding, fire, ambulance, GP and emergency readiness.",
      "primaryTraits": [
        "care",
        "discipline",
        "service"
      ]
    },
    {
      "id": "transport_runner",
      "name": "Transport Runner",
      "icon": "🚌",
      "purpose": "Keep access routes alive: taxi, bus, train, walking and cycling.",
      "primaryTraits": [
        "confidence",
        "service",
        "skill"
      ]
    },
    {
      "id": "space_farmer",
      "name": "SPACE Farmer",
      "icon": "🌾",
      "purpose": "Use land, sensors, satellites, bees and enterprise to produce future skills.",
      "primaryTraits": [
        "skill",
        "enterprise",
        "service"
      ]
    }
  ],
  "matrices": {
    "nectarToTraits": {
      "education": {
        "curiosity": 0.28,
        "discipline": 0.16,
        "skill": 0.24
      },
      "sport": {
        "courage": 0.22,
        "discipline": 0.25,
        "confidence": 0.28
      },
      "health": {
        "care": 0.25,
        "confidence": 0.16,
        "discipline": 0.12
      },
      "learning": {
        "curiosity": 0.22,
        "skill": 0.26,
        "discipline": 0.12
      },
      "enterprise": {
        "enterprise": 0.32,
        "confidence": 0.18,
        "skill": 0.2
      },
      "ecology": {
        "care": 0.25,
        "service": 0.2,
        "curiosity": 0.18
      },
      "astronomy": {
        "curiosity": 0.3,
        "discipline": 0.12,
        "skill": 0.14
      }
    },
    "traitsToHoney": {
      "courage": {
        "sport": 0.12,
        "jobs": 0.1,
        "civicPride": 0.08
      },
      "curiosity": {
        "knowledge": 0.22,
        "invention": 0.18
      },
      "discipline": {
        "sport": 0.12,
        "apprenticeships": 0.18,
        "jobs": 0.12
      },
      "care": {
        "wellbeing": 0.2,
        "ecologicalRepair": 0.12
      },
      "skill": {
        "knowledge": 0.15,
        "jobs": 0.2,
        "invention": 0.16
      },
      "confidence": {
        "wellbeing": 0.16,
        "jobs": 0.12,
        "sport": 0.12
      },
      "service": {
        "civicPride": 0.22,
        "ecologicalRepair": 0.14
      },
      "enterprise": {
        "jobs": 0.24,
        "apprenticeships": 0.18,
        "invention": 0.12
      }
    },
    "servicesToHoney": {
      "school": {
        "knowledge": 0.15
      },
      "college": {
        "apprenticeships": 0.2,
        "jobs": 0.12
      },
      "university": {
        "knowledge": 0.18,
        "invention": 0.16
      },
      "library": {
        "knowledge": 0.14,
        "civicPride": 0.08
      },
      "GP": {
        "wellbeing": 0.18
      },
      "hospital": {
        "wellbeing": 0.14
      },
      "sportsField": {
        "sport": 0.22,
        "wellbeing": 0.1
      },
      "park": {
        "wellbeing": 0.08,
        "ecologicalRepair": 0.08
      },
      "zoo": {
        "knowledge": 0.08,
        "ecologicalRepair": 0.1
      },
      "bus": {
        "jobs": 0.06,
        "knowledge": 0.05
      },
      "train": {
        "jobs": 0.09,
        "apprenticeships": 0.07
      },
      "taxi": {
        "wellbeing": 0.05
      },
      "ambulance": {
        "wellbeing": 0.06
      },
      "fire": {
        "wellbeing": 0.05,
        "civicPride": 0.05
      }
    }
  },
  "beeTemplate": {
    "id": "bee-001",
    "ageStage": "Little Bee",
    "homeScale": "village",
    "currentHive": "Bangor",
    "gps": {
      "lat": 53.2274,
      "lon": -4.1293
    },
    "osgb36": {
      "easting": 258035,
      "northing": 371000,
      "crs": "EPSG:27700"
    },
    "nectar": {
      "education": 0,
      "sport": 0,
      "health": 0,
      "learning": 0,
      "enterprise": 0,
      "ecology": 0,
      "astronomy": 0
    },
    "traits": {
      "courage": 0,
      "curiosity": 0,
      "discipline": 0,
      "care": 0,
      "skill": 0,
      "confidence": 0,
      "service": 0,
      "enterprise": 0
    },
    "places": {
      "household": 0,
      "hamlet": 0,
      "village": 0,
      "town": 0,
      "city": 0,
      "Wales": 0
    },
    "services": {
      "taxi": 0,
      "ambulance": 0,
      "fire": 0,
      "bus": 0,
      "train": 0,
      "school": 0,
      "college": 0,
      "university": 0,
      "library": 0,
      "GP": 0,
      "hospital": 0,
      "sportsField": 0,
      "park": 0,
      "zoo": 0
    },
    "honey": {
      "wellbeing": 0,
      "knowledge": 0,
      "sport": 0,
      "jobs": 0,
      "apprenticeships": 0,
      "invention": 0,
      "food": 0,
      "ecologicalRepair": 0,
      "civicPride": 0
    },
    "role": "knowledge_forager",
    "eventLog": []
  },
  "architecture": {
    "version": "2.0.0",
    "name": "Cymru Hive OS v2",
    "description": "Quantified individual-bee pathway engine for Wales.",
    "entities": {
      "Bee": {
        "description": "Individual learner/citizen agent.",
        "required": [
          "id",
          "ageStage",
          "homeScale",
          "currentHive",
          "nectar",
          "traits",
          "places",
          "services",
          "honey",
          "gps",
          "osgb36"
        ]
      },
      "Hive": {
        "description": "Place/service node from household to Wales scale.",
        "required": [
          "id",
          "name",
          "placeScale",
          "type",
          "gps",
          "osgb36",
          "services",
          "nectarTags"
        ]
      },
      "AutoTune": {
        "description": "Age-stage scenario that updates bee states and route priorities.",
        "required": [
          "id",
          "age",
          "ageStage",
          "nectarDelta",
          "traitDelta",
          "placeDelta",
          "serviceDelta",
          "honeyDelta"
        ]
      },
      "HoneyOutput": {
        "description": "Measurable social output produced by bees and hives."
      }
    },
    "keys": {
      "nectar": [
        "education",
        "sport",
        "health",
        "learning",
        "enterprise",
        "ecology",
        "astronomy"
      ],
      "traits": [
        "courage",
        "curiosity",
        "discipline",
        "care",
        "skill",
        "confidence",
        "service",
        "enterprise"
      ],
      "places": [
        "household",
        "hamlet",
        "village",
        "town",
        "city",
        "Wales"
      ],
      "services": [
        "taxi",
        "ambulance",
        "fire",
        "bus",
        "train",
        "school",
        "college",
        "university",
        "library",
        "GP",
        "hospital",
        "sportsField",
        "park",
        "zoo"
      ],
      "honey": [
        "wellbeing",
        "knowledge",
        "sport",
        "jobs",
        "apprenticeships",
        "invention",
        "food",
        "ecologicalRepair",
        "civicPride"
      ]
    },
    "coordinateSystems": {
      "gps": "WGS84 latitude/longitude, EPSG:4326",
      "osgb36": "British National Grid Easting/Northing, EPSG:27700, approximate seed conversion for planning demo"
    },
    "updateCycle": [
      "autoTune applies deltas",
      "nectar feeds traits via matrix",
      "traits and services feed honey via matrices",
      "bee moves to a hive whose type matches tune priorities",
      "hive and bee event logs update"
    ],
    "note": "Coordinates are planning/demo seeds and not a substitute for survey-grade OS data."
  },
  "pathways": {
    "ageSpine": [
      {
        "age": 5,
        "name": "Moon Wonder",
        "stage": "Little Bee",
        "target": "Start from wonder: Moon diary, safe looking, drawing and family sky language."
      },
      {
        "age": 5,
        "name": "Safe Darkness",
        "stage": "Little Bee",
        "target": "Darkness is habitat and safety practice, not fear."
      },
      {
        "age": 6,
        "name": "Sun and Shadow Clock",
        "stage": "Little Bee",
        "target": "Use shadows, play and outdoor observation to understand time."
      },
      {
        "age": 6,
        "name": "Park Play and Nature",
        "stage": "Little Bee",
        "target": "Parks become first ecology and physical-literacy combs."
      },
      {
        "age": 7,
        "name": "Story Constellations",
        "stage": "Little Bee",
        "target": "Welsh stories and sky patterns become memory and language."
      },
      {
        "age": 7,
        "name": "Family Health Hive",
        "stage": "Explorer Bee",
        "target": "Prevention starts before crisis: family health and movement."
      },
      {
        "age": 8,
        "name": "Cubs Brownies Team Play",
        "stage": "Explorer Bee",
        "target": "Youth groups and sports clubs create team confidence."
      },
      {
        "age": 8,
        "name": "Library Stars",
        "stage": "Explorer Bee",
        "target": "Library is a public memory comb: books, digital, sky and stories."
      },
      {
        "age": 9,
        "name": "Map North Navigation",
        "stage": "Explorer Bee",
        "target": "Navigation links sport, sky and place."
      },
      {
        "age": 9,
        "name": "Sports Field Confidence",
        "stage": "Explorer Bee",
        "target": "Sport is a confidence engine and prevention pathway."
      },
      {
        "age": 10,
        "name": "Pollinator Garden",
        "stage": "Explorer Bee",
        "target": "Bees, flowers, food and service become practical ecology."
      },
      {
        "age": 10,
        "name": "Transport Independence",
        "stage": "Explorer Bee",
        "target": "Transport is a nectar route. No route, no opportunity."
      },
      {
        "age": 11,
        "name": "Telescope Basics",
        "stage": "Team Bee",
        "target": "Telescopes teach patience, optics, evidence and wonder."
      },
      {
        "age": 11,
        "name": "Water Weather Fieldwork",
        "stage": "Team Bee",
        "target": "Weather and water become field science and farm intelligence."
      },
      {
        "age": 12,
        "name": "Dark Sky Ecology",
        "stage": "Team Bee",
        "target": "Dark skies become ecology, habitat and Welsh place identity."
      },
      {
        "age": 12,
        "name": "Zoo Biodiversity",
        "stage": "Team Bee",
        "target": "Zoo and nature centres become biodiversity learning combs."
      },
      {
        "age": 13,
        "name": "Coding Charts",
        "stage": "Skill Bee",
        "target": "Data visualisation turns observations into evidence."
      },
      {
        "age": 13,
        "name": "Community Service",
        "stage": "Skill Bee",
        "target": "Service is a core trait, not an optional extra."
      },
      {
        "age": 14,
        "name": "Satellite GIS",
        "stage": "Skill Bee",
        "target": "GPS, OSGB, satellite layers and WebUI maps become technical literacy."
      },
      {
        "age": 14,
        "name": "GP Prevention Fitness",
        "stage": "Skill Bee",
        "target": "Health, fitness and GP prevention are linked before crisis."
      },
      {
        "age": 15,
        "name": "Sensor Farm",
        "stage": "Apprentice Bee",
        "target": "Sensors connect farm, water, bees, weather and skills evidence."
      },
      {
        "age": 15,
        "name": "Enterprise Challenge",
        "stage": "Apprentice Bee",
        "target": "Opportunity becomes service, project, venture and local value."
      },
      {
        "age": 16,
        "name": "College Apprenticeship Taster",
        "stage": "Apprentice Bee",
        "target": "College and transport connect young people to recognised pathways."
      },
      {
        "age": "16+",
        "name": "SPACE Farmer Capstone",
        "stage": "SPACE Farmer",
        "target": "Capstone: land-and-sky, sport-and-service, education-to-enterprise."
      }
    ],
    "scaleLadder": [
      "household",
      "hamlet",
      "village",
      "town",
      "city",
      "Wales"
    ],
    "strategicOutcomes": [
      "wellbeing",
      "knowledge",
      "sport",
      "jobs",
      "apprenticeships",
      "invention",
      "food",
      "ecologicalRepair",
      "civicPride"
    ],
    "routes": [
      {
        "from": "household",
        "to": "school",
        "purpose": "start learning and confidence"
      },
      {
        "from": "school",
        "to": "sportsField",
        "purpose": "health, discipline and teamwork"
      },
      {
        "from": "library",
        "to": "college",
        "purpose": "knowledge to qualification"
      },
      {
        "from": "park",
        "to": "ecology",
        "purpose": "place care and biodiversity"
      },
      {
        "from": "college",
        "to": "enterprise",
        "purpose": "apprenticeship and jobs"
      },
      {
        "from": "astronomy",
        "to": "satelliteGIS",
        "purpose": "wonder to technical land-and-sky intelligence"
      }
    ]
  },
  "serviceModel": {
    "serviceOrgans": {
      "taxi": {
        "id": "taxi",
        "description": "taxi service comb in the Welsh hive system."
      },
      "ambulance": {
        "id": "ambulance",
        "description": "ambulance service comb in the Welsh hive system."
      },
      "fire": {
        "id": "fire",
        "description": "fire service comb in the Welsh hive system."
      },
      "bus": {
        "id": "bus",
        "description": "bus service comb in the Welsh hive system."
      },
      "train": {
        "id": "train",
        "description": "train service comb in the Welsh hive system."
      },
      "school": {
        "id": "school",
        "description": "school service comb in the Welsh hive system."
      },
      "college": {
        "id": "college",
        "description": "college service comb in the Welsh hive system."
      },
      "university": {
        "id": "university",
        "description": "university service comb in the Welsh hive system."
      },
      "library": {
        "id": "library",
        "description": "library service comb in the Welsh hive system."
      },
      "GP": {
        "id": "GP",
        "description": "GP service comb in the Welsh hive system."
      },
      "hospital": {
        "id": "hospital",
        "description": "hospital service comb in the Welsh hive system."
      },
      "sportsField": {
        "id": "sportsField",
        "description": "sportsField service comb in the Welsh hive system."
      },
      "park": {
        "id": "park",
        "description": "park service comb in the Welsh hive system."
      },
      "zoo": {
        "id": "zoo",
        "description": "zoo service comb in the Welsh hive system."
      }
    },
    "hiveCombs": [
      "learning comb",
      "health comb",
      "sport comb",
      "transport comb",
      "enterprise comb",
      "ecology comb",
      "culture-memory comb"
    ],
    "interventions": [
      {
        "name": "repair missing transport trail",
        "signals": [
          "low bus",
          "low train",
          "low taxi",
          "low apprenticeships"
        ]
      },
      {
        "name": "add mentor bees",
        "signals": [
          "low confidence",
          "low service",
          "low knowledge"
        ]
      },
      {
        "name": "increase sport prevention",
        "signals": [
          "low health",
          "low sport honey",
          "high GP demand"
        ]
      },
      {
        "name": "activate dark-sky ecology",
        "signals": [
          "low astronomy",
          "low ecologicalRepair",
          "available parks"
        ]
      }
    ]
  },
  "keys": {
    "nectar": [
      "education",
      "sport",
      "health",
      "learning",
      "enterprise",
      "ecology",
      "astronomy"
    ],
    "traits": [
      "courage",
      "curiosity",
      "discipline",
      "care",
      "skill",
      "confidence",
      "service",
      "enterprise"
    ],
    "places": [
      "household",
      "hamlet",
      "village",
      "town",
      "city",
      "Wales"
    ],
    "services": [
      "taxi",
      "ambulance",
      "fire",
      "bus",
      "train",
      "school",
      "college",
      "university",
      "library",
      "GP",
      "hospital",
      "sportsField",
      "park",
      "zoo"
    ],
    "honey": [
      "wellbeing",
      "knowledge",
      "sport",
      "jobs",
      "apprenticeships",
      "invention",
      "food",
      "ecologicalRepair",
      "civicPride"
    ]
  }
};
