
(function(){
  const DATA = window.CYMRU_HIVE_DATA;
  const clamp = (v, min=0, max=100) => Math.max(min, Math.min(max, v));
  const avg = obj => { const vals = Object.values(obj || {}); return vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : 0; };
  const clone = obj => JSON.parse(JSON.stringify(obj));
  const zeros = keys => Object.fromEntries(keys.map(k => [k, 0]));
  const safeAdd = (target, deltas, rate=0.035) => {
    Object.entries(deltas || {}).forEach(([k,v]) => target[k] = clamp((target[k] || 0) + Number(v || 0) * rate));
  };
  function createBee(index){
    const hives = DATA.hives;
    const start = hives[index % hives.length];
    const target = hives[(index * 7 + 3) % hives.length];
    const role = DATA.roles[index % DATA.roles.length];
    return {
      id: `bee-${String(index + 1).padStart(3, '0')}`,
      ageStage: 'Little Bee',
      homeScale: 'household',
      currentHive: start.name,
      currentHiveId: start.id,
      gps: clone(start.gps),
      osgb36: clone(start.osgb36),
      mapX: start.map.xPercent,
      mapY: start.map.yPercent,
      targetHiveId: target.id,
      targetX: target.map.xPercent,
      targetY: target.map.yPercent,
      progress: Math.random(),
      speed: 0.002 + Math.random() * 0.004,
      emoji: index % 5 === 0 ? '🔭' : index % 4 === 0 ? '🌾' : index % 3 === 0 ? '🍯' : '🐝',
      role: role.id,
      nectar: zeros(DATA.keys.nectar),
      traits: zeros(DATA.keys.traits),
      places: zeros(DATA.keys.places),
      services: zeros(DATA.keys.services),
      honey: zeros(DATA.keys.honey),
      eventLog: []
    };
  }
  function createBees(count=24){ return Array.from({length: count}, (_, i) => createBee(i)); }
  function pickTargetHive(tune, index){
    const hives = DATA.hives;
    const active = hives.filter(h => tune.activeHiveTypes.includes(h.type) || h.nectarTags.some(t => tune.activeHiveTypes.includes(t)));
    const pool = active.length ? active : hives;
    return pool[Math.floor((index * 13 + performance.now()/1000) % pool.length)] || pool[0];
  }
  function applyMatrix(source, matrix, target, rate=0.0012){
    Object.entries(source || {}).forEach(([srcKey, srcVal]) => {
      const row = matrix[srcKey] || {};
      Object.entries(row).forEach(([dstKey, coeff]) => target[dstKey] = clamp((target[dstKey] || 0) + srcVal * coeff * rate));
    });
  }
  function applyTune(bee, tune){
    bee.ageStage = tune.ageStage;
    bee.homeScale = tune.homeScale;
    safeAdd(bee.nectar, tune.nectarDelta);
    safeAdd(bee.traits, tune.traitDelta);
    safeAdd(bee.places, tune.placeDelta);
    safeAdd(bee.services, tune.serviceDelta);
    safeAdd(bee.honey, tune.honeyDelta);
    applyMatrix(bee.nectar, DATA.matrices.nectarToTraits, bee.traits);
    applyMatrix(bee.traits, DATA.matrices.traitsToHoney, bee.honey);
    applyMatrix(bee.services, DATA.matrices.servicesToHoney, bee.honey);
  }
  function stepBee(bee, tune, index){
    applyTune(bee, tune);
    bee.progress += bee.speed;
    if (bee.progress >= 1) {
      const target = DATA.hives.find(h => h.id === bee.targetHiveId) || DATA.hives[0];
      bee.progress = 0;
      bee.mapX = target.map.xPercent;
      bee.mapY = target.map.yPercent;
      bee.currentHive = target.name;
      bee.currentHiveId = target.id;
      bee.gps = clone(target.gps);
      bee.osgb36 = clone(target.osgb36);
      const next = pickTargetHive(tune, index);
      bee.targetHiveId = next.id;
      bee.targetX = next.map.xPercent;
      bee.targetY = next.map.yPercent;
      bee.speed = 0.002 + Math.random() * 0.004;
      bee.eventLog.unshift({at: new Date().toISOString(), type:'arrive_hive', hive: target.name, tune: tune.id});
      bee.eventLog = bee.eventLog.slice(0, 20);
    }
  }
  function scoreBee(bee){
    return {honeyIndex: Math.round(avg(bee.honey)), nectarIndex: Math.round(avg(bee.nectar)), traitIndex: Math.round(avg(bee.traits)), serviceIndex: Math.round(avg(bee.services))};
  }
  window.CymruEngine = {clamp, avg, clone, createBees, applyTune, stepBee, scoreBee, pickTargetHive};
})();
