<?php
header('Content-Type: application/json');
$p=__DIR__.'/../data/suits_v16_3/summary.json';
if(!file_exists($p)){ http_response_code(404); echo json_encode(['error'=>'summary missing']); exit; }
readfile($p);
