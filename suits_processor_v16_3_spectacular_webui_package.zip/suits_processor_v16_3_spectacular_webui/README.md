# [o][o] $uits Processor v16.3 — Spectacular WebUI + Neo4j Graph Phase

v16.3 is the spectacular review layer for analysed/profiled processor output.

It consumes existing processor files such as:

- `music_profile.json`
- `video_profile.json`
- `song_video_match_plan.json`
- `song_story_plan.json`
- `webui_song_story_index.json`
- v8/v9/v16 recursive outputs when present

It produces:

- `$uits` dark/navy WebUI pages
- global navigation on every page
- main logo heading with home link on every page
- mouse trail behaviour on every page
- song/video/story dashboards
- strategic predation/comedy event browser
- event-chain review data
- Neo4j CSV + Cypher graph phase
- SQL/CSV review tables

## Install

```bash
cd /home/andy/Downloads
unzip -o /mnt/data/suits_processor_v16_3_spectacular_webui_package.zip
cd suits_processor_v16_3_spectacular_webui
chmod +x scripts/*.sh tools/*.py
./scripts/install_v16_3.sh
```

## Run against your current `$uitsmafia` project

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_3_spectacular_webui
```

## Run directly

```bash
python3 /home/andy/Documents/suitsmafia/processors/suits_processor_v16_3_spectacular_webui/tools/suits_spectacular_webui_builder_v16_3.py \
  --root /home/andy/Documents/suitsmafia \
  --site /home/andy/Documents/suitsmafia/susitsmafia_website \
  --out /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_3_spectacular_webui \
  --build-neo4j --build-webui --build-sql --build-review
```

## Open WebUI

```bash
cd /home/andy/Documents/suitsmafia/susitsmafia_website
php -S 127.0.0.1:8081
```

Then open:

- `http://127.0.0.1:8081/suits_v16_3_dashboard.php`
- `http://127.0.0.1:8081/suits_v16_3_song_story.php`
- `http://127.0.0.1:8081/suits_v16_3_event_chains.php`
- `http://127.0.0.1:8081/suits_v16_3_graph.php`
- `http://127.0.0.1:8081/suits_v16_3_review.php`

## Notes

This package does not include font files. It references your local site fonts/assets if present and falls back gracefully.
