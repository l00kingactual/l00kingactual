#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/andy/Documents/suitsmafia"
SITE="$ROOT/susitsmafia_website"
PROC_DIR="$ROOT/processors/suits_processor_v16_3_spectacular_webui"
TOOLS_DIR="$ROOT/tools"
mkdir -p "$ROOT/processors" "$TOOLS_DIR" "$SITE/css" "$SITE/js" "$SITE/api" "$SITE/data/suits_v16_3"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
rm -rf "$PROC_DIR"
cp -a "$SRC_DIR" "$PROC_DIR"
rsync -av "$SRC_DIR/web/" "$SITE/"
rsync -av "$SRC_DIR/css/" "$SITE/css/"
rsync -av "$SRC_DIR/js/" "$SITE/js/"
rsync -av "$SRC_DIR/api/" "$SITE/api/"
cat > "$TOOLS_DIR/suits_processor_v16_3_spectacular_webui" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
python3 /home/andy/Documents/suitsmafia/processors/suits_processor_v16_3_spectacular_webui/tools/suits_spectacular_webui_builder_v16_3.py \
  --root /home/andy/Documents/suitsmafia \
  --site /home/andy/Documents/suitsmafia/susitsmafia_website \
  --out /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_3_spectacular_webui \
  --build-neo4j --build-webui --build-sql --build-review "$@"
EOF
chmod +x "$TOOLS_DIR/suits_processor_v16_3_spectacular_webui"
echo "[o][o] installed $uits v16.3 processor and WebUI"
echo "Run: $TOOLS_DIR/suits_processor_v16_3_spectacular_webui"
