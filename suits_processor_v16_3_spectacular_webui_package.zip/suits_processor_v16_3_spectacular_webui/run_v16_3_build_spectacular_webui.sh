#!/usr/bin/env bash
set -euo pipefail
python3 tools/suits_spectacular_webui_builder_v16_3.py \
  --root /home/andy/Documents/suitsmafia \
  --site /home/andy/Documents/suitsmafia/susitsmafia_website \
  --out /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_3_spectacular_webui \
  --build-neo4j --build-webui --build-sql --build-review "$@"
