# $uits v16.3 Spectacular WebUI Strategy

v16.3 turns processor output into a reviewable cinematic intelligence surface.

## Purpose

The processor has already generated evidence:

- songs
- videos
- render plans
- match scores
- story variants
- predation/comedy/shot/hit labels
- generated clips/stills/APNGs

v16.3 packages that into a WebUI so Andrew can review the chain:

```text
song -> cue -> video -> event -> story variant -> render job -> human feedback -> learned metadata
```

## Key WebUI pages

1. Dashboard: counts, top matches, story mix, score bins.
2. Song Story: top song/video plans and 18 variants per song.
3. Event Chains: strategic/comedic event chain browser.
4. Graph: vanilla JS graph surface and Neo4j export links.
5. Review: human feedback table template.

## Graph phase

Neo4j graph shape:

```cypher
(:Song)-[:MATCHES {score,rank,use}]->(:Video)
(:Song)-[:HAS_STORY_VARIANT]->(:StoryVariant)
(:Video)-[:HAS_TONE]->(:Tone)
(:EventChain)-[:USES_SONG]->(:Song)
(:EventChain)-[:USES_VIDEO]->(:Video)
(:EventChain)-[:EXPRESSES]->(:Tone)
(:RenderJob)-[:USES_CHAIN]->(:EventChain)
(:HumanFeedback)-[:REVIEWS]->(:EventChain)
```

## Branding

The UI uses:

- dark navy surface
- light blue-grey panels
- `$uit$` heading
- `[o][o]` mouse trail
- fixed navigation on every page
- home logo link on every page
- local font references only, no font files shipped
