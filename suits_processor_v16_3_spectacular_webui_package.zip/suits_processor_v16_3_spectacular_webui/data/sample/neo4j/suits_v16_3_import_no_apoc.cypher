LOAD CSV WITH HEADERS FROM 'file:///neo4j_nodes.csv' AS row
MERGE (n:SuitsNode {id: row.id})
SET n.label=row.label, n.type=row.type, n.duration_s=row.duration_s, n.tone=row.tone, n.score=row.score, n.use=row.use;

LOAD CSV WITH HEADERS FROM 'file:///neo4j_edges.csv' AS row
MATCH (a:SuitsNode {id: row.source})
MATCH (b:SuitsNode {id: row.target})
MERGE (a)-[r:RELATED_TO {edge_type: row.type}]->(b)
SET r.weight=row.weight;
