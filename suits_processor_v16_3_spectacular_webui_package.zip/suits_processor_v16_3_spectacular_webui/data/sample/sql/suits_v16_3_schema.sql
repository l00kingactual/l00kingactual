See sqlite database suits_v16_3_webui.sqlite3
