#!/usr/bin/env python3
import argparse, csv, json, os, re, sqlite3, hashlib, datetime as dt, html
from pathlib import Path

VERSION='v16.3.0'
SCHEMA='suits_spectacular_webui_v16_3'
DEFAULT_ROOT='/home/andy/Documents/suitsmafia'
DEFAULT_SITE='/home/andy/Documents/suitsmafia/susitsmafia_website'
DEFAULT_OUT='/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_3_spectacular_webui'

def now(): return dt.datetime.now(dt.UTC).isoformat().replace('+00:00','Z')
def sid(s): return hashlib.sha1(str(s).encode('utf-8','ignore')).hexdigest()[:12]
def load_json(path, default):
    try:
        with open(path,'r',encoding='utf-8') as f: return json.load(f)
    except Exception: return default

def find_first(root, names):
    root=Path(root)
    for name in names:
        p=root/name
        if p.exists(): return p
    for p in root.rglob('*'):
        if p.name in names: return p
    return None

def tone_from_row(row):
    ts=row.get('tone_scores') or {}
    if isinstance(ts,str):
        try: ts=json.loads(ts)
        except Exception: ts={}
    vals={k:int(v or 0) for k,v in ts.items()} if isinstance(ts,dict) else {}
    if row.get('story_variant'): vals[row.get('story_variant')]=max(vals.get(row.get('story_variant'),0),1)
    if not vals: return 'uncategorised'
    return max(vals.items(), key=lambda kv: kv[1])[0]

def score_band(score):
    try: score=float(score)
    except Exception: return 'unknown'
    if score>=48: return 'spectacular'
    if score>=43: return 'strong'
    if score>=37: return 'useful'
    if score>=25: return 'review'
    return 'weak'

def read_inputs(root):
    root=Path(root)
    candidates=[
        root/'outputs'/'suits_processor_v16_2_1_cinematic_song_story',
        root/'outputs'/'suits_processor_v16_2_1_cinematic_song_story_smoke',
        Path('/mnt/data')
    ]
    def load_from(names, default):
        for base in candidates:
            for name in names:
                p=base/name
                if p.exists(): return load_json(p, default), str(p)
        p=find_first(root, names)
        if p: return load_json(p, default), str(p)
        return default, ''
    music, music_src = load_from(['music_profile.json'], [])
    videos, video_src = load_from(['video_profile.json'], [])
    matches, match_src = load_from(['song_video_match_plan.json'], [])
    stories, story_src = load_from(['song_story_plan.json','webui_song_story_index.json'], {})
    if isinstance(stories, list): stories={'items':stories}
    return {'music':music,'videos':videos,'matches':matches,'stories':stories,
            'sources':{'music':music_src,'videos':video_src,'matches':match_src,'stories':story_src}}

def build_event_chains(matches, max_rows=3000):
    chains=[]
    for i,m in enumerate(matches[:max_rows]):
        variant=m.get('story_variant') or 'predation_pressure'
        score=float(m.get('match_score') or 0)
        chain_id=sid(f"chain:{m.get('song_id')}:{m.get('video_id')}:{m.get('story_rank')}:{variant}")
        steps=[]
        if variant=='shot_fired': steps=['cue_pressure','aim_or_set_piece','shot_fired_candidate','impact_or_payoff','title_release']
        elif variant=='hit_confirmed': steps=['cue_build','contact_moment','hit_confirmed_candidate','reaction_or_collapse','aftermath_cut']
        elif variant=='comedy_blunder': steps=['setup','overconfidence','bad_timing','blunder','laugh_release']
        elif variant=='dark_aftermath': steps=['ominous_open','slow_pressure','loss_or_cost','silence_or_hangtime','aftermath_title']
        elif variant=='graphic_intensity_review': steps=['warning_context','pressure','intensity_peak','review_gate','aftermath']
        else: steps=['establish_route','predation_pressure','constraint_or_chase','turning_point','outcome']
        chains.append({
            'chain_id':chain_id,
            'rank':i+1,
            'song_id':m.get('song_id',''), 'song_name':m.get('song_name',''), 'song_path':m.get('song_path',''),
            'video_id':m.get('video_id',''), 'video_name':m.get('video_name',''), 'video_path':m.get('video_path',''),
            'story_variant':variant, 'suggested_use':m.get('suggested_use',''), 'match_score':score,
            'score_band':score_band(score), 'render_slug':m.get('render_slug',''), 'steps':steps,
            'objective':'spectacular_full_movie' if m.get('suggested_use')=='full_song_story' else '29s_trailer_or_variant',
            'key_result_areas':['identity','pressure','action','story clarity','music sync','reviewability']
        })
    return chains

def summarize(music, videos, matches, chains):
    story_counts={}; use_counts={}; band_counts={}; video_tones={}; song_tones={}
    for m in matches:
        story_counts[m.get('story_variant','unknown')]=story_counts.get(m.get('story_variant','unknown'),0)+1
        use_counts[m.get('suggested_use','unknown')]=use_counts.get(m.get('suggested_use','unknown'),0)+1
        band_counts[score_band(m.get('match_score'))]=band_counts.get(score_band(m.get('match_score')),0)+1
    for v in videos:
        t=tone_from_row(v); video_tones[t]=video_tones.get(t,0)+1
    for s in music:
        t=tone_from_row(s); song_tones[t]=song_tones.get(t,0)+1
    return {
        'schema':SCHEMA,'version':VERSION,'created_utc':now(),
        'counts':{'songs':len(music),'videos':len(videos),'matches':len(matches),'event_chains':len(chains)},
        'story_counts':story_counts,'use_counts':use_counts,'score_bands':band_counts,
        'video_tones':video_tones,'song_tones':song_tones,
        'top_matches':matches[:100], 'top_chains':chains[:100]
    }

def graph_data(music, videos, matches, chains, max_matches=1200):
    nodes=[]; edges=[]; seen=set()
    def node(nid,label,typ,**props):
        if nid in seen: return
        seen.add(nid); nodes.append({'id':nid,'label':label,'type':typ,**props})
    for s in music[:700]: node('song_'+s.get('asset_id',sid(s.get('path'))), s.get('name','song')[:90], 'song', duration_s=s.get('duration_s'), tone=tone_from_row(s))
    for v in videos[:700]: node('video_'+v.get('asset_id',sid(v.get('path'))), v.get('name','video')[:90], 'video', duration_s=v.get('duration_s'), tone=tone_from_row(v))
    for c in chains[:max_matches]:
        cid='chain_'+c['chain_id']; node(cid, c['story_variant'], 'event_chain', score=c['match_score'], use=c['suggested_use'])
        sidn='song_'+(c.get('song_id') or sid(c.get('song_path'))); vid='video_'+(c.get('video_id') or sid(c.get('video_path')))
        edges.append({'source':sidn,'target':cid,'type':'USES_SONG','weight':c['match_score']})
        edges.append({'source':cid,'target':vid,'type':'USES_VIDEO','weight':c['match_score']})
        tone='tone_'+c['story_variant']; node(tone,c['story_variant'],'tone')
        edges.append({'source':cid,'target':tone,'type':'EXPRESSES','weight':1})
    return nodes, edges

def write_csv(path, rows, fields):
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k:r.get(k,'') for k in fields})

def write_neo4j(out, nodes, edges):
    neo=Path(out)/'neo4j'; neo.mkdir(parents=True,exist_ok=True)
    write_csv(neo/'neo4j_nodes.csv', nodes, ['id','label','type','duration_s','tone','score','use'])
    write_csv(neo/'neo4j_edges.csv', edges, ['source','target','type','weight'])
    cypher="""
LOAD CSV WITH HEADERS FROM 'file:///neo4j_nodes.csv' AS row
MERGE (n:SuitsNode {id: row.id})
SET n.label=row.label, n.type=row.type, n.duration_s=row.duration_s, n.tone=row.tone, n.score=row.score, n.use=row.use;

LOAD CSV WITH HEADERS FROM 'file:///neo4j_edges.csv' AS row
MATCH (a:SuitsNode {id: row.source})
MATCH (b:SuitsNode {id: row.target})
CALL apoc.merge.relationship(a, row.type, {}, {weight: row.weight}, b, {}) YIELD rel
RETURN count(rel);
""".strip()+"\n"
    (neo/'suits_v16_3_import.cypher').write_text(cypher,encoding='utf-8')
    cypher2="""
LOAD CSV WITH HEADERS FROM 'file:///neo4j_nodes.csv' AS row
MERGE (n:SuitsNode {id: row.id})
SET n.label=row.label, n.type=row.type, n.duration_s=row.duration_s, n.tone=row.tone, n.score=row.score, n.use=row.use;

LOAD CSV WITH HEADERS FROM 'file:///neo4j_edges.csv' AS row
MATCH (a:SuitsNode {id: row.source})
MATCH (b:SuitsNode {id: row.target})
MERGE (a)-[r:RELATED_TO {edge_type: row.type}]->(b)
SET r.weight=row.weight;
""".strip()+"\n"
    (neo/'suits_v16_3_import_no_apoc.cypher').write_text(cypher2,encoding='utf-8')

def write_sql(out, music, videos, matches, chains):
    sql=Path(out)/'sql'; sql.mkdir(parents=True,exist_ok=True)
    db=Path(out)/'suits_v16_3_webui.sqlite3'
    conn=sqlite3.connect(db)
    c=conn.cursor()
    c.executescript('''
CREATE TABLE IF NOT EXISTS song(asset_id TEXT PRIMARY KEY,name TEXT,path TEXT,duration_s REAL,tone TEXT,term_score REAL);
CREATE TABLE IF NOT EXISTS video(asset_id TEXT PRIMARY KEY,name TEXT,path TEXT,duration_s REAL,tone TEXT,term_score REAL);
CREATE TABLE IF NOT EXISTS match_plan(match_id TEXT PRIMARY KEY,song_id TEXT,video_id TEXT,story_variant TEXT,suggested_use TEXT,match_score REAL,render_slug TEXT);
CREATE TABLE IF NOT EXISTS event_chain(chain_id TEXT PRIMARY KEY,song_id TEXT,video_id TEXT,story_variant TEXT,suggested_use TEXT,match_score REAL,steps_json TEXT,objective TEXT);
CREATE TABLE IF NOT EXISTS human_feedback(feedback_id TEXT PRIMARY KEY,chain_id TEXT,human_score REAL,human_label TEXT,human_note TEXT,accepted INTEGER,created_utc TEXT);
''')
    for s in music:
        c.execute('INSERT OR REPLACE INTO song VALUES(?,?,?,?,?,?)',(s.get('asset_id',sid(s.get('path'))),s.get('name',''),s.get('path',''),s.get('duration_s'),tone_from_row(s),s.get('term_score')))
    for v in videos:
        c.execute('INSERT OR REPLACE INTO video VALUES(?,?,?,?,?,?)',(v.get('asset_id',sid(v.get('path'))),v.get('name',''),v.get('path',''),v.get('duration_s'),tone_from_row(v),v.get('term_score')))
    for m in matches:
        mid=sid(json.dumps(m,sort_keys=True,ensure_ascii=False)); c.execute('INSERT OR REPLACE INTO match_plan VALUES(?,?,?,?,?,?,?)',(mid,m.get('song_id'),m.get('video_id'),m.get('story_variant'),m.get('suggested_use'),m.get('match_score'),m.get('render_slug')))
    for ch in chains:
        c.execute('INSERT OR REPLACE INTO event_chain VALUES(?,?,?,?,?,?,?,?)',(ch['chain_id'],ch['song_id'],ch['video_id'],ch['story_variant'],ch['suggested_use'],ch['match_score'],json.dumps(ch['steps']),ch['objective']))
    conn.commit(); conn.close()
    (sql/'suits_v16_3_schema.sql').write_text('\n'.join(conn.iterdump()) if False else 'See sqlite database suits_v16_3_webui.sqlite3\n',encoding='utf-8')
    # CSVs
    write_csv(sql/'event_chains.csv', chains, ['chain_id','rank','song_name','video_name','story_variant','suggested_use','match_score','score_band','render_slug','objective'])

def write_html_report(out, summary):
    top=summary['top_chains'][:50]
    rows=''.join(f"<tr><td>{c['match_score']}</td><td>{html.escape(c['story_variant'])}</td><td>{html.escape(c['song_name'][:80])}</td><td>{html.escape(c['video_name'][:80])}</td><td>{html.escape(c['suggested_use'])}</td></tr>" for c in top)
    h=f"""<!doctype html><html><head><meta charset='utf-8'><title>$uits v16.3 report</title><style>body{{background:#07111f;color:#e8f4ff;font-family:Arial}}.wrap{{max-width:1300px;margin:30px auto}}.card{{background:#0d1b2f;border:1px solid #284766;border-radius:16px;padding:18px;margin:14px 0}}th,td{{border-bottom:1px solid #243b54;padding:8px;text-align:left}}table{{width:100%;border-collapse:collapse}}h1{{color:#9dd7ff}}</style></head><body><div class='wrap'><h1>[o][o] $uits v16.3 Spectacular WebUI Report</h1><div class='card'>Songs: {summary['counts']['songs']} &nbsp; Videos: {summary['counts']['videos']} &nbsp; Matches: {summary['counts']['matches']} &nbsp; Chains: {summary['counts']['event_chains']}</div><div class='card'><h2>Top event chains</h2><table><tr><th>Score</th><th>Story</th><th>Song</th><th>Video</th><th>Use</th></tr>{rows}</table></div></div></body></html>"""
    Path(out,'suits_v16_3_report.html').write_text(h,encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default=DEFAULT_ROOT); ap.add_argument('--site',default=DEFAULT_SITE); ap.add_argument('--out',default=DEFAULT_OUT)
    ap.add_argument('--build-neo4j',action='store_true'); ap.add_argument('--build-webui',action='store_true'); ap.add_argument('--build-sql',action='store_true'); ap.add_argument('--build-review',action='store_true')
    ap.add_argument('--limit-matches',type=int,default=1000000)
    args=ap.parse_args()
    print('[o][o] $uits Processor v16.3.0')
    print('SCRIPT=suits_spectacular_webui_builder_v16_3.py')
    print('SCHEMA='+SCHEMA)
    print('ROOT='+args.root); print('SITE='+args.site); print('OUT='+args.out)
    Path(args.out).mkdir(parents=True,exist_ok=True)
    data=read_inputs(args.root)
    music=data['music']; videos=data['videos']; matches=data['matches'][:args.limit_matches]
    chains=build_event_chains(matches)
    summary=summarize(music,videos,matches,chains); summary['sources']=data['sources']
    data_dir=Path(args.site)/'data'/'suits_v16_3'
    data_dir.mkdir(parents=True,exist_ok=True)
    nodes,edges=graph_data(music,videos,matches,chains)
    for name,obj in [('summary.json',summary),('music_profile_index.json',music),('video_profile_index.json',videos),('song_video_match_index.json',matches),('event_chains.json',chains),('graph_nodes.json',nodes),('graph_edges.json',edges)]:
        (Path(args.out)/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
        (data_dir/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
    write_html_report(args.out, summary)
    if args.build_neo4j: write_neo4j(args.out,nodes,edges)
    if args.build_sql: write_sql(args.out,music,videos,matches,chains)
    print('[o][o] wrote WebUI data:', data_dir)
    print('[o][o] report:', Path(args.out)/'suits_v16_3_report.html')
if __name__=='__main__': main()
