#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 suits_media_director_v8.py \
  --song-preset bat_out_of_hell_disciples \
  --duration-mode full \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/bat_out_of_hell_disciples_full "$@"
