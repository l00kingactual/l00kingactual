#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 suits_media_director_v8.py \
  --song-preset hells_bells_disciples \
  --duration-mode clip29 \
  --clip-seconds 29 \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/hells_bells_disciples_29s "$@"
