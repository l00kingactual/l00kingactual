# $uits Media Director v8

Local-first fictional GTA/FiveM / machinima media director.

Boundary: predation, Sun Tzu, Janus, humour, tactics, kills, prey and predator are editorial/media-analysis tags for fictional GTARP / FiveM / machinima footage. They are not real-world conduct guidance.

## What changed in this build

This build no longer imports from Downloads. It uses the actual project directories:

```text
/home/andy/Documents/suitsmafia/videos
/home/andy/Documents/suitsmafia/videos/disciples
/home/andy/Documents/suitsmafia/videos/disciples/youtube
/home/andy/Documents/suitsmafia/videos/suits_youtube
/home/andy/Documents/suitsmafia/videos/youtube
/home/andy/Documents/suitsmafia/music_mp4
```

Known song presets:

```text
good4u_suits
  /home/andy/Documents/suitsmafia/music_mp4/good_4_u.webm
  video project: suits

shoot_to_thrill_suits
  /home/andy/Documents/suitsmafia/music_mp4/Shoot to Thrill [wLoWd2KyUro].webm
  video project: suits

bat_out_of_hell_disciples
  /home/andy/Documents/suitsmafia/music_mp4/Meat Loaf - Bat Out of Hell (PCM Stereo) [3QGMCSCFoKA].webm
  video project: disciples

hells_bells_disciples
  /home/andy/Documents/suitsmafia/music_mp4/Hells Bells.webm
  video project: disciples
```

If you do not yet have `Hells Bells.webm`, that preset will scan the Disciples videos but may show zero music assets until you add the file or pass `--music-file` manually.

## Install cleanly

If the ZIP unpacks as `suits_media_director_v8_package/suits_media_director_v8`, run:

```bash
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8_package/suits_media_director_v8
./install_to_py_script.sh
```

Then use:

```bash
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8
./run_webui.sh
```

## WebUI

```bash
./run_webui.sh
```

Open:

```text
http://127.0.0.1:8788
```

The WebUI scans all project video folders and the music folder, then generates both full-track and 29-second planning outputs.

## One-at-a-time runners

29-second social edit plans:

```bash
./run_good4u_suits_29s.sh
./run_shoot_to_thrill_suits_29s.sh
./run_bat_out_of_hell_disciples_29s.sh
./run_hells_bells_disciples_29s.sh
```

Full-length music plans:

```bash
./run_good4u_suits_full.sh
./run_shoot_to_thrill_suits_full.sh
./run_bat_out_of_hell_disciples_full.sh
./run_hells_bells_disciples_full.sh
```

All three named songs, both 29s and full:

```bash
./run_three_songs_both.sh
```

Add `--render` to any runner to create sample MP4 clips and PNG stills if FFmpeg is installed:

```bash
./run_shoot_to_thrill_suits_29s.sh --render
```

## Direct switch examples

Good 4 U, Suits Mafia, 29s:

```bash
python3 suits_media_director_v8.py \
  --song-preset good4u_suits \
  --duration-mode clip29 \
  --clip-seconds 29 \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/good4u_suits_29s
```

Shoot to Thrill, Suits Mafia, full length:

```bash
python3 suits_media_director_v8.py \
  --song-preset shoot_to_thrill_suits \
  --duration-mode full \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/shoot_to_thrill_suits_full
```

Bat Out of Hell, Disciples, 29s:

```bash
python3 suits_media_director_v8.py \
  --song-preset bat_out_of_hell_disciples \
  --duration-mode clip29 \
  --clip-seconds 29 \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/bat_out_of_hell_disciples_29s
```

Manual Hells Bells path:

```bash
python3 suits_media_director_v8.py \
  --project disciples \
  --music-file '/home/andy/Documents/suitsmafia/music_mp4/Hells Bells [YOUR_ID].webm' \
  --duration-mode full \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/hells_bells_disciples_full
```

## Core switches

```text
--video-dir       Repeatable video folder scanner.
--video-file      Repeatable exact video file.
--video-playlist  Repeatable txt/m3u/csv/json video playlist.
--music-dir       Repeatable music folder scanner.
--music-file      Repeatable exact music file.
--music-playlist  Repeatable txt/m3u/csv/json music playlist.
--song-preset     good4u_suits | shoot_to_thrill_suits | bat_out_of_hell_disciples | hells_bells_disciples.
--project         all | suits | disciples.
--duration-mode   full | clip29 | both.
--clip-seconds    Defaults to 29.
--mode            full-track | timings | batch.
--timings         Inline cue windows, for example: 0-13=intro,13-31=build.
--timing-json     Cue sheet JSON.
--out             Output directory.
--render          Optional FFmpeg sample clips/stills.
--webui           Start local WebUI.
--print-switches  Print switch dictionary.
```

## Outputs

Each run writes:

```text
media_dictionary.json
video_assets.json
music_assets.json
video_assets.csv
music_assets.csv
edit_plan.json
cue_match_plan.json
cue_match_plan.csv
run_manifest.json
curated_music_cue_report.html
renders/clips/*.mp4      only with --render
renders/stills/*.png     only with --render
```

## Song intent

`good4u_suits`: sharp, funny, panic turns, lyric irony, social clips.

`shoot_to_thrill_suits`: swagger, action chains, controlled burst, spectacular timing.

`bat_out_of_hell_disciples`: long narrative, road/route pressure, chase, epic aftermath.

`hells_bells_disciples`: ominous, ambush, territory, strategic pressure, aftermath control.
