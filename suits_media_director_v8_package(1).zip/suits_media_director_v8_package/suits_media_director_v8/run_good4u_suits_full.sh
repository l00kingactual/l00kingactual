#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 suits_media_director_v8.py \
  --song-preset good4u_suits \
  --duration-mode full \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/good4u_suits_full "$@"
