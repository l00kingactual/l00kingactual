#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT_DIR="${OUT_DIR:-/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_metadata_guided_full}"
SERVER_LOG_DIR="${SERVER_LOG_DIR:-/home/andy/Documents/suitsmafia/server_logs}"
CLIENT_LOG_DIR="${CLIENT_LOG_DIR:-/home/andy/Documents/suitsmafia/client_logs}"
mkdir -p "$OUT_DIR"
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --reuse-previous \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
  --foreground-model \
  --foreground-model-mode metadata_guided_delta \
  --server-log-dir "$SERVER_LOG_DIR" \
  --client-log-dir "$CLIENT_LOG_DIR" \
  --render \
  --out "$OUT_DIR"
