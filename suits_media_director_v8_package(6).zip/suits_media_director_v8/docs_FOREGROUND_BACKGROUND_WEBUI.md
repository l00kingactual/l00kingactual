# 🌌 Foreground / Background Predation Model + WebUI Controls

Boundary: fictional GTA/FiveM / machinima media analysis. Predation, prey, kills, gore, tactics and strategy are editorial/media-analysis labels, not real-world guidance.

## Core idea

Pixels alone are only bright dots, black play, colour, and motion. Accuracy improves when the script has an expectation of what the background *should* look like, then scores what changes in the foreground.

Astronomy analogy:

| Astronomy | Video analysis |
|---|---|
| Star image pixels | Game-frame pixels |
| Gaia/JWST catalogue | Previous run metadata, server logs, cue plans |
| RA/Dec coordinates | Frame x/y, centre patch, HUD region, route/world position |
| Proper motion | Player/vehicle movement vectors |
| Brightness/colour | muzzle flash, red proxy, fire, HUD signal |
| Object catalogue | known clip, event, player, weapon, cue match |

The script writes `foreground_background_model.json` to record which assets are likely to contain meaningful foreground action.

## Signals

- `centre_pixel_change`: central aim/shotline area changes rapidly.
- `frame_difference_above_background`: foreground motion differs from expected static scene.
- `red_impact_or_blood_proxy`: red-heavy change suggests hit/blood/impact review.
- `muzzle_flash_or_bright_impulse`: brief flash/bright event.
- `motion_vector_change`: route break, aim break, vehicle/path disruption.
- `route_deviation`: player/vehicle begins moving predictably or erratically.
- `server_or_client_event_alignment`: FiveM truth layer supports the video signal.

## WebUI controls

The WebUI includes:

- select all / unselect all videos
- select all / unselect all music
- checkboxes for predation/event labels
- checkboxes for prey behaviour types
- checkboxes for comedy classifications
- render button with mouseover title text
- links to foreground model, server logs, client logs, report, dictionary and cue plan

## Server/client logs

Use:

```bash
--server-log-dir /home/andy/Documents/suitsmafia/server_logs
--client-log-dir /home/andy/Documents/suitsmafia/client_logs
```

The scanner currently indexes JSON, JSONL, CSV, LOG and TXT files and counts hints for kills, damage, projectiles, explosions, player connect/drop and resources. Later strict schemas can replace hints.

## Useful switches

```bash
--foreground-model
--foreground-model-mode metadata_guided_delta
--background-sample-step 5
--centre-patch-fraction 0.18
--red-proxy-threshold 0.18
--movement-detection frame_delta
--reuse-previous
--previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8
--server-log-dir /home/andy/Documents/suitsmafia/server_logs
--client-log-dir /home/andy/Documents/suitsmafia/client_logs
--selected-label kill_candidate
--selected-label team_play
--prey-type route_prey
--comedy-class funny
```

## Doctrine

The background tells the machine what is normal. The foreground tells it what changed. The metadata tells it whether that change is interesting. The beat tells it where to place it.

[o][o]: Static stars in the back, chaos in the front.
