#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT_DIR="${OUT_DIR:-/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8}"
SERVER_LOG_DIR="${SERVER_LOG_DIR:-/home/andy/Documents/suitsmafia/server_logs}"
CLIENT_LOG_DIR="${CLIENT_LOG_DIR:-/home/andy/Documents/suitsmafia/client_logs}"
UPLOAD_DIR="${UPLOAD_DIR:-/home/andy/Documents/suitsmafia/upload}"
mkdir -p "$OUT_DIR"
echo '$uits Media Director v8 Advanced WebUI: http://127.0.0.1:8788'
echo "Outputs: $OUT_DIR"
echo "Server logs: $SERVER_LOG_DIR"
echo "Client logs: $CLIENT_LOG_DIR"
python3 suits_media_director_v8.py \
  --video-dir /home/andy/Documents/suitsmafia/videos \
  --video-dir /home/andy/Documents/suitsmafia/videos/disciples \
  --video-dir /home/andy/Documents/suitsmafia/videos/disciples/youtube \
  --video-dir /home/andy/Documents/suitsmafia/videos/suits_youtube \
  --video-dir /home/andy/Documents/suitsmafia/videos/youtube \
  --music-dir /home/andy/Documents/suitsmafia/music_mp4 \
  --upload-dir "$UPLOAD_DIR" \
  --duration-mode both \
  --analysis-depth patient \
  --reuse-previous \
  --previous-out-dir "$OUT_DIR" \
  --foreground-model \
  --foreground-model-mode metadata_guided_delta \
  --server-log-dir "$SERVER_LOG_DIR" \
  --client-log-dir "$CLIENT_LOG_DIR" \
  --out "$OUT_DIR" \
  --webui
