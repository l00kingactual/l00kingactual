(function(){
"use strict";

window.addEventListener("error", function(e){
  const box = document.getElementById("v6MathErrors");
  if (box) box.textContent += "\n" + e.message + " @ " + e.filename + ":" + e.lineno;
});

const D = window.SPACE_WALES_V5_DATA || {};
const M = window.SpaceWalesV6Math;
const $ = id => document.getElementById(id);
const money = n => n >= 1e9 ? "£"+(n/1e9).toFixed(2)+"bn" : n >= 1e6 ? "£"+(n/1e6).toFixed(1)+"m" : "£"+Math.round(n).toLocaleString();

let pheromone = {};
let predator = {prey:80, predator:20, preyGrowth:1.1, predation:.018, predatorDeath:.65, predatorEfficiency:.011};
let particles = Array.from({length:24}, () => ({position:[Math.random(),Math.random(),Math.random()], velocity:[0,0,0]}));
let lastResult = null;

function headings(){
  return D.allocations || D.headings || [
    {id:"education", name:"Education", icon:"🏫", annual_gbp:350000000, value:90, pct:14},
    {id:"health", name:"Health", icon:"🩺", annual_gbp:275000000, value:88, pct:11},
    {id:"transport", name:"Transport", icon:"🚌", annual_gbp:200000000, value:80, pct:8},
    {id:"agrarian", name:"Agrarian", icon:"🌾", annual_gbp:250000000, value:84, pct:10},
    {id:"spacegis", name:"Space/GIS", icon:"🛰️", annual_gbp:150000000, value:80, pct:6},
    {id:"animals", name:"Animals", icon:"🐑", annual_gbp:100000000, value:74, pct:4}
  ];
}

function hives(){
  return (D.hives || []).filter(h => typeof h.lat === "number" && typeof h.lon === "number");
}

function projects(){
  return headings().map((h,i) => ({
    id:h.id,
    label:(h.icon||"•")+" "+(h.name||h.id),
    cost:Math.max(500000, Math.round((h.annual_gbp || 2500000000*(h.pct||5)/100 || 100000000) * (.02 + (i%5)*.006))),
    value:(h.value || 60) + (i%4)*5,
    risk:(i%7)/14
  }));
}

function assets(){
  const hs = hives();
  if (hs.length) return hs.map((h,i)=>({id:h.id,label:(h.icon||"•")+" "+h.name,lat:h.lat,lon:h.lon,type:h.type,people:1000+i*4000,risk:.35+(i%6)*.08,value:70+(i%5)*5}));
  return projects().map((p,i)=>({id:p.id,label:p.label,lat:51.5+i*.12,lon:-4.8+i*.15,type:p.id,people:1000+i*3500,risk:.45,value:p.value}));
}

function stations(){
  return assets().map((a,i)=>({id:"station_"+a.id,label:"🚑 "+(a.label||a.id)+" response hub",lat:a.lat,lon:a.lon,cost:1_100_000+(i%6)*520_000,readiness:.72+(i%5)*.045}));
}

function localCap(){
  const ps = projects();
  return Math.min(75_000_000, Math.max(2_000_000, ps.slice(0,6).reduce((a,p)=>a+p.cost,0)*.85));
}

function drawBars(rows,title){
  const c = $("v6MathCanvas");
  if (!c) return;
  const ctx = c.getContext("2d");
  const w = c.width, h = c.height;
  ctx.clearRect(0,0,w,h);
  const bg = ctx.createLinearGradient(0,0,0,h);
  bg.addColorStop(0,"#081426");
  bg.addColorStop(1,"#101c2f");
  ctx.fillStyle = bg;
  ctx.fillRect(0,0,w,h);
  ctx.fillStyle = "#facc15";
  ctx.font = "24px system-ui";
  ctx.textAlign = "left";
  ctx.fillText(title,36,38);
  const max = Math.max(...rows.map(r=>r.value),1);
  rows.slice(0,18).forEach((r,i)=>{
    const y = 76 + i*((h-115)/Math.min(18,rows.length || 1));
    const bw = (w-250)*(r.value/max);
    const g = ctx.createLinearGradient(46,y,46+bw,y);
    g.addColorStop(0,"#39d5ff");
    g.addColorStop(.62,"#facc15");
    g.addColorStop(1,"#4ade80");
    ctx.fillStyle = g;
    ctx.fillRect(46,y,bw,14);
    ctx.fillStyle = "#eaf2ff";
    ctx.font = "12px system-ui";
    ctx.textAlign = "left";
    ctx.fillText(r.label,46,y-5);
    ctx.fillStyle = "#facc15";
    ctx.textAlign = "right";
    ctx.fillText(r.fmt || Math.round(r.value),w-36,y+13);
  });
}

function progress(label,value,txt){
  return `<div class="barrow"><strong>${label}</strong><span class="bar"><i style="width:${Math.max(1,Math.min(100,value))}%"></i></span><span>${txt}</span></div>`;
}

function renderResult(result, title){
  lastResult = result;
  const rows = [];
  if (result.knapsack) rows.push({label:"🧮 knapsack value", value:result.knapsack.value/4, fmt:result.knapsack.selectedIds.length+" items"});
  if (result.subset) rows.push({label:"🧩 subset spend", value:result.subset.spend/localCap()*100, fmt:money(result.subset.spend)});
  if (result.coverage) rows.push({label:"🚑 coverage", value:result.coverage.coveragePct, fmt:result.coverage.coveragePct+"%"});
  if (result.aco) rows.push({label:"🐜 ACO route", value:Math.max(1,100-result.aco.lengthKm/8), fmt:result.aco.lengthKm+" km"});
  if (result.bco) rows.push({label:"🐝 BCO top", value:result.bco[0]?.bees || 0, fmt:(result.bco[0]?.bees||0)+" bees"});
  if (result.pso) rows.push({label:"🦅 PSO best", value:result.pso.globalBest.score*100, fmt:result.pso.globalBest.score.toFixed(3)});
  if (result.predatorPrey) rows.push({label:"🦊 ecology balance", value:result.predatorPrey.balance, fmt:result.predatorPrey.balance+"/100"});
  if (result.pruning) rows.push({label:"🧬 pruning depth", value:result.pruning.depth*10, fmt:"depth "+result.pruning.depth});
  if (result.roi) rows.push({label:"£ ROI", value:Math.min(100,result.roi.multiple*18), fmt:result.roi.multiple+"x"});
  drawBars(rows, title || "V6 advanced mathematics");
  const metrics = $("v6MathMetrics");
  if (metrics) metrics.innerHTML = rows.map(r=>progress(r.label,r.value,r.fmt)).join("");
  const out = $("v6MathOut");
  if (out) out.textContent = JSON.stringify(result, null, 2);
}

function runAll(){
  const ps = projects(), as = assets(), st = stations(), cap = localCap();
  const knapsack = M.knapsack(ps, cap);
  const subset = M.subsetSumNear(ps, cap);
  const coverage = M.coverage(as, st, cap, {thresholdMinutes:18, speedKmh:52, turnoutMinutes:2});
  const aco = M.acoRoute(as, pheromone, {start:as[0]?.id});
  pheromone = aco.pheromone || {};
  const bco = M.bcoAllocate(ps, 100);
  const psoFull = M.psoStep(particles, pos => Math.min(1,.42*pos[0]+.36*pos[1]+.22*pos[2]-Math.abs(pos[0]-pos[1])*.08));
  particles = psoFull.particles;
  predator = M.predatorPreyStep(predator, .045);
  const pruning = M.fractalPruneScore({
    urgency:Number($("v6Urgency")?.value || .55),
    risk:Number($("v6Risk")?.value || .45),
    zoom:Number($("v6Zoom")?.value || .6),
    roi:Number($("v6RoiWeight")?.value || .7),
    mandelX:-.745 + Math.sin(Date.now()/5000)*.02,
    mandelY:.113 + Math.cos(Date.now()/6000)*.02
  });
  const roi = M.composeROI({
    finance:knapsack.value/3,
    access:coverage.valuePct,
    skills:(bco[0]?.bees || 0)*2,
    ecology:predator.balance,
    resilience:pruning.depth*10,
    enterprise:60,
    time:Math.max(1,100-aco.lengthKm/8)
  });
  renderResult({knapsack, subset, coverage, aco, bco, pso:{algorithm:psoFull.algorithm, globalBest:psoFull.globalBest}, predatorPrey:predator, pruning, roi}, "V6 advanced mathematics engine");
}

function runKnapsack(){
  const ps = projects(), cap = localCap();
  renderResult({knapsack:M.knapsack(ps,cap), subset:M.subsetSumNear(ps,cap), projects:ps}, "Knapsack + subset sum");
}
function runCoverage(){
  renderResult({coverage:M.coverage(assets(),stations(),localCap(),{thresholdMinutes:18,speedKmh:52,turnoutMinutes:2})}, "Coverage optimiser");
}
function runSwarm(){
  const as = assets(), ps = projects();
  const aco = M.acoRoute(as, pheromone, {start:as[0]?.id});
  pheromone = aco.pheromone || {};
  const bco = M.bcoAllocate(ps,100);
  const psoFull = M.psoStep(particles, pos => Math.min(1,.42*pos[0]+.36*pos[1]+.22*pos[2]));
  particles = psoFull.particles;
  renderResult({aco,bco,pso:{algorithm:psoFull.algorithm, globalBest:psoFull.globalBest}}, "ACO / BCO / PSO swarm maths");
}
function runEcology(){
  predator = M.predatorPreyStep(predator,.045);
  const pruning = M.fractalPruneScore({urgency:Number($("v6Urgency")?.value || .55),risk:Number($("v6Risk")?.value || .45),zoom:Number($("v6Zoom")?.value || .6),roi:Number($("v6RoiWeight")?.value || .7)});
  renderResult({predatorPrey:predator, pruning}, "Predator/prey + fractal pruning");
}

function savePng(){
  const c = $("v6MathCanvas");
  if (!c) return;
  const a = document.createElement("a");
  a.href = c.toDataURL("image/png");
  a.download = "cymru_hive_os_v6_advanced_math_chart.png";
  a.click();
}
function exportJson(){
  const payload = {version:"6.0-advanced-fixed", generatedAt:new Date().toISOString(), result:lastResult};
  const blob = new Blob([JSON.stringify(payload,null,2)], {type:"application/json"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "cymru_hive_os_v6_advanced_math_result.json";
  a.click();
  URL.revokeObjectURL(a.href);
}

function bind(){
  const map = {
    v6RunAll:runAll, v6RunKnapsack:runKnapsack, v6RunCoverage:runCoverage,
    v6RunSwarm:runSwarm, v6RunEcology:runEcology, v6SavePng:savePng, v6ExportJson:exportJson
  };
  Object.entries(map).forEach(([id,fn]) => { const el = $(id); if (el) el.onclick = fn; });
  ["v6Urgency","v6Risk","v6Zoom","v6RoiWeight"].forEach(id => { const el = $(id); if (el) el.oninput = runAll; });
  setTimeout(runAll, 350);
}
document.addEventListener("DOMContentLoaded", bind);
})();