// Cymru Hive OS V6 Advanced Fixed · JS math registry
MERGE (m:MathEngine {id:'cymru_hive_os_v6_math', version:'6.0-advanced-fixed', file:'assets/js/v6_math_engine.js'});
UNWIND [
 ['knapsack','optimisation'],
 ['subset_sum_near','optimisation'],
 ['coverage','emergency/access'],
 ['aco_route','swarm'],
 ['bco_allocate','swarm'],
 ['pso_step','swarm'],
 ['predator_prey_step','ecology'],
 ['fractal_prune_score','behaviour-tree'],
 ['compose_roi','roi']
] AS row
MERGE (f:MathFunction {id:row[0], category:row[1]})
WITH f
MATCH (m:MathEngine {id:'cymru_hive_os_v6_math'})
MERGE (m)-[:IMPLEMENTS]->(f);
