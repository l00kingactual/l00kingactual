-- Cymru Hive OS V6 Advanced Fixed · JS math registry
CREATE TABLE IF NOT EXISTS v6_js_math_function (
  function_id TEXT PRIMARY KEY,
  category TEXT,
  description TEXT,
  file_path TEXT
);
INSERT INTO v6_js_math_function VALUES ('knapsack','optimisation','0/1 dynamic-programming budget/value optimiser','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('subset_sum_near','optimisation','near-target budget packing','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('coverage','emergency/access','greedy maximal coverage over civic/farm hives','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('aco_route','swarm','pheromone route construction','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('bco_allocate','swarm','colony allocation by nectar score','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('pso_step','swarm','particle-swarm update','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('predator_prey_step','ecology','Lotka-Volterra style difference update','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('fractal_prune_score','behaviour-tree','Mandelbrot-informed pruning depth','assets/js/v6_math_engine.js');
INSERT INTO v6_js_math_function VALUES ('compose_roi','roi','weighted public-value ROI multiple','assets/js/v6_math_engine.js');
