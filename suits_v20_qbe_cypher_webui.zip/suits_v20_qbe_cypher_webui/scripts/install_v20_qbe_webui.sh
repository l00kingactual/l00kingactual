#!/usr/bin/env bash
set -euo pipefail
SUITS_ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
SITE_ROOT="${SUITS_SITE_ROOT:-$SUITS_ROOT/susitsmafia_website}"
WEB_OUT="$SITE_ROOT/v20_qbe"
TOOLS="$SUITS_ROOT/tools"
mkdir -p "$WEB_OUT" "$TOOLS"
cp -a web/. "$WEB_OUT/"
cat > "$TOOLS/suits_v20_launch_qbe_webui" <<LAUNCH
#!/usr/bin/env bash
set -euo pipefail
cd "$WEB_OUT"
php -S 0.0.0.0:\${SUITS_QBE_PORT:-8097}
LAUNCH
chmod +x "$TOOLS/suits_v20_launch_qbe_webui"
echo "[o][o] installed v20 QBE WebUI to $WEB_OUT"
echo "[o][o] launch: $TOOLS/suits_v20_launch_qbe_webui"
