# [o][o] $uits v20 QBE + Cypher WebUI

This package turns the v19 atomic graph outputs into a browser query workbench.

It expects the v19 scan outputs here by default:

`/home/andy/Documents/suitsmafia/outputs/suits_v19_atomic_graph`

Main features:

- SQLite 3NF table browser
- Query By Example (QBE) form
- Safe preset SQL queries
- Neo4j Cypher entry form
- Iconed graph table/JSON view
- Optional Neo4j HTTP query runner
- Local launch script

## Install

```bash
cd ~/Downloads
unzip -o suits_v20_qbe_cypher_webui.zip
cd suits_v20_qbe_cypher_webui
chmod +x scripts/*.sh
./scripts/install_v20_qbe_webui.sh
```

## Launch

```bash
/home/andy/Documents/suitsmafia/tools/suits_v20_launch_qbe_webui
```

Open:

`http://127.0.0.1:8097/suits_v20_dashboard.php`

## VPS launch

```bash
cd /home/andy/Documents/suitsmafia/susitsmafia_website/v20_qbe
php -S 0.0.0.0:8097
```

Open:

`http://217.154.62.118:8097/suits_v20_dashboard.php`

## Neo4j optional config

The Cypher page can generate Cypher without credentials. To execute queries against Neo4j HTTP, set environment variables before launch:

```bash
export SUITS_NEO4J_HTTP=http://127.0.0.1:7474/db/neo4j/tx/commit
export SUITS_NEO4J_USER=neo4j
export SUITS_NEO4J_PASS='your-password'
```

Keep Neo4j local/VPN-only unless you deliberately secure it.
