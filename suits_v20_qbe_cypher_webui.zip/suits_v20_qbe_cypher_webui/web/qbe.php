<?php require_once __DIR__.'/config.php'; header_html('🔎 Query By Example'); $pdo=db(); if(!$pdo){echo '<div class="card">Missing DB: '.h(db_path()).'</div>'; footer_html(); exit;} 
$table=safe_table($_GET['table']??'source_file'); $columns=cols($pdo,$table); $where=[]; $params=[];
foreach($columns as $col){ $val=trim($_GET[$col]??''); if($val!==''){ $where[]="$col LIKE ?"; $params[]='%'.$val.'%'; }}
$sql='SELECT * FROM '.$table; if($where)$sql.=' WHERE '.implode(' AND ',$where); $sql.=' LIMIT 200';
?>
<div class="card"><form method="get"><label>Table </label><select name="table" onchange="this.form.submit()">
<?php foreach(['source_file','source_file_group','entity','attribute','relationship','event'] as $t){echo '<option '.($t===$table?'selected':'').' value="'.h($t).'">'.h($t).'</option>'; }?>
</select><div class="grid">
<?php foreach($columns as $col){ $v=$_GET[$col]??''; echo '<label>'.h($col).'<br><input name="'.h($col).'" value="'.h($v).'" placeholder="contains..."></label>'; } ?>
</div><p><button class="btn">🔎 Search</button> <a href="qbe.php?table=<?=h($table)?>">Reset</a></p></form></div>
<div class="card"><h2>SQL generated</h2><pre><?=h($sql)?></pre></div>
<div class="card"><h2>Results</h2><?php $st=$pdo->prepare($sql); $st->execute($params); render_table($st->fetchAll(PDO::FETCH_ASSOC)); ?></div>
<?php footer_html(); ?>
