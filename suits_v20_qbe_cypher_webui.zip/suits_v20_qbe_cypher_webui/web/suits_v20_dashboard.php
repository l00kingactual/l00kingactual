<?php require_once __DIR__.'/config.php'; header_html('$uits v20 QBE + Cypher WebUI');
$pdo = db();
$summary = v19_out().'/summary.json';
$data = file_exists($summary) ? json_decode(file_get_contents($summary), true) : null;
?>
<div class="card">
<h2>🧬 Data source</h2>
<p><span class="pill">Root: <?=h(suits_root())?></span></p>
<p><span class="pill">v19 out: <?=h(v19_out())?></span></p>
<p><span class="pill">SQLite: <?=h(db_path())?></span></p>
<p><span class="pill">DB status: <?=$pdo?'✅ found':'❌ missing'?></span></p>
</div>
<?php if ($data): $c=$data['counts']??[]; $k=$data['kind_counts']??[]; ?>
<div class="grid">
<?php foreach ([['📦','assets'],['🧩','entities'],['🏷️','attributes'],['🔗','relationships'],['🔥','events'],['🗂️','groups']] as $it): ?>
<div class="card"><h2><?=$it[0]?> <?=h($it[1])?></h2><p style="font-size:28px"><?=number_format($c[$it[1]]??0)?></p></div>
<?php endforeach; ?>
</div>
<div class="card"><h2>📁 Kind counts</h2><?php foreach ($k as $name=>$cnt) echo '<span class="pill">'.h(icon_for($name).' '.$name.' '.number_format($cnt)).'</span>'; ?></div>
<div class="card"><h2>🗂️ Top groups</h2><table><tr><th>Group</th><th>Files</th></tr><?php foreach(array_slice($data['top_groups']??[],0,30) as $g){echo '<tr><td>'.h(icon_for($g[0]).' '.$g[0]).'</td><td>'.number_format($g[1]).'</td></tr>'; }?></table></div>
<?php else: ?>
<div class="card"><h2>⚠️ No summary found</h2><p>Run v19 atomic graph builder first or set SUITS_V19_OUT.</p></div>
<?php endif; footer_html(); ?>
