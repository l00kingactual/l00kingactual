<?php require_once __DIR__.'/config.php'; header_html('📊 SQL presets'); $pdo=db(); if(!$pdo){echo '<div class="card">Missing DB: '.h(db_path()).'</div>'; footer_html(); exit;}
$presets=[
'kind_counts'=>"SELECT kind, COUNT(*) AS count FROM source_file GROUP BY kind ORDER BY count DESC",
'top_groups'=>"SELECT group_name, file_count FROM source_file_group ORDER BY file_count DESC LIMIT 50",
'top_attributes'=>"SELECT key, COUNT(*) AS count FROM attribute GROUP BY key ORDER BY count DESC LIMIT 50",
'animal_classes'=>"SELECT value AS animal_class, COUNT(*) AS count FROM attribute WHERE key='animal_class' GROUP BY value ORDER BY count DESC",
'event_types'=>"SELECT event_type, COUNT(*) AS count FROM event GROUP BY event_type ORDER BY count DESC LIMIT 50",
'relationship_types'=>"SELECT rel_type, COUNT(*) AS count FROM relationship GROUP BY rel_type ORDER BY count DESC LIMIT 50",
'large_files'=>"SELECT path, kind, size_bytes FROM source_file ORDER BY size_bytes DESC LIMIT 100"
];
$p=$_GET['preset']??'kind_counts'; if(!isset($presets[$p]))$p='kind_counts';
?>
<div class="card"><?php foreach($presets as $name=>$sql){echo '<a class="pill" href="?preset='.h($name).'">'.h(icon_for($name).' '.$name).'</a>'; } ?></div>
<div class="card"><h2><?=h($p)?></h2><pre><?=h($presets[$p])?></pre><?php render_table($pdo->query($presets[$p])->fetchAll(PDO::FETCH_ASSOC)); ?></div>
<?php footer_html(); ?>
