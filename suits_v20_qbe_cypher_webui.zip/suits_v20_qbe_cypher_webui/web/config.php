<?php
function suits_root() {
    return getenv('SUITS_ROOT') ?: '/home/andy/Documents/suitsmafia';
}
function v19_out() {
    return getenv('SUITS_V19_OUT') ?: suits_root() . '/outputs/suits_v19_atomic_graph';
}
function db_path() {
    return getenv('SUITS_V19_DB') ?: v19_out() . '/suits_v19_atomic_3nf.sqlite3';
}
function csv_dir() {
    return v19_out() . '/csv_3nf';
}
function neo4j_dir() {
    return v19_out() . '/neo4j';
}
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function db() {
    $path = db_path();
    if (!file_exists($path)) return null;
    $pdo = new PDO('sqlite:' . $path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;
}
function table_exists($pdo, $table) {
    $stmt = $pdo->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?");
    $stmt->execute([$table]);
    return (bool)$stmt->fetchColumn();
}
function cols($pdo, $table) {
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $rows = $pdo->query("PRAGMA table_info($safe)")->fetchAll(PDO::FETCH_ASSOC);
    return array_map(fn($r) => $r['name'], $rows);
}
function safe_table($table) {
    $allow = ['source_file','source_file_group','entity','attribute','relationship','event'];
    return in_array($table, $allow, true) ? $table : 'source_file';
}
function icon_for($s) {
    $s = strtolower((string)$s);
    if (str_contains($s,'lion')) return '🦁';
    if (str_contains($s,'hawk') || str_contains($s,'eagle')) return '🦅';
    if (str_contains($s,'raven')) return '🐦‍⬛';
    if (str_contains($s,'owl')) return '🦉';
    if (str_contains($s,'wolf')) return '🐺';
    if (str_contains($s,'tiger')) return '🐯';
    if (str_contains($s,'shark')) return '🦈';
    if (str_contains($s,'crocodile')) return '🐊';
    if (str_contains($s,'fox')) return '🦊';
    if (str_contains($s,'spider')) return '🕷️';
    if (str_contains($s,'sheep')) return '🐑';
    if (str_contains($s,'goat')) return '🐐';
    if (str_contains($s,'duck')) return '🦆';
    if (str_contains($s,'swan')) return '🦢';
    if (str_contains($s,'comedy')) return '😂';
    if (str_contains($s,'video') || str_contains($s,'.mp4') || str_contains($s,'.mkv') || str_contains($s,'.webm')) return '🎥';
    if (str_contains($s,'audio') || str_contains($s,'.mp3') || str_contains($s,'.wav')) return '🎵';
    if (str_contains($s,'image') || str_contains($s,'.png') || str_contains($s,'.jpg')) return '🖼️';
    if (str_contains($s,'script') || str_contains($s,'.py') || str_contains($s,'.sh')) return '🐍';
    if (str_contains($s,'event')) return '🔥';
    if (str_contains($s,'graph')) return '🕸️';
    return '🧩';
}
function header_html($title) {
    echo "<!doctype html><html><head><meta charset='utf-8'><title>".h($title)."</title>";
    echo "<style>body{font-family:system-ui;background:#07111f;color:#dbeafe;margin:0;padding:24px}a{color:#93c5fd;text-decoration:none}nav a{margin-right:14px}.card{background:#0f1e33;border:1px solid #1d3558;border-radius:16px;padding:18px;margin:14px 0}table{border-collapse:collapse;width:100%;background:#09172a}th,td{padding:7px 10px;border-bottom:1px solid #243956;vertical-align:top;font-size:13px}th{background:#10213a;text-align:left}.pill{display:inline-block;background:#172a46;border:1px solid #35517a;border-radius:999px;padding:4px 8px;margin:2px}input,select,textarea{background:#09172a;color:#dbeafe;border:1px solid #35517a;border-radius:8px;padding:8px}textarea{width:100%;min-height:140px}.btn{background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;cursor:pointer}pre{white-space:pre-wrap;background:#09172a;padding:12px;border-radius:12px;overflow:auto}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}.node{display:inline-block;padding:7px 10px;margin:4px;background:#111f35;border:1px solid #314a6d;border-radius:12px}.edge{color:#93c5fd}</style></head><body>";
    echo "<h1>[o][o] ".h($title)."</h1><nav><a href='suits_v20_dashboard.php'>🏠 Dashboard</a><a href='qbe.php'>🔎 QBE</a><a href='sql_presets.php'>📊 SQL presets</a><a href='cypher.php'>🕸️ Cypher</a><a href='graph.php'>🎭 Icon graph</a></nav>";
}
function footer_html(){ echo "</body></html>"; }
function render_table($rows, $limit=200) {
    if (!$rows) { echo "<p>No rows.</p>"; return; }
    $rows = array_slice($rows, 0, $limit);
    $keys = array_keys($rows[0]);
    echo "<table><thead><tr>";
    foreach ($keys as $k) echo "<th>".h($k)."</th>";
    echo "</tr></thead><tbody>";
    foreach ($rows as $r) {
        echo "<tr>";
        foreach ($keys as $k) {
            $v = $r[$k] ?? '';
            echo "<td>".h(icon_for($v).' '.$v)."</td>";
        }
        echo "</tr>";
    }
    echo "</tbody></table>";
}
?>
