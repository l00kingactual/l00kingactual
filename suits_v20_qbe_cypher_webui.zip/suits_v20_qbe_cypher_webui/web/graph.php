<?php require_once __DIR__.'/config.php'; header_html('🎭 Iconed graph view');
$nodesFile=neo4j_dir().'/neo4j_nodes.csv'; $edgesFile=neo4j_dir().'/neo4j_edges.csv';
function read_csv_limited($file,$limit=80){ if(!file_exists($file))return []; $fh=fopen($file,'r'); $head=fgetcsv($fh); $rows=[]; while(($r=fgetcsv($fh))!==false && count($rows)<$limit){$rows[]=array_combine($head,$r);} fclose($fh); return $rows; }
$nodes=read_csv_limited($nodesFile,80); $edges=read_csv_limited($edgesFile,120);
?>
<div class="card"><h2>🕸️ Graph files</h2><p><span class="pill"><?=file_exists($nodesFile)?'✅':'❌'?> nodes <?=h($nodesFile)?></span></p><p><span class="pill"><?=file_exists($edgesFile)?'✅':'❌'?> edges <?=h($edgesFile)?></span></p></div>
<div class="card"><h2>🧩 Nodes</h2><?php foreach($nodes as $n){$label=$n['label']??$n['name']??$n['id']??json_encode($n); echo '<span class="node">'.h(icon_for($label).' '.$label).'</span>'; } ?></div>
<div class="card"><h2>🔗 Edges</h2><table><tr><th>Source</th><th>Rel</th><th>Target</th></tr><?php foreach($edges as $e){$s=$e['source']??$e['start']??$e['from']??''; $r=$e['rel']??$e['type']??$e['relationship']??''; $t=$e['target']??$e['end']??$e['to']??''; echo '<tr><td>'.h(icon_for($s).' '.$s).'</td><td class="edge">'.h($r).'</td><td>'.h(icon_for($t).' '.$t).'</td></tr>'; } ?></table></div>
<div class="card"><h2>JSON mini graph</h2><pre><?php echo h(json_encode(['nodes'=>array_slice($nodes,0,20),'edges'=>array_slice($edges,0,30)],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)); ?></pre></div>
<?php footer_html(); ?>
