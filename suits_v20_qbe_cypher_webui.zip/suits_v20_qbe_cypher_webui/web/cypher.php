<?php require_once __DIR__.'/config.php'; header_html('🕸️ Cypher query entry');
$examples=[
'MATCH (n) RETURN labels(n) AS labels, count(n) AS count ORDER BY count DESC LIMIT 25',
'MATCH (a)-[r]->(b) RETURN a.id AS source, type(r) AS rel, b.id AS target LIMIT 100',
'MATCH (n) WHERE toLower(coalesce(n.label,n.name,n.id,"")) CONTAINS "lion" RETURN n LIMIT 50',
'MATCH (n)-[r]->(m) WHERE toLower(type(r)) CONTAINS "classified" RETURN n,r,m LIMIT 100'
];
$q=$_POST['cypher']??$examples[0]; $result=null; $err=null;
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['run'])){
  $url=getenv('SUITS_NEO4J_HTTP'); $user=getenv('SUITS_NEO4J_USER'); $pass=getenv('SUITS_NEO4J_PASS');
  if(!$url||!$user||!$pass){ $err='Neo4j execution not configured. Set SUITS_NEO4J_HTTP, SUITS_NEO4J_USER, SUITS_NEO4J_PASS. You can still copy the Cypher.'; }
  else{
    $payload=json_encode(['statements'=>[['statement'=>$q,'resultDataContents'=>['row','graph']]]]);
    $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_USERPWD=>$user.':'.$pass,CURLOPT_POSTFIELDS=>$payload]);
    $out=curl_exec($ch); if($out===false)$err=curl_error($ch); else $result=json_decode($out,true); curl_close($ch);
  }
}
?>
<div class="card"><h2>Examples</h2><?php foreach($examples as $ex){echo '<form method="post" style="display:inline"><input type="hidden" name="cypher" value="'.h($ex).'"><button class="btn" style="margin:3px">'.h(substr($ex,0,48)).'...</button></form>'; } ?></div>
<div class="card"><form method="post"><textarea name="cypher"><?=h($q)?></textarea><p><button class="btn" name="run" value="1">▶️ Run if Neo4j configured</button></p></form></div>
<?php if($err): ?><div class="card"><h2>⚠️ Notice</h2><pre><?=h($err)?></pre></div><?php endif; ?>
<?php if($result): ?><div class="card"><h2>Result JSON</h2><pre><?=h(json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre></div><?php endif; ?>
<div class="card"><h2>Import files</h2><p><span class="pill">Neo4j dir: <?=h(neo4j_dir())?></span></p><pre>:source suits_v19_import.cypher
:source suits_v19_import_no_apoc.cypher</pre></div>
<?php footer_html(); ?>
