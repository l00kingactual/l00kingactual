# Cymru V6 diagnostics patch

Copy `diagnostics.html` into your existing `cymru_hive_os_v6_advanced_fixed_webui/` folder, replacing the old diagnostics page.

```bash
cp diagnostics.html ~/Documents/cymru_v6_clean_test/cymru_hive_os_v6_advanced_fixed_webui/diagnostics.html
```

Then refresh:

```text
http://127.0.0.1:8099/diagnostics.html
```
