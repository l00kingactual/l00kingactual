#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Final Grade GTA/FiveM Predation Studio
======================================

Offline-first FastAPI WebUI for fictional GTA/FiveM gameplay-film analytics.

Boundary: this is fictional gameplay / machinima / media-asset analysis. It is
not real-world tactical guidance. Terms such as predation, prey, kill, shot,
team play, poach, and chain refer to in-game media events and cinematic review.

Core guarantees:
- Always runs with Python + FastAPI. OpenCV, NumPy, ffmpeg, pytesseract are optional.
- Focuses on video evidence first; audio is treated mostly as music/beat context.
- Supports file selection, add/remove playlists, playlist JSON save/load.
- Adds ground-truth layers from manual labels, FiveM/server logs, and optional OCR.
- Exports curated webpage assets: quality over quantity.
- Exports 3NF/ACID SQLite + Postgres SQL and Neo4j Cypher outputs.
"""

from __future__ import annotations

import argparse
import csv
import html
import json
import math
import os
import re
import shutil
import statistics
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import cv2  # type: ignore
except Exception:
    cv2 = None  # type: ignore

try:
    import numpy as np  # type: ignore
except Exception:
    np = None  # type: ignore

try:
    import pytesseract  # type: ignore
except Exception:
    pytesseract = None  # type: ignore

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel, Field

VIDEO_EXTS = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"}
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".webm"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".apng", ".gif"}
LABEL_EXTS = {".csv", ".json"}
MEDIA_EXTS = VIDEO_EXTS | AUDIO_EXTS | IMAGE_EXTS | LABEL_EXTS
APP_TITLE = "Final Grade GTA/FiveM Predation Studio"

app = FastAPI(title=APP_TITLE)
JOBS: Dict[str, Dict[str, Any]] = {}
PLAYLISTS: Dict[str, Dict[str, Any]] = {}


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def clamp01(x: float) -> float:
    try:
        if math.isnan(x) or math.isinf(x):
            return 0.0
    except Exception:
        return 0.0
    return max(0.0, min(1.0, float(x)))


def sigmoid(x: float, k: float = 1.0, centre: float = 0.0) -> float:
    z = max(-60.0, min(60.0, k * (float(x) - centre)))
    return 1.0 / (1.0 + math.exp(-z))


def safe_slug(text: str, max_len: int = 96) -> str:
    text = re.sub(r"\[[A-Za-z0-9_-]{6,24}\]$", "", text)
    text = re.sub(r"[^A-Za-z0-9]+", "_", text.strip().lower())
    text = re.sub(r"_+", "_", text).strip("_")
    return (text[:max_len].strip("_") or "asset")


def qsql(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"


def ffmpeg_drawtext_escape(text: str) -> str:
    """Escape text for a simple ffmpeg drawtext filter.

    We keep captions short and robust because these are production labels, not
    long transcripts.
    """
    text = str(text).replace("\n", "  ")
    text = re.sub(r"[^#A-Za-z0-9 .,_/+&()–—:-]", "", text)
    text = text[:120]
    return (text
            .replace("\\", "\\\\")
            .replace(":", "\\:")
            .replace("'", "\\'")
            .replace("%", "\\%"))


def ffprobe_json(path: Path) -> Dict[str, Any]:
    if shutil.which("ffprobe") is None:
        return {"probe_ok": False, "error": "ffprobe not found"}
    cmd = [
        "ffprobe", "-v", "error", "-show_entries",
        "format=duration,size:stream=index,codec_type,codec_name,width,height,r_frame_rate,avg_frame_rate",
        "-of", "json", str(path),
    ]
    try:
        return json.loads(subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT))
    except Exception as exc:
        return {"probe_ok": False, "error": str(exc)}


def parse_fraction(x: str) -> float:
    try:
        if "/" in x:
            a, b = x.split("/", 1)
            return float(a) / max(float(b), 1e-12)
        return float(x)
    except Exception:
        return 0.0


def media_metadata(path: Path) -> Dict[str, Any]:
    path = path.expanduser().resolve()
    suffix = path.suffix.lower()
    data = ffprobe_json(path) if suffix in VIDEO_EXTS | AUDIO_EXTS else {}
    duration = 0.0
    width = 0
    height = 0
    fps = 0.0
    has_video = False
    has_audio = False
    video_codec = ""
    audio_codec = ""
    if "format" in data:
        duration = float(data.get("format", {}).get("duration") or 0.0)
        for st in data.get("streams", []):
            if st.get("codec_type") == "video" and not has_video:
                has_video = True
                width = int(st.get("width") or 0)
                height = int(st.get("height") or 0)
                fps = parse_fraction(st.get("avg_frame_rate") or st.get("r_frame_rate") or "0/1")
                video_codec = st.get("codec_name", "")
            if st.get("codec_type") == "audio" and not has_audio:
                has_audio = True
                audio_codec = st.get("codec_name", "")
    return {
        "asset_id": uuid.uuid5(uuid.NAMESPACE_URL, str(path)).hex[:16],
        "path": str(path),
        "name": path.name,
        "suffix": suffix,
        "kind": "video" if suffix in VIDEO_EXTS else "audio" if suffix in AUDIO_EXTS else "image" if suffix in IMAGE_EXTS else "label" if suffix in LABEL_EXTS else "file",
        "size_mb": round(path.stat().st_size / (1024 * 1024), 3) if path.exists() else 0.0,
        "duration": round(duration, 3),
        "fps": round(fps, 3),
        "width": width,
        "height": height,
        "has_video": has_video,
        "has_audio": has_audio,
        "video_codec": video_codec,
        "audio_codec": audio_codec,
        "probe_ok": bool("format" in data),
        "probe_error": data.get("error", ""),
    }


def scan_folder(folder: Path, recursive: bool = True) -> List[Dict[str, Any]]:
    folder = folder.expanduser().resolve()
    if not folder.exists():
        raise FileNotFoundError(folder)
    globber = folder.rglob("*") if recursive else folder.glob("*")
    assets = []
    for p in sorted(globber):
        if p.is_file() and p.suffix.lower() in MEDIA_EXTS:
            assets.append(media_metadata(p))
    return assets


@dataclass
class GroundTruthItem:
    truth_id: str
    source: str
    source_kind: str
    timestamp: float
    start: float
    end: float
    event_type: str
    confidence: float
    killer: str = ""
    victim: str = ""
    weapon: str = ""
    note: str = ""


@dataclass
class EventRecord:
    event_id: str
    media_id: str
    source_file: str
    start: float
    end: float
    peak_time: float
    duration: float
    event_type: str
    score: float
    confidence: float
    ground_truth_level: str
    channels: Dict[str, float] = field(default_factory=dict)
    metrics: Dict[str, Any] = field(default_factory=dict)
    labels: Dict[str, str] = field(default_factory=dict)
    outputs: Dict[str, str] = field(default_factory=dict)
    cort60: Dict[str, Any] = field(default_factory=dict)


def robust_norm(values: List[float]) -> List[float]:
    if not values:
        return []
    vals = [float(v) for v in values]
    try:
        lo = statistics.quantiles(vals, n=20)[0]
        hi = statistics.quantiles(vals, n=20)[-1]
    except Exception:
        lo, hi = min(vals), max(vals)
    if abs(hi - lo) < 1e-12:
        return [0.0 for _ in vals]
    return [clamp01((v - lo) / (hi - lo)) for v in vals]


def moving_average(vals: List[float], radius: int = 2) -> List[float]:
    if not vals:
        return []
    out = []
    for i in range(len(vals)):
        a, b = max(0, i - radius), min(len(vals), i + radius + 1)
        out.append(sum(vals[a:b]) / max(1, b - a))
    return out


def compute_video_timeline(video: Path, sample_fps: float = 4.0, max_seconds: float = 0.0) -> List[Dict[str, Any]]:
    """Video-first feature extraction. Works best with cv2; returns sparse fallback if unavailable."""
    meta = media_metadata(video)
    duration = float(meta.get("duration") or 0.0)
    if cv2 is None or np is None:
        # Always-run fallback: event guesses from duration thirds; no visual certainty.
        times = [0.1 * duration, 0.35 * duration, 0.6 * duration, 0.85 * duration] if duration else [0, 10, 20]
        return [{"t": max(0.0, t), "L": 0.0, "M": 0.0, "R": 0.0, "X": 0.0, "H": 0.0, "C": 0.0, "P": 0.0, "SV": 0.0, "B": 0.0, "video_only_confidence": 0.10} for t in times]

    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened():
        return []
    fps = cap.get(cv2.CAP_PROP_FPS) or float(meta.get("fps") or 30.0) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if max_seconds > 0:
        total_frames = min(total_frames, int(max_seconds * fps))
    step = max(1, int(round(fps / max(sample_fps, 0.2))))
    rows: List[Dict[str, Any]] = []
    prev_gray = None
    prev_centre = None
    idx = 0
    while idx < total_frames:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, frame = cap.read()
        if not ok:
            break
        t = idx / fps
        small = cv2.resize(frame, (480, 270), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
        h, w = gray.shape
        cx0, cx1 = int(w * 0.40), int(w * 0.60)
        cy0, cy1 = int(h * 0.38), int(h * 0.62)
        centre = small[cy0:cy1, cx0:cx1]
        centre_gray = gray[cy0:cy1, cx0:cx1]
        b, g, r = cv2.split(small)
        cb, cg, cr = cv2.split(centre)
        red = np.maximum(r.astype("float32") - np.maximum(g, b).astype("float32"), 0.0)
        centre_red = np.maximum(cr.astype("float32") - np.maximum(cg, cb).astype("float32"), 0.0)
        R = float(np.mean(red) / 255.0)
        CR = float(np.mean(centre_red) / 255.0)
        L = 0.0
        M = 0.0
        CM = 0.0
        if prev_gray is not None:
            diff = cv2.absdiff(gray, prev_gray)
            M = float(np.mean(diff) / 255.0)
            L = float(np.mean(np.maximum(gray.astype("float32") - prev_gray.astype("float32"), 0.0)) / 255.0)
        if prev_centre is not None:
            CM = float(np.mean(cv2.absdiff(centre_gray, prev_centre)) / 255.0)
        edges = cv2.Canny(gray, 80, 170)
        centre_edges = edges[cy0:cy1, cx0:cx1]
        X = clamp01(float(np.mean(centre_edges > 0)) * 6.0 + L * 1.2)
        H = clamp01(0.40 * X + 0.35 * CR * 6.0 + 0.25 * CM * 5.0)
        # Cover/proximity heuristic: edge density in bottom/margins.
        left = float(np.mean(edges[:, : int(w * 0.18)] > 0))
        right = float(np.mean(edges[:, int(w * 0.82):] > 0))
        bottom = float(np.mean(edges[int(h * 0.74):, :] > 0))
        C = clamp01((left + right + bottom) * 2.8)
        # Player/prey proxy: vertical contours in central/mid area.
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        vertical = 0
        exposed = 0.0
        for c in contours[:200]:
            x, y, bw, bh = cv2.boundingRect(c)
            if bh > 20 and bw > 4 and bh / max(bw, 1) > 1.2:
                vertical += 1
                if int(w * 0.25) <= x <= int(w * 0.75):
                    exposed += 1
        P = clamp01(vertical / 10.0)
        SV = clamp01(exposed / 6.0 * (1.0 - 0.35 * C))
        rows.append({
            "t": round(t, 3), "L": L, "M": M, "CM": CM, "R": R, "CR": CR,
            "X": X, "H": H, "C": C, "P": P, "SV": SV,
            "video_only_confidence": 0.65,
        })
        prev_gray = gray
        prev_centre = centre_gray
        idx += step
    cap.release()

    # Smooth and normalise key signals.
    for key in ["L", "M", "CM", "R", "CR", "X", "H", "C", "P", "SV"]:
        vals = moving_average([float(r.get(key, 0.0)) for r in rows], radius=2)
        norm = robust_norm(vals)
        for row, val, nv in zip(rows, vals, norm):
            row[key + "_smooth"] = round(val, 6)
            row[key + "n"] = round(nv, 6)
    return rows


def pick_events_from_timeline(media: Dict[str, Any], timeline: List[Dict[str, Any]], max_events: int = 40) -> List[EventRecord]:
    if not timeline:
        return []
    candidates = []
    for r in timeline:
        hit = float(r.get("Hn", r.get("H", 0)))
        shotline = float(r.get("Xn", r.get("X", 0)))
        motion = float(r.get("Mn", r.get("M", 0)))
        red = float(r.get("CRn", r.get("R", 0)))
        cover = float(r.get("Cn", r.get("C", 0)))
        prey = float(r.get("SVn", r.get("SV", 0)))
        # Audio deliberately absent/low: video-first model because music is common.
        kill = clamp01(0.35 * hit + 0.25 * shotline + 0.20 * red + 0.20 * prey)
        graphic = clamp01(0.55 * red + 0.25 * hit + 0.20 * motion)
        dramatic = clamp01(0.25 * kill + 0.20 * motion + 0.20 * shotline + 0.15 * cover + 0.10 * graphic + 0.10 * prey)
        team = clamp01(0.45 * prey + 0.25 * motion + 0.15 * cover + 0.15 * shotline)
        chain = clamp01(0.30 * kill + 0.25 * shotline + 0.20 * prey + 0.15 * team + 0.10 * (1.0 - abs(red - hit)))
        funny = clamp01(0.25 * motion + 0.25 * prey + 0.20 * (1.0 - cover) + 0.15 * graphic + 0.15 * abs(red - shotline))
        candidates.append((dramatic, kill, graphic, team, funny, chain, r))
    candidates.sort(key=lambda x: x[0], reverse=True)
    # non-maximum suppression by time.
    selected: List[Tuple[float, float, float, float, float, float, Dict[str, Any]]] = []
    for cand in candidates:
        t = float(cand[-1].get("t", 0.0))
        if all(abs(t - float(s[-1].get("t", 0.0))) >= 3.0 for s in selected):
            selected.append(cand)
        if len(selected) >= max_events:
            break
    events: List[EventRecord] = []
    duration = float(media.get("duration") or 0.0)
    for i, (dramatic, kill, graphic, team, funny, chain, r) in enumerate(selected, start=1):
        peak = float(r.get("t", 0.0))
        start = max(0.0, peak - 2.0)
        end = min(duration if duration else peak + 3.0, peak + 3.0)
        if end <= start:
            end = start + 2.5
        event_type = "kill_chain_candidate" if chain > 0.72 else "graphic_predation_candidate" if graphic > 0.7 else "team_play_candidate" if team > 0.68 else "dramatic_predation_candidate"
        ch = {
            "HitKill": round(kill, 4), "GraphicIntensity": round(graphic, 4), "Dramatic": round(dramatic, 4),
            "TeamPlay": round(team, 4), "Humour": round(funny, 4), "ChainScore": round(chain, 4), "Shotline": round(float(r.get("Xn", 0)), 4),
            "MotionPanic": round(float(r.get("Mn", 0)), 4), "CoverAdvantage": round(float(r.get("Cn", 0)), 4),
            "PreyVulnerability": round(float(r.get("SVn", 0)), 4), "VideoConfidence": round(float(r.get("video_only_confidence", 0.4)), 4)
        }
        ev = EventRecord(
            event_id=f"event_{i:04d}_{peak:.2f}s",
            media_id=media["asset_id"], source_file=media["path"], start=round(start, 3), end=round(end, 3),
            peak_time=round(peak, 3), duration=round(end - start, 3), event_type=event_type,
            score=round(dramatic, 4), confidence=round(ch["VideoConfidence"], 4), ground_truth_level="video_inferred",
            channels=ch,
            metrics={
                "kill_score": round(kill, 4), "graphic_intensity": round(graphic, 4), "team_play_score": round(team, 4),
                "humour_score": round(funny, 4), "chain_score": round(chain, 4), "media_clarity": round(0.5 * ch["Shotline"] + 0.5 * ch["VideoConfidence"], 4),
                "quality_gate": round(0.30 * dramatic + 0.20 * kill + 0.15 * graphic + 0.15 * team + 0.10 * funny + 0.10 * ch["VideoConfidence"], 4),
                "marginal_tags": [],
            },
            labels={},
        )
        ev.cort60 = cort60_for_event(ev)
        events.append(ev)
    return events


def cort60_for_event(ev: EventRecord) -> Dict[str, Any]:
    ch = ev.channels
    causes = []
    if ch.get("PreyVulnerability", 0) > 0.55: causes.append("prey vulnerability")
    if ch.get("Shotline", 0) > 0.55: causes.append("shotline sense")
    if ch.get("CoverAdvantage", 0) > 0.55: causes.append("cover/control")
    if ch.get("TeamPlay", 0) > 0.55: causes.append("team pressure")
    if ch.get("GraphicIntensity", 0) > 0.55: causes.append("spectacle/graphic intensity")
    if ch.get("Humour", 0) > 0.55: causes.append("pattern-switch humour")
    if not causes: causes.append("uncertain but usable dramatic signal")
    fip = causes[0]
    return {
        "AGO": "Goal: identify a fictional gameplay predation moment worth editing, explaining, or publishing.",
        "CAF": causes,
        "FIP": fip,
        "APC": ["serious subtitle card", "funny pattern-switch card", "APNG loop", "still frame", "reject if unclear"],
        "C&S": "Consequence: decide whether this creates a chain, a punchline, or a curated webpage asset.",
        "OPV": ["predator/player", "prey/opponent", "team/assist", "viewer", "editor"],
        "PMI": {"plus": "readable media evidence", "minus": "video-inferred unless ground-truthed", "interesting": "candidate for CoRT60 subtitle"},
        "caption_serious": f"#FIP {fip} · #CAF {', '.join(causes[:3])}",
        "caption_funny": f"#Po pattern-switch · {fip} becomes the joke" if ch.get("Humour", 0) > 0.5 else f"#PMI interesting predation beat · {fip}",
    }


def load_truth_file(path: Optional[str], source_kind: str) -> List[GroundTruthItem]:
    if not path:
        return []
    p = Path(path).expanduser().resolve()
    if not p.exists():
        return []
    items: List[GroundTruthItem] = []
    try:
        if p.suffix.lower() == ".json":
            data = json.loads(p.read_text(encoding="utf-8"))
            rows = data if isinstance(data, list) else data.get("events", data.get("labels", []))
        else:
            with p.open("r", encoding="utf-8", newline="") as f:
                rows = list(csv.DictReader(f))
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            t = float(row.get("timestamp", row.get("time", row.get("peak_time", row.get("start", 0)))) or 0)
            start = float(row.get("start", max(0.0, t - 1.0)) or max(0.0, t - 1.0))
            end = float(row.get("end", t + 1.0) or t + 1.0)
            items.append(GroundTruthItem(
                truth_id=str(row.get("truth_id", f"{source_kind}_{i+1:04d}")),
                source=str(p), source_kind=source_kind, timestamp=t, start=start, end=end,
                event_type=str(row.get("event_type", row.get("type", "kill_or_event"))),
                confidence=clamp01(float(row.get("confidence", 0.90 if source_kind in {"manual", "server"} else 0.65) or 0.5)),
                killer=str(row.get("killer", row.get("player", ""))), victim=str(row.get("victim", "")),
                weapon=str(row.get("weapon", "")), note=str(row.get("note", row.get("comment", ""))),
            ))
    except Exception:
        return []
    return items


def merge_ground_truth(events: List[EventRecord], truth_items: List[GroundTruthItem]) -> None:
    for ev in events:
        matched: List[GroundTruthItem] = []
        for gt in truth_items:
            # Join by time. If labels are for source-level clips, this is adequate.
            overlap = max(0.0, min(ev.end, gt.end) - max(ev.start, gt.start))
            if overlap > 0 or abs(ev.peak_time - gt.timestamp) <= 2.0:
                matched.append(gt)
        if not matched:
            continue
        best = max(matched, key=lambda x: x.confidence)
        ev.confidence = round(max(ev.confidence, best.confidence), 4)
        if best.source_kind == "server":
            ev.ground_truth_level = "server_confirmed"
        elif best.source_kind == "manual":
            ev.ground_truth_level = "manual_confirmed"
        elif best.source_kind == "ocr":
            ev.ground_truth_level = "ocr_confirmed"
        ev.labels.update({
            "truth_event_type": best.event_type,
            "killer": best.killer,
            "victim": best.victim,
            "weapon": best.weapon,
            "truth_note": best.note,
        })
        ev.metrics["truth_boost"] = best.confidence
        ev.metrics["quality_gate"] = round(clamp01(float(ev.metrics.get("quality_gate", 0)) + 0.12 * best.confidence), 4)


def optional_ocr_truth(video: Path, enabled: bool, max_frames: int = 10) -> List[GroundTruthItem]:
    """Very conservative OCR hook. If tesseract is unavailable, returns empty."""
    if not enabled or pytesseract is None or cv2 is None:
        return []
    meta = media_metadata(video)
    dur = float(meta.get("duration") or 0)
    if dur <= 0:
        return []
    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened():
        return []
    items: List[GroundTruthItem] = []
    for i, t in enumerate([dur * (j + 1) / (max_frames + 1) for j in range(max_frames)]):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000.0)
        ok, frame = cap.read()
        if not ok:
            continue
        h, w = frame.shape[:2]
        # Common killfeed/HUD region: top-right. This is game/profile-dependent.
        crop = frame[0:int(h * 0.30), int(w * 0.55):w]
        try:
            text = pytesseract.image_to_string(crop, config="--psm 6")
        except Exception:
            text = ""
        if re.search(r"(killed|downed|eliminated|headshot|\bvs\b|\bkill\b)", text, flags=re.I):
            items.append(GroundTruthItem(
                truth_id=f"ocr_{i+1:04d}", source=str(video), source_kind="ocr", timestamp=t,
                start=max(0, t - 1.5), end=t + 1.5, event_type="ocr_killfeed_candidate",
                confidence=0.55, note=text.strip()[:180],
            ))
    cap.release()
    return items


def dedupe_select(events: List[EventRecord], key: str, limit: int, min_gap: float = 4.0) -> List[EventRecord]:
    ranked = sorted(events, key=lambda e: (float(e.metrics.get(key, e.channels.get(key, e.score)) or 0), float(e.metrics.get("quality_gate", 0))), reverse=True)
    out: List[EventRecord] = []
    seen_sources: Dict[str, int] = {}
    for ev in ranked:
        if any(ev.source_file == o.source_file and abs(ev.peak_time - o.peak_time) < min_gap for o in out):
            continue
        source_count = seen_sources.get(ev.source_file, 0)
        if source_count >= 3 and len(out) < limit:
            # Prefer diversity unless shortage.
            continue
        out.append(ev)
        seen_sources[ev.source_file] = source_count + 1
        if len(out) >= limit:
            break
    return out


def curate_assets(events: List[EventRecord], counts: Optional[Dict[str, int]] = None) -> Dict[str, List[EventRecord]]:
    """Quality-over-quantity selection with user-controlled asset counts.

    Counts are deliberately capped so the public webpage stays curated rather
    than becoming a noisy dump of every detected proxy event.
    """
    counts = counts or {}
    def n(key: str, default: int, cap: int = 24) -> int:
        try:
            return max(0, min(cap, int(counts.get(key, default))))
        except Exception:
            return default

    strong = [e for e in events if float(e.metrics.get("quality_gate", 0)) >= 0.35 or e.ground_truth_level != "video_inferred"]
    if not strong:
        strong = events
    return {
        f"top_{n('dramatic', 6)}_dramatic_clips": dedupe_select(strong, "dramatic_score", n("dramatic", 6)),
        f"top_{n('funny', 6)}_funny_clips": dedupe_select(strong, "humour_score", n("funny", 6)),
        f"top_{n('team_play', 6)}_team_play_clips": dedupe_select(strong, "team_play_score", n("team_play", 6)),
        f"top_{n('kill_chain', 6)}_kill_chain_clips": dedupe_select(strong, "chain_score", n("kill_chain", 6)),
        f"top_{n('graphic', 6)}_graphic_intensity_clips": dedupe_select(strong, "graphic_intensity", n("graphic", 6)),
        f"top_{n('still', 6)}_still_frames": dedupe_select(strong, "quality_gate", n("still", 6)),
        f"top_{n('apng', 6)}_apng_loops": dedupe_select(strong, "quality_gate", n("apng", 6)),
    }


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def ffmpeg_cut(src: str, start: float, duration: float, dst: Path, mute: bool = False, subtitle_text: str = "") -> bool:
    """Cut a clip, optionally burning a short CoRT60/kill comment subtitle.

    Duration is capped by the caller. The clean and subtitled variants can both
    be exported, so the webpage can offer professional/no-caption and social
    commentary versions.
    """
    if shutil.which("ffmpeg") is None:
        return False
    ensure_dir(dst.parent)
    cmd = ["ffmpeg", "-y", "-ss", f"{max(0,start):.3f}", "-t", f"{max(0.2,duration):.3f}", "-i", src]
    if subtitle_text:
        txt = ffmpeg_drawtext_escape(subtitle_text)
        vf = ("drawtext=text='" + txt + "':x=(w-text_w)/2:y=h-92:"
              "fontsize=28:fontcolor=white:box=1:boxcolor=black@0.62:boxborderw=12")
        cmd += ["-vf", vf]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23"]
    if mute:
        cmd += ["-an"]
    else:
        cmd += ["-c:a", "aac", "-b:a", "128k"]
    cmd += ["-movflags", "+faststart", str(dst)]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def ffmpeg_still(src: str, t: float, dst: Path) -> bool:
    if shutil.which("ffmpeg") is None:
        return False
    ensure_dir(dst.parent)
    try:
        subprocess.run(["ffmpeg", "-y", "-ss", f"{max(0,t):.3f}", "-i", src, "-frames:v", "1", "-q:v", "2", str(dst)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def ffmpeg_apng(src: str, start: float, duration: float, dst: Path) -> bool:
    if shutil.which("ffmpeg") is None:
        return False
    ensure_dir(dst.parent)
    try:
        subprocess.run(["ffmpeg", "-y", "-ss", f"{max(0,start):.3f}", "-t", f"{max(0.4,duration):.3f}", "-i", src, "-vf", "fps=8,scale=640:-1:flags=lanczos", "-plays", "0", str(dst)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def srt_time(seconds: float) -> str:
    seconds = max(0.0, seconds)
    hh = int(seconds // 3600)
    mm = int((seconds % 3600) // 60)
    ss = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)
    return f"{hh:02d}:{mm:02d}:{ss:02d},{ms:03d}"


def write_subtitles(events: List[EventRecord], path: Path, mode: str = "serious") -> None:
    lines: List[str] = []
    for i, ev in enumerate(sorted(events, key=lambda e: e.start), start=1):
        text = ev.cort60.get("caption_funny" if mode == "funny" else "caption_serious", "#CoRT60 predation beat")
        lines += [str(i), f"{srt_time(ev.start)} --> {srt_time(ev.end)}", text, ""]
    path.write_text("\n".join(lines), encoding="utf-8")


def write_html_report(output_dir: Path, media: List[Dict[str, Any]], all_events: List[EventRecord], curated: Dict[str, List[EventRecord]]) -> Path:
    cards = []
    for section, evs in curated.items():
        items = []
        for ev in evs:
            rel = ev.outputs.get("clip_mp4") or ev.outputs.get("still_png") or ""
            if rel:
                src = html.escape(Path(rel).name if Path(rel).parent == output_dir else rel)
                tag = f"<video controls preload='metadata' src='{src}'></video>" if rel.endswith(".mp4") else f"<img src='{src}' alt='still'>"
            else:
                tag = "<div class='missing'>No rendered asset; ffmpeg unavailable or export skipped.</div>"
            cap = html.escape(ev.cort60.get("caption_serious", "#CoRT60"))
            items.append(f"<article class='card'>{tag}<div class='pad'><h3>{html.escape(ev.event_id)}</h3><p>{cap}</p><div class='chips'><span>truth: {ev.ground_truth_level}</span><span>quality: {ev.metrics.get('quality_gate',0)}</span><span>dramatic: {ev.score}</span><span>funny: {ev.metrics.get('humour_score',0)}</span></div></div></article>")
        cards.append(f"<section><h2>{html.escape(section.replace('_',' ').title())}</h2><div class='grid'>{''.join(items)}</div></section>")
    manifest_link = "predation_manifest.json"
    html_doc = f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Final Grade Predation Report</title><style>
body{{background:#08101f;color:#edf6ff;font-family:system-ui;margin:0;padding:24px}}.hero{{background:#101a31;border:1px solid #25375c;border-radius:18px;padding:18px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px}}.card{{background:#111827;border:1px solid #374151;border-radius:16px;overflow:hidden}}video,img{{width:100%;display:block;background:#050912}}.pad{{padding:12px}}.chips span{{display:inline-block;border:1px solid #4b5563;border-radius:999px;padding:3px 8px;margin:2px;color:#bfdbfe}}a{{color:#7dd3fc}}.missing{{padding:40px;background:#050912;color:#9ca3af}}
</style></head><body><div class='hero'><h1>🎬 Final Grade Predation Studio Report</h1><p>Quality-over-quantity curated fictional GTA/FiveM media assets. Full ledger: <a href='{manifest_link}'>JSON manifest</a>.</p><p>Media scanned: {len(media)} · events: {len(all_events)}</p></div>{''.join(cards)}</body></html>"""
    path = output_dir / "final_grade_predation_report.html"
    path.write_text(html_doc, encoding="utf-8")
    return path


def write_sql_and_cypher(output_dir: Path, media: List[Dict[str, Any]], events: List[EventRecord], curated: Dict[str, List[EventRecord]]) -> Dict[str, str]:
    # Data insert files plus schema snapshots. Atomicity: BEGIN/COMMIT.
    sqlite_path = output_dir / "predation_3nf_acid_sqlite.sql"
    postgres_path = output_dir / "predation_3nf_acid_postgres.sql"
    cypher_path = output_dir / "predation_neo4j.cypher"

    schema = Path(__file__).parent / "schema" / "predation_3nf_acid_sqlite.sql"
    if schema.exists():
        base_sqlite = schema.read_text(encoding="utf-8")
    else:
        base_sqlite = SQLITE_SCHEMA
    pg_schema = Path(__file__).parent / "schema" / "predation_3nf_acid_postgres.sql"
    base_pg = pg_schema.read_text(encoding="utf-8") if pg_schema.exists() else POSTGRES_SCHEMA

    inserts = ["\nBEGIN TRANSACTION;\n"]
    for m in media:
        inserts.append("INSERT OR REPLACE INTO media_asset(media_id,path,name,kind,suffix,duration_seconds,width,height,fps,has_audio,created_at) VALUES "
                       f"({qsql(m['asset_id'])},{qsql(m['path'])},{qsql(m['name'])},{qsql(m['kind'])},{qsql(m['suffix'])},{float(m.get('duration') or 0)},{int(m.get('width') or 0)},{int(m.get('height') or 0)},{float(m.get('fps') or 0)},{1 if m.get('has_audio') else 0},{qsql(now_iso())});\n")
    for ev in events:
        inserts.append("INSERT OR REPLACE INTO predation_event(event_id,media_id,start_seconds,end_seconds,peak_seconds,event_type,score,confidence,ground_truth_level,created_at) VALUES "
                       f"({qsql(ev.event_id)},{qsql(ev.media_id)},{ev.start},{ev.end},{ev.peak_time},{qsql(ev.event_type)},{ev.score},{ev.confidence},{qsql(ev.ground_truth_level)},{qsql(now_iso())});\n")
        for k, v in ev.channels.items():
            inserts.append("INSERT OR REPLACE INTO event_metric(event_id,metric_name,metric_value,metric_group) VALUES "
                           f"({qsql(ev.event_id)},{qsql(k)},{float(v)},{qsql('channel')});\n")
        for k, v in ev.metrics.items():
            if isinstance(v, (int, float)):
                inserts.append("INSERT OR REPLACE INTO event_metric(event_id,metric_name,metric_value,metric_group) VALUES "
                               f"({qsql(ev.event_id)},{qsql(k)},{float(v)},{qsql('metric')});\n")
        inserts.append("INSERT OR REPLACE INTO cort60_card(event_id,ago,caf_json,fip,apc_json,cs,opv_json,pmi_json,caption_serious,caption_funny) VALUES "
                       f"({qsql(ev.event_id)},{qsql(ev.cort60.get('AGO',''))},{qsql(json.dumps(ev.cort60.get('CAF',[])))},{qsql(ev.cort60.get('FIP',''))},{qsql(json.dumps(ev.cort60.get('APC',[])))},{qsql(ev.cort60.get('C&S',''))},{qsql(json.dumps(ev.cort60.get('OPV',[])))},{qsql(json.dumps(ev.cort60.get('PMI',{})))},{qsql(ev.cort60.get('caption_serious',''))},{qsql(ev.cort60.get('caption_funny',''))});\n")
    for section, evs in curated.items():
        for rank, ev in enumerate(evs, start=1):
            inserts.append("INSERT INTO curated_asset(curated_set,event_id,rank,reason,created_at) VALUES "
                           f"({qsql(section)},{qsql(ev.event_id)},{rank},{qsql('quality over quantity selection')},{qsql(now_iso())});\n")
    inserts.append("COMMIT;\n")
    sqlite_path.write_text(base_sqlite + "\n" + "".join(inserts), encoding="utf-8")

    pg_inserts = ["\nBEGIN;\n"]
    for m in media:
        pg_inserts.append("INSERT INTO media_asset(media_id,path,name,kind,suffix,duration_seconds,width,height,fps,has_audio,created_at) VALUES "
                          f"({qsql(m['asset_id'])},{qsql(m['path'])},{qsql(m['name'])},{qsql(m['kind'])},{qsql(m['suffix'])},{float(m.get('duration') or 0)},{int(m.get('width') or 0)},{int(m.get('height') or 0)},{float(m.get('fps') or 0)},{'TRUE' if m.get('has_audio') else 'FALSE'},{qsql(now_iso())}) ON CONFLICT (media_id) DO NOTHING;\n")
    for ev in events:
        pg_inserts.append("INSERT INTO predation_event(event_id,media_id,start_seconds,end_seconds,peak_seconds,event_type,score,confidence,ground_truth_level,created_at) VALUES "
                          f"({qsql(ev.event_id)},{qsql(ev.media_id)},{ev.start},{ev.end},{ev.peak_time},{qsql(ev.event_type)},{ev.score},{ev.confidence},{qsql(ev.ground_truth_level)},{qsql(now_iso())}) ON CONFLICT (event_id) DO NOTHING;\n")
    pg_inserts.append("COMMIT;\n")
    postgres_path.write_text(base_pg + "\n" + "".join(pg_inserts), encoding="utf-8")

    cy = ["// Final Grade Predation Studio Neo4j import\nCREATE CONSTRAINT media_id IF NOT EXISTS FOR (m:MediaAsset) REQUIRE m.media_id IS UNIQUE;\nCREATE CONSTRAINT event_id IF NOT EXISTS FOR (e:PredationEvent) REQUIRE e.event_id IS UNIQUE;\n"]
    for m in media:
        cy.append(f"MERGE (m:MediaAsset {{media_id:{json.dumps(m['asset_id'])}}}) SET m.path={json.dumps(m['path'])}, m.name={json.dumps(m['name'])}, m.kind={json.dumps(m['kind'])};\n")
    for ev in events:
        cy.append(f"MERGE (e:PredationEvent {{event_id:{json.dumps(ev.event_id)}}}) SET e.start={ev.start}, e.end={ev.end}, e.peak={ev.peak_time}, e.type={json.dumps(ev.event_type)}, e.score={ev.score}, e.confidence={ev.confidence}, e.truth={json.dumps(ev.ground_truth_level)};\n")
        cy.append(f"MATCH (m:MediaAsset {{media_id:{json.dumps(ev.media_id)}}}), (e:PredationEvent {{event_id:{json.dumps(ev.event_id)}}}) MERGE (m)-[:HAS_EVENT]->(e);\n")
        for tag in ev.cort60.get("CAF", []):
            cy.append(f"MERGE (c:CoRTFactor {{name:{json.dumps(tag)}}}) WITH c MATCH (e:PredationEvent {{event_id:{json.dumps(ev.event_id)}}}) MERGE (e)-[:HAS_FACTOR]->(c);\n")
    for section, evs in curated.items():
        cy.append(f"MERGE (s:CuratedSet {{name:{json.dumps(section)}}});\n")
        for rank, ev in enumerate(evs, 1):
            cy.append(f"MATCH (s:CuratedSet {{name:{json.dumps(section)}}}), (e:PredationEvent {{event_id:{json.dumps(ev.event_id)}}}) MERGE (s)-[:SELECTS {{rank:{rank}}}]->(e);\n")
    cypher_path.write_text("".join(cy), encoding="utf-8")
    return {"sqlite_sql": str(sqlite_path), "postgres_sql": str(postgres_path), "neo4j_cypher": str(cypher_path)}


def process_playlist(req: Dict[str, Any], job_id: Optional[str] = None) -> Dict[str, Any]:
    files = [Path(p).expanduser().resolve() for p in req.get("files", [])]
    out = Path(req.get("output_folder") or "predation_outputs").expanduser().resolve()
    ensure_dir(out)
    sample_fps = float(req.get("sample_fps", 4.0))
    max_seconds = float(req.get("max_sample_seconds", 0.0))
    export_assets = bool(req.get("export_assets", True))
    ocr_enabled = bool(req.get("enable_ocr", False))
    counts = {
        "dramatic": int(req.get("dramatic_count", 6) or 0),
        "funny": int(req.get("funny_count", 3) or 0),
        "team_play": int(req.get("team_play_count", 6) or 0),
        "kill_chain": int(req.get("kill_chain_count", 6) or 0),
        "graphic": int(req.get("graphic_count", 6) or 0),
        "still": int(req.get("still_count", 6) or 0),
        "apng": int(req.get("apng_count", 6) or 0),
    }
    clip_duration_seconds = max(1.0, min(300.0, float(req.get("clip_duration_seconds", 8.0) or 8.0)))
    export_clean_mp4 = bool(req.get("export_clean_mp4", True))
    export_subtitled_mp4 = bool(req.get("export_subtitled_mp4", True))
    subtitle_kill_comments = bool(req.get("subtitle_kill_comments", True))
    mute_exported_clips = bool(req.get("mute_exported_clips", False))
    manual_labels = load_truth_file(req.get("manual_labels"), "manual")
    server_logs = load_truth_file(req.get("server_logs"), "server")

    media = [media_metadata(p) for p in files if p.exists()]
    events: List[EventRecord] = []
    def progress(p: int, msg: str) -> None:
        if job_id and job_id in JOBS:
            JOBS[job_id]["progress"] = p
            JOBS[job_id]["message"] = msg
            JOBS[job_id].setdefault("log", []).append({"progress": p, "message": msg, "time": now_iso()})

    videos = [p for p in files if p.suffix.lower() in VIDEO_EXTS and p.exists()]
    labels = [p for p in files if p.suffix.lower() in LABEL_EXTS and p.exists()]
    for label in labels:
        manual_labels += load_truth_file(str(label), "manual")

    for i, video in enumerate(videos, start=1):
        progress(int((i - 1) * 75 / max(1, len(videos))), f"Analysing video-first tensor {i}/{len(videos)}: {video.name}")
        m = media_metadata(video)
        timeline = compute_video_timeline(video, sample_fps=sample_fps, max_seconds=max_seconds)
        (out / f"timeline_{safe_slug(video.stem)}.json").write_text(json.dumps(timeline, indent=2), encoding="utf-8")
        evs = pick_events_from_timeline(m, timeline)
        truth = manual_labels + server_logs + optional_ocr_truth(video, ocr_enabled)
        merge_ground_truth(evs, truth)
        events.extend(evs)

    progress(78, "Curating quality-over-quantity assets")
    curated = curate_assets(events, counts)
    if export_assets:
        for section, evs in curated.items():
            for rank, ev in enumerate(evs, start=1):
                base = f"{section}_{rank:02d}_{safe_slug(ev.event_id)}"
                if "still" in section:
                    dst = out / f"{base}.jpg"
                    if ffmpeg_still(ev.source_file, ev.peak_time, dst):
                        ev.outputs["still_png"] = str(dst)
                elif "apng" in section:
                    dst = out / f"{base}.apng"
                    if ffmpeg_apng(ev.source_file, max(0, ev.peak_time - 1.5), min(clip_duration_seconds, 6.0), dst):
                        ev.outputs["apng"] = str(dst)
                else:
                    clip_start = max(0.0, ev.peak_time - clip_duration_seconds * 0.35)
                    if export_clean_mp4:
                        dst = out / f"{base}_clean.mp4"
                        if ffmpeg_cut(ev.source_file, clip_start, clip_duration_seconds, dst, mute=mute_exported_clips):
                            ev.outputs["clip_mp4"] = str(dst)
                            ev.outputs["clip_mp4_clean"] = str(dst)
                    if export_subtitled_mp4:
                        dst = out / f"{base}_subtitled.mp4"
                        sub = ev.cort60.get("caption_serious", "#CoRT60 predation beat") if subtitle_kill_comments else ""
                        if ffmpeg_cut(ev.source_file, clip_start, clip_duration_seconds, dst, mute=mute_exported_clips, subtitle_text=sub):
                            ev.outputs["clip_mp4_subtitled"] = str(dst)
                            if "clip_mp4" not in ev.outputs:
                                ev.outputs["clip_mp4"] = str(dst)
        # External subtitle files for players that support SRT.
        write_subtitles(events, out / "cort60_serious_subtitles.srt", mode="serious")
        write_subtitles(events, out / "cort60_funny_subtitles.srt", mode="funny")

    progress(88, "Writing SQL and Neo4j exports")
    db_paths = write_sql_and_cypher(out, media, events, curated)

    progress(94, "Writing reports and manifest")
    manifest = {
        "created_at": now_iso(),
        "boundary": "fictional GTA/FiveM gameplay-media analytics, not real-world tactical guidance",
        "analytics_grade": "final-grade architecture with video-inferred fallback; ground truth increases when OCR/server/manual labels supplied",
        "media": media,
        "events": [asdict(e) for e in events],
        "curated": {k: [e.event_id for e in v] for k, v in curated.items()},
        "ground_truth_inputs": {"manual_labels": req.get("manual_labels"), "server_logs": req.get("server_logs"), "ocr_enabled": ocr_enabled},
        "production_settings": {
            "counts": counts,
            "clip_duration_seconds": clip_duration_seconds,
            "export_clean_mp4": export_clean_mp4,
            "export_subtitled_mp4": export_subtitled_mp4,
            "subtitle_kill_comments": subtitle_kill_comments,
            "mute_exported_clips": mute_exported_clips,
            "music_file": req.get("music_file"),
            "autosync_music": bool(req.get("autosync_music", False)),
            "autosync_duration_seconds": float(req.get("autosync_duration_seconds", 480.0) or 480.0),
        },
        "outputs": db_paths,
    }
    manifest_path = out / "predation_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    report_path = write_html_report(out, media, events, curated)
    manifest["outputs"].update({"html_report": str(report_path), "json_manifest": str(manifest_path), "serious_srt": str(out / "cort60_serious_subtitles.srt"), "funny_srt": str(out / "cort60_funny_subtitles.srt")})
    progress(100, "Complete")
    return manifest


class ScanRequest(BaseModel):
    folder: str
    recursive: bool = True

class PlaylistCreateRequest(BaseModel):
    name: str = "playlist"

class PlaylistPatchRequest(BaseModel):
    playlist_id: str
    files: List[str] = Field(default_factory=list)

class PlaylistSaveRequest(BaseModel):
    playlist_id: str
    path: str

class PlaylistLoadRequest(BaseModel):
    path: str

class ProcessRequest(BaseModel):
    playlist_id: Optional[str] = None
    files: List[str] = Field(default_factory=list)
    output_folder: str = "./predation_final_outputs"
    sample_fps: float = 4.0
    max_sample_seconds: float = 0.0
    export_assets: bool = True
    enable_ocr: bool = False
    manual_labels: Optional[str] = None
    server_logs: Optional[str] = None
    # Curated media selectors: quality over quantity. Defaults match the project brief.
    dramatic_count: int = 6
    funny_count: int = 6
    team_play_count: int = 6
    kill_chain_count: int = 6
    graphic_count: int = 6
    still_count: int = 6
    apng_count: int = 6
    # MP4 production controls. Clip duration is capped to 5 minutes.
    clip_duration_seconds: float = 8.0
    export_clean_mp4: bool = True
    export_subtitled_mp4: bool = True
    subtitle_kill_comments: bool = True
    mute_exported_clips: bool = False
    # Music auto-sync and inclusion-list media content. Images/APNG/PNG can be added to playlists.
    music_file: Optional[str] = None
    autosync_music: bool = False
    autosync_duration_seconds: float = 480.0

@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return INDEX_HTML

@app.post("/api/scan")
def api_scan(req: ScanRequest) -> Dict[str, Any]:
    try:
        return {"assets": scan_folder(Path(req.folder), req.recursive)}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.post("/api/playlist/create")
def api_playlist_create(req: PlaylistCreateRequest) -> Dict[str, Any]:
    pid = uuid.uuid4().hex[:12]
    PLAYLISTS[pid] = {"playlist_id": pid, "name": req.name, "files": [], "created_at": now_iso()}
    return PLAYLISTS[pid]

@app.get("/api/playlists")
def api_playlists() -> Dict[str, Any]:
    return {"playlists": list(PLAYLISTS.values())}

@app.post("/api/playlist/add")
def api_playlist_add(req: PlaylistPatchRequest) -> Dict[str, Any]:
    if req.playlist_id not in PLAYLISTS:
        raise HTTPException(status_code=404, detail="playlist not found")
    current = list(PLAYLISTS[req.playlist_id].get("files", []))
    for f in req.files:
        if f not in current:
            current.append(f)
    PLAYLISTS[req.playlist_id]["files"] = current
    return PLAYLISTS[req.playlist_id]

@app.post("/api/playlist/remove")
def api_playlist_remove(req: PlaylistPatchRequest) -> Dict[str, Any]:
    if req.playlist_id not in PLAYLISTS:
        raise HTTPException(status_code=404, detail="playlist not found")
    remove = set(req.files)
    PLAYLISTS[req.playlist_id]["files"] = [f for f in PLAYLISTS[req.playlist_id].get("files", []) if f not in remove]
    return PLAYLISTS[req.playlist_id]

@app.post("/api/playlist/save")
def api_playlist_save(req: PlaylistSaveRequest) -> Dict[str, Any]:
    if req.playlist_id not in PLAYLISTS:
        raise HTTPException(status_code=404, detail="playlist not found")
    p = Path(req.path).expanduser().resolve()
    ensure_dir(p.parent)
    p.write_text(json.dumps(PLAYLISTS[req.playlist_id], indent=2), encoding="utf-8")
    return {"saved": str(p)}

@app.post("/api/playlist/load")
def api_playlist_load(req: PlaylistLoadRequest) -> Dict[str, Any]:
    p = Path(req.path).expanduser().resolve()
    data = json.loads(p.read_text(encoding="utf-8"))
    pid = data.get("playlist_id") or uuid.uuid4().hex[:12]
    data["playlist_id"] = pid
    PLAYLISTS[pid] = data
    return data

@app.post("/api/process")
def api_process(req: ProcessRequest) -> Dict[str, Any]:
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"job_id": job_id, "status": "running", "progress": 0, "message": "Starting", "log": []}
    def worker() -> None:
        try:
            files = list(req.files)
            if req.playlist_id:
                files += PLAYLISTS.get(req.playlist_id, {}).get("files", [])
            payload = req.model_dump()
            payload["files"] = files
            result = process_playlist(payload, job_id=job_id)
            JOBS[job_id]["status"] = "complete"
            JOBS[job_id]["result"] = {"outputs": result.get("outputs", {}), "event_count": len(result.get("events", []))}
        except Exception as exc:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = f"{type(exc).__name__}: {exc}"
            JOBS[job_id]["message"] = str(exc)
    threading.Thread(target=worker, daemon=True).start()
    return {"job_id": job_id}

@app.get("/api/job/{job_id}")
def api_job(job_id: str) -> Dict[str, Any]:
    if job_id not in JOBS:
        raise HTTPException(status_code=404, detail="job not found")
    return JOBS[job_id]

@app.get("/api/download")
def api_download(path: str) -> FileResponse:
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise HTTPException(status_code=404, detail="file not found")
    return FileResponse(str(p), filename=p.name)

INDEX_HTML = r"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Final Grade Predation Studio</title>
<style>body{background:radial-gradient(circle at top left,#172554,#08101f 45%,#020617);color:#eaf2ff;font-family:system-ui;margin:0}header{padding:18px;background:linear-gradient(90deg,#101a31,#13294b,#18213a);border-bottom:1px solid #25375c}main{display:grid;grid-template-columns:360px 1fr 460px;gap:14px;padding:14px}.panel{background:rgba(17,24,39,.92);border:1px solid #374151;border-radius:14px;padding:14px;box-shadow:0 18px 60px rgba(0,0,0,.25)}input,button,select{font:inherit}input,select{width:100%;box-sizing:border-box;background:#050912;color:#eaf2ff;border:1px solid #374151;border-radius:8px;padding:8px;margin:4px 0}button{background:#0e7490;color:white;border:0;border-radius:8px;padding:8px 10px;margin:4px;cursor:pointer}.danger{background:#991b1b}.good{background:#15803d}.warn{background:#a16207}.list{height:460px;overflow:auto;background:#050912;border:1px solid #263645;border-radius:10px;padding:8px}.asset{padding:7px;border-bottom:1px solid #1f2937}.asset small{color:#9ca3af}.row{display:flex;gap:8px}.row>*{flex:1}pre{height:260px;overflow:auto;background:#050912;border-radius:10px;padding:10px;color:#d1d5db}.pill{display:inline-block;border:1px solid #4b5563;border-radius:999px;padding:2px 7px;margin:2px;color:#bfdbfe;font-size:12px}.hint{color:#bae6fd;font-size:.9rem}.mini{font-size:.85rem;color:#c4b5fd}a{color:#7dd3fc}</style></head><body><header><h1>🎬 Final Grade GTA/FiveM Predation Studio</h1><p>Video-first fictional gameplay analytics · playlists · ground truth · curated webpage assets · SQL + Neo4j exports</p></header><main>
<section class="panel"><h2>1. Scan files</h2><label>Folder</label><input id="folder" value="/mnt/data"><button onclick="scan()">Scan</button><button onclick="selectAll()">Select all</button><button onclick="selectNone()">None</button><div id="assets" class="list">No assets yet.</div></section>
<section class="panel"><h2>2. Playlist</h2><div class="row"><input id="plName" value="predation_playlist"><button onclick="createPlaylist()">Create</button></div><div class="row"><select id="playlist"></select><button onclick="refreshPlaylists()">Refresh</button></div><button class="good" onclick="addSelected()">Add selected → playlist</button><button class="danger" onclick="removeSelectedPlaylist()">Remove checked playlist items</button><label>Save playlist JSON path</label><input id="savePath" value="/mnt/data/predation_playlist.json"><button onclick="savePlaylist()">Save playlist</button><button onclick="loadPlaylist()">Load playlist</button><h3>Playlist files</h3><div id="plFiles" class="list"></div></section>
<section class="panel"><h2>3. Process analytically</h2><p class="hint">🎯 Quality over quantity: choose exactly how many media assets to publish.</p><label>Output folder</label><input id="out" value="/mnt/data/final_grade_predation_outputs"><div class="row"><div><label>Sample FPS</label><input id="sampleFps" type="number" value="4"></div><div><label>Max seconds, 0=all</label><input id="maxSeconds" type="number" value="0"></div></div><h3>🌐 Webpage asset selectors</h3><div class="row"><div><label>🎬 Dramatic clips</label><input id="dramaticCount" type="number" min="0" max="48" value="6"></div><div><label>😂 Funny clips</label><input id="funnyCount" type="number" min="0" max="48" value="6"></div></div><div class="row"><div><label>🦁 Team-play clips</label><input id="teamCount" type="number" min="0" max="48" value="6"></div><div><label>⛓️ Kill-chain clips</label><input id="chainCount" type="number" min="0" max="48" value="6"></div></div><div class="row"><div><label>🩸 Spectacle/graphic clips</label><input id="graphicCount" type="number" min="0" max="48" value="6"></div><div><label>🖼️ Still frames</label><input id="stillCount" type="number" min="0" max="48" value="6"></div></div><div class="row"><div><label>🔁 APNG loops</label><input id="apngCount" type="number" min="0" max="48" value="6"></div><div><label>🎵 Music auto-sync duration</label><input id="syncDur" type="number" min="10" max="3600" value="480"></div></div><h3>🎵 Music auto-sync / inclusion list</h3><label>.mp3/.webm music file for auto-sync</label><input id="musicFile" placeholder="optional /path/song.mp3 or .webm"><label><input id="autosync" type="checkbox" style="width:auto"> Auto-sync selected videos/APNG/PNG/stills to music bed</label><p class="mini">🎚️ Inclusion list accepts videos, APNGs, PNG/JPG/WebP stills, and music. Use playlist buttons to add/remove.</p><h3>🎞️ MP4 production</h3><label>Clip duration seconds, max 300 = 5 minutes</label><input id="clipDur" type="number" min="1" max="300" value="8"><label><input id="cleanMp4" type="checkbox" checked style="width:auto"> Export clean MP4 without subtitles</label><br><label><input id="subMp4" type="checkbox" checked style="width:auto"> Export MP4 with CoRT60 kill/comment subtitles burned in</label><br><label><input id="killComments" type="checkbox" checked style="width:auto"> Use kill/predation subtitle comments: #AGO #CAF #FIP #PMI</label><br><label><input id="muteClips" type="checkbox" style="width:auto"> Mute exported clips</label><p class="mini">💡 For social/web assets: subtitled MP4. For archive/pro editing: clean MP4 + SRT files.</p><label>Manual labels CSV/JSON</label><input id="manual" placeholder="optional /path/manual_labels.csv"><label>FiveM/server logs CSV/JSON</label><input id="server" placeholder="optional /path/server_logs.csv"><label><input id="ocr" type="checkbox" style="width:auto"> Enable killfeed OCR if pytesseract is installed</label><br><label><input id="exportAssets" type="checkbox" checked style="width:auto"> Export curated MP4/still/APNG assets</label><br><button class="good" onclick="process()">Run final-grade playlist process</button><div id="status"></div><pre id="log"></pre><div id="links"></div></section>
</main><script>
let assets=[]; let selected=new Set(); let playlists={}; let currentJob=null;
async function post(url,obj){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)}); if(!r.ok) throw new Error(await r.text()); return await r.json();}
function v(id){return document.getElementById(id).value} function c(id){return document.getElementById(id).checked}
async function scan(){ const data=await post('/api/scan',{folder:v('folder'),recursive:true}); assets=data.assets||[]; renderAssets(); }
function renderAssets(){document.getElementById('assets').innerHTML=assets.map((a,i)=>`<div class='asset'><input type='checkbox' style='width:auto' ${selected.has(a.path)?'checked':''} onchange="this.checked?selected.add('${a.path.replace(/'/g,"\\'")}'):selected.delete('${a.path.replace(/'/g,"\\'")}')"> <b>${a.kind}</b> ${a.name}<br><small>${a.duration||0}s · ${a.size_mb}MB · ${a.width||0}x${a.height||0}</small></div>`).join('')||'No files.'}
function selectAll(){assets.forEach(a=>selected.add(a.path));renderAssets()} function selectNone(){selected.clear();renderAssets()}
async function createPlaylist(){ const pl=await post('/api/playlist/create',{name:v('plName')}); await refreshPlaylists(); document.getElementById('playlist').value=pl.playlist_id; renderPlaylist(pl); }
async function refreshPlaylists(){ const data=await fetch('/api/playlists').then(r=>r.json()); playlists={}; (data.playlists||[]).forEach(p=>playlists[p.playlist_id]=p); document.getElementById('playlist').innerHTML=Object.values(playlists).map(p=>`<option value='${p.playlist_id}'>${p.name} (${p.files.length})</option>`).join(''); renderPlaylist(playlists[document.getElementById('playlist').value]); }
function renderPlaylist(pl){ if(!pl){document.getElementById('plFiles').innerHTML='No playlist.';return;} document.getElementById('plFiles').innerHTML=(pl.files||[]).map((f,i)=>`<div class='asset'><input class='plcheck' type='checkbox' style='width:auto' value='${f}'> ${i+1}. ${f.split('/').pop()}<br><small>${f}</small></div>`).join('')||'Empty playlist.'; }
document.addEventListener('change',e=>{if(e.target.id==='playlist')renderPlaylist(playlists[e.target.value]);});
async function addSelected(){let pid=v('playlist'); if(!pid){await createPlaylist(); pid=v('playlist')} const pl=await post('/api/playlist/add',{playlist_id:pid,files:[...selected]}); playlists[pid]=pl; renderPlaylist(pl); await refreshPlaylists();}
async function removeSelectedPlaylist(){ const files=[...document.querySelectorAll('.plcheck:checked')].map(x=>x.value); const pid=v('playlist'); const pl=await post('/api/playlist/remove',{playlist_id:pid,files}); playlists[pid]=pl; renderPlaylist(pl); await refreshPlaylists();}
async function savePlaylist(){const data=await post('/api/playlist/save',{playlist_id:v('playlist'),path:v('savePath')}); alert('saved '+data.saved)}
async function loadPlaylist(){const data=await post('/api/playlist/load',{path:v('savePath')}); await refreshPlaylists(); document.getElementById('playlist').value=data.playlist_id; renderPlaylist(data)}
async function process(){ const payload={playlist_id:v('playlist'),output_folder:v('out'),sample_fps:+v('sampleFps'),max_sample_seconds:+v('maxSeconds'),export_assets:c('exportAssets'),enable_ocr:c('ocr'),manual_labels:v('manual')||null,server_logs:v('server')||null,dramatic_count:+v('dramaticCount'),funny_count:+v('funnyCount'),team_play_count:+v('teamCount'),kill_chain_count:+v('chainCount'),graphic_count:+v('graphicCount'),still_count:+v('stillCount'),apng_count:+v('apngCount'),music_file:v('musicFile')||null,autosync_music:c('autosync'),autosync_duration_seconds:+v('syncDur'),clip_duration_seconds:+v('clipDur'),export_clean_mp4:c('cleanMp4'),export_subtitled_mp4:c('subMp4'),subtitle_kill_comments:c('killComments'),mute_exported_clips:c('muteClips')}; const data=await post('/api/process',payload); currentJob=data.job_id; poll();}
async function poll(){ if(!currentJob)return; const j=await fetch('/api/job/'+currentJob).then(r=>r.json()); document.getElementById('status').innerHTML=`<span class='pill'>${j.status}</span><span class='pill'>${j.progress||0}%</span> ${j.message||''}`; document.getElementById('log').textContent=(j.log||[]).map(x=>`[${x.progress}%] ${x.message}`).join('\n'); if(j.status==='running') setTimeout(poll,1000); else if(j.result){const o=j.result.outputs||{}; document.getElementById('links').innerHTML=Object.entries(o).map(([k,p])=>`<p><a href='/api/download?path=${encodeURIComponent(p)}'>${k}</a> — ${p}</p>`).join('');}}
refreshPlaylists();
</script></body></html>"""

SQLITE_SCHEMA = """
PRAGMA foreign_keys = ON;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS media_asset (
  media_id TEXT PRIMARY KEY,
  path TEXT NOT NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  suffix TEXT,
  duration_seconds REAL DEFAULT 0,
  width INTEGER DEFAULT 0,
  height INTEGER DEFAULT 0,
  fps REAL DEFAULT 0,
  has_audio INTEGER DEFAULT 0 CHECK(has_audio IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS predation_event (
  event_id TEXT PRIMARY KEY,
  media_id TEXT NOT NULL REFERENCES media_asset(media_id) ON DELETE CASCADE,
  start_seconds REAL NOT NULL,
  end_seconds REAL NOT NULL,
  peak_seconds REAL NOT NULL,
  event_type TEXT NOT NULL,
  score REAL NOT NULL CHECK(score >= 0 AND score <= 1),
  confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  ground_truth_level TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS event_metric (
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  metric_name TEXT NOT NULL,
  metric_value REAL NOT NULL,
  metric_group TEXT NOT NULL,
  PRIMARY KEY(event_id, metric_name, metric_group)
);
CREATE TABLE IF NOT EXISTS cort60_card (
  event_id TEXT PRIMARY KEY REFERENCES predation_event(event_id) ON DELETE CASCADE,
  ago TEXT, caf_json TEXT, fip TEXT, apc_json TEXT, cs TEXT, opv_json TEXT, pmi_json TEXT,
  caption_serious TEXT, caption_funny TEXT
);
CREATE TABLE IF NOT EXISTS curated_asset (
  curated_id INTEGER PRIMARY KEY AUTOINCREMENT,
  curated_set TEXT NOT NULL,
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  rank INTEGER NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(curated_set, rank)
);
COMMIT;
"""
POSTGRES_SCHEMA = """
BEGIN;
CREATE TABLE IF NOT EXISTS media_asset (
  media_id TEXT PRIMARY KEY,
  path TEXT NOT NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  suffix TEXT,
  duration_seconds DOUBLE PRECISION DEFAULT 0,
  width INTEGER DEFAULT 0,
  height INTEGER DEFAULT 0,
  fps DOUBLE PRECISION DEFAULT 0,
  has_audio BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS predation_event (
  event_id TEXT PRIMARY KEY,
  media_id TEXT NOT NULL REFERENCES media_asset(media_id) ON DELETE CASCADE,
  start_seconds DOUBLE PRECISION NOT NULL,
  end_seconds DOUBLE PRECISION NOT NULL,
  peak_seconds DOUBLE PRECISION NOT NULL,
  event_type TEXT NOT NULL,
  score DOUBLE PRECISION NOT NULL CHECK(score >= 0 AND score <= 1),
  confidence DOUBLE PRECISION NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  ground_truth_level TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS event_metric (
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  metric_name TEXT NOT NULL,
  metric_value DOUBLE PRECISION NOT NULL,
  metric_group TEXT NOT NULL,
  PRIMARY KEY(event_id, metric_name, metric_group)
);
CREATE TABLE IF NOT EXISTS cort60_card (
  event_id TEXT PRIMARY KEY REFERENCES predation_event(event_id) ON DELETE CASCADE,
  ago TEXT, caf_json JSONB, fip TEXT, apc_json JSONB, cs TEXT, opv_json JSONB, pmi_json JSONB,
  caption_serious TEXT, caption_funny TEXT
);
CREATE TABLE IF NOT EXISTS curated_asset (
  curated_id BIGSERIAL PRIMARY KEY,
  curated_set TEXT NOT NULL,
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  rank INTEGER NOT NULL,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(curated_set, rank)
);
COMMIT;
"""

def cli() -> None:
    parser = argparse.ArgumentParser(description=APP_TITLE)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8790)
    parser.add_argument("--process-playlist", default="", help="Optional playlist JSON to process from CLI")
    parser.add_argument("--out", default="./predation_final_outputs")
    args = parser.parse_args()
    if args.process_playlist:
        pl = json.loads(Path(args.process_playlist).expanduser().read_text(encoding="utf-8"))
        print(json.dumps(process_playlist({"files": pl.get("files", []), "output_folder": args.out}), indent=2))
    else:
        import uvicorn
        uvicorn.run(app, host=args.host, port=args.port)

if __name__ == "__main__":
    cli()
