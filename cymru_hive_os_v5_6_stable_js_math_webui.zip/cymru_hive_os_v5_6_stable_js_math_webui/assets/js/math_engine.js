(() => {
  "use strict";
  const EPS = 1e-9;
  const clamp = (v, lo=0, hi=1) => Math.max(lo, Math.min(hi, Number(v) || 0));
  const sum = (arr, fn=x=>x) => arr.reduce((a,x,i)=>a+(Number(fn(x,i))||0),0);
  const round = (n, dp=3) => Math.round((Number(n)||0)*10**dp)/10**dp;

  function normalise(values, cap) {
    const out = {...values};
    const total = sum(Object.values(out));
    if (total <= cap + EPS) return out;
    const s = cap / Math.max(total, EPS);
    for (const k of Object.keys(out)) out[k] = Math.round(out[k] * s);
    return out;
  }

  function haversineKm(a, b) {
    if (!a || !b) return 0;
    const R = 6371.0088;
    const p1 = a.lat * Math.PI/180, p2 = b.lat * Math.PI/180;
    const dp = (b.lat-a.lat)*Math.PI/180, dl = (b.lon-a.lon)*Math.PI/180;
    const q = Math.sin(dp/2)**2 + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
    return 2 * R * Math.asin(Math.sqrt(q));
  }

  function knapsack(items, budget, scale=100000) {
    const cap = Math.max(0, Math.floor(budget/scale));
    const dp = Array(cap+1).fill(0);
    const keep = Array.from({length:cap+1}, () => []);
    for (const it of items) {
      const w = Math.max(1, Math.round(it.cost/scale));
      const v = Number(it.value) || 0;
      for (let c=cap; c>=w; c--) {
        const candidate = dp[c-w] + v;
        if (candidate > dp[c]) {
          dp[c] = candidate;
          keep[c] = keep[c-w].concat(it.id);
        }
      }
    }
    const selectedIds = keep[cap];
    const cost = sum(selectedIds, id => items.find(x=>x.id===id)?.cost || 0);
    return {algorithm:"0/1 knapsack", selectedIds, value:round(dp[cap]), cost};
  }

  function subsetSumNear(items, target, scale=100000) {
    const cap = Math.floor(target/scale);
    let states = new Map([[0, []]]);
    for (const it of items) {
      const w = Math.max(1, Math.round(it.cost/scale));
      const next = new Map(states);
      for (const [t, ids] of states.entries()) {
        const nt = t + w;
        if (nt <= cap && !next.has(nt)) next.set(nt, ids.concat(it.id));
      }
      states = next;
    }
    const best = Math.max(...states.keys());
    const selectedIds = states.get(best) || [];
    const spend = sum(selectedIds, id => items.find(x=>x.id===id)?.cost || 0);
    return {algorithm:"near-target subset sum", selectedIds, spend, remaining: target - spend};
  }

  function coverage(assets, stations, budget, options={}) {
    const thresholdMinutes = options.thresholdMinutes ?? 18;
    const speedKmh = options.speedKmh ?? 55;
    const turnout = options.turnoutMinutes ?? 2;
    const covered = new Set();
    const selectedIds = [];
    let spend = 0;
    const remaining = new Map(stations.map(s => [s.id, s]));
    const assetValue = a => {
      const pop = Math.log10((a.people || 1000)+10);
      const risk = a.risk ?? .5;
      const typeMul = {hospital:1.45,gp:1.25,school:1.18,university:1.12,library:.86,education:1.1,animals:.96,agrarian:1}[a.type] || 1;
      return typeMul * ((a.value||60)*.55 + risk*100*.35 + pop*7.5);
    };
    const minutes = (s,a) => turnout + (haversineKm(s,a) / Math.max(1,speedKmh))*60;

    while (remaining.size) {
      let best = null, bestScore = -Infinity;
      for (const st of remaining.values()) {
        if (spend + st.cost > budget) continue;
        let gain = 0;
        for (const a of assets) if (!covered.has(a.id) && minutes(st,a) <= thresholdMinutes) gain += assetValue(a) * (st.readiness ?? .82);
        const score = gain / Math.max(1, st.cost);
        if (gain > 0 && score > bestScore) { best = st; bestScore = score; }
      }
      if (!best) break;
      selectedIds.push(best.id);
      spend += best.cost;
      remaining.delete(best.id);
      for (const a of assets) if (minutes(best,a) <= thresholdMinutes) covered.add(a.id);
    }
    const totalValue = sum(assets, assetValue);
    const coveredValue = sum(assets.filter(a => covered.has(a.id)), assetValue);
    return {
      algorithm:"greedy maximal coverage",
      selectedIds,
      spend,
      coveredAssetIds:[...covered],
      coveragePct: round(100 * covered.size / Math.max(1, assets.length), 2),
      valuePct: round(100 * coveredValue / Math.max(EPS, totalValue), 2),
      roiScore: round(coveredValue / Math.max(1, spend/1_000_000), 3)
    };
  }

  function acoRoute(nodes, pheromone={}, options={}) {
    const alpha = options.alpha ?? 1.1, beta = options.beta ?? 2.1, evaporation = options.evaporation ?? .06;
    const start = options.start || nodes[0]?.id;
    const route = [start];
    const unvisited = new Set(nodes.map(n=>n.id).filter(id => id !== start));
    const byId = Object.fromEntries(nodes.map(n => [n.id, n]));
    const dist = (a,b) => haversineKm(byId[a], byId[b]) + .01;
    while (unvisited.size) {
      const cur = route.at(-1);
      const choices = [...unvisited].map(id => {
        const tau = pheromone[cur+">"+id] ?? 1;
        const eta = 1 / dist(cur,id);
        return {id, score: Math.pow(tau, alpha) * Math.pow(eta, beta)};
      });
      const total = sum(choices, x=>x.score) || 1;
      let r = Math.random() * total, picked = choices[0].id;
      for (const c of choices) { r -= c.score; if (r <= 0) { picked = c.id; break; } }
      route.push(picked);
      unvisited.delete(picked);
    }
    const lengthKm = sum(route.slice(1), (id,i) => dist(route[i], id));
    for (const k of Object.keys(pheromone)) pheromone[k] *= (1 - evaporation);
    for (let i=1; i<route.length; i++) {
      const k = route[i-1]+">"+route[i];
      pheromone[k] = (pheromone[k] ?? 1) + 100 / Math.max(1, lengthKm);
    }
    return {algorithm:"ACO route construction", route, lengthKm: round(lengthKm,2), pheromone};
  }

  function bcoAllocate(projects, bees=100) {
    const scored = projects.map(p => {
      const nectar = (p.value || p.quality || 1) / Math.max(1, Math.sqrt((p.cost||1)/1_000_000)) * (1 - (p.risk||0)*.24);
      return {...p, nectar};
    }).sort((a,b)=>b.nectar-a.nectar);
    const total = sum(scored, x=>x.nectar) || 1;
    return scored.map(p => ({id:p.id, label:p.label || p.name || p.id, bees:Math.round(p.nectar/total*bees), nectar:round(p.nectar)}));
  }

  function psoStep(particles, objective) {
    const w=.62, c1=1.35, c2=1.55;
    let globalBest = particles[0].best || {position:particles[0].position.slice(), score:-Infinity};
    for (const p of particles) {
      const score = objective(p.position);
      if (!p.best || score > p.best.score) p.best = {position:p.position.slice(), score};
      if (p.best.score > globalBest.score) globalBest = {position:p.best.position.slice(), score:p.best.score};
    }
    for (const p of particles) {
      p.velocity = p.velocity.map((v,i) => w*v + c1*Math.random()*(p.best.position[i]-p.position[i]) + c2*Math.random()*(globalBest.position[i]-p.position[i]));
      p.position = p.position.map((x,i) => clamp(x+p.velocity[i], 0, 1));
    }
    return {algorithm:"PSO update", particles, globalBest};
  }

  function predatorPreyStep(state, dt=.045) {
    const prey = Math.max(0, state.prey ?? 80), pred = Math.max(0, state.predator ?? 20);
    const a = state.preyGrowth ?? 1.1, b = state.predation ?? .018, c = state.predatorDeath ?? .65, d = state.predatorEfficiency ?? .011;
    const nextPrey = Math.max(0, prey + (a*prey - b*prey*pred)*dt);
    const nextPred = Math.max(0, pred + (d*prey*pred - c*pred)*dt);
    const balance = 100 / (1 + Math.abs((nextPrey/(nextPred+EPS))-4));
    return {...state, prey:round(nextPrey), predator:round(nextPred), balance:round(balance,2)};
  }

  function mandelbrotIterations(cx, cy, maxIter=64) {
    let x=0, y=0, iter=0;
    while (x*x+y*y <= 4 && iter < maxIter) {
      const xt = x*x-y*y+cx;
      y = 2*x*y+cy;
      x = xt;
      iter++;
    }
    return iter;
  }

  function fractalPruneScore({urgency=.4,risk=.5,zoom=.5,roi=.7,mandelX=-.745,mandelY=.113}={}) {
    const mandel = mandelbrotIterations(mandelX, mandelY, 64)/64;
    const depth = Math.round(1 + 9 * clamp(.25*urgency + .25*risk + .2*zoom + .2*roi + .1*mandel));
    return {algorithm:"Mandelbrot/fractal pruning", depth, prune:round(1-depth/10,3), mandelbrot:round(mandel,3)};
  }

  function composeROI(values, weights={finance:.18,access:.14,skills:.18,ecology:.18,resilience:.14,enterprise:.1,time:.08}) {
    const weighted = Object.entries(weights).reduce((a,[k,w]) => a + (Number(values[k])||0)*w, 0);
    const multiple = 1.15 + (weighted/100)*3.8;
    return {algorithm:"weighted ROI composition", weightedScore:round(weighted), multiple:round(multiple,3)};
  }

  window.SpaceMath = {clamp, sum, round, normalise, haversineKm, knapsack, subsetSumNear, coverage, acoRoute, bcoAllocate, psoStep, predatorPreyStep, mandelbrotIterations, fractalPruneScore, composeROI};
})();
