(() => {
  "use strict";
  const D = window.SPACE_WALES_DATA;
  const M = window.SpaceMath;
  const $ = id => document.getElementById(id);
  const money = n => n >= 1e9 ? "£"+(n/1e9).toFixed(2)+"bn" : n >= 1e6 ? "£"+(n/1e6).toFixed(1)+"m" : "£"+Math.round(n).toLocaleString();
  const cap = D.budgetCap, staffCap = D.staffCap;

  let budget = Object.fromEntries(D.headings.map(h => [h.id, Math.round(cap*h.pct/100)]));
  let staff = Object.fromEntries(D.headings.map(h => [h.id, h.staff]));
  let tuneIndex = 0;
  let running = true;
  let pheromone = {};
  let predatorState = {prey:80, predator:20, preyGrowth:1.1, predation:.018, predatorDeath:.65, predatorEfficiency:.011};
  let particles = Array.from({length:20}, () => ({position:[Math.random(),Math.random(),Math.random()], velocity:[0,0,0]}));
  let agents = [];
  let mathResult = {};
  let tick = 0;

  function currentTune(){ return D.tunes[tuneIndex]; }
  function total(obj){ return Object.values(obj).reduce((a,b)=>a+(Number(b)||0),0); }
  function heading(id){ return D.headings.find(h => h.id === id); }
  function tuneFit(){
    const t = currentTune();
    let score = 0, max = 0;
    for (const [id,w] of Object.entries(t.mods)) {
      score += (budget[id] || 0) / cap * 100 * w;
      max += 100 * w;
    }
    return max ? Math.min(100, score / max * 100 * 3) : 0;
  }

  function buildSliders(){
    $("budgetSliders").innerHTML = D.headings.map(h => `
      <div class="sliderCard">
        <strong><span>${h.icon} ${h.name}</span><span>${money(budget[h.id])}</span></strong>
        <input data-budget="${h.id}" type="range" min="0" max="${cap}" step="1000000" value="${budget[h.id]}">
        <small>${((budget[h.id]/cap)*100).toFixed(1)}% · staff ${staff[h.id].toLocaleString()}</small>
      </div>`).join("");
    document.querySelectorAll("[data-budget]").forEach(el => el.oninput = e => {
      budget[e.target.dataset.budget] = Number(e.target.value);
      budget = M.normalise(budget, cap);
      refresh();
      buildSliders();
    });
    $("staffSliders").innerHTML = D.headings.map(h => `
      <div class="sliderCard">
        <strong><span>${h.icon} ${h.name}</span><span>${staff[h.id].toLocaleString()}</span></strong>
        <input data-staff="${h.id}" type="range" min="0" max="${staffCap}" step="10" value="${staff[h.id]}">
        <small>${((staff[h.id]/staffCap)*100).toFixed(1)}% · budget ${money(budget[h.id])}</small>
      </div>`).join("");
    document.querySelectorAll("[data-staff]").forEach(el => el.oninput = e => {
      staff[e.target.dataset.staff] = Number(e.target.value);
      staff = M.normalise(staff, staffCap);
      refresh();
      buildSliders();
    });
  }

  function buildTunes(){
    $("tuneButtons").innerHTML = D.tunes.map((t,i)=>`
      <button class="sideBtn ${i===tuneIndex?'active':''}" data-tune="${i}">
        <strong>${t.icon} ${String(i+1).padStart(2,"0")} · ${t.name}</strong>
        <small>${t.cohort} · ${Object.keys(t.mods).join(", ")}</small>
      </button>`).join("");
    document.querySelectorAll("[data-tune]").forEach(b => b.onclick = () => {
      tuneIndex = Number(b.dataset.tune);
      running = true;
      $("playBtn").textContent = "⏸ pause";
      $("playBtn").classList.add("active");
      buildTunes();
      refresh();
    });
  }

  function demoProjects(){
    return D.headings.map((h,i)=>({id:h.id,label:h.icon+" "+h.name,cost:Math.max(500000,Math.round(budget[h.id]*(.025+(i%4)*.009))),value:h.value + ((currentTune().mods[h.id]||0)*6),risk:(i%7)/13}));
  }
  function demoAssets(){
    return D.hives.map((h,i)=>({id:h.id,label:h.icon+" "+h.name,lat:h.lat,lon:h.lon,type:h.type,people:1000+i*4500,risk:.35+(i%6)*.08,value:heading(h.type)?.value || 60}));
  }
  function demoStations(){
    return D.hives.map((h,i)=>({id:"station_"+h.id,label:"🚑 "+h.name+" response hub",lat:h.lat,lon:h.lon,cost:1_100_000+(i%6)*500_000,readiness:.72+(i%5)*.045}));
  }

  function runMath(mode="all"){
    const projects = demoProjects(), assets = demoAssets(), stations = demoStations();
    const localCap = Math.min(75_000_000, Math.max(1_000_000, budget.pathway + budget.transport + budget.health + budget.evidence));
    const result = {};
    if (mode === "all" || mode === "knapsack") {
      result.knapsack = M.knapsack(projects, localCap);
      result.subset = M.subsetSumNear(projects, localCap);
    }
    if (mode === "all" || mode === "coverage") {
      result.coverage = M.coverage(assets, stations, localCap, {thresholdMinutes:18, speedKmh:52, turnoutMinutes:2});
    }
    if (mode === "all" || mode === "swarm") {
      result.aco = M.acoRoute(assets, pheromone, {start:assets[0].id});
      pheromone = result.aco.pheromone;
      result.bco = M.bcoAllocate(projects, 100);
      result.pso = M.psoStep(particles, pos => Math.min(1, .42*pos[0] + .36*pos[1] + .22*pos[2] - Math.abs(pos[0]-pos[1])*.08));
      particles = result.pso.particles;
      result.pso = {algorithm:result.pso.algorithm, globalBest:result.pso.globalBest};
    }
    if (mode === "all" || mode === "ecology") {
      predatorState = M.predatorPreyStep(predatorState, .045);
      result.predatorPrey = predatorState;
      result.pruning = M.fractalPruneScore({
        urgency:Number($("urgency").value),
        risk:Number($("risk").value),
        zoom:Number($("detail").value),
        roi:Number($("roiWeight").value),
        mandelX:-.745 + Math.sin(tick/40)*.02,
        mandelY:.113 + Math.cos(tick/45)*.02
      });
    }
    const tf = tuneFit();
    result.roi = M.composeROI({
      finance:(result.knapsack?.value || mathResult.knapsack?.value || 50)/3,
      access:result.coverage?.valuePct || mathResult.coverage?.valuePct || 50,
      skills:(result.bco?.[0]?.bees || mathResult.bco?.[0]?.bees || 25)*2,
      ecology:result.predatorPrey?.balance || mathResult.predatorPrey?.balance || 50,
      resilience:(result.pruning?.depth || mathResult.pruning?.depth || 5)*10,
      enterprise:tf,
      time: result.aco ? Math.max(1,100-result.aco.lengthKm/8) : 50
    });
    mathResult = {...mathResult, ...result};
    $("mathOut").textContent = JSON.stringify(mathResult, null, 2);
    drawMathChart();
    refresh();
  }

  function drawMathChart(){
    const rows = [];
    if (mathResult.knapsack) rows.push({label:"🧮 knapsack value", value:mathResult.knapsack.value/4, fmt:mathResult.knapsack.selectedIds.length+" items"});
    if (mathResult.subset) rows.push({label:"🧩 subset spend", value:mathResult.subset.spend/75_000_000*100, fmt:money(mathResult.subset.spend)});
    if (mathResult.coverage) rows.push({label:"🚑 coverage", value:mathResult.coverage.coveragePct, fmt:mathResult.coverage.coveragePct+"%"});
    if (mathResult.aco) rows.push({label:"🐜 ACO route", value:Math.max(1,100-mathResult.aco.lengthKm/8), fmt:mathResult.aco.lengthKm+" km"});
    if (mathResult.bco) rows.push({label:"🐝 BCO top", value:mathResult.bco[0]?.bees || 0, fmt:(mathResult.bco[0]?.bees||0)+" bees"});
    if (mathResult.pso) rows.push({label:"🦅 PSO best", value:mathResult.pso.globalBest.score*100, fmt:mathResult.pso.globalBest.score.toFixed(3)});
    if (mathResult.predatorPrey) rows.push({label:"🦊 ecology balance", value:mathResult.predatorPrey.balance, fmt:mathResult.predatorPrey.balance+"/100"});
    if (mathResult.pruning) rows.push({label:"🧬 tree depth", value:mathResult.pruning.depth*10, fmt:"depth "+mathResult.pruning.depth});
    if (mathResult.roi) rows.push({label:"£ ROI multiple", value:Math.min(100,mathResult.roi.multiple*18), fmt:mathResult.roi.multiple+"x"});
    drawBars($("mathCanvas"), rows, "V5.6 JavaScript mathematics engine");
  }

  function drawBars(canvas, rows, title){
    const ctx = canvas.getContext("2d"), w=canvas.width, h=canvas.height;
    ctx.clearRect(0,0,w,h);
    const bg = ctx.createLinearGradient(0,0,0,h); bg.addColorStop(0,"#081426"); bg.addColorStop(1,"#101c2f");
    ctx.fillStyle = bg; ctx.fillRect(0,0,w,h);
    ctx.fillStyle = "#facc15"; ctx.font = "24px system-ui"; ctx.textAlign = "left"; ctx.fillText(title,36,38);
    const max = Math.max(...rows.map(r=>r.value),1);
    rows.forEach((r,i)=>{
      const y = 78 + i*((h-120)/Math.max(rows.length,1));
      const bw = (w-240) * (r.value/max);
      const g = ctx.createLinearGradient(46,y,46+bw,y); g.addColorStop(0,"#39d5ff"); g.addColorStop(.65,"#facc15"); g.addColorStop(1,"#4ade80");
      ctx.fillStyle = g; ctx.fillRect(46,y,bw,14);
      ctx.fillStyle = "#eaf2ff"; ctx.font = "12px system-ui"; ctx.textAlign = "left"; ctx.fillText(r.label,46,y-5);
      ctx.fillStyle = "#facc15"; ctx.textAlign = "right"; ctx.fillText(r.fmt || Math.round(r.value),w-35,y+13);
    });
  }

  function makeAgents(){
    agents = [];
    const types = [["🐝","bee",30],["🐜","ant",22],["🦅","bird",8],["🚜","tractor",8],["🦊","predator",7],["🐁","prey",18],["🔭","astro",8]];
    for (const [icon,type,n] of types) for (let i=0;i<n;i++) agents.push({icon,type,x:Math.random()*980,y:Math.random()*620,tx:Math.random()*980,ty:Math.random()*620,speed:.45+Math.random()*1.2});
  }

  function mapAt(h){
    const minLon=-5.85,maxLon=-2.55,minLat=51.25,maxLat=53.55;
    return {x:(h.lon-minLon)/(maxLon-minLon)*980+60, y:660-((h.lat-minLat)/(maxLat-minLat)*580+40)};
  }
  function hiveValue(h){
    return (budget[h.type]||0)/cap*100 + (currentTune().mods[h.type]||0)*8 + (heading(h.type)?.value||50)/4;
  }
  function stepAgents(){
    for (const a of agents) {
      if (Math.hypot(a.tx-a.x,a.ty-a.y)<8 || Math.random()<.004) {
        const sorted = D.hives.slice().sort((x,y)=>hiveValue(y)-hiveValue(x));
        const h = sorted[Math.floor(Math.random()*Math.min(4,sorted.length))];
        const p = mapAt(h);
        a.tx = p.x + (Math.random()-.5)*45;
        a.ty = p.y + (Math.random()-.5)*45;
      }
      const dx=a.tx-a.x, dy=a.ty-a.y, d=Math.hypot(dx,dy)||1;
      a.x += dx/d*a.speed; a.y += dy/d*a.speed;
    }
  }

  function drawMap(){
    const c=$("mapCanvas"), ctx=c.getContext("2d"), w=c.width, h=c.height;
    ctx.clearRect(0,0,w,h);
    const bg=ctx.createLinearGradient(0,0,0,h); bg.addColorStop(0,"#07111f"); bg.addColorStop(1,"#10213a"); ctx.fillStyle=bg; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle="rgba(255,255,255,.14)"; ctx.lineWidth=1;
    for (let i=0;i<=8;i++){ ctx.beginPath(); ctx.moveTo(i*w/8,0); ctx.lineTo(i*w/8,h); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0,i*h/8); ctx.lineTo(w,i*h/8); ctx.stroke(); }
    ctx.fillStyle="rgba(49,71,94,.68)"; ctx.strokeStyle="#eaf2ff"; ctx.lineWidth=3;
    const poly=[[-4.7,53.45],[-4.15,53.35],[-3.0,53.1],[-2.85,52.75],[-3.35,52.3],[-3.05,51.9],[-2.85,51.58],[-3.25,51.42],[-4.1,51.52],[-4.85,51.75],[-5.25,51.92],[-4.7,52.18],[-4.3,52.65],[-4.7,53.45]];
    ctx.beginPath();
    poly.forEach((p,i)=>{ const q=mapAt({lon:p[0],lat:p[1]}); i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y); }); 
    ctx.closePath(); ctx.fill(); ctx.stroke();

    D.hives.forEach(hv => {
      const p=mapAt(hv);
      ctx.fillStyle="#facc15"; ctx.beginPath(); ctx.arc(p.x,p.y,17,0,Math.PI*2); ctx.fill();
      ctx.fillStyle="#07111f"; ctx.font="17px system-ui"; ctx.textAlign="center"; ctx.fillText(hv.icon,p.x,p.y+6);
      ctx.fillStyle="#fff"; ctx.font="11px system-ui"; ctx.fillText(hv.name,p.x,p.y+34);
    });
    agents.forEach(a => { ctx.font="16px system-ui"; ctx.fillText(a.icon,a.x,a.y); });
    ctx.fillStyle="#b9cbe2"; ctx.textAlign="left"; ctx.font="13px system-ui"; ctx.fillText("Old local map: no WMS/WFS, no proxy, no remote dependency.",18,h-18);
  }

  function refresh(){
    $("budgetUsed").textContent = money(total(budget));
    $("staffUsed").textContent = total(staff).toLocaleString();
    $("activeTune").textContent = `${String(tuneIndex+1).padStart(2,"0")} / 24`;
    $("roiMetric").textContent = mathResult.roi ? mathResult.roi.multiple+"x" : "—";
    $("tuneTitle").textContent = `${currentTune().icon} ${currentTune().name}`;
    $("tuneText").textContent = `Cohort: ${currentTune().cohort}. Modifies: ${Object.entries(currentTune().mods).map(([k,v])=>`${k}+${v}`).join(", ")}.`;
    $("budgetStatus").innerHTML = progress("budget", total(budget)/cap*100, money(total(budget))) + progress("staff", total(staff)/staffCap*100, total(staff).toLocaleString()) + progress("tune fit", tuneFit(), Math.round(tuneFit())+"/100");
    $("mathMetrics").innerHTML = [
      mathResult.knapsack ? progress("knapsack", mathResult.knapsack.value/4, mathResult.knapsack.selectedIds.length+" items") : "",
      mathResult.coverage ? progress("coverage", mathResult.coverage.coveragePct, mathResult.coverage.coveragePct+"%") : "",
      mathResult.aco ? progress("ACO route", Math.max(1,100-mathResult.aco.lengthKm/8), mathResult.aco.lengthKm+" km") : "",
      mathResult.predatorPrey ? progress("ecology", mathResult.predatorPrey.balance, mathResult.predatorPrey.balance+"/100") : "",
      mathResult.roi ? progress("ROI", Math.min(100,mathResult.roi.multiple*18), mathResult.roi.multiple+"x") : ""
    ].join("");
  }

  function progress(label,value,txt){
    return `<div class="barrow"><strong>${label}</strong><span class="bar"><i style="width:${Math.max(1,Math.min(100,value))}%"></i></span><span>${txt}</span></div>`;
  }

  function bind(){
    buildSliders();
    buildTunes();
    makeAgents();
    $("playBtn").onclick = () => { running = !running; $("playBtn").textContent = running ? "⏸ pause" : "▶ play"; $("playBtn").classList.toggle("active", running); };
    $("nextTuneBtn").onclick = () => { tuneIndex = (tuneIndex+1)%D.tunes.length; buildTunes(); refresh(); };
    $("runAllBtn").onclick = () => runMath("all");
    $("knapsackBtn").onclick = () => runMath("knapsack");
    $("coverageBtn").onclick = () => runMath("coverage");
    $("swarmBtn").onclick = () => runMath("swarm");
    $("ecologyBtn").onclick = () => runMath("ecology");
    $("savePngBtn").onclick = () => { const a=document.createElement("a"); a.href=$("mathCanvas").toDataURL("image/png"); a.download="cymru_hive_os_v5_6_math_chart.png"; a.click(); };
    $("exportBtn").onclick = () => {
      const payload = {version:D.version, generatedAt:new Date().toISOString(), budget, staff, tune:currentTune(), mathResult};
      const blob = new Blob([JSON.stringify(payload,null,2)], {type:"application/json"});
      const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="cymru_hive_os_v5_6_scenario.json"; a.click(); URL.revokeObjectURL(a.href);
    };
    ["urgency","risk","detail","roiWeight"].forEach(id => $(id).oninput = () => runMath("all"));
    runMath("all");
    loop();
  }

  function loop(){
    tick++;
    if (running) {
      stepAgents();
      if (tick % 90 === 0) runMath("all");
    }
    drawMap();
    requestAnimationFrame(loop);
  }

  document.addEventListener("DOMContentLoaded", bind);
})();
