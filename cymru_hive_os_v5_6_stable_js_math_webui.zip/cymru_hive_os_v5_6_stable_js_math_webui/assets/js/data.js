window.SPACE_WALES_DATA = {
  "version": "5.6-stable",
  "budgetCap": 2500000000,
  "staffCap": 25000,
  "headings": [
    {
      "id": "compute",
      "icon": "🧠",
      "name": "Super-advanced compute + data",
      "pct": 18,
      "staff": 2500,
      "value": 92
    },
    {
      "id": "education",
      "icon": "🏫",
      "name": "Education + lifelong learning",
      "pct": 14,
      "staff": 3500,
      "value": 90
    },
    {
      "id": "pathway",
      "icon": "🎖️",
      "name": "SPACE WALE$ Pathway League",
      "pct": 5,
      "staff": 2000,
      "value": 82
    },
    {
      "id": "farm_twins",
      "icon": "🚜",
      "name": "Digital farm twins + terrain maps",
      "pct": 3,
      "staff": 1000,
      "value": 76
    },
    {
      "id": "health",
      "icon": "🩺",
      "name": "Health + prevention",
      "pct": 11,
      "staff": 3000,
      "value": 88
    },
    {
      "id": "agrarian",
      "icon": "🌾",
      "name": "Agrarian WALE$ infrastructure",
      "pct": 10,
      "staff": 2500,
      "value": 84
    },
    {
      "id": "eco_energy",
      "icon": "🔋",
      "name": "Eco-fuel / school energy hives",
      "pct": 6,
      "staff": 1250,
      "value": 78
    },
    {
      "id": "transport",
      "icon": "🚌",
      "name": "Transport + service access",
      "pct": 8,
      "staff": 1750,
      "value": 80
    },
    {
      "id": "enterprise",
      "icon": "💼",
      "name": "Enterprise + apprenticeships",
      "pct": 8,
      "staff": 2000,
      "value": 82
    },
    {
      "id": "spacegis",
      "icon": "🛰️",
      "name": "Space, GIS, sensors, astronomy",
      "pct": 6,
      "staff": 1500,
      "value": 80
    },
    {
      "id": "animals",
      "icon": "🐑",
      "name": "Animal guilds + ecology",
      "pct": 4,
      "staff": 1250,
      "value": 74
    },
    {
      "id": "hives",
      "icon": "🏘️",
      "name": "Hamlets, villages, towns, cities",
      "pct": 3,
      "staff": 1000,
      "value": 70
    },
    {
      "id": "cyber",
      "icon": "🔐",
      "name": "Cybersecurity + civil resilience",
      "pct": 3,
      "staff": 1000,
      "value": 76
    },
    {
      "id": "evidence",
      "icon": "🧾",
      "name": "Evidence, CoRT60, audit",
      "pct": 1,
      "staff": 750,
      "value": 68
    }
  ],
  "hives": [
    {
      "id": "holyhead",
      "name": "Holyhead",
      "icon": "🚆",
      "lon": -4.633,
      "lat": 53.3103,
      "type": "transport"
    },
    {
      "id": "bangor",
      "name": "Bangor",
      "icon": "🏫",
      "lon": -4.1293,
      "lat": 53.2274,
      "type": "education"
    },
    {
      "id": "eryri",
      "name": "Eryri / Snowdonia",
      "icon": "⛰️",
      "lon": -3.891,
      "lat": 52.918,
      "type": "pathway"
    },
    {
      "id": "wrexham",
      "name": "Wrexham",
      "icon": "💼",
      "lon": -2.9925,
      "lat": 53.0465,
      "type": "enterprise"
    },
    {
      "id": "aberystwyth",
      "name": "Aberystwyth",
      "icon": "🔭",
      "lon": -4.0829,
      "lat": 52.4153,
      "type": "spacegis"
    },
    {
      "id": "brecon",
      "name": "Brecon",
      "icon": "🌌",
      "lon": -3.391,
      "lat": 51.947,
      "type": "spacegis"
    },
    {
      "id": "cardigan",
      "name": "Cardigan",
      "icon": "🐝",
      "lon": -4.6592,
      "lat": 52.0837,
      "type": "animals"
    },
    {
      "id": "carmarthen",
      "name": "Carmarthen",
      "icon": "🌾",
      "lon": -4.3121,
      "lat": 51.8576,
      "type": "agrarian"
    },
    {
      "id": "swansea",
      "name": "Swansea",
      "icon": "⚙️",
      "lon": -3.9436,
      "lat": 51.6214,
      "type": "enterprise"
    },
    {
      "id": "cardiff",
      "name": "Cardiff",
      "icon": "🏙️",
      "lon": -3.1791,
      "lat": 51.4816,
      "type": "hives"
    },
    {
      "id": "newport",
      "name": "Newport",
      "icon": "🚑",
      "lon": -2.9977,
      "lat": 51.5842,
      "type": "transport"
    },
    {
      "id": "stdavids",
      "name": "St David’s",
      "icon": "🌊",
      "lon": -5.269,
      "lat": 51.882,
      "type": "animals"
    }
  ],
  "tunes": [
    {
      "id": "t01",
      "icon": "🌙",
      "name": "Moon Wonder + Family Story",
      "cohort": "5–7",
      "mods": {
        "education": 5,
        "spacegis": 5,
        "pathway": 2
      }
    },
    {
      "id": "t02",
      "icon": "🐝",
      "name": "School Hive + Pollinator Art",
      "cohort": "5–7",
      "mods": {
        "animals": 5,
        "education": 3,
        "hives": 2
      }
    },
    {
      "id": "t03",
      "icon": "🏃",
      "name": "Movement + Confidence Play",
      "cohort": "5–7",
      "mods": {
        "health": 6,
        "education": 2,
        "pathway": 2
      }
    },
    {
      "id": "t04",
      "icon": "📚",
      "name": "Library Language Hive",
      "cohort": "5–7",
      "mods": {
        "education": 5,
        "hives": 3,
        "evidence": 2
      }
    },
    {
      "id": "t05",
      "icon": "🐺",
      "name": "Cubs / Brownies Team Play",
      "cohort": "8–10",
      "mods": {
        "pathway": 7,
        "health": 2,
        "transport": 2
      }
    },
    {
      "id": "t06",
      "icon": "🧭",
      "name": "Map + Compass Adventure",
      "cohort": "8–10",
      "mods": {
        "pathway": 4,
        "spacegis": 4,
        "transport": 3
      }
    },
    {
      "id": "t07",
      "icon": "🐓",
      "name": "School Ark Responsibility",
      "cohort": "8–10",
      "mods": {
        "animals": 6,
        "education": 2,
        "agrarian": 2
      }
    },
    {
      "id": "t08",
      "icon": "🔋",
      "name": "Eco-Energy School Challenge",
      "cohort": "8–10",
      "mods": {
        "eco_energy": 7,
        "education": 2,
        "compute": 1
      }
    },
    {
      "id": "t09",
      "icon": "🔭",
      "name": "Scouts / Guides Telescope Fieldwork",
      "cohort": "11–13",
      "mods": {
        "spacegis": 6,
        "pathway": 3,
        "education": 2
      }
    },
    {
      "id": "t10",
      "icon": "💧",
      "name": "River Farm Scientist",
      "cohort": "11–13",
      "mods": {
        "agrarian": 4,
        "animals": 4,
        "spacegis": 3
      }
    },
    {
      "id": "t11",
      "icon": "🚜",
      "name": "Farm Twin Mapper I",
      "cohort": "11–13",
      "mods": {
        "farm_twins": 7,
        "spacegis": 4,
        "compute": 2
      }
    },
    {
      "id": "t12",
      "icon": "🎨",
      "name": "County Eco-Art Evidence",
      "cohort": "11–13",
      "mods": {
        "pathway": 4,
        "animals": 3,
        "evidence": 3
      }
    },
    {
      "id": "t13",
      "icon": "🎖️",
      "name": "Civil Resilience Cadet Basics",
      "cohort": "14–16",
      "mods": {
        "pathway": 5,
        "transport": 3,
        "cyber": 3
      }
    },
    {
      "id": "t14",
      "icon": "🛰️",
      "name": "Satellite GIS + Terrain",
      "cohort": "14–16",
      "mods": {
        "spacegis": 6,
        "farm_twins": 5,
        "compute": 3
      }
    },
    {
      "id": "t15",
      "icon": "⚛️",
      "name": "Physics of Energy + Machinery",
      "cohort": "14–16",
      "mods": {
        "eco_energy": 5,
        "education": 3,
        "agrarian": 2
      }
    },
    {
      "id": "t16",
      "icon": "🧪",
      "name": "Chemistry of Soil + Water",
      "cohort": "14–16",
      "mods": {
        "agrarian": 4,
        "animals": 3,
        "education": 3
      }
    },
    {
      "id": "t17",
      "icon": "💼",
      "name": "Enterprise Honey Challenge",
      "cohort": "14–16",
      "mods": {
        "enterprise": 6,
        "pathway": 3,
        "evidence": 2
      }
    },
    {
      "id": "t18",
      "icon": "🏥",
      "name": "Sport-Health Prevention",
      "cohort": "14–16",
      "mods": {
        "health": 7,
        "hives": 2,
        "evidence": 1
      }
    },
    {
      "id": "t19",
      "icon": "🎓",
      "name": "College Apprenticeship Bridge",
      "cohort": "16–24",
      "mods": {
        "enterprise": 5,
        "education": 4,
        "transport": 2
      }
    },
    {
      "id": "t20",
      "icon": "🌾",
      "name": "SPACE Farmer Capstone",
      "cohort": "16–24",
      "mods": {
        "agrarian": 7,
        "farm_twins": 5,
        "enterprise": 4
      }
    },
    {
      "id": "t21",
      "icon": "🧠",
      "name": "AI/ML Farm Optimiser",
      "cohort": "16–24",
      "mods": {
        "compute": 7,
        "farm_twins": 4,
        "evidence": 3
      }
    },
    {
      "id": "t22",
      "icon": "🐑",
      "name": "Animal Guild Husbandry",
      "cohort": "16–24",
      "mods": {
        "animals": 7,
        "agrarian": 4,
        "pathway": 2
      }
    },
    {
      "id": "t23",
      "icon": "🏘️",
      "name": "Community Hive Service",
      "cohort": "adult",
      "mods": {
        "hives": 5,
        "health": 3,
        "transport": 3
      }
    },
    {
      "id": "t24",
      "icon": "📚",
      "name": "Elder Memory + Welsh Culture",
      "cohort": "elder",
      "mods": {
        "hives": 4,
        "education": 3,
        "health": 2
      }
    }
  ]
};
