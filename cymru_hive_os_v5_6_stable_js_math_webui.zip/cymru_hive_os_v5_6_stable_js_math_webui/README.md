# Cymru Hive OS v5.6 Stable JS Maths WebUI

This is a clean corrected rebuild.

It deliberately leaves out the broken DataMap/WMS/WFS web-service path and returns to a local working WebUI.

## Run

```bash
cd cymru_hive_os_v5_6_stable_js_math_webui
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## What is included

- Local old-style Wales map canvas
- Budget sliders
- Staff sliders
- 24 auto-tunes
- JavaScript mathematics engine:
  - 0/1 knapsack
  - near-target subset sum
  - greedy coverage optimiser
  - ACO route construction
  - BCO allocation
  - PSO update
  - predator/prey difference equation
  - Mandelbrot/fractal pruning
  - ROI composition
- Save math chart as PNG
- Export scenario JSON

## Main files

```text
index.html
assets/css/styles.css
assets/js/data.js
assets/js/math_engine.js
assets/js/app.js
```

## Note

This package has one top-level folder only. After unzip, `index.html` is directly inside that folder.
