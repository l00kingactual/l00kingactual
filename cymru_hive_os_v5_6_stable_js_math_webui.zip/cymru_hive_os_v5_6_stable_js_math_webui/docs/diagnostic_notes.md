# Diagnostic notes

The previous v5.5 package was likely failing because the ZIP contained a double-nested folder path. After unzip, the user landed in an outer folder without `index.html`.

This v5.6 package is rebuilt cleanly with:

- one top-level folder
- `index.html` directly inside the folder
- no external WMS/WFS dependency
- no PHP dependency
- no server proxy dependency
- only three JS files loaded by the page
