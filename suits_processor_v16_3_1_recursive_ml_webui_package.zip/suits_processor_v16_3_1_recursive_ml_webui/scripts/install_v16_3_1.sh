#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/andy/Documents/suitsmafia"
SITE="$ROOT/susitsmafia_website"
PROC_DIR="$ROOT/processors/suits_processor_v16_3_1_recursive_ml_webui"
TOOLS_DIR="$ROOT/tools"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$ROOT/processors" "$TOOLS_DIR" "$SITE" "$SITE/css" "$SITE/js" "$SITE/api" "$SITE/images" "$SITE/data"
rm -rf "$PROC_DIR"
mkdir -p "$PROC_DIR"
rsync -a "$SRC_DIR/" "$PROC_DIR/"
rsync -a "$SRC_DIR/web/" "$SITE/"
rsync -a "$SRC_DIR/api/" "$SITE/api/"
rsync -a "$SRC_DIR/css/" "$SITE/css/"
rsync -a "$SRC_DIR/js/" "$SITE/js/"
rsync -a "$SRC_DIR/icons/" "$SITE/images/suits_v16_3_1_icons/"
cat > "$TOOLS_DIR/suits_processor_v16_3_1_recursive_ml_webui" <<LAUNCH
#!/usr/bin/env bash
set -euo pipefail
cd "$PROC_DIR"
exec ./run_v16_3_1_recursive_ml_webui.sh "\$@"
LAUNCH
chmod +x "$TOOLS_DIR/suits_processor_v16_3_1_recursive_ml_webui"
echo '[o][o] Suits Processor v16.3.1 installed.'
echo "Processor: $PROC_DIR"
echo "Launcher:  $TOOLS_DIR/suits_processor_v16_3_1_recursive_ml_webui"
echo "WebUI:     $SITE/suits_v16_3_1_dashboard.php"
