# [o][o] $uits Processor v16.3.1 — Recursive ML WebUI + Predation Pattern Learner

This package fixes the v16.3 installer issue and adds a broader recursive processor for the whole `/home/andy/Documents/suitsmafia` tree.

It scans previous processor outputs, music/audio/video/stills/APNGs/logs/metadata, builds lightweight ML-style feature matrices, learns predation/comedy/story priors from past outputs, exports SQLite/CSV/JSON/Neo4j, and installs a themed WebUI with navigation, home link, logo header, and mouse trail on every page.

## Install

```bash
cd /home/andy/Downloads
unzip -o /mnt/data/suits_processor_v16_3_1_recursive_ml_webui_package.zip
cd suits_processor_v16_3_1_recursive_ml_webui
chmod +x scripts/*.sh tools/*.py run_v16_3_1_recursive_ml_webui.sh
./scripts/install_v16_3_1.sh
```

## Run

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_3_1_recursive_ml_webui
```

Direct run:

```bash
./run_v16_3_1_recursive_ml_webui.sh
```

## Open WebUI

```bash
cd /home/andy/Documents/suitsmafia/susitsmafia_website
php -S 127.0.0.1:8081
```

Open:

```text
http://127.0.0.1:8081/suits_v16_3_1_dashboard.php
```

## Outputs

```text
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_3_1_recursive_ml_webui
```

Key outputs:

```text
summary.json
learned_predation_patterns.json
action_event_chains.json
song_action_recommendations.json
action_song_recommendations.json
music_playlists.json
dougies_story.json
aims_goals.json
stills_index.json
webui_index.json
sql/suits_v16_3_1_recursive_ml.sqlite3
sql/*.csv
neo4j/neo4j_nodes.csv
neo4j/neo4j_edges.csv
neo4j/suits_v16_3_1_import.cypher
neo4j/suits_v16_3_1_import_no_apoc.cypher
report.html
```
