#!/usr/bin/env python3
"""
$uits v18 Render Factory
Generates stills, APNG previews, 29-second song clips, full-song movies, and one full film.

Designed for mirrored VPS/local roots such as:
  /home/andy/Documents/suitsmafia

Inputs are normally produced by v16.6/v16.6.1:
  outputs/suits_processor_v16_6_dramatic_movie_theatre/movie_factory_12.json
  outputs/suits_processor_v16_6_dramatic_movie_theatre/grouped_playlists.json
  outputs/suits_processor_v16_6_dramatic_movie_theatre/song_action_recommendations.json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

DEFAULT_ROOT = Path("/home/andy/Documents/suitsmafia")
DEFAULT_OUT_REL = Path("outputs/suits_processor_v16_6_dramatic_movie_theatre")
DEFAULT_SITE_REL = Path("susitsmafia_website")

VIDEO_EXTS = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"}
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}


def run(cmd: List[str], *, check: bool = True, quiet: bool = False) -> subprocess.CompletedProcess:
    if not quiet:
        print("[cmd]", " ".join(shlex_quote(c) for c in cmd), flush=True)
    return subprocess.run(cmd, check=check)


def shlex_quote(s: str) -> str:
    if re.fullmatch(r"[A-Za-z0-9_./:=,+@%\-]+", s):
        return s
    return "'" + s.replace("'", "'\\''") + "'"


def which_or_die(name: str) -> None:
    if shutil.which(name) is None:
        print(f"[error] required binary not found: {name}", file=sys.stderr)
        sys.exit(2)


def load_json(path: Path, default: Any) -> Any:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return default


def slugify(text: str, max_len: int = 90) -> str:
    text = text.replace("$", "s")
    text = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")
    text = re.sub(r"_+", "_", text)
    return (text[:max_len] or "item").strip("_")


def rewrite_path(path: Optional[str], local_root: Path, root: Path) -> Optional[Path]:
    if not path:
        return None
    p = Path(path)
    # v16.6 data may contain local /home/andy paths. Replace prefix with chosen root.
    old = Path("/home/andy/Documents/suitsmafia")
    try:
        rel = p.relative_to(old)
        return root / rel
    except Exception:
        pass
    if p.is_absolute():
        return p
    return root / p


def ffprobe_duration(path: Path) -> float:
    try:
        cp = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nk=1:nw=1", str(path)],
            check=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
        )
        return max(0.0, float(cp.stdout.strip() or "0"))
    except Exception:
        return 0.0


def concat_file(files: Iterable[Path], path: Path) -> int:
    count = 0
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for item in files:
            if item and item.exists():
                f.write("file " + shlex_quote(str(item)) + "\n")
                count += 1
    return count


def loop_clip_list_to_duration(clips: List[Path], target_seconds: float) -> List[Path]:
    clean = [c for c in clips if c.exists()]
    if not clean:
        return []
    total = sum(ffprobe_duration(c) or 20.0 for c in clean)
    if total <= 0:
        total = len(clean) * 20.0
    reps = max(1, int(target_seconds / total) + 2)
    return clean * reps


@dataclass
class MoviePlan:
    movie_id: str
    title: str
    song_path: Optional[Path]
    clips: List[Path] = field(default_factory=list)
    animal_class: str = "mixed"
    song_mood: str = "mixed"


def plan_from_movie_factory(data: Any, root: Path) -> List[MoviePlan]:
    plans: List[MoviePlan] = []
    if not isinstance(data, list):
        return plans
    for idx, row in enumerate(data, 1):
        if not isinstance(row, dict):
            continue
        song = row.get("song") or {}
        song_path = rewrite_path(song.get("path"), DEFAULT_ROOT, root) if isinstance(song, dict) else None
        clips = []
        for c in row.get("clips", []) or []:
            if isinstance(c, dict):
                cp = rewrite_path(c.get("path"), DEFAULT_ROOT, root)
                if cp:
                    clips.append(cp)
        plans.append(MoviePlan(
            movie_id=str(row.get("movie_id") or f"movie_{idx:02d}"),
            title=str(row.get("title") or f"$uit$ Movie {idx:02d}"),
            song_path=song_path,
            clips=clips,
            animal_class=str(row.get("animal_class") or "mixed"),
            song_mood=str(row.get("song_mood") or "mixed"),
        ))
    return plans


def plan_from_grouped_playlists(data: Any, root: Path) -> List[MoviePlan]:
    plans: List[MoviePlan] = []
    if not isinstance(data, list):
        return plans
    for idx, pl in enumerate(data, 1):
        if not isinstance(pl, dict):
            continue
        items = pl.get("items") or []
        if not items:
            continue
        first = items[0]
        song_path = rewrite_path(first.get("song_path"), DEFAULT_ROOT, root) if isinstance(first, dict) else None
        clips = []
        for item in items:
            if isinstance(item, dict):
                cp = rewrite_path(item.get("video_path"), DEFAULT_ROOT, root)
                if cp:
                    clips.append(cp)
        plans.append(MoviePlan(
            movie_id=str(pl.get("playlist_id") or f"playlist_{idx:02d}"),
            title=str(pl.get("title") or f"Playlist {idx:02d}"),
            song_path=song_path,
            clips=clips,
            animal_class=str(pl.get("animal_class") or "mixed"),
            song_mood=str(pl.get("song_mood") or "mixed"),
        ))
    return plans


def plan_from_recommendations(data: Any, root: Path, max_songs: int) -> List[MoviePlan]:
    # Build one plan per song, using best matching clips.
    by_song: Dict[str, Dict[str, Any]] = {}
    if not isinstance(data, list):
        return []
    for item in data:
        if not isinstance(item, dict):
            continue
        sp = item.get("song_path")
        vp = item.get("video_path")
        if not sp or not vp:
            continue
        song_key = str(sp)
        rec = by_song.setdefault(song_key, {
            "song_path": rewrite_path(sp, DEFAULT_ROOT, root),
            "song_name": item.get("song_name") or Path(sp).name,
            "clips": [],
            "scores": [],
            "animal": item.get("animal_class") or "mixed",
            "mood": item.get("song_mood") or "mixed",
        })
        cp = rewrite_path(vp, DEFAULT_ROOT, root)
        if cp:
            rec["clips"].append(cp)
            rec["scores"].append(float(item.get("score") or 0.0))
    ranked = sorted(by_song.values(), key=lambda r: (len(r["clips"]), sum(r["scores"])), reverse=True)
    plans = []
    for idx, rec in enumerate(ranked[:max_songs], 1):
        plans.append(MoviePlan(
            movie_id=f"song_{idx:02d}_{slugify(str(rec['song_name']), 40)}",
            title=f"$uit$ Song Movie {idx:02d}: {rec['song_name']}",
            song_path=rec["song_path"],
            clips=rec["clips"][:36],
            animal_class=str(rec.get("animal") or "mixed"),
            song_mood=str(rec.get("mood") or "mixed"),
        ))
    return plans


def dedupe_plans(plans: List[MoviePlan]) -> List[MoviePlan]:
    seen: set[str] = set()
    out: List[MoviePlan] = []
    for p in plans:
        key = f"{p.movie_id}|{p.song_path}"
        if key in seen:
            continue
        seen.add(key)
        # Deduplicate clips while preserving order.
        clip_seen: set[str] = set()
        clips = []
        for c in p.clips:
            s = str(c)
            if s not in clip_seen:
                clip_seen.add(s)
                clips.append(c)
        p.clips = clips
        out.append(p)
    return out


def make_still(clip: Path, out: Path, second: float = 1.0) -> bool:
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-ss", str(second), "-i", str(clip), "-frames:v", "1", "-q:v", "2", str(out)]
    return subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0


def make_apng(clip: Path, out: Path, seconds: int = 5, fps: int = 8, width: int = 640) -> bool:
    out.parent.mkdir(parents=True, exist_ok=True)
    vf = f"fps={fps},scale={width}:-1:flags=lanczos"
    cmd = ["ffmpeg", "-y", "-t", str(seconds), "-i", str(clip), "-vf", vf, "-plays", "0", str(out)]
    return subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0


def render_song_movie(plan: MoviePlan, out_file: Path, clip_seconds: Optional[int] = None) -> bool:
    if not plan.song_path or not plan.song_path.exists():
        print(f"[skip] missing song for {plan.movie_id}: {plan.song_path}")
        return False
    clips = [c for c in plan.clips if c.exists()]
    if not clips:
        print(f"[skip] no clips for {plan.movie_id}")
        return False
    target = float(clip_seconds) if clip_seconds else (ffprobe_duration(plan.song_path) or 240.0)
    looped = loop_clip_list_to_duration(clips, target)
    concat_path = out_file.with_suffix(".concat.txt")
    concat_file(looped, concat_path)
    out_file.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_path),
        "-i", str(plan.song_path),
    ]
    if clip_seconds:
        cmd += ["-t", str(clip_seconds)]
    cmd += [
        "-map", "0:v:0", "-map", "1:a:0", "-shortest",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k", str(out_file)
    ]
    rc = subprocess.run(cmd).returncode
    return rc == 0 and out_file.exists()


def render_full_film(movie_files: List[Path], out_file: Path) -> bool:
    files = [f for f in movie_files if f.exists()]
    if not files:
        print("[skip] no full-song movies for full film")
        return False
    out_file.parent.mkdir(parents=True, exist_ok=True)
    concat_path = out_file.with_suffix(".concat.txt")
    concat_file(files, concat_path)
    # Try stream copy first, fallback to reencode.
    copy_cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_path), "-c", "copy", str(out_file)]
    if subprocess.run(copy_cmd).returncode == 0 and out_file.exists():
        return True
    enc_cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_path),
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k", str(out_file)
    ]
    return subprocess.run(enc_cmd).returncode == 0 and out_file.exists()


def publish_to_site(render_root: Path, site: Path) -> None:
    dest = site / "videos" / "renders_v18"
    dest.mkdir(parents=True, exist_ok=True)
    for mp4 in render_root.rglob("*.mp4"):
        shutil.copy2(mp4, dest / mp4.name)
    print(f"[publish] copied renders to {dest}")


def main() -> int:
    ap = argparse.ArgumentParser(description="$uits v18 Render Factory")
    ap.add_argument("--root", default=str(DEFAULT_ROOT), help="Suits root folder")
    ap.add_argument("--out", default=None, help="Processor output folder")
    ap.add_argument("--site", default=None, help="Website folder")
    ap.add_argument("--max-songs", type=int, default=18, help="maximum full-song movies")
    ap.add_argument("--stills", action="store_true", help="generate still thumbnails")
    ap.add_argument("--apng", action="store_true", help="generate APNG previews")
    ap.add_argument("--clips29", action="store_true", help="render 29-second song movies")
    ap.add_argument("--full-songs", action="store_true", help="render full-song song movies")
    ap.add_argument("--full-movie", action="store_true", help="render full movie from full-song movies")
    ap.add_argument("--publish", action="store_true", help="copy rendered movies to WebsiteUI videos/renders_v18")
    ap.add_argument("--all", action="store_true", help="do stills, APNG, 29s, full songs, full movie, publish")
    ap.add_argument("--apng-seconds", type=int, default=5)
    ap.add_argument("--apng-fps", type=int, default=8)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    root = Path(args.root)
    out = Path(args.out) if args.out else root / DEFAULT_OUT_REL
    site = Path(args.site) if args.site else root / DEFAULT_SITE_REL
    render_root = out / "renders_v18"

    which_or_die("ffmpeg")
    which_or_die("ffprobe")

    movie_factory = load_json(out / "movie_factory_12.json", [])
    grouped_playlists = load_json(out / "grouped_playlists.json", [])
    recommendations = load_json(out / "song_action_recommendations.json", [])

    plans = []
    plans.extend(plan_from_movie_factory(movie_factory, root))
    plans.extend(plan_from_grouped_playlists(grouped_playlists, root))
    # Recommendations create extra song movies until max-songs reached.
    plans = dedupe_plans(plans)
    if len(plans) < args.max_songs:
        plans.extend(plan_from_recommendations(recommendations, root, args.max_songs * 2))
        plans = dedupe_plans(plans)
    plans = plans[: args.max_songs]

    print(f"[o][o] plans={len(plans)} out={out}")
    if not plans:
        print("[error] no plans found. Run v16.6.1 processor first or upload output JSONs.", file=sys.stderr)
        return 1

    manifest: Dict[str, Any] = {"schema": "suits_v18_render_factory", "root": str(root), "out": str(out), "site": str(site), "plans": []}

    do_stills = args.all or args.stills
    do_apng = args.all or args.apng
    do_29 = args.all or args.clips29
    do_full = args.all or args.full_songs
    do_movie = args.all or args.full_movie
    do_publish = args.all or args.publish

    full_song_outputs: List[Path] = []

    for idx, plan in enumerate(plans, 1):
        slug = f"{idx:02d}_{slugify(plan.title)}"
        print(f"[plan] {idx:02d} {plan.title} clips={len(plan.clips)} song={plan.song_path}")
        plan_entry = {"movie_id": plan.movie_id, "title": plan.title, "song": str(plan.song_path) if plan.song_path else None, "clips": [str(c) for c in plan.clips]}

        existing_clips = [c for c in plan.clips if c.exists()]
        if do_stills:
            still_dir = render_root / "stills" / slug
            made = 0
            for j, clip in enumerate(existing_clips[:18], 1):
                if make_still(clip, still_dir / f"still_{j:03d}_{slugify(clip.stem, 60)}.jpg"):
                    made += 1
            plan_entry["stills"] = made

        if do_apng:
            apng_dir = render_root / "apng" / slug
            made = 0
            for j, clip in enumerate(existing_clips[:6], 1):
                if make_apng(clip, apng_dir / f"preview_{j:03d}_{slugify(clip.stem, 60)}.apng", args.apng_seconds, args.apng_fps):
                    made += 1
            plan_entry["apng"] = made

        if do_29:
            clip29_out = render_root / "clip29_movies" / f"{slug}_29s.mp4"
            if not args.dry_run:
                ok = render_song_movie(plan, clip29_out, clip_seconds=29)
            else:
                ok = False
            plan_entry["clip29_output"] = str(clip29_out)
            plan_entry["clip29_ok"] = ok

        full_out = render_root / "full_song_movies" / f"{slug}_full_song.mp4"
        if do_full:
            if not args.dry_run:
                ok = render_song_movie(plan, full_out, clip_seconds=None)
            else:
                ok = False
            plan_entry["full_song_output"] = str(full_out)
            plan_entry["full_song_ok"] = ok
        if full_out.exists():
            full_song_outputs.append(full_out)
        manifest["plans"].append(plan_entry)

    if do_movie:
        full_film = render_root / "full_film" / "suits_full_movie_18_songs.mp4"
        ok = False if args.dry_run else render_full_film(full_song_outputs, full_film)
        manifest["full_movie_output"] = str(full_film)
        manifest["full_movie_ok"] = ok

    if do_publish:
        publish_to_site(render_root, site)

    manifest_path = render_root / "render_manifest_v18.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"[done] manifest={manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
