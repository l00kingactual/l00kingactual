# $uits v18 Render Factory

This is a standalone Python renderer for the v16.6/v16.6.1 output database.

It generates:

- still JPG frames
- APNG previews
- 29-second song movies
- full-song song movies
- one full movie made from up to 18 full-song movies
- optional publish copy into WebsiteUI videos/renders_v18

## Expected input

Run or upload v16.6.1 first so this exists:

```bash
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre
```

It uses these files when present:

```text
movie_factory_12.json
grouped_playlists.json
song_action_recommendations.json
```

## Install on VPS

```bash
cd /root
unzip -o suits_v18_render_factory.zip
chmod +x suits_v18_render_factory/*.py suits_v18_render_factory/*.sh
mkdir -p /home/andy/Documents/suitsmafia/tools
cp suits_v18_render_factory/suits_v18_render_factory.py /home/andy/Documents/suitsmafia/tools/
cp suits_v18_render_factory/run_v18_render_all.sh /home/andy/Documents/suitsmafia/tools/
```

## Run everything

```bash
SUITS_ROOT=/home/andy/Documents/suitsmafia \
py /home/andy/Documents/suitsmafia/tools/suits_v18_render_factory.py \
  --root /home/andy/Documents/suitsmafia \
  --max-songs 18 \
  --all
```

Or:

```bash
SUITS_ROOT=/home/andy/Documents/suitsmafia \
/home/andy/Documents/suitsmafia/tools/run_v18_render_all.sh
```

## Render only selected outputs

```bash
py /home/andy/Documents/suitsmafia/tools/suits_v18_render_factory.py \
  --root /home/andy/Documents/suitsmafia \
  --max-songs 18 \
  --stills --apng --clips29
```

```bash
py /home/andy/Documents/suitsmafia/tools/suits_v18_render_factory.py \
  --root /home/andy/Documents/suitsmafia \
  --max-songs 18 \
  --full-songs --full-movie --publish
```

## Outputs

```text
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre/renders_v18/stills
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre/renders_v18/apng
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre/renders_v18/clip29_movies
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre/renders_v18/full_song_movies
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre/renders_v18/full_film/suits_full_movie_18_songs.mp4
```
