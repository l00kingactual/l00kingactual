#!/usr/bin/env bash
set -euo pipefail
ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
PY="${SUITS_PYTHON:-py}"
exec "$PY" "$(dirname "$0")/suits_v18_render_factory.py" --root "$ROOT" --max-songs "${MAX_SONGS:-18}" --all "$@"
