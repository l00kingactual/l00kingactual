#!/usr/bin/env python3
"""
$uits Media Director v8
Local-first fictional GTA/FiveM / machinima media director.

Boundary:
  This tool treats predation, Sun Tzu, Janus, humour, tactics, kills, prey and predator
  as editorial/media-analysis tags for fictional GTARP / FiveM / machinima footage.
  It is not real-world tactical guidance.

Core jobs:
  - scan video and music folders/playlists
  - generate a canonical media dictionary
  - generate cue sheets for full-track or timing-window edits
  - score/select candidate footage using editorial labels
  - export JSON/CSV/HTML outputs
  - optionally call FFmpeg/FFprobe for metadata and render extracts
  - run a simple local WebUI with no external Python packages
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import html
import json
import mimetypes
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
from dataclasses import dataclass, asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterable

APP_NAME = "$uits Media Director v8"
SCHEMA = "suits_media_director_v8"

VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v"}
MUSIC_EXTS = {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".webm", ".mp4"}
PLAYLIST_EXTS = {".m3u", ".m3u8", ".txt", ".json", ".csv"}

DEFAULT_VIDEO_DIRS = [
    "/home/andy/Documents/suitsmafia/videos",
    "/home/andy/Documents/suitsmafia/videos/disciples",
    "/home/andy/Documents/suitsmafia/videos/disciples/youtube",
    "/home/andy/Documents/suitsmafia/videos/suits_youtube",
    "/home/andy/Documents/suitsmafia/videos/youtube",
]
DEFAULT_MUSIC_DIRS = [
    "/home/andy/Documents/suitsmafia/music_mp4",
]
DEFAULT_OUT = "/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8"

SUITS_VIDEO_DIRS = [
    "/home/andy/Documents/suitsmafia/videos",
    "/home/andy/Documents/suitsmafia/videos/suits_youtube",
    "/home/andy/Documents/suitsmafia/videos/youtube",
]
DISCIPLES_VIDEO_DIRS = [
    "/home/andy/Documents/suitsmafia/videos/disciples",
    "/home/andy/Documents/suitsmafia/videos/disciples/youtube",
]
MUSIC_LIBRARY_DIR = "/home/andy/Documents/suitsmafia/music_mp4"
KNOWN_SONGS = {
    "good4u_suits": {
        "title": "good 4 u",
        "project": "suits",
        "music_file": "/home/andy/Documents/suitsmafia/music_mp4/good_4_u.webm",
        "profile": "good_4_u",
        "tone": "fast irony / comedy / sharp escalation",
    },
    "shoot_to_thrill_suits": {
        "title": "Shoot to Thrill",
        "project": "suits",
        "music_file": "/home/andy/Documents/suitsmafia/music_mp4/Shoot to Thrill [wLoWd2KyUro].webm",
        "profile": "shoot_to_thrill",
        "tone": "swagger / controlled burst / action chain",
    },
    "bat_out_of_hell_disciples": {
        "title": "Bat Out of Hell",
        "project": "disciples",
        "music_file": "/home/andy/Documents/suitsmafia/music_mp4/Meat Loaf - Bat Out of Hell (PCM Stereo) [3QGMCSCFoKA].webm",
        "profile": "bat_out_of_hell",
        "tone": "long narrative / pursuit / epic aftermath",
    },
    "hells_bells_disciples": {
        "title": "Hells Bells",
        "project": "disciples",
        "music_file": "/home/andy/Documents/suitsmafia/music_mp4/Hells Bells [GL56LY6fE0E].webm",
        "profile": "hells_bells",
        "tone": "ominous / ambush / aftermath control",
    },
    "who_made_who_all": {
        "title": "Who Made Who",
        "project": "all",
        "music_file": "/home/andy/Documents/suitsmafia/music_mp4/AC⧸DC - Who Made Who (Official HD Video) [PiZHNw1MtzI].webm",
        "profile": "who_made_who",
        "tone": "machine question / identity reveal / predator-prey irony",
    },
    "who_made_who_suits": {
        "title": "Who Made Who",
        "project": "suits",
        "music_file": "/home/andy/Documents/suitsmafia/music_mp4/AC⧸DC - Who Made Who (Official HD Video) [PiZHNw1MtzI].webm",
        "profile": "who_made_who",
        "tone": "Suits identity / irony / comic machine intelligence",
    },
    "who_made_who_disciples": {
        "title": "Who Made Who",
        "project": "disciples",
        "music_file": "/home/andy/Documents/suitsmafia/music_mp4/AC⧸DC - Who Made Who (Official HD Video) [PiZHNw1MtzI].webm",
        "profile": "who_made_who",
        "tone": "Disciples pressure / prey question / machine judgement",
    },
}

LABEL_DICTIONARY: dict[str, Any] = {
    "boundary": "Fictional GTA/FiveM / machinima media analysis; editorial tags, not real-world conduct.",
    "evidence_hierarchy": [
        "server_confirmed", "client_confirmed", "manual_confirmed", "OCR_confirmed",
        "video_strong", "video_inferred", "filename_guess"
    ],
    "event_classes": {
        "spectacular": {"icon": "⭐", "meaning": "apex/standout moment, strong image value"},
        "funny": {"icon": "😂", "meaning": "incongruity, bad timing, absurd movement, lyric irony"},
        "gory_bloody": {"icon": "🩸", "meaning": "red-impact/blood-proxy/heavy aftermath; review before public"},
        "accidental": {"icon": "🎲", "meaning": "unexpected failure or environmental outcome"},
        "plus_chain": {"icon": "➕", "meaning": "linked sequence/chain/clustered events"},
        "team_play": {"icon": "🤝", "meaning": "coordination, support, pack pressure"},
        "controlled_burst": {"icon": "🎯", "meaning": "low-waste timing, clean burst, shot discipline"},
        "panic_event": {"icon": "🐇", "meaning": "panic turn, reactive movement, collapse"},
        "odd_unusual": {"icon": "🌀", "meaning": "rare geometry, strange survival, weird route"},
        "needs_review": {"icon": "❓", "meaning": "uncertain, needs human correction"},
    },
    "prey_types": {
        "exposed_prey": {"icon": "🐑", "behaviour": "stayed visible too long/no cover"},
        "isolated_prey": {"icon": "🐐", "behaviour": "separated from group/late regroup"},
        "panicked_prey": {"icon": "🐇", "behaviour": "erratic route/reactive movement"},
        "wounded_prey": {"icon": "🩸", "behaviour": "previously damaged, now finishable"},
        "winged_prey": {"icon": "🪽", "behaviour": "aim/path/formation disrupted"},
        "shelled_prey": {"icon": "🐢", "behaviour": "defensive but static"},
        "counter_threat_prey": {"icon": "🐃", "behaviour": "dangerous but overcommitted"},
        "comedic_prey": {"icon": "🐓", "behaviour": "mistake creates clip value"},
        "route_prey": {"icon": "🚗", "behaviour": "chased into predictable path"},
        "tunnel_prey": {"icon": "🎯", "behaviour": "focused forward, blind to side pressure"},
        "reload_prey": {"icon": "🔄", "behaviour": "reload/ammo transition exposed"},
        "baited_prey": {"icon": "🧲", "behaviour": "accepted lure or false opportunity"},
        "trap_prey": {"icon": "🕳️", "behaviour": "entered bad geometry or dead zone"},
    },
    "prey_behaviour_labels": [
        "overextended", "split_from_team", "late_regroup", "bad_route", "no_cover",
        "over_pursuit", "reload_exposure", "tunnel_vision", "panic_turn", "vehicle_trap",
        "missed_escape_window", "ignored_pressure", "accepted_bait", "entered_dead_zone",
        "lost_line_of_sight", "failed_crossfire", "static_under_fire", "poor_cover_choice",
        "blind_side_pressure", "bad_vehicle_exit"
    ],
    "predator_archetypes": {
        "lion_front_push": {"icon": "🦁", "meaning": "frontal dominance/direct push"},
        "leopard_ambush": {"icon": "🐆", "meaning": "stealth, flank, sudden pounce"},
        "snake_trap": {"icon": "🐍", "meaning": "bait, delay, deception, angle"},
        "shark_pursuit": {"icon": "🦈", "meaning": "relentless chase pressure"},
        "hyena_cleanup": {"icon": "🟣", "meaning": "pack pressure, poach, cleanup"},
        "wasp_harassment": {"icon": "🐝", "meaning": "repeated sting/harassment"},
    },
    "lens_stack": {
        "sun_tzu": ["timing", "terrain", "deception", "weak_points", "manoeuvre", "foreknowledge"],
        "janus": ["attacker_view", "defender_view", "team_view", "aftermath_view"],
        "thirteen_s": ["strategy", "structure", "systems", "skills", "style", "staff", "shared_values", "signals", "space", "sequence", "stress", "synergy", "selection"],
        "uqebm": ["smoothing", "norming", "scaling", "scoping", "marginal_value"],
        "de_bono": ["humour", "alternatives", "consequences", "lateral_punchline"],
        "aco_bco": ["selection_route", "swarm_pressure", "repeated_opportunity_trails"],
    },
    "auto_tunes": {
        "kill": {"icon": "🔥", "selects": ["kill_candidate", "shotline_strong", "route_stop", "clear_aftermath"], "music": "chorus/drop/final hit"},
        "wounding": {"icon": "🩸", "selects": ["hit_evidence", "target_survives", "route_changes", "team_pressure_increases"], "music": "build-up/pre-chorus"},
        "winging": {"icon": "🪽", "selects": ["formation_break", "aim_break", "path_break", "no_clear_kill"], "music": "bridge/tension/comic pause"},
        "comedy": {"icon": "😂", "selects": ["bad_timing", "panic_turn", "poach", "absurd_motion", "subtitle_potential"], "music": "lyric irony/beat stop"},
        "tactical": {"icon": "🧠", "selects": ["clean_angle", "line_of_sight", "pre_shot_setup", "low_waste_motion"], "music": "stalk/build-up"},
        "strategic": {"icon": "🏰", "selects": ["team_pressure", "territory", "aftermath_control", "scene_state_change"], "music": "longer narrative sections"},
        "odd": {"icon": "🌀", "selects": ["rare_geometry", "unexpected_outcome", "strange_fall", "weird_survival"], "music": "transition/bridge/Dougie gap"},
    },
    "song_profiles": {
        "shoot_to_thrill": {
            "icon": "🎸", "tone": "swagger/action/controlled burst",
            "preferred": ["spectacular", "controlled_burst", "plus_chain", "team_play", "solo_precision", "prey_panic_turn", "route_prey"],
            "placements": {"chorus": "kills/chain peaks", "riffs": "shotlines/pursuit", "breaks": "comedy/reload exposure"},
        },
        "hells_bells": {
            "icon": "🔔", "tone": "ominous/strategic/aftermath",
            "preferred": ["ambush", "territory", "all_out_assault", "strategic_pressure", "aftermath_control", "odd_unusual"],
            "placements": {"bell_intro": "slow stills/APNGs", "build": "stalking/terrain", "chorus": "decisive impacts"},
        },
        "good_4_u": {
            "icon": "💅", "tone": "fast irony/comedy/panic-turn/social clip energy",
            "preferred": ["funny", "panic_event", "odd_unusual", "comedic_prey", "plus_chain", "spectacular"],
            "placements": {"verse": "setup and social context", "chorus": "comedy/impact payoff", "break": "lyric irony and [o][o] captions"},
        },
        "bat_out_of_hell": {
            "icon": "🏍️", "tone": "epic ride/pursuit/long-form cinematic narrative",
            "preferred": ["route_prey", "shark_pursuit", "team_play", "survival_escape", "spectacular", "aftermath_control"],
            "placements": {"intro": "ride/stills/territory", "build": "pursuit and route pressure", "finale": "long aftermath and doctrine card"},
        },
        "who_made_who": {
            "icon": "🤖", "tone": "machine identity / cause-effect / predation irony",
            "preferred": ["kill_candidate", "predation", "prey", "team_play", "funny", "lyric_irony", "odd_unusual", "spectacular"],
            "placements": {"question_hook": "who caused this outcome", "chorus": "beat-to-kill or beat-to-fail", "break": "Janus attacker/prey reversal"},
        },
    },
}

@dataclass
class MediaAsset:
    asset_id: str
    path: str
    name: str
    kind: str
    ext: str
    size_bytes: int
    duration_s: float | None
    tags: list[str]
    source: str


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def safe_slug(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_") or "item"


def read_playlist(path: Path) -> list[Path]:
    if not path.exists():
        return []
    items: list[Path] = []
    ext = path.suffix.lower()
    try:
        if ext == ".json":
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                raw = data
            elif isinstance(data, dict):
                raw = data.get("items") or data.get("paths") or data.get("videos") or data.get("music") or []
            else:
                raw = []
            for entry in raw:
                if isinstance(entry, str):
                    items.append(Path(entry).expanduser())
                elif isinstance(entry, dict) and entry.get("path"):
                    items.append(Path(str(entry["path"])).expanduser())
        elif ext == ".csv":
            with path.open("r", encoding="utf-8", newline="") as fh:
                for row in csv.DictReader(fh):
                    value = row.get("path") or row.get("file") or row.get("filename") or row.get("source")
                    if value:
                        items.append(Path(value).expanduser())
        else:
            for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                items.append(Path(line).expanduser())
    except Exception:
        pass
    return items


def iter_files_from_dirs(dirs: Iterable[str], exts: set[str], recursive: bool = True) -> list[Path]:
    paths: list[Path] = []
    for raw in dirs:
        if not raw:
            continue
        root = Path(raw).expanduser()
        if not root.exists():
            continue
        if root.is_file() and root.suffix.lower() in exts:
            paths.append(root.resolve())
        elif root.is_dir():
            iterator = root.rglob("*") if recursive else root.glob("*")
            for p in iterator:
                if p.is_file() and p.suffix.lower() in exts:
                    paths.append(p.resolve())
    return sorted(set(paths))


def run_json(cmd: list[str], timeout: int = 20) -> dict[str, Any] | None:
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if proc.returncode != 0:
            return None
        return json.loads(proc.stdout)
    except Exception:
        return None


def ffprobe_duration(path: Path) -> float | None:
    if not shutil.which("ffprobe"):
        return None
    data = run_json([
        "ffprobe", "-v", "error", "-print_format", "json",
        "-show_entries", "format=duration", str(path)
    ])
    try:
        return float(data["format"]["duration"]) if data else None
    except Exception:
        return None



def load_previous_metadata(paths: list[str] | None) -> dict[str, dict[str, Any]]:
    """Load useful asset metadata from earlier $uits Media Director runs.

    This is the Gaia/JWST-style background catalogue: previous scans, cue matches,
    human labels, scores and paths become a reference layer behind the current video.
    The current run can then promote background metadata into foreground scoring.
    """
    index: dict[str, dict[str, Any]] = {}
    for raw in paths or []:
        root = Path(raw).expanduser()
        if not root.exists():
            continue
        files: list[Path] = []
        if root.is_file():
            files = [root]
        else:
            files = list(root.rglob("*.json")) + list(root.rglob("*.csv"))
        for fp in files:
            name = fp.name.lower()
            try:
                if fp.suffix.lower() == ".json":
                    data = json.loads(fp.read_text(encoding="utf-8", errors="ignore"))
                    records: list[dict[str, Any]] = []
                    if isinstance(data, list):
                        records = [x for x in data if isinstance(x, dict)]
                    elif isinstance(data, dict):
                        if isinstance(data.get("projects"), list):
                            for project in data.get("projects", []):
                                for cm in project.get("cue_matches", []) if isinstance(project, dict) else []:
                                    cue = cm.get("cue", {})
                                    for m in cm.get("matches", []):
                                        if isinstance(m, dict):
                                            r = dict(m)
                                            r["cue_theme"] = cue.get("theme")
                                            r["cue_energy"] = cue.get("energy")
                                            r["song_profile"] = project.get("song_profile")
                                            records.append(r)
                        for key in ("video_assets", "music_assets", "assets", "events", "clips"):
                            if isinstance(data.get(key), list):
                                records += [x for x in data[key] if isinstance(x, dict)]
                    for r in records:
                        path = str(r.get("path") or r.get("source_path") or r.get("video_path") or "")
                        asset_name = str(r.get("name") or r.get("asset_name") or Path(path).name)
                        key = path or asset_name
                        if not key:
                            continue
                        rec = index.setdefault(key, {"tags": set(), "score_sum": 0.0, "seen": 0, "reasons": set(), "sources": set()})
                        tags = r.get("tags", [])
                        if isinstance(tags, str):
                            tags = re.split(r"[|,;\s]+", tags)
                        for t in tags or []:
                            if t:
                                rec["tags"].add(str(t))
                        for field in ("event_class", "prey_type", "predator_archetype", "cue_theme", "cue_energy", "song_profile"):
                            if r.get(field):
                                rec["tags"].add(str(r[field]))
                        try:
                            rec["score_sum"] += float(r.get("score") or r.get("confidence") or 0)
                        except Exception:
                            pass
                        rec["seen"] += 1
                        for rr in r.get("reasons", []) if isinstance(r.get("reasons"), list) else str(r.get("reasons", "")).split("|"):
                            if rr:
                                rec["reasons"].add(str(rr))
                        rec["sources"].add(fp.as_posix())
                elif fp.suffix.lower() == ".csv" and ("cue" in name or "asset" in name or "event" in name):
                    with fp.open("r", encoding="utf-8", errors="ignore", newline="") as fh:
                        for r in csv.DictReader(fh):
                            path = str(r.get("path") or r.get("asset_path") or "")
                            asset_name = str(r.get("name") or r.get("asset_name") or Path(path).name)
                            key = path or asset_name
                            if not key:
                                continue
                            rec = index.setdefault(key, {"tags": set(), "score_sum": 0.0, "seen": 0, "reasons": set(), "sources": set()})
                            tags = r.get("tags", "")
                            for t in re.split(r"[|,;\s]+", tags):
                                if t:
                                    rec["tags"].add(t)
                            for field in ("theme", "song_profile", "duration_mode"):
                                if r.get(field):
                                    rec["tags"].add(str(r[field]))
                            try:
                                rec["score_sum"] += float(r.get("score") or 0)
                            except Exception:
                                pass
                            rec["seen"] += 1
                            for rr in str(r.get("reasons", "")).split("|"):
                                if rr:
                                    rec["reasons"].add(rr)
                            rec["sources"].add(fp.as_posix())
            except Exception:
                continue
    # Convert sets to sorted lists for JSON outputs.
    clean: dict[str, dict[str, Any]] = {}
    for key, rec in index.items():
        clean[key] = {
            "tags": sorted(rec.get("tags", set())),
            "seen": int(rec.get("seen", 0)),
            "avg_score": round(float(rec.get("score_sum", 0.0)) / max(1, int(rec.get("seen", 0))), 4),
            "reasons": sorted(rec.get("reasons", set())),
            "sources": sorted(rec.get("sources", set())),
        }
    return clean


def metadata_for_asset(asset: MediaAsset, metadata_index: dict[str, dict[str, Any]] | None) -> dict[str, Any]:
    if not metadata_index:
        return {}
    if asset.path in metadata_index:
        return metadata_index[asset.path]
    if asset.name in metadata_index:
        return metadata_index[asset.name]
    # Fuzzy basename lookup handles moved files / duplicate folders.
    base = Path(asset.path).name
    for key, rec in metadata_index.items():
        if Path(key).name == base:
            return rec
    return {}


def enrich_assets_with_previous_metadata(assets: list[MediaAsset], metadata_index: dict[str, dict[str, Any]] | None) -> list[MediaAsset]:
    if not metadata_index:
        return assets
    out: list[MediaAsset] = []
    for a in assets:
        rec = metadata_for_asset(a, metadata_index)
        tags = set(a.tags)
        tags.update(rec.get("tags", []))
        if rec:
            tags.add("previous_metadata")
            if rec.get("avg_score", 0) >= 3:
                tags.add("previously_strong")
        b = MediaAsset(a.asset_id, a.path, a.name, a.kind, a.ext, a.size_bytes, a.duration_s, sorted(tags), a.source)
        out.append(b)
    return out


def guess_tags(path: Path, kind: str) -> list[str]:
    text = path.stem.lower() + " " + str(path.parent).lower()
    tags: set[str] = set()
    rules = {
        "shoot_to_thrill": ["shoot", "thrill"],
        "hells_bells": ["hells", "bells"],
        "who_made_who": ["who made who", "who_made_who", "who", "made"],
        "disciples": ["disciples"],
        "suits": ["suits", "$uits"],
        "youtube": ["youtube", "yt"],
        "spectacular": ["spectacular", "apex", "wow", "hero"],
        "funny": ["funny", "comedy", "comic", "fail", "twat"],
        "gory_bloody": ["gory", "bloody", "blood", "splatter", "red"],
        "plus_chain": ["chain", "multi", "streak"],
        "team_play": ["team", "squad", "assist"],
        "controlled_burst": ["burst", "controlled"],
        "panic_event": ["panic", "panic_turn"],
        "odd_unusual": ["odd", "weird", "unusual", "strange"],
        "ambush": ["ambush", "flank", "leopard", "snake"],
        "all_out_assault": ["assault", "push", "rush"],
        "route_prey": ["route", "chase", "vehicle"],
        "tunnel_prey": ["tunnel", "blindside", "blind_side"],
        "kill_candidate": ["kill", "killed", "death", "dead", "downed"],
        "wounding": ["wound", "wounded", "hit", "damage"],
        "winging": ["wing", "winged", "disrupt", "break"],
        "lyric_irony": ["irony", "sarcasm", "wit", "lyric"],
        "metadata_catalogue": ["catalog", "metadata", "scan", "gaia", "jwst"],
    }
    for tag, needles in rules.items():
        if any(n in text for n in needles):
            tags.add(tag)
    if kind == "music":
        tags.add("music")
    if kind == "video":
        tags.add("video")
    return sorted(tags)


def build_assets(video_dirs: list[str], music_dirs: list[str], video_playlists: list[str], music_playlists: list[str], recursive: bool = True, video_files: list[str] | None = None, music_files: list[str] | None = None) -> tuple[list[MediaAsset], list[MediaAsset]]:
    video_paths = iter_files_from_dirs(video_dirs, VIDEO_EXTS, recursive)
    music_paths = iter_files_from_dirs(music_dirs, MUSIC_EXTS, recursive)
    for raw in video_files or []:
        p = Path(raw).expanduser()
        if p.exists() and p.suffix.lower() in VIDEO_EXTS:
            video_paths.append(p.resolve())
    for raw in music_files or []:
        p = Path(raw).expanduser()
        if p.exists() and p.suffix.lower() in MUSIC_EXTS:
            music_paths.append(p.resolve())
    for pl in video_playlists:
        for p in read_playlist(Path(pl).expanduser()):
            if p.exists() and p.suffix.lower() in VIDEO_EXTS:
                video_paths.append(p.resolve())
    for pl in music_playlists:
        for p in read_playlist(Path(pl).expanduser()):
            if p.exists() and p.suffix.lower() in MUSIC_EXTS:
                music_paths.append(p.resolve())
    video_paths = sorted(set(video_paths))
    music_paths = sorted(set(music_paths))

    videos: list[MediaAsset] = []
    music: list[MediaAsset] = []
    for i, p in enumerate(video_paths, 1):
        videos.append(MediaAsset(
            asset_id=f"vid_{i:05d}", path=str(p), name=p.name, kind="video", ext=p.suffix.lower(),
            size_bytes=p.stat().st_size, duration_s=ffprobe_duration(p), tags=guess_tags(p, "video"), source="folder_or_playlist"
        ))
    for i, p in enumerate(music_paths, 1):
        music.append(MediaAsset(
            asset_id=f"mus_{i:05d}", path=str(p), name=p.name, kind="music", ext=p.suffix.lower(),
            size_bytes=p.stat().st_size, duration_s=ffprobe_duration(p), tags=guess_tags(p, "music"), source="folder_or_playlist"
        ))
    return videos, music


def song_profile_for(asset: MediaAsset) -> str:
    name = asset.name.lower()
    if "good" in name and ("4" in name or "u" in name):
        return "good_4_u"
    if "shoot" in name and "thrill" in name:
        return "shoot_to_thrill"
    if "hell" in name and "bell" in name:
        return "hells_bells"
    if "bat" in name and "hell" in name:
        return "bat_out_of_hell"
    if "who" in name and "made" in name:
        return "who_made_who"
    return "generic_full_track"


def parse_timing_string(text: str) -> list[dict[str, Any]]:
    if not text:
        return []
    rows: list[dict[str, Any]] = []
    for i, chunk in enumerate(text.split(","), 1):
        if not chunk.strip():
            continue
        m = re.match(r"\s*([0-9.]+)\s*[-:]\s*([0-9.]+)(?:\s*=(.+))?\s*$", chunk)
        if not m:
            continue
        rows.append({"cue_id": f"cue_{i:03d}", "start_s": float(m.group(1)), "end_s": float(m.group(2)), "theme": (m.group(3) or "manual").strip()})
    return rows


def load_timing_rows(timing_json: str | None, timings: str | None) -> list[dict[str, Any]]:
    if timing_json:
        p = Path(timing_json).expanduser()
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                return data.get("cues") or data.get("rows") or []
    return parse_timing_string(timings or "")


def auto_cues_for_music(music: MediaAsset, mode: str, manual_rows: list[dict[str, Any]] | None = None, duration_mode: str = "full", clip_seconds: float = 29.0) -> list[dict[str, Any]]:
    if manual_rows:
        return normalize_cues(manual_rows)
    duration = music.duration_s or 180.0
    profile = song_profile_for(music)
    if duration_mode == "clip29":
        clip = max(3.0, min(float(clip_seconds), duration))
        cut_points = [0, min(clip * 0.22, duration), min(clip * 0.52, duration), min(clip * 0.82, duration), min(clip, duration)]
        names = ["hook_intro", "build", "payoff", "tag"]
    elif mode == "timings":
        cut_points = [0, min(13, duration), min(31, duration), min(52, duration), min(70, duration), duration]
        names = ["intro", "build", "impact", "chain_or_chorus", "aftermath"]
    elif mode == "full-track":
        cut_points = [0, duration * 0.08, duration * 0.22, duration * 0.42, duration * 0.67, duration * 0.86, duration]
        names = ["intro", "build", "impact", "chain_or_chorus", "aftermath", "finale"]
    else:
        cut_points = [0, duration]
        names = ["whole_track"]
    cues: list[dict[str, Any]] = []
    for i in range(len(cut_points) - 1):
        start = round(float(cut_points[i]), 3)
        end = round(float(cut_points[i + 1]), 3)
        if end <= start:
            continue
        theme = names[i] if i < len(names) else f"section_{i+1}"
        energy = "calm" if i == 0 else "building" if i == 1 else "hard" if i in {2, 3} else "calm"
        wanted = LABEL_DICTIONARY["song_profiles"].get(profile, {}).get("preferred", ["spectacular", "funny", "plus_chain"])
        cues.append({
            "cue_id": f"{safe_slug(profile)}_{duration_mode}_cue_{i+1:03d}",
            "start_s": start,
            "end_s": end,
            "theme": theme,
            "energy": energy,
            "song_profile": profile,
            "duration_mode": duration_mode,
            "allowed_asset_types": ["mp4", "png", "apng"],
            "wanted_event_classes": wanted[:6],
            "subtitle_style": "sarcasm" if profile == "good_4_u" else "recognition" if profile == "shoot_to_thrill" else "serious" if profile in {"hells_bells", "bat_out_of_hell"} else "analytic",
            "max_clips": 2 if duration_mode == "clip29" else (4 if end-start < 30 else 8),
            "clip_duration_max_s": 2.4 if duration_mode == "clip29" else 3.0,
            "janus_modes": ["attacker_view", "defender_view", "team_view", "aftermath_view"],
            "sun_tzu_tags": ["timing", "weak_points", "manoeuvre"],
        })
    return cues

def normalize_cues(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for i, row in enumerate(rows, 1):
        start = float(row.get("start_s", row.get("start", 0)))
        end = float(row.get("end_s", row.get("end", start + 10)))
        out.append({
            "cue_id": str(row.get("cue_id") or f"cue_{i:03d}"),
            "start_s": start,
            "end_s": end,
            "theme": str(row.get("theme") or "manual"),
            "energy": str(row.get("energy") or "balanced"),
            "allowed_asset_types": row.get("allowed_asset_types") or ["mp4", "png", "apng"],
            "wanted_event_classes": row.get("wanted_event_classes") or row.get("wanted_kill_types") or ["spectacular", "funny", "plus_chain"],
            "subtitle_style": str(row.get("subtitle_style") or "analytic"),
            "max_clips": int(row.get("max_clips") or 4),
            "clip_duration_max_s": float(row.get("clip_duration_max_s") or row.get("clip_duration") or 3.0),
            "janus_modes": row.get("janus_modes") or ["attacker_view", "defender_view"],
            "sun_tzu_tags": row.get("sun_tzu_tags") or ["timing"],
        })
    return out


def score_asset_for_cue(asset: MediaAsset, cue: dict[str, Any], metadata_index: dict[str, dict[str, Any]] | None = None) -> tuple[float, list[str]]:
    score = 0.0
    reasons: list[str] = []
    tags = set(asset.tags)
    wanted = set(str(x) for x in cue.get("wanted_event_classes", []))
    theme = str(cue.get("theme", "")).lower()
    energy = str(cue.get("energy", "")).lower()
    if asset.ext in VIDEO_EXTS:
        score += 1.0; reasons.append("video_asset")
    if tags & wanted:
        score += 2.5 * len(tags & wanted); reasons.append("wanted_label_overlap")
    meta = metadata_for_asset(asset, metadata_index)
    if meta:
        meta_tags = set(meta.get("tags", []))
        if meta_tags & wanted:
            score += 1.5 * len(meta_tags & wanted); reasons.append("previous_metadata_overlap")
        if meta.get("avg_score", 0) >= 3:
            score += min(1.5, float(meta.get("avg_score", 0)) / 3.0); reasons.append("previous_strong_score")
        if meta.get("seen", 0) >= 2:
            score += 0.5; reasons.append("metadata_repeated_evidence")
    if theme and theme in tags:
        score += 1.5; reasons.append("theme_overlap")
    if energy in {"hard", "extreme"} and {"spectacular", "plus_chain", "controlled_burst"} & tags:
        score += 1.5; reasons.append("hard_energy_match")
    if energy == "building" and {"ambush", "route_prey", "tunnel_prey"} & tags:
        score += 1.2; reasons.append("build_tension_match")
    if "who_made_who" == str(cue.get("song_profile", "")) and {"funny", "kill_candidate", "team_play", "odd_unusual", "previous_metadata"} & tags:
        score += 1.3; reasons.append("who_made_who_identity_irony")
    if "lyric_irony" in wanted and {"funny", "panic_event", "odd_unusual", "comedic_prey"} & tags:
        score += 1.0; reasons.append("lyric_irony_fit")
    # filename fallback: every video is at least possible but lower confidence
    if not reasons or reasons == ["video_asset"]:
        score += random.Random(asset.path + str(cue.get("cue_id"))).random() * 0.75
        reasons.append("filename_guess")
    return round(score, 4), reasons



def source_story_key(asset: MediaAsset) -> str:
    """Stable source key used to avoid repeated scenes across duplicated folders."""
    stem = Path(asset.name).stem.lower()
    # Strip common duplicated location markers but keep title identity.
    return re.sub(r"[^a-z0-9]+", "_", stem).strip("_")[:120] or asset.asset_id


def section_story_bonus(asset: MediaAsset, cue: dict[str, Any], story_arc: str) -> tuple[float, list[str]]:
    """Add light narrative intent so full songs progress like a film, not a repeated best-of loop."""
    tags = set(asset.tags)
    name = asset.name.lower()
    theme = str(cue.get("theme", "")).lower()
    wanted = set(str(x) for x in cue.get("wanted_event_classes", []))
    score = 0.0
    reasons: list[str] = []
    if story_arc in {"cinematic", "predation", "theatrical"}:
        if theme == "intro" and any(x in name for x in ["trailer", "joins", "ride", "chapter", "arrival", "mafia"]):
            score += 1.2; reasons.append("story_intro_identity")
        if theme == "build" and ({"team_play", "route_prey", "ambush", "tunnel_prey"} & (tags | wanted) or any(x in name for x in ["mission", "shipment", "war", "vs", "fight"])):
            score += 1.1; reasons.append("story_build_pressure")
        if theme == "impact" and ({"spectacular", "gory_bloody", "controlled_burst", "kill_candidate"} & (tags | wanted) or any(x in name for x in ["war", "fight", "caught", "dangerous"])):
            score += 1.3; reasons.append("story_impact_peak")
        if theme in {"chain_or_chorus", "chorus"} and ({"plus_chain", "team_play", "spectacular"} & (tags | wanted)):
            score += 1.4; reasons.append("story_chorus_chain")
        if theme in {"break", "bridge"} and ({"funny", "odd_unusual", "panic_event", "comedic_prey"} & (tags | wanted)):
            score += 1.2; reasons.append("story_break_janus")
        if theme in {"aftermath", "finale"} and any(x in name for x in ["fallout", "farewell", "caught", "finally", "trailer", "chapter"]):
            score += 1.0; reasons.append("story_aftermath_resolution")
    if story_arc == "comedy":
        if {"funny", "odd_unusual", "panic_event", "comedic_prey"} & (tags | wanted):
            score += 1.5; reasons.append("story_comedy_priority")
    if story_arc == "documentary":
        if any(x in name for x in ["chapter", "trailer", "highlights", "montage", "farewell"]):
            score += 1.0; reasons.append("story_documentary_context")
    return score, reasons


def select_story_matches(
    ranked: list[dict[str, Any]],
    cue: dict[str, Any],
    asset_by_id: dict[str, MediaAsset],
    cue_index: int,
    usage_by_asset: dict[str, int],
    usage_by_source: dict[str, int],
    last_cue_by_source: dict[str, int],
    story_mode: bool,
    story_arc: str,
    max_reuse_per_video: int,
    max_reuse_per_asset: int,
    min_reuse_gap_cues: int,
    prefer_unused: bool,
) -> list[dict[str, Any]]:
    """Select cue matches with penalties that reduce repeated scenes in long-form renders."""
    if not story_mode:
        return ranked[: int(cue.get("max_clips", 4))]
    target_count = int(cue.get("max_clips", 8))
    adjusted: list[dict[str, Any]] = []
    for row in ranked:
        asset = asset_by_id.get(row.get("asset_id", ""))
        if not asset:
            continue
        source_key = source_story_key(asset)
        asset_uses = usage_by_asset.get(asset.asset_id, 0)
        source_uses = usage_by_source.get(source_key, 0)
        last_cue = last_cue_by_source.get(source_key, -9999)
        score = float(row.get("score", 0.0))
        reasons = list(row.get("reasons", []))
        if asset_uses >= max_reuse_per_asset:
            score -= 4.0 + asset_uses; reasons.append("story_asset_reuse_limit_penalty")
        elif asset_uses > 0:
            score -= 1.0 * asset_uses; reasons.append("story_asset_reuse_penalty")
        if source_uses >= max_reuse_per_video:
            score -= 5.0 + source_uses; reasons.append("story_source_reuse_limit_penalty")
        elif source_uses > 0:
            score -= 1.25 * source_uses; reasons.append("story_source_reuse_penalty")
        if cue_index - last_cue < min_reuse_gap_cues:
            score -= 3.0; reasons.append("story_min_gap_penalty")
        if prefer_unused and source_uses == 0 and asset_uses == 0:
            score += 1.25; reasons.append("story_unused_source_bonus")
        b, br = section_story_bonus(asset, cue, story_arc)
        score += b; reasons.extend(br)
        new_row = dict(row)
        new_row["score"] = round(score, 4)
        new_row["reasons"] = reasons
        new_row["source_story_key"] = source_key
        adjusted.append(new_row)
    adjusted.sort(key=lambda x: x["score"], reverse=True)
    picks: list[dict[str, Any]] = []
    # First pass: prefer non-over-limit and positive-ish score.
    for row in adjusted:
        if len(picks) >= target_count:
            break
        source_key = row.get("source_story_key", "")
        asset_id = row.get("asset_id", "")
        if usage_by_asset.get(asset_id, 0) >= max_reuse_per_asset and len(adjusted) > target_count:
            continue
        if usage_by_source.get(source_key, 0) >= max_reuse_per_video and len(adjusted) > target_count:
            continue
        if cue_index - last_cue_by_source.get(source_key, -9999) < min_reuse_gap_cues and len(adjusted) > target_count:
            continue
        picks.append(row)
    # Fallback: fill target_count so renderer can cover full cue duration.
    if len(picks) < target_count:
        seen = {p.get("asset_id") for p in picks}
        for row in adjusted:
            if len(picks) >= target_count:
                break
            if row.get("asset_id") not in seen:
                picks.append(row); seen.add(row.get("asset_id"))
    # Update usage after final picks.
    for row in picks:
        asset_id = row.get("asset_id", "")
        source_key = row.get("source_story_key", "")
        usage_by_asset[asset_id] = usage_by_asset.get(asset_id, 0) + 1
        usage_by_source[source_key] = usage_by_source.get(source_key, 0) + 1
        last_cue_by_source[source_key] = cue_index
    return picks


def build_edit_plan(videos: list[MediaAsset], music_assets: list[MediaAsset], mode: str, timing_rows: list[dict[str, Any]] | None = None, limit_assets: int = 9999, duration_mode: str = "full", clip_seconds: float = 29.0, metadata_index: dict[str, dict[str, Any]] | None = None, extra_wanted: list[str] | None = None, story_mode: bool = False, story_arc: str = "cinematic", max_reuse_per_video: int = 2, max_reuse_per_asset: int = 1, min_reuse_gap_cues: int = 2, min_scene_gap_seconds: float = 45.0, prefer_unused: bool = False, story_scene_seconds: float = 10.0) -> dict[str, Any]:
    projects = []
    selected_videos = videos[:limit_assets]
    asset_by_id = {v.asset_id: v for v in selected_videos}
    variants = ["full", "clip29"] if duration_mode == "both" else [duration_mode]
    for mus in music_assets or [MediaAsset("mus_none", "", "no_music", "music", "", 0, 180.0, [], "none")]:
        for variant in variants:
            rows = timing_rows if variant != "full" and timing_rows else None
            cues = auto_cues_for_music(mus, mode=mode, manual_rows=rows, duration_mode=variant, clip_seconds=clip_seconds)
            if story_mode and variant == "full":
                for cue in cues:
                    cue["story_mode"] = True
                    cue["story_arc"] = story_arc
                    cue["clip_duration_max_s"] = max(float(cue.get("clip_duration_max_s") or 3.0), float(story_scene_seconds))
                    cue["max_clips"] = max(int(cue.get("max_clips", 8)), 12)
            if extra_wanted:
                for cue in cues:
                    merged = list(dict.fromkeys(list(cue.get("wanted_event_classes", [])) + [str(x) for x in extra_wanted if x]))
                    cue["wanted_event_classes"] = merged
                    cue["webui_selected_labels"] = [str(x) for x in extra_wanted if x]
            cue_matches = []
            usage_by_asset: dict[str, int] = {}
            usage_by_source: dict[str, int] = {}
            last_cue_by_source: dict[str, int] = {}
            for cue_index, cue in enumerate(cues):
                ranked = []
                for asset in selected_videos:
                    score, reasons = score_asset_for_cue(asset, cue, metadata_index=metadata_index)
                    ranked.append({"asset_id": asset.asset_id, "path": asset.path, "name": asset.name, "score": round(score, 4), "reasons": reasons, "tags": asset.tags})
                ranked.sort(key=lambda x: x["score"], reverse=True)
                picks = select_story_matches(
                    ranked, cue, asset_by_id, cue_index, usage_by_asset, usage_by_source, last_cue_by_source,
                    story_mode=story_mode and variant == "full",
                    story_arc=story_arc,
                    max_reuse_per_video=max_reuse_per_video,
                    max_reuse_per_asset=max_reuse_per_asset,
                    min_reuse_gap_cues=min_reuse_gap_cues,
                    prefer_unused=prefer_unused,
                )
                cue_matches.append({"cue": cue, "matches": picks})
            projects.append({
                "music_asset": asdict(mus),
                "song_profile": song_profile_for(mus),
                "duration_mode": variant,
                "story": {
                    "story_mode": bool(story_mode and variant == "full"),
                    "story_arc": story_arc,
                    "max_reuse_per_video": max_reuse_per_video,
                    "max_reuse_per_asset": max_reuse_per_asset,
                    "min_reuse_gap_cues": min_reuse_gap_cues,
                    "min_scene_gap_seconds": min_scene_gap_seconds,
                    "prefer_unused": prefer_unused,
                    "story_scene_seconds": story_scene_seconds,
                },
                "cues": cues,
                "cue_matches": cue_matches,
            })
    return {
        "schema": SCHEMA,
        "created_utc": now_iso(),
        "mode": mode,
        "duration_mode": duration_mode,
        "clip_seconds": clip_seconds,
        "metadata_index_size": len(metadata_index or {}),
        "story_mode": bool(story_mode),
        "story_arc": story_arc,
        "projects": projects,
    }

def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_html_report(out_dir: Path, videos: list[MediaAsset], music: list[MediaAsset], edit_plan: dict[str, Any]) -> str:
    rows = []
    for project in edit_plan.get("projects", []):
        mus = project.get("music_asset", {})
        rows.append(f"<h2>🎵 {html.escape(mus.get('name','no music'))}</h2>")
        rows.append(f"<p><b>Profile:</b> {html.escape(project.get('song_profile','generic'))}</p>")
        for cm in project.get("cue_matches", []):
            cue = cm["cue"]
            rows.append(f"<section class='cue'><h3>🎬 {html.escape(cue['cue_id'])}: {html.escape(cue.get('theme',''))} ({cue.get('start_s')}s–{cue.get('end_s')}s)</h3>")
            for m in cm.get("matches", []):
                tags = " ".join(f"<span>{html.escape(t)}</span>" for t in m.get("tags", []))
                rows.append(f"<div class='match'><b>{html.escape(m['name'])}</b><br><small>{html.escape(m['path'])}</small><br>score={m['score']} reasons={html.escape(', '.join(m.get('reasons', [])))}<br>{tags}</div>")
            rows.append("</section>")
    return f"""<!doctype html>
<html><head><meta charset='utf-8'><title>{APP_NAME} Report</title>
<style>
body{{font-family:Arial,sans-serif;background:#18232d;color:#f2f6f8;margin:0;padding:24px}}
a{{color:#9cd2ff}}.card,.cue{{background:#243545;border:1px solid #5d7a91;border-radius:14px;padding:16px;margin:14px 0}}
.match{{background:#17242f;border:1px solid #49677e;border-radius:10px;padding:10px;margin:8px 0}}span{{display:inline-block;background:#2e4b62;border-radius:99px;padding:3px 8px;margin:2px}}
</style></head><body>
<h1>🎬 {APP_NAME}</h1>
<div class='card'><b>Boundary:</b> Fictional GTA/FiveM / machinima media analysis; editorial tags, not real-world conduct.</div>
<div class='card'>Videos: {len(videos)} | Music: {len(music)} | Created: {now_iso()}</div>
{''.join(rows)}
</body></html>"""


def run_ffmpeg(cmd: list[str], log_path: Path | None = None) -> int:
    """Run ffmpeg/ffprobe-style commands and optionally append stderr to a log."""
    try:
        proc = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("a", encoding="utf-8") as fh:
                fh.write("\n$ " + " ".join(cmd) + "\n")
                fh.write(proc.stderr or "")
        return int(proc.returncode)
    except Exception as exc:
        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("a", encoding="utf-8") as fh:
                fh.write("\nERROR running: " + " ".join(cmd) + "\n" + repr(exc) + "\n")
        return 99


def pick_source_start(asset: MediaAsset, cue: dict[str, Any], clip_duration: float) -> float:
    """Deterministic source offset so repeated runs are stable, not random."""
    dur = asset.duration_s or 0.0
    if dur <= clip_duration + 1.0:
        return 0.0
    seed = f"{asset.path}|{cue.get('cue_id')}|{cue.get('theme')}"
    rnd = random.Random(seed).random()
    # Avoid first/last second where intros/outros often live.
    return round(1.0 + rnd * max(0.0, dur - clip_duration - 2.0), 3)


def render_sample_extracts(out_dir: Path, videos: list[MediaAsset], cue_rows: list[dict[str, Any]], max_renders: int, width: int, height: int) -> None:
    if not shutil.which("ffmpeg"):
        return
    render_dir = out_dir / "renders"
    (render_dir / "clips").mkdir(parents=True, exist_ok=True)
    (render_dir / "stills").mkdir(parents=True, exist_ok=True)
    log_path = render_dir / "ffmpeg_samples.log"
    video_by_id = {v.asset_id: v for v in videos}
    count = 0
    for row in cue_rows:
        if count >= max_renders:
            break
        asset = video_by_id.get(row.get("asset_id", ""))
        if not asset or not Path(asset.path).exists():
            continue
        slug = safe_slug(f"{row.get('duration_mode','')}_{row['cue_id']}_{row['asset_id']}")
        dur = 3.0
        start = pick_source_start(asset, {"cue_id": row.get("cue_id"), "theme": row.get("theme")}, dur)
        vf = f"scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1"
        run_ffmpeg([
            "ffmpeg", "-y", "-ss", str(start), "-t", str(dur), "-i", asset.path,
            "-an", "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            str(render_dir / "clips" / f"{slug}.mp4")
        ], log_path)
        run_ffmpeg([
            "ffmpeg", "-y", "-ss", str(start), "-i", asset.path,
            "-vf", vf, "-frames:v", "1", str(render_dir / "stills" / f"{slug}.png")
        ], log_path)
        count += 1


def render_complete_projects(out_dir: Path, videos: list[MediaAsset], edit_plan: dict[str, Any], width: int, height: int, analysis_depth: str = "fast") -> None:
    """Render complete 29s/full-track proof outputs by filling every cue with selected clips and adding the selected music track.

    This is a production-planning renderer, not a final artistic editor. It creates complete watchable MP4s
    so the WebUI has real outputs while the human editor can later replace/lock clips.
    """
    if not shutil.which("ffmpeg"):
        return
    video_by_id = {v.asset_id: v for v in videos}
    final_dir = out_dir / "renders" / "final"
    work_root = out_dir / "renders" / "work"
    final_dir.mkdir(parents=True, exist_ok=True)
    work_root.mkdir(parents=True, exist_ok=True)
    log_path = out_dir / "renders" / "ffmpeg_final.log"
    vf = f"scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p"
    for project in edit_plan.get("projects", []):
        mus = project.get("music_asset", {})
        music_path = mus.get("path") or ""
        music_name = mus.get("name") or "no_music"
        profile = project.get("song_profile", "generic")
        duration_mode = project.get("duration_mode", "full")
        project_slug = safe_slug(f"{profile}_{duration_mode}_{Path(music_name).stem}")
        work_dir = work_root / project_slug
        work_dir.mkdir(parents=True, exist_ok=True)
        segments: list[Path] = []
        segment_rows: list[dict[str, Any]] = []
        segment_index = 0
        for cm in project.get("cue_matches", []):
            cue = cm.get("cue", {})
            cue_start = float(cue.get("start_s") or 0.0)
            cue_end = float(cue.get("end_s") or cue_start)
            cue_len = max(0.1, cue_end - cue_start)
            matches = cm.get("matches", [])
            if not matches:
                continue
            # Full-song mode must fill the whole cue window, not only make a few proof clips.
            # Patient mode uses shorter cuts and cycles ranked matches until the cue is filled;
            # fast mode uses longer cuts. This ensures full duration outputs match the music track.
            max_pick = 8 if analysis_depth == "patient" else 4
            picks = matches[:max_pick] or matches[:1]
            base_clip = 3.0 if analysis_depth == "patient" else 6.0
            requested_max = float(cue.get("clip_duration_max_s") or base_clip)
            per_clip = max(1.2, min(max(base_clip, requested_max), 8.0 if analysis_depth == "patient" else 12.0))
            remaining = cue_len
            cycle_index = 0
            safety_limit = 400
            while remaining > 0.25 and picks and safety_limit > 0:
                safety_limit -= 1
                match = picks[cycle_index % len(picks)]
                cycle_index += 1
                asset = video_by_id.get(match.get("asset_id", ""))
                if not asset or not Path(asset.path).exists():
                    continue
                available = max(0.5, (asset.duration_s or per_clip) - 0.5)
                clip_dur = min(per_clip, remaining, available)
                if clip_dur <= 0.25:
                    continue
                start = pick_source_start(asset, cue, clip_dur)
                segment_index += 1
                seg_path = work_dir / f"seg_{segment_index:04d}_{safe_slug(match.get('asset_id','video'))}.mp4"
                rc = run_ffmpeg([
                    "ffmpeg", "-y", "-ss", str(start), "-t", str(round(clip_dur,3)), "-i", asset.path,
                    "-an", "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", seg_path.as_posix()
                ], log_path)
                if rc == 0 and seg_path.exists() and seg_path.stat().st_size > 1000:
                    segments.append(seg_path)
                    segment_rows.append({
                        "segment": seg_path.name, "cue_id": cue.get("cue_id"), "theme": cue.get("theme"),
                        "source_asset": asset.name, "source_start_s": start, "segment_duration_s": round(clip_dur,3),
                        "score": match.get("score"), "reasons": "|".join(match.get("reasons", [])),
                        "tags": "|".join(match.get("tags", [])),
                    })
                    remaining -= clip_dur
        if not segments:
            continue
        concat_file = work_dir / "concat.txt"
        concat_file.write_text("".join(f"file '{seg.as_posix()}'\n" for seg in segments), encoding="utf-8")
        noaudio = work_dir / f"{project_slug}_video_noaudio.mp4"
        run_ffmpeg(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_file.as_posix(), "-c", "copy", noaudio.as_posix()], log_path)
        final_out = final_dir / f"{project_slug}_complete.mp4"
        if music_path and Path(music_path).exists():
            # Shortest keeps 29s outputs tight and full outputs close to assembled video duration.
            run_ffmpeg([
                "ffmpeg", "-y", "-i", noaudio.as_posix(), "-stream_loop", "-1", "-i", music_path,
                "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", final_out.as_posix()
            ], log_path)
        else:
            shutil.copy2(noaudio, final_out)
        write_csv(final_dir / f"{project_slug}_segments.csv", segment_rows)


def render_outputs(out_dir: Path, videos: list[MediaAsset], music: list[MediaAsset], edit_plan: dict[str, Any], render: bool = False, max_renders: int = 12, render_final: bool = False, render_samples: bool = False, render_width: int = 1280, render_height: int = 720, analysis_depth: str = "fast", metadata_index: dict[str, dict[str, Any]] | None = None) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    write_json(out_dir / "media_dictionary.json", LABEL_DICTIONARY)
    write_json(out_dir / "video_assets.json", [asdict(v) for v in videos])
    write_json(out_dir / "music_assets.json", [asdict(m) for m in music])
    write_json(out_dir / "edit_plan.json", edit_plan)
    write_json(out_dir / "previous_metadata_index.json", metadata_index or {})
    write_json(out_dir / "run_manifest.json", {
        "schema": SCHEMA, "created_utc": now_iso(), "app": APP_NAME,
        "video_count": len(videos), "music_count": len(music),
        "ffmpeg": bool(shutil.which("ffmpeg")), "ffprobe": bool(shutil.which("ffprobe")),
        "render_requested": bool(render), "render_final": bool(render_final), "render_samples": bool(render_samples),
        "analysis_depth": analysis_depth,
        "metadata_index_size": len(metadata_index or {}),
    })
    write_csv(out_dir / "video_assets.csv", [{**asdict(v), "tags": "|".join(v.tags)} for v in videos])
    write_csv(out_dir / "music_assets.csv", [{**asdict(m), "tags": "|".join(m.tags)} for m in music])

    cue_rows = []
    for project in edit_plan.get("projects", []):
        for cm in project.get("cue_matches", []):
            cue = cm["cue"]
            for match in cm.get("matches", []):
                cue_rows.append({
                    "music": project.get("music_asset", {}).get("name", ""),
                    "song_profile": project.get("song_profile", ""),
                    "duration_mode": project.get("duration_mode", ""),
                    "cue_id": cue.get("cue_id", ""),
                    "start_s": cue.get("start_s", ""),
                    "end_s": cue.get("end_s", ""),
                    "theme": cue.get("theme", ""),
                    "asset_id": match.get("asset_id", ""),
                    "asset_name": match.get("name", ""),
                    "score": match.get("score", ""),
                    "reasons": "|".join(match.get("reasons", [])),
                    "tags": "|".join(match.get("tags", [])),
                })
    write_csv(out_dir / "cue_match_plan.csv", cue_rows)
    write_json(out_dir / "cue_match_plan.json", cue_rows)
    (out_dir / "curated_music_cue_report.html").write_text(build_html_report(out_dir, videos, music, edit_plan), encoding="utf-8")

    # Backwards compatibility: --render now means complete output + sample extracts.
    do_final = render or render_final
    do_samples = render or render_samples
    if do_samples:
        render_sample_extracts(out_dir, videos, cue_rows, max_renders=max_renders, width=render_width, height=render_height)
    if do_final:
        render_complete_projects(out_dir, videos, edit_plan, width=render_width, height=render_height, analysis_depth=analysis_depth)


class WebState:
    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.out_dir = Path(args.out).expanduser()
        self.videos: list[MediaAsset] = []
        self.music: list[MediaAsset] = []
        self.edit_plan: dict[str, Any] = {}
        self.refresh()

    def refresh(self) -> None:
        metadata_index = load_previous_metadata(self.args.previous_out_dir if self.args.reuse_previous else [])
        self.videos, self.music = build_assets(self.args.video_dir, self.args.music_dir, self.args.video_playlist, self.args.music_playlist, self.args.recursive, self.args.video_file, self.args.music_file)
        self.videos = enrich_assets_with_previous_metadata(self.videos, metadata_index)
        rows = load_timing_rows(self.args.timing_json, self.args.timings)
        self.edit_plan = build_edit_plan(self.videos, self.music, self.args.mode, rows, self.args.limit_assets, self.args.duration_mode, self.args.clip_seconds, metadata_index=metadata_index)
        render_outputs(self.out_dir, self.videos, self.music, self.edit_plan, render=False, metadata_index=metadata_index)


def make_handler(state: WebState):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

        def send_json(self, data: Any, code: int = 200) -> None:
            raw = json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8")
            try:
                self.send_response(code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
            except BrokenPipeError:
                # Browser refreshed or cancelled the request mid-response. Safe to ignore.
                return

        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            if path == "/":
                return self.index()
            if path == "/favicon.ico":
                self.send_response(204)
                self.end_headers()
                return
            if path == "/api/status":
                return self.send_json({"app": APP_NAME, "videos": len(state.videos), "music": len(state.music), "out": str(state.out_dir), "created": now_iso()})
            if path == "/api/dictionary":
                return self.send_json(LABEL_DICTIONARY)
            if path == "/api/assets":
                return self.send_json({"videos": [asdict(v) for v in state.videos], "music": [asdict(m) for m in state.music]})
            if path == "/api/edit-plan":
                return self.send_json(state.edit_plan)
            if path == "/api/refresh":
                state.refresh()
                return self.send_json({"ok": True, "videos": len(state.videos), "music": len(state.music)})
            if path == "/api/generate":
                render = urllib.parse.parse_qs(parsed.query).get("render", ["0"])[0] in {"1", "true", "yes"}
                render_outputs(state.out_dir, state.videos, state.music, state.edit_plan, render=render, max_renders=state.args.sample_render_count, render_width=state.args.render_width, render_height=state.args.render_height, analysis_depth=state.args.analysis_depth)
                return self.send_json({"ok": True, "out": str(state.out_dir), "render": render})
            if path.startswith("/outputs/"):
                rel = path[len("/outputs/"):]
                return self.serve_file((state.out_dir / rel).resolve())
            self.send_error(404, "Not found")

        def serve_file(self, p: Path) -> None:
            try:
                base = state.out_dir.resolve()
                if not str(p).startswith(str(base)) or not p.exists() or not p.is_file():
                    self.send_error(404, "Not found")
                    return
                ctype = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
                data = p.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                try:
                    self.wfile.write(data)
                except BrokenPipeError:
                    return
            except Exception as exc:
                self.send_error(500, str(exc))

        def index(self) -> None:
            report_link = "/outputs/curated_music_cue_report.html"
            html_page = f"""<!doctype html><html><head><meta charset='utf-8'><title>{APP_NAME}</title>
<style>
body{{margin:0;background:#15212b;color:#f4f8fb;font-family:Arial,sans-serif}}header{{background:#24384a;padding:18px 24px;border-bottom:1px solid #5e7e98}}main{{padding:20px;display:grid;grid-template-columns:1fr 1fr;gap:16px}}.card{{background:#223343;border:1px solid #5e7e98;border-radius:14px;padding:16px}}button,a.btn{{background:#3b75c5;color:white;border:1px solid #94b8e8;border-radius:10px;padding:10px 14px;text-decoration:none;font-weight:bold;display:inline-block;margin:4px}}pre{{background:#111c25;border:1px solid #3d5c73;border-radius:10px;padding:12px;white-space:pre-wrap;max-height:420px;overflow:auto}}span{{display:inline-block;background:#31506a;border-radius:99px;padding:3px 8px;margin:2px}}
</style></head><body><header><h1>🎬 {APP_NAME}</h1><p>Fictional GTARP/FiveM machinima media director: video + music + cue sheet + predator/prey doctrine + outputs.</p></header><main>
<section class='card'><h2>📁 Inputs</h2><p><b>Videos:</b> {len(state.videos)}<br><b>Music:</b> {len(state.music)}<br><b>Output:</b> {html.escape(str(state.out_dir))}<br><b>Mode:</b> {html.escape(state.args.duration_mode)}</p><a class='btn' href='/api/refresh'>🔄 Refresh scan</a><a class='btn' href='/api/generate'>🧾 Generate outputs</a><a class='btn' href='/api/generate?render=1'>🎞 Generate + render samples</a><a class='btn' href='{report_link}'>🌐 Open report</a><p><b>Preset runners:</b> use the shell scripts: run_good4u_suits_29s.sh, run_shoot_to_thrill_suits_full.sh, run_bat_out_of_hell_disciples_29s.sh, run_three_songs_both.sh</p></section>
<section class='card'><h2>🎛 Switch dictionary</h2><pre>{html.escape(json.dumps(build_switch_dictionary(), indent=2))}</pre></section>
<section class='card'><h2>🧬 Label dictionary</h2><p>{' '.join('<span>'+html.escape(k)+'</span>' for k in LABEL_DICTIONARY['event_classes'].keys())}</p><a class='btn' href='/api/dictionary'>Open JSON</a></section>
<section class='card'><h2>🎵 Edit plan</h2><a class='btn' href='/api/edit-plan'>Open JSON</a><a class='btn' href='/outputs/cue_match_plan.csv'>Download cue CSV</a><a class='btn' href='/outputs/media_dictionary.json'>Download dictionary</a></section>
<section class='card' style='grid-column:1/-1'><h2>🕴️ [o][o]</h2><p>“Ju$t 0ff t00 $k1n up!” — i.e. the machine has gone to prepare the footage, skin the metadata, season the cue sheet, and bring back a plate of clips. D0c0ti/iid machina piccolini: little doctor-machine, big appetite.</p></section>
</main></body></html>"""
            raw = html_page.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
    return Handler


def build_switch_dictionary() -> dict[str, Any]:
    return {
        "--video-dir": {"repeatable": True, "default": DEFAULT_VIDEO_DIRS, "meaning": "Folders to scan for video footage."},
        "--video-playlist": {"repeatable": True, "default": [], "meaning": "M3U/TXT/CSV/JSON playlists listing video files."},
        "--music-dir": {"repeatable": True, "default": DEFAULT_MUSIC_DIRS, "meaning": "Folders to scan for music/audio/video-music files."},
        "--music-playlist": {"repeatable": True, "default": [], "meaning": "M3U/TXT/CSV/JSON playlists listing music files."},
        "--video-file": {"repeatable": True, "default": [], "meaning": "Specific video file(s) to include."},
        "--music-file": {"repeatable": True, "default": [], "meaning": "Specific music file(s) to include."},
        "--song-preset": {"values": list(KNOWN_SONGS.keys()), "meaning": "Pick a known song/project preset."},
        "--project": {"values": ["all", "suits", "disciples"], "default": "all", "meaning": "Choose video folder family."},
        "--duration-mode": {"values": ["full", "clip29", "both"], "default": "full", "meaning": "Full music track, 29-second social edit, or both."},
        "--clip-seconds": {"default": 29.0, "meaning": "Length for clip29 mode."},
        "--mode": {"values": ["full-track", "timings", "batch"], "default": "full-track", "meaning": "Full music track cueing, manual timing windows, or batch asset plan."},
        "--timings": {"example": "0-13=intro,13-31=build,31-52=impact", "meaning": "Manual cue windows from the command line."},
        "--timing-json": {"meaning": "Cue sheet JSON file with rows/cues."},
        "--out": {"default": DEFAULT_OUT, "meaning": "Output folder for JSON/CSV/HTML/renders."},
        "--render": {"default": False, "meaning": "Call FFmpeg to render complete outputs and sample clips/stills."},
        "--render-final": {"default": False, "meaning": "Render complete watchable MP4 outputs under renders/final."},
        "--render-samples": {"default": False, "meaning": "Render proof clips/stills only."},
        "--sample-render-count": {"default": 12, "meaning": "Number of sample clips/stills."},
        "--analysis-depth": {"values": ["fast", "patient"], "default": "fast", "meaning": "Patient uses more clips per cue for richer complete outputs."},
        "--story-mode": {"default": False, "meaning": "Enable story-aware full-song selection with anti-repetition penalties."},
        "--story-arc": {"values": ["cinematic", "theatrical", "predation", "comedy", "documentary"], "default": "cinematic", "meaning": "Narrative intent for long-form renders."},
        "--max-reuse-per-video": {"default": 2, "meaning": "Maximum repeated source title across cue chapters."},
        "--max-reuse-per-asset": {"default": 1, "meaning": "Maximum repeated exact asset ID across cue chapters."},
        "--min-reuse-gap-cues": {"default": 2, "meaning": "Minimum cue gap before the same source title can return."},
        "--min-scene-gap-seconds": {"default": 45.0, "meaning": "Intended minimum scene window gap for reused sources."},
        "--prefer-unused": {"default": False, "meaning": "Boost unused source videos for stronger variety."},
        "--story-scene-seconds": {"default": 10.0, "meaning": "Target full-song dramatic scene length."},
        "--render-width": {"default": 1280, "meaning": "Output width for rendered video."},
        "--render-height": {"default": 720, "meaning": "Output height for rendered video."},
        "--webui": {"default": False, "meaning": "Start the local WebUI."},
        "--host": {"default": "127.0.0.1", "meaning": "WebUI host."},
        "--port": {"default": 8788, "meaning": "WebUI port."},
        "--limit-assets": {"default": 9999, "meaning": "Limit number of videos considered per cue."},
        "--no-recursive": {"default": False, "meaning": "Do not recursively scan input folders."},
        "--reuse-previous": {"default": False, "meaning": "Load previous JSON/CSV outputs as a metadata catalogue for scoring."},
        "--previous-out-dir": {"repeatable": True, "default": [DEFAULT_OUT], "meaning": "Previous output folder/file to mine for cue/video/event metadata."},
        "--upload-dir": {"repeatable": True, "default": [], "meaning": "Extra upload/intake folder scanned for video and music assets."},
        "--selected-label": {"repeatable": True, "meaning": "Bias matching toward predation/event labels."},
        "--prey-type": {"repeatable": True, "meaning": "Bias matching toward prey behaviour labels."},
        "--comedy-class": {"repeatable": True, "meaning": "Bias matching toward comedy/irony labels."},
        "--server-log-dir": {"repeatable": True, "meaning": "FiveM/server log folders for analysis metadata."},
        "--client-log-dir": {"repeatable": True, "meaning": "FiveM/client log folders for analysis metadata."},
        "--foreground-model": {"default": False, "meaning": "Enable foreground/background model intent metadata."},
        "--foreground-model-mode": {"default": "metadata_guided_delta", "meaning": "Model label for foreground/background analysis."},
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=f"{APP_NAME}: fictional GTARP/FiveM media director")
    p.add_argument("--video-dir", action="append", default=[], help="Video folder to scan. Repeatable.")
    p.add_argument("--video-playlist", action="append", default=[], help="Video playlist file: txt/m3u/csv/json. Repeatable.")
    p.add_argument("--music-dir", action="append", default=[], help="Music folder to scan. Repeatable.")
    p.add_argument("--music-playlist", action="append", default=[], help="Music playlist file: txt/m3u/csv/json. Repeatable.")
    p.add_argument("--video-file", action="append", default=[], help="Specific video file to include. Repeatable.")
    p.add_argument("--music-file", action="append", default=[], help="Specific music file to include. Repeatable.")
    p.add_argument("--song-preset", choices=sorted(KNOWN_SONGS.keys()), default="", help="Known preset: good4u_suits, shoot_to_thrill_suits, bat_out_of_hell_disciples, hells_bells_disciples, who_made_who_all/suits/disciples.")
    p.add_argument("--project", choices=["all", "suits", "disciples"], default="all", help="Choose video folder family if --video-dir is not supplied.")
    p.add_argument("--duration-mode", choices=["full", "clip29", "both"], default="full", help="Full track, 29-second edit, or both.")
    p.add_argument("--clip-seconds", type=float, default=29.0, help="Seconds for clip29 mode.")
    p.add_argument("--mode", choices=["full-track", "timings", "batch"], default="full-track", help="Cueing mode.")
    p.add_argument("--timings", default="", help="Manual timings, e.g. '0-13=intro,13-31=build'.")
    p.add_argument("--timing-json", default="", help="Cue sheet JSON file.")
    p.add_argument("--out", default=DEFAULT_OUT, help="Output folder.")
    p.add_argument("--render", action="store_true", help="Render complete MP4 outputs plus sample clips/stills with FFmpeg if available.")
    p.add_argument("--render-final", action="store_true", help="Render complete watchable MP4 outputs under renders/final.")
    p.add_argument("--render-samples", action="store_true", help="Render sample clips/stills only.")
    p.add_argument("--sample-render-count", type=int, default=12, help="Number of sample clips/stills to render.")
    p.add_argument("--analysis-depth", choices=["fast", "patient"], default="fast", help="Patient mode uses more candidate clips per cue.")
    p.add_argument("--story-mode", action="store_true", help="Enable long-form narrative selection: reduce repeated scenes and build a cinematic story arc.")
    p.add_argument("--story-arc", choices=["cinematic", "theatrical", "predation", "comedy", "documentary"], default="cinematic", help="Narrative intent for full-song renders.")
    p.add_argument("--max-reuse-per-video", type=int, default=2, help="Maximum times a source title can be selected across cue chapters in story mode.")
    p.add_argument("--max-reuse-per-asset", type=int, default=1, help="Maximum times the exact asset ID can be selected across cue chapters in story mode.")
    p.add_argument("--min-reuse-gap-cues", type=int, default=2, help="Minimum cue gap before reusing the same source title in story mode.")
    p.add_argument("--min-scene-gap-seconds", type=float, default=45.0, help="Minimum intended gap between reused scene windows; recorded in plan metadata.")
    p.add_argument("--prefer-unused", action="store_true", help="Boost unused source videos for stronger full-song variety.")
    p.add_argument("--story-scene-seconds", type=float, default=10.0, help="Target scene length for full-song story renders.")
    p.add_argument("--render-width", type=int, default=1280, help="Rendered video width.")
    p.add_argument("--render-height", type=int, default=720, help="Rendered video height.")
    p.add_argument("--webui", action="store_true", help="Start local WebUI.")
    p.add_argument("--host", default="127.0.0.1", help="WebUI host.")
    p.add_argument("--port", type=int, default=8788, help="WebUI port.")
    p.add_argument("--limit-assets", type=int, default=9999, help="Limit assets considered.")
    p.add_argument("--no-recursive", action="store_true", help="Disable recursive scan.")
    p.add_argument("--reuse-previous", action="store_true", help="Reuse previous JSON/CSV metadata from earlier runs as a background catalogue.")
    p.add_argument("--previous-out-dir", action="append", default=[], help="Previous output folder/file to scan for metadata. Repeatable.")
    p.add_argument("--upload-dir", action="append", default=[], help="Upload/intake folder containing new video/music assets. Repeatable.")
    p.add_argument("--selected-label", action="append", default=[], help="Bias cue matching toward event/predation labels. Repeatable.")
    p.add_argument("--prey-type", action="append", default=[], help="Bias cue matching toward prey-behaviour labels. Repeatable.")
    p.add_argument("--comedy-class", action="append", default=[], help="Bias cue matching toward comedy/irony labels. Repeatable.")
    p.add_argument("--server-log-dir", action="append", default=[], help="Server log folder for external WebUI/log indexing. Repeatable.")
    p.add_argument("--client-log-dir", action="append", default=[], help="Client log folder for external WebUI/log indexing. Repeatable.")
    p.add_argument("--foreground-model", action="store_true", help="Write foreground/background intent metadata in run outputs.")
    p.add_argument("--foreground-model-mode", default="metadata_guided_delta", help="Foreground/background model mode label.")
    p.add_argument("--print-switches", action="store_true", help="Print switch dictionary and exit.")
    args = p.parse_args(argv)
    if args.song_preset:
        preset = KNOWN_SONGS[args.song_preset]
        args.project = preset.get("project", args.project)
        mf = preset.get("music_file", "")
        if mf and mf not in args.music_file:
            args.music_file.append(mf)
        # A preset should focus on its named song, not every file in music_mp4.
        if not args.music_dir:
            args.music_dir = []
    # Upload/intake dirs can contain either footage or music; scan them as both.
    for u in args.upload_dir:
        if u not in args.video_dir:
            args.video_dir.append(u)
        if u not in args.music_dir:
            args.music_dir.append(u)
    if args.reuse_previous and not args.previous_out_dir:
        args.previous_out_dir = [DEFAULT_OUT]
    if not args.video_dir:
        if args.project == "suits":
            args.video_dir = SUITS_VIDEO_DIRS.copy()
        elif args.project == "disciples":
            args.video_dir = DISCIPLES_VIDEO_DIRS.copy()
        else:
            args.video_dir = DEFAULT_VIDEO_DIRS.copy()
    if not args.music_dir and not args.music_file:
        args.music_dir = DEFAULT_MUSIC_DIRS.copy()
    args.recursive = not args.no_recursive
    return args



def write_foreground_and_log_sidecars(out_dir: Path, args: argparse.Namespace) -> None:
    """Write lightweight sidecar metadata for foreground/background and log intent."""
    out_dir.mkdir(parents=True, exist_ok=True)
    if getattr(args, "foreground_model", False):
        write_json(out_dir / "foreground_background_model.json", {
            "schema": "suits_foreground_background_model_v1",
            "created_utc": now_iso(),
            "mode": getattr(args, "foreground_model_mode", "metadata_guided_delta"),
            "idea": "expected background + previous metadata + log truth versus foreground pixel/motion/red/centre deltas",
            "foreground_signals": ["centre_patch_delta", "frame_delta", "red_impact_proxy", "motion_vector", "route_deviation"],
            "background_signals": ["static_scene_pattern", "previous_metadata", "server_log_truth", "client_log_truth", "cue_history"],
            "boundary": LABEL_DICTIONARY.get("boundary"),
        })
    def scan_logs(paths: list[str]) -> dict[str, Any]:
        hints = {
            "kill": ["kill", "killed", "death", "died", "downed"],
            "damage": ["damage", "hit", "weaponDamageEvent"],
            "shot": ["shot", "fire", "projectile", "startProjectileEvent"],
            "explosion": ["explosion", "explode"],
            "connect": ["connecting", "joined", "dropped", "playerDropped"],
        }
        out = {"files": [], "hint_counts": {k:0 for k in hints}, "total_files": 0, "total_bytes": 0}
        for raw in paths or []:
            root = Path(raw).expanduser()
            if not root.exists():
                continue
            files = [root] if root.is_file() else [x for x in root.rglob("*") if x.is_file() and x.suffix.lower() in {".log", ".txt", ".json", ".jsonl", ".csv"}]
            for fp in files:
                try:
                    text = fp.read_text(encoding="utf-8", errors="ignore")[:200000].lower()
                    rec = {"path": fp.as_posix(), "bytes": fp.stat().st_size, "hints": {}}
                    for key, needles in hints.items():
                        c = sum(text.count(n.lower()) for n in needles)
                        if c:
                            rec["hints"][key] = c
                            out["hint_counts"][key] += c
                    out["files"].append(rec)
                    out["total_files"] += 1
                    out["total_bytes"] += fp.stat().st_size
                except Exception:
                    pass
        return out
    if getattr(args, "server_log_dir", []):
        write_json(out_dir / "server_log_index.json", scan_logs(args.server_log_dir))
    if getattr(args, "client_log_dir", []):
        write_json(out_dir / "client_log_index.json", scan_logs(args.client_log_dir))

def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.print_switches:
        print(json.dumps(build_switch_dictionary(), indent=2, ensure_ascii=False))
        return 0
    if args.webui:
        state = WebState(args)
        server = ThreadingHTTPServer((args.host, args.port), make_handler(state))
        print(f"{APP_NAME} WebUI: http://{args.host}:{args.port}")
        print(f"Outputs: {state.out_dir}")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nStopping WebUI.")
        return 0

    metadata_index = load_previous_metadata(args.previous_out_dir if args.reuse_previous else [])
    videos, music = build_assets(args.video_dir, args.music_dir, args.video_playlist, args.music_playlist, args.recursive, args.video_file, args.music_file)
    videos = enrich_assets_with_previous_metadata(videos, metadata_index)
    timing_rows = load_timing_rows(args.timing_json, args.timings)
    extra_wanted = list(dict.fromkeys((args.selected_label or []) + (args.prey_type or []) + (args.comedy_class or [])))
    plan = build_edit_plan(
        videos, music, args.mode, timing_rows, args.limit_assets, args.duration_mode, args.clip_seconds,
        metadata_index=metadata_index, extra_wanted=extra_wanted,
        story_mode=args.story_mode, story_arc=args.story_arc,
        max_reuse_per_video=args.max_reuse_per_video, max_reuse_per_asset=args.max_reuse_per_asset,
        min_reuse_gap_cues=args.min_reuse_gap_cues, min_scene_gap_seconds=args.min_scene_gap_seconds,
        prefer_unused=args.prefer_unused, story_scene_seconds=args.story_scene_seconds,
    )
    out_path = Path(args.out).expanduser()
    render_outputs(out_path, videos, music, plan, render=args.render, max_renders=args.sample_render_count, render_final=args.render_final, render_samples=args.render_samples, render_width=args.render_width, render_height=args.render_height, analysis_depth=args.analysis_depth, metadata_index=metadata_index)
    write_foreground_and_log_sidecars(out_path, args)
    print(json.dumps({"ok": True, "videos": len(videos), "music": len(music), "out": args.out, "render": args.render, "render_final": bool(args.render or args.render_final), "render_samples": bool(args.render or args.render_samples), "duration_mode": args.duration_mode, "analysis_depth": args.analysis_depth, "story_mode": args.story_mode, "story_arc": args.story_arc, "metadata_index_size": len(metadata_index)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
