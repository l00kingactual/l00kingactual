# 🧬 Metadata-to-Predation Model

## Boundary

This is a fictional GTA/FiveM / machinima media-analysis system. Terms such as predation, prey, kill, wound, wing, tactics, Sun Tzu, and strategy are editorial labels for gameplay footage and cinematic review. They are not real-world tactical instruction.

## 🌌 Gaia / JWST Analogy

Astronomy pipelines often separate two layers:

- **Background catalogue**: RA/Dec, parallax, colour, magnitude, redshift, instrument metadata, provenance.
- **Foreground image**: pixels from a telescope exposure.

The useful trick is that the image becomes smarter when the hidden catalogue is projected onto it. A point of light is not just a pixel; it is a star candidate with coordinates, confidence, motion, colour, and history.

For `$uits Media Director`, the same pattern applies:

- **Background catalogue**: earlier scan outputs, cue plans, labels, server logs, human feedback, durations, filenames, tags, scores, event IDs.
- **Foreground video**: active pixels, motion, red-impact proxy, shotline geometry, body/vehicle/path movement, audio impulses.

The editor asks:

> Which background metadata should be promoted into the foreground at this moment?

## 🧭 Coordinate Systems

| Astronomy | Machinima video |
|---|---|
| RA / Dec | frame x/y pixel coordinates |
| Galactic coordinates | world/scene/route coordinates, if server logs exist |
| Star catalogue | asset/event catalogue |
| Image exposure | video frame / clip window |
| Proper motion | player/vehicle movement vector |
| Colour index | red-impact, muzzle flash, fire, lighting, HUD colour proxies |
| Object confidence | event confidence / truth level |

## 🎯 Pixel-to-Event Abstraction

The script should treat each frame window as a candidate event field:

```text
frame_window
+ pixel change
+ centre-screen intensity
+ red-impact proxy
+ line/shotline geometry
+ object/route movement
+ audio impulse
+ previous metadata
= event candidate
```

## 🐑 Prey Behaviour Layer

Prey classification is behaviour-state analysis, not identity labelling.

```text
exposure + isolation + panic + predictable route + missed recovery window
= prey-state probability
```

Useful labels:

- 🐑 exposed_prey: stayed visible / no cover
- 🐐 isolated_prey: split from team
- 🐇 panicked_prey: erratic movement
- 🩸 wounded_prey: previously damaged / finishable
- 🪽 winged_prey: aim/path/formation broken
- 🚗 route_prey: chased into predictable path
- 🎯 tunnel_prey: forward focus, blind side pressure
- 🔄 reload_prey: transition exposure
- 🧲 baited_prey: accepted false opportunity
- 🕳️ trap_prey: entered dead geometry

## 🦁 Predation Pressure Layer

Predation is the pressure shape applied to the scene:

- 🦁 lion_front_push: direct pressure
- 🐆 leopard_ambush: flank/pounce
- 🐍 snake_trap: bait/angle/delay
- 🦈 shark_pursuit: chase pressure
- 🟣 hyena_cleanup: poach/pack cleanup
- 🐝 wasp_harassment: repeated sting pressure

## 🎵 Beat-to-Kill / Beat-to-Prey Auto-Tune

Every cue receives a musical role:

```text
intro -> establish world / route / threat
build -> stalking, pressure, recovery window
impact -> hit, wound, crash, reveal
chorus -> kill, chain, team play, spectacle
break -> irony, comedy, panic, Janus reversal
aftermath -> consequence, doctrine card, survival review
```

The score is:

```text
clip_score = visual_event_score
           + metadata_overlap
           + beat_alignment
           + lyric_irony_fit
           + predation_pressure_fit
           + prey_behaviour_fit
           + Janus/SunTzu fit
           - repetition_penalty
           - public_review_penalty
```

## 😏 Lyric / Humour Layer

Do not store or reproduce full copyrighted lyrics. Store cue metadata instead:

```json
{
  "lyric_cue_id": "who_made_who_hook_001",
  "time_s": 42.0,
  "cue_type": "question_hook",
  "rhetorical_use": ["irony", "identity", "cause_effect"],
  "clip_targets": ["predation", "prey", "funny", "kill_candidate"]
}
```

Uses:

- 🎭 drama: big reveal / title / aftermath
- 😏 irony: confident lyric over failed movement
- 🧂 sarcasm: caption contradicts what happened
- 🧠 wit: smart bait / reversal / Janus double-read
- 😂 humour: panic, poach, absurd physics, bad route
- 🔥 recognition: beat lands on hit/kill/impact

## 🗃️ Previous Metadata Reuse

The patched script supports:

```bash
--reuse-previous \
--previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8
```

It scans previous JSON/CSV outputs such as:

- `video_assets.json`
- `music_assets.json`
- `edit_plan.json`
- `cue_match_plan.json`
- `cue_match_plan.csv`
- event/human-feedback CSVs when present

Then it builds:

```text
previous_metadata_index.json
```

This is the background star catalogue for the current edit.

## 🤖 Who Made Who Profile

`Who Made Who` is treated as an identity/cause-effect song:

```text
Who caused the outcome?
Who became prey?
Who made the mistake?
Who made the pressure?
Who made the clip funny?
```

Best matches:

- kill_candidate
- predation/prey reversal
- team_play
- funny / lyric irony
- odd_unusual
- previous_metadata overlap

## ✅ Project Switches

```bash
./run_who_made_who_all_29s.sh
./run_who_made_who_all_full.sh
./run_who_made_who_suits_29s.sh
./run_who_made_who_disciples_29s.sh
```

Direct command:

```bash
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --reuse-previous \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
  --render \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_all_full
```

## 🕴️ [o][o]

The video pixels are the sky. The previous scans are the star catalogue. The beat is the clock. The kill is not the whole story; the useful question is who made who become available.
