#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./run_good4u_suits_29s.sh "$@"
./run_good4u_suits_full.sh "$@"
./run_shoot_to_thrill_suits_29s.sh "$@"
./run_shoot_to_thrill_suits_full.sh "$@"
./run_bat_out_of_hell_disciples_29s.sh "$@"
./run_bat_out_of_hell_disciples_full.sh "$@"
