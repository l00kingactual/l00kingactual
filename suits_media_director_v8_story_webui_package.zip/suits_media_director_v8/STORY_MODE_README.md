# 🎭 $uits Media Director v8 Story Mode

This build adds fully working story-aware switches to both the processor and the Plus WebUI.

## What changed

- `--story-mode` is now a real processor switch.
- Full-song renders use anti-repetition planning before FFmpeg rendering.
- The WebUI includes story controls and passes them to the processor.
- Full-song runner scripts now use story mode by default.

## Story switches

```bash
--story-mode
--story-arc cinematic|theatrical|predation|comedy|documentary
--max-reuse-per-video 2
--max-reuse-per-asset 1
--min-reuse-gap-cues 2
--min-scene-gap-seconds 45
--prefer-unused
--story-scene-seconds 10
```

## Recommended full-song command

```bash
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --story-mode \
  --story-arc cinematic \
  --max-reuse-per-video 2 \
  --max-reuse-per-asset 1 \
  --min-reuse-gap-cues 2 \
  --min-scene-gap-seconds 45 \
  --prefer-unused \
  --story-scene-seconds 10 \
  --reuse-previous \
  --foreground-model \
  --render \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_story_full
```

## Run all full-song story movies

```bash
./run_all_songs_story_full.sh
```

## WebUI

```bash
./run_webui.sh
```

Open:

```text
http://127.0.0.1:8788
```

The WebUI has controls for story mode, story arc, max reuse, cue gap, scene seconds, and prefer unused sources.
