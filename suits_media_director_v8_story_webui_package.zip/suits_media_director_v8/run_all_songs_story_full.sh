#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Running full-song theatrical story renders with anti-repetition planning. This can take a while."
./run_good4u_suits_full.sh --render
./run_shoot_to_thrill_suits_full.sh --render
./run_bat_out_of_hell_disciples_full.sh --render
./run_hells_bells_disciples_full.sh --render
./run_who_made_who_all_full.sh --render
echo "Done. Final story outputs:"
find /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 -path '*/renders/final/*_complete.mp4' -print
