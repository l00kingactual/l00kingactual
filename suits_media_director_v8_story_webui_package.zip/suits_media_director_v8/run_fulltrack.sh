#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
MUSIC_DIR="${MUSIC_DIR:-/home/andy/Documents/suitsmafia/music_mp4}"
OUT_DIR="${OUT_DIR:-/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/full_library_scan}"
mkdir -p "$MUSIC_DIR" "$OUT_DIR"
python3 suits_media_director_v8.py   --video-dir /home/andy/Documents/suitsmafia/videos   --video-dir /home/andy/Documents/suitsmafia/videos/disciples   --video-dir /home/andy/Documents/suitsmafia/videos/disciples/youtube   --video-dir /home/andy/Documents/suitsmafia/videos/suits_youtube   --video-dir /home/andy/Documents/suitsmafia/videos/youtube   --music-dir "$MUSIC_DIR"   --out "$OUT_DIR"   --mode full-track "$@"
