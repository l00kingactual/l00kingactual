#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT="/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/hells_bells_disciples_29s"
mkdir -p "$OUT"
# Default is patient rendered output. Pass --render-samples or other switches after the script if needed.
python3 suits_media_director_v8.py \
  --song-preset hells_bells_disciples \
  --duration-mode clip29 \
  --clip-seconds 29 \
  --analysis-depth patient \
  --render \
  --sample-render-count 24 \
  --out "$OUT" "$@"
