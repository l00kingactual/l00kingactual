# 🎬 $uits Media Director v8 Plus WebUI

A local-first WebUI for fictional GTA/FiveM / machinima media analysis and rendering.

## Start

```bash
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8
./run_webui.sh
```

Open:

```text
http://127.0.0.1:8788
```

## What the Plus WebUI includes

- 🎥 Video selector with select-all / unselect-all
- 🎵 Music selector with select-all / unselect-all
- 🔥 Predation/event label checkboxes
- 🐑 Prey-behaviour checkboxes
- 😂 Comedy/irony/wit checkboxes
- 🗃️ Previous metadata reuse
- 🌌 Foreground/background sidecar model
- 🖥️ Server log folder input
- 🎮 Client log folder input
- 🎬 Render selected assets as MP4 outputs
- 📋 Background job tracking
- 📁 Output links and logs

## Default paths

```text
Videos:
/home/andy/Documents/suitsmafia/videos
/home/andy/Documents/suitsmafia/videos/disciples
/home/andy/Documents/suitsmafia/videos/disciples/youtube
/home/andy/Documents/suitsmafia/videos/suits_youtube
/home/andy/Documents/suitsmafia/videos/youtube

Music:
/home/andy/Documents/suitsmafia/music_mp4

Outputs:
/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8

Upload/intake:
/home/andy/Documents/suitsmafia/upload

Logs:
/home/andy/Documents/suitsmafia/server_logs
/home/andy/Documents/suitsmafia/client_logs
```

## Recommended use

1. Start the WebUI.
2. Tick videos and music.
3. Tick relevant predation/prey/comedy labels.
4. Keep `reuse previous metadata` enabled.
5. Keep `foreground/background sidecar` enabled.
6. Use `patient` analysis for serious renders.
7. Click **🎬 Render selected**.

## CLI equivalent

```bash
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --reuse-previous \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
  --foreground-model \
  --server-log-dir /home/andy/Documents/suitsmafia/server_logs \
  --client-log-dir /home/andy/Documents/suitsmafia/client_logs \
  --selected-label kill_candidate \
  --selected-label team_play \
  --prey-type route_prey \
  --comedy-class lyric_irony \
  --render \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_plus_full
```

## Boundary

All predation, prey, kill, shot, tactic, Sun Tzu, Janus, humour and gore terms are editorial/media-analysis labels for fictional GTA/FiveM / machinima footage. They are not real-world tactical instructions.
