#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Starting $uits Media Director v8 Plus WebUI: http://127.0.0.1:8788"
python3 suits_media_director_v8_webui_plus.py --host 127.0.0.1 --port 8788
