#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./run_three_songs_both.sh "$@"
./run_hells_bells_disciples_29s.sh "$@"
./run_hells_bells_disciples_full.sh "$@"
