#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT="/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/bat_out_of_hell_disciples_full"
mkdir -p "$OUT"
# Default is patient rendered output. Pass --render-samples or other switches after the script if needed.
python3 suits_media_director_v8.py \
  --song-preset bat_out_of_hell_disciples \
  --duration-mode full \
  --analysis-depth patient \
  --story-mode \
  --story-arc cinematic \
  --max-reuse-per-video 2 \
  --max-reuse-per-asset 1 \
  --min-reuse-gap-cues 2 \
  --min-scene-gap-seconds 45 \
  --prefer-unused \
  --story-scene-seconds 10 \
  --render \
  --sample-render-count 24 \
  --out "$OUT" "$@"
