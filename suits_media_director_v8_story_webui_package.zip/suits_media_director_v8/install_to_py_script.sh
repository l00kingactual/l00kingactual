#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="/home/andy/Documents/suitsmafia/py_script/suits_media_director_v8"
mkdir -p "$(dirname "$TARGET")"
rm -rf "$TARGET"
cp -a "$SRC_DIR" "$TARGET"
echo "Installed to $TARGET"
echo "Run: cd $TARGET && ./run_webui.sh"
