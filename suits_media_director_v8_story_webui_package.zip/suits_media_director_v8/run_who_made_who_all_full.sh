#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 suits_media_director_v8.py \
  --song-preset who_made_who_all \
  --duration-mode full \
  --analysis-depth patient \
  --story-mode \
  --story-arc cinematic \
  --max-reuse-per-video 2 \
  --max-reuse-per-asset 1 \
  --min-reuse-gap-cues 2 \
  --min-scene-gap-seconds 45 \
  --prefer-unused \
  --story-scene-seconds 10 \
  --reuse-previous \
  --previous-out-dir /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
  --render \
  --sample-render-count 36 \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8/who_made_who_all_full
