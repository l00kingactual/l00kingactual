# [o][o] $uits Processor v16.3.2 — Story Menu + Video Theatre + Recursive ML WebUI

v16.3.2 patches the v16.3.1 WebUI so every page has a clear home link, global navigation, the mouse trail, and a combined D0ug1e$ Story menu that links old and new pages together.

It also adds a Video Theatre page that scans:

```text
/home/andy/Documents/suitsmafia/susitsmafia_website/videos
```

for `.mp4` files and creates:

```text
website_videos_index.json
suits_v16_3_2_videos.php
```

Each video appears in a sidebar with a thumbnail `<video>` preview, processor-generated metadata comment, and one-click loading into the main player.

## Install

```bash
cd /home/andy/Downloads
unzip -o /mnt/data/suits_processor_v16_3_2_story_menu_video_ml_webui_package.zip
cd suits_processor_v16_3_2_story_menu_video_ml_webui
chmod +x scripts/*.sh tools/*.py run_v16_3_2_recursive_ml_webui.sh
./scripts/install_v16_3_2.sh
```

## Run

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_3_2_recursive_ml_webui
```

## Open WebUI

```bash
cd /home/andy/Documents/suitsmafia/susitsmafia_website
php -S 127.0.0.1:8081
```

Then open:

```text
http://127.0.0.1:8081/suits_v16_3_2_dashboard.php
http://127.0.0.1:8081/suits_v16_3_2_videos.php
http://127.0.0.1:8081/suits_v16_3_2_dougies_story.php
```

## Outputs

```text
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_3_2_recursive_ml_webui
```

Key data files:

```text
summary.json
combined_menu_manifest.json
website_videos_index.json
music_profile_index.json
video_profile_index.json
song_action_recommendations.json
action_song_recommendations.json
action_event_chains.json
music_playlists.json
stills_index.json
human_review_queue.json
graph_nodes.json
graph_edges.json
sql/suits_v16_3_2_recursive_ml.sqlite3
neo4j/suits_v16_3_2_import.cypher
```

## Strategy

The processor recursively scans `$uitsmafia`, learns from prior profiler outputs, profiles media/log/data metadata, generates song-action and action-song recommendations, restores D0ugie$ Story as a menu system, and makes the website video folder browseable with metadata comments.

The model treats movie production as a chain:

```text
raw media -> metadata -> action/change event -> predation/comedy tone -> objective -> playlist/render/review -> graph memory
```
