#!/usr/bin/env python3
import argparse, csv, json, os, re, sqlite3, subprocess, hashlib, datetime as dt
from pathlib import Path
VERSION='v16.3.2'
SCHEMA='suits_recursive_ml_webui_v16_3_2'
MEDIA_EXT={'.mp4','.mkv','.webm','.mov','.m4v','.avi'}
AUDIO_EXT={'.mp3','.wav','.flac','.m4a','.aac','.opus','.ogg','.webm'}
IMAGE_EXT={'.png','.jpg','.jpeg','.webp','.gif','.apng','.svg'}
DATA_EXT={'.json','.jsonl','.csv','.txt','.log','.md','.html','.htm','.sql','.cypher'}
TONES=['shot_fired','hit_confirmed','graphic_intensity_review','comedy_blunder','predation_pressure','chase_escape','dark_aftermath','hero_intro','team_play','dramatic']
TERM_MAP={
 'shot_fired':['shot','shoot','gun','guns','rifle','dsr','fire','fired','trigger'],
 'hit_confirmed':['hit','blooded','damage','impact','downed'],
 'graphic_intensity_review':['graphic','intensity','brutal','gore'],
 'comedy_blunder':['funny','comedy','stupid','blunder','worst','upset','dreams','onlyfans'],
 'predation_pressure':['mafia','war','fight','crips','disciples','suits','predation','pursuit','chase','caught','dangerous','notorious','rejects'],
 'chase_escape':['chase','route','escape','fired','kidnapped','mission','shipment'],
 'dark_aftermath':['hell','bells','black','dark','farewell','fallout','reaper','midnight'],
 'hero_intro':['official','trailer','joins','chapter','intro','boys','highlights'],
 'team_play':['team','crew','chapter','multi','vs','versus'],
 'dramatic':['dramatic','dangerous','war','fallout','fight','blooded']
}
def now(): return dt.datetime.now(dt.UTC).isoformat().replace('+00:00','Z')
def sid(s): return hashlib.sha1(str(s).encode('utf-8','ignore')).hexdigest()[:12]
def safe_text(x): return str(x or '')
def tone_scores(name,path=''):
    text=(name+' '+path).lower()
    scores={k:0 for k in TONES}; hits=[]
    for tone,terms in TERM_MAP.items():
        for t in terms:
            if t in text:
                scores[tone]+=1; hits.append(t)
    return scores, sorted(set(hits))
def ffprobe_duration(path):
    try:
        out=subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)],stderr=subprocess.DEVNULL,timeout=8).decode().strip()
        return float(out) if out else None
    except Exception: return None
def load_json(path):
    try:
        return json.loads(Path(path).read_text(errors='ignore'))
    except Exception: return None
def write_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True); Path(path).write_text(json.dumps(obj,indent=2,ensure_ascii=False))
def write_csv(path,rows,fields):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); [w.writerow({k:r.get(k,'') for k in fields}) for r in rows]
def asset_record(p,root):
    ext=p.suffix.lower(); kind='data'
    if ext in MEDIA_EXT: kind='video'
    elif ext in AUDIO_EXT: kind='audio'
    elif ext in IMAGE_EXT: kind='image'
    scores,hits=tone_scores(p.name,str(p))
    dur=ffprobe_duration(p) if ext in MEDIA_EXT|AUDIO_EXT else None
    st=p.stat()
    return {'asset_id':sid(p),'path':str(p),'rel_path':str(p.relative_to(root)) if str(p).startswith(str(root)) else str(p),'name':p.name,'slug':re.sub(r'[^a-z0-9]+','_',p.stem.lower()).strip('_')[:80],'ext':ext,'kind':kind,'size_bytes':st.st_size,'duration_s':dur,'term_score':sum(scores.values()),'term_hits':'|'.join(hits),'tone_scores':scores,'mtime_utc':dt.datetime.fromtimestamp(st.st_mtime,dt.UTC).isoformat().replace('+00:00','Z')}
def get_previous_profiles(root):
    candidates=[]
    for nm in ['music_profile.json','video_profile.json','song_video_match_plan.json','song_story_plan.json','webui_song_story_index.json']:
        candidates += list(Path(root).rglob(nm))[:1000]
    return candidates
def normalize_existing(records):
    if isinstance(records,dict):
        for key in ['songs','videos','matches']:
            if key in records and isinstance(records[key],list): return records[key]
        return []
    return records if isinstance(records,list) else []
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default='/home/andy/Documents/suitsmafia')
    ap.add_argument('--site',default='/home/andy/Documents/suitsmafia/susitsmafia_website')
    ap.add_argument('--out',default='/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_3_2_recursive_ml_webui')
    ap.add_argument('--limit-files',type=int,default=0)
    ap.add_argument('--extract-stills',action='store_true')
    ap.add_argument('--max-stills',type=int,default=80)
    args=ap.parse_args(); root=Path(args.root); out=Path(args.out); site=Path(args.site)
    print('[o][o] $uits Processor',VERSION)
    print('SCRIPT=suits_story_menu_video_ml_processor_v16_3_2.py')
    print('SCHEMA='+SCHEMA)
    print('ROOT='+str(root)); print('OUT='+str(out)); print('SITE='+str(site))
    out.mkdir(parents=True,exist_ok=True); (out/'sql').mkdir(exist_ok=True); (out/'neo4j').mkdir(exist_ok=True)
    # scan all useful files
    assets=[]; count=0
    skip={'node_modules','.git','__pycache__','.cache','.venv','venv'}
    for p in root.rglob('*'):
        if any(part in skip for part in p.parts): continue
        if not p.is_file(): continue
        if p.suffix.lower() in MEDIA_EXT|AUDIO_EXT|IMAGE_EXT|DATA_EXT:
            try: assets.append(asset_record(p,root)); count+=1
            except Exception: pass
            if args.limit_files and count>=args.limit_files: break
    songs=[a for a in assets if a['kind']=='audio' or ('music' in a['path'].lower() and a['kind']=='video')]
    videos=[a for a in assets if a['kind']=='video' and 'music' not in a['path'].lower()]
    images=[a for a in assets if a['kind']=='image']
    # ingest previous profile JSONs if available
    prev=[]
    for fp in get_previous_profiles(root):
        dat=load_json(fp); rows=normalize_existing(dat)
        if rows: prev.append({'path':str(fp),'rows':len(rows)})
    # create song/action and action/song recommendations
    recs=[]
    for song in songs[:425]:
        ss=song.get('tone_scores',{})
        candidates=[]
        for vid in videos[:350]:
            vs=vid.get('tone_scores',{})
            common=sum(min(ss.get(t,0),vs.get(t,0)) for t in TONES)
            base=common*12 + min(float(song.get('duration_s') or 180),500)/100 + min(float(vid.get('duration_s') or 120),900)/300
            for t in TONES:
                if vs.get(t,0)>0 or ss.get(t,0)>0:
                    score=base + vs.get(t,0)*5 + ss.get(t,0)*2
                    if score>8: candidates.append((score,t,vid))
        candidates=sorted(candidates,key=lambda x:x[0],reverse=True)[:18]
        for rank,(score,action,vid) in enumerate(candidates,1):
            use='full_song_story' if rank==1 else ('29s_trailer' if rank<=3 else 'alternate_story_variant')
            recs.append({'score':round(score,2),'song':song['name'],'song_path':song['path'],'song_duration_s':song.get('duration_s'),'action':action,'video':vid['name'],'video_path':vid['path'],'video_duration_s':vid.get('duration_s'),'rank':rank,'use':use,'render_slug':song['slug']+'__'+action+'__'+str(rank).zfill(2)})
    action_song=sorted([{'action':r['action'],'song':r['song'],'video':r['video'],'score':r['score'],'reason':'tone overlap + duration/story fit + recursive prior'} for r in recs],key=lambda r:r['score'],reverse=True)
    # event chains
    chain_templates=[
      ('predation_pressure',['route_prey','pressure_rise','shot_fired_candidate','hit_or_escape','aftermath'],'clean pressure curve'),
      ('comedy_blunder',['advantage','panic_turn','vehicle_fail','dumb_luck','laugh_release'],'comedy timing + reversal'),
      ('dark_aftermath',['impact','silence','slow_motion_memory','title_card'],'emotional residue'),
      ('hero_intro',['identity_card','crew_motion','music_rise','first_action'],'mythic opening'),
      ('graphic_intensity_review',['impact_event','review_gate','safe_story_context'],'review before publication'),
      ('team_play',['crew_alignment','flank','cross_pressure','objective_taken'],'synergistic behaviour')]
    chains=[]
    for i,(obj,steps,ex) in enumerate(chain_templates,1):
        chains.append({'chain_id':'chain_'+str(i).zfill(3),'objective':obj,'steps':steps,'excellence':ex,'measure':'human_acceptance + render_value + no_repeat_score'})
    # playlists
    playlists={}
    for tone in TONES:
        rows=[{'song':s['name'],'tone':tone,'score':s.get('tone_scores',{}).get(tone,0),'duration_s':s.get('duration_s')} for s in songs if s.get('tone_scores',{}).get(tone,0)>0]
        playlists[tone]=sorted(rows,key=lambda r:(r['score'],r.get('duration_s') or 0),reverse=True)[:50]
    # story/goals
    doug={'opening':'D0ug1e$ Story returns as a WebUI lens: daring, dumb luck, cinematic pressure, tactical comedy, and roleplay myth turned into machine-readable memory.','chapters':[{'title':'The dare','text':'Who dares wins: the model learns which risky plays become cinematic value.'},{'title':'The dance','text':'Action is choreographed by pressure, timing, route evolution, and music cue fit.'},{'title':'El doll0','text':'Luck is not ignored: survival by accident, dumb luck, and comic reversal become labels.'},{'title':'Royal Welsh commando SBS iv.ii','text':'The theatrical command deck turns evidence into objectives, key result areas, and performance excellence.'}]}
    goals={'goals':[{'goal':'Learn predation patterning','why':'Find pressure sequences before collapse or escape.','measure':'predation chain precision + human accepted labels'},{'goal':'Learn comedy timing','why':'Detect the failure/reversal moments that make roleplay funny.','measure':'comedy acceptance rate'},{'goal':'Song to action / action to song','why':'Match riffs, beats and energy curves to events and vice versa.','measure':'render approval score'},{'goal':'Improve synergistic behaviours','why':'Identify team play, flanks, route pressure and survival excellence.','measure':'team_play and objective chain scores'},{'goal':'Build movie production intelligence','why':'Turn raw media into stories, trailers, full-song films and reviewable plans.','measure':'completed high-value renders'}]}
    # stills index existing images + optional extraction commands placeholder
    stills=[{'path':i['path'],'label':i['name'],'kind':i['ext'].lstrip('.')} for i in images[:250]]
    # website video theatre scan: relative to susitsmafia_website/videos for browser-friendly URLs
    website_videos=[]
    webvid_root=site/'videos'
    if webvid_root.exists():
        for vp in sorted(webvid_root.rglob('*.mp4')):
            try:
                dur=ffprobe_duration(vp)
                scores,hits=tone_scores(vp.name,str(vp))
                tones=[k for k,v in scores.items() if v>0]
                comment_parts=[]
                if dur: comment_parts.append('duration %.1fs' % dur)
                if tones: comment_parts.append('tones: '+', '.join(tones[:5]))
                if 'render' in str(vp).lower() or 'complete' in vp.name.lower(): comment_parts.append('processor-rendered result')
                if 'clip29' in vp.name.lower() or '29' in vp.name.lower(): comment_parts.append('trailer/short-form candidate')
                if 'full' in vp.name.lower(): comment_parts.append('full-song / long-form candidate')
                comment='; '.join(comment_parts) if comment_parts else 'scanned .mp4 asset for theatre review'
                website_videos.append({'path':str(vp),'rel_path':str(vp.relative_to(webvid_root)),'name':vp.name,'duration_s':dur,'tones':tones,'metadata_comment':comment,'size_bytes':vp.stat().st_size,'mtime_utc':dt.datetime.fromtimestamp(vp.stat().st_mtime,dt.UTC).isoformat().replace('+00:00','Z')})
            except Exception:
                pass
    combined_menu_manifest=[
      {'title':'Dashboard','href':'suits_v16_3_2_dashboard.php','comment':'Processor metrics, learned patterns, and production-chain overview.'},
      {'title':'D0ug1e$ Story','href':'suits_v16_3_2_dougies_story.php','comment':'Myth, luck, daring, comedy, predation, and movie-production story layer.'},
      {'title':'Aims / Goals / KRAs','href':'suits_v16_3_2_aims_goals.php','comment':'McKinsey-style objective management for theatrical GTA:RP ML production.'},
      {'title':'Video Theatre','href':'suits_v16_3_2_videos.php','comment':'Scanned website .mp4 sidebar thumbnails and main player with metadata comments.'},
      {'title':'Song → Action','href':'suits_v16_3_2_song_action.php','comment':'Which action, clip, still, animation, or chain fits each song.'},
      {'title':'Action → Song','href':'suits_v16_3_2_action_song.php','comment':'Which music best fits predation, comedy, hit, shot, chase, aftermath.'},
      {'title':'Event Chains','href':'suits_v16_3_2_event_chains.php','comment':'Production chain: raw media to action/change to story objective.'},
      {'title':'Playlists','href':'suits_v16_3_2_playlists.php','comment':'Tone-scored music playlists for hero, predation, comedy, aftermath.'},
      {'title':'Stills / Evidence','href':'suits_v16_3_2_stills.php','comment':'Processed stills, APNG/still evidence, thumbnails and review anchors.'},
      {'title':'Neo4j Graph','href':'suits_v16_3_2_graph.php','comment':'Graph phase with nodes, edges, tones, recommendations and chains.'},
      {'title':'Human Review','href':'suits_v16_3_2_review.php','comment':'Market signal: keep, reject, relabel, or promote to story beat.'},
      {'title':'Old Maxims','href':'maxims.html','comment':'Previous strategic/maxim menu restored into the combined story menu.'},
      {'title':'Old Videos','href':'videos.html','comment':'Prior videos page remains linked for continuity.'},
      {'title':'Legacy Graph','href':'graph_view.php','comment':'Previous graph browser remains linked.'},
      {'title':'Render Browser','href':'render_browser.php','comment':'Old render diagnostics and browse page remains linked.'},
      {'title':'Members / Join','href':'members_v2.php','comment':'Previous member and join/login route remains discoverable.'}
    ]
    review=[{'priority':'high' if r['score']>40 else 'medium','item':r['render_slug'],'label':r['action'],'question':'Keep, reject, relabel, or make this a story beat?'} for r in recs[:200]]
    # graph
    nodes=[]; edges=[]
    def add_node(id,t,label): nodes.append({'id':id,'type':t,'label':label})
    def add_edge(a,b,t,w=1): edges.append({'source':a,'target':b,'type':t,'weight':w})
    for tone in TONES: add_node('tone_'+tone,'Tone',tone)
    for s in songs[:120]: add_node('song_'+s['asset_id'],'Song',s['name']); [add_edge('song_'+s['asset_id'],'tone_'+t,'HAS_TONE',s['tone_scores'].get(t,0)) for t in TONES if s['tone_scores'].get(t,0)>0]
    for v in videos[:160]: add_node('video_'+v['asset_id'],'Video',v['name']); [add_edge('video_'+v['asset_id'],'tone_'+t,'HAS_TONE',v['tone_scores'].get(t,0)) for t in TONES if v['tone_scores'].get(t,0)>0]
    for c in chains: add_node(c['chain_id'],'EventChain',c['objective']); [add_edge(c['chain_id'],'tone_'+step,'USES_TONE',1) for step in c['steps'] if 'tone_'+step in {n['id'] for n in nodes}]
    for r in recs[:250]:
        rid='rec_'+sid(r['render_slug']); add_node(rid,'Recommendation',r['render_slug']); add_edge(rid,'tone_'+r['action'],'RECOMMENDS_ACTION',r['score'])
    # sqlite
    db=out/'sql'/'suits_v16_3_2_recursive_ml.sqlite3'
    if db.exists(): db.unlink()
    conn=sqlite3.connect(db); c=conn.cursor()
    c.execute('create table asset(asset_id text primary key,path text,name text,kind text,ext text,duration_s real,term_score real,term_hits text)')
    c.execute('create table recommendation(render_slug text primary key,song text,video text,action text,score real,use text)')
    c.execute('create table event_chain(chain_id text primary key,objective text,steps text,excellence text)')
    for a in assets: c.execute('insert or replace into asset values(?,?,?,?,?,?,?,?)',(a['asset_id'],a['path'],a['name'],a['kind'],a['ext'],a.get('duration_s'),a.get('term_score'),a.get('term_hits')))
    for r in recs: c.execute('insert or replace into recommendation values(?,?,?,?,?,?)',(r['render_slug'],r['song'],r['video'],r['action'],r['score'],r['use']))
    for ch in chains: c.execute('insert or replace into event_chain values(?,?,?,?)',(ch['chain_id'],ch['objective'],'|'.join(ch['steps']),ch['excellence']))
    conn.commit(); conn.close()
    # output JSON/CSV
    summary={'version':VERSION,'created_utc':now(),'assets':len(assets),'songs':len(songs),'videos':len(videos),'images':len(images),'website_videos':len(website_videos),'matches':len(recs),'event_chains':len(chains),'stills':len(stills),'patterns':len(TONES),'previous_profile_files':prev[:80]}
    for name,obj in [('summary.json',summary),('music_profile_index.json',songs),('video_profile_index.json',videos),('website_videos_index.json',website_videos),('combined_menu_manifest.json',combined_menu_manifest),('song_action_recommendations.json',recs),('action_song_recommendations.json',action_song),('action_event_chains.json',chains),('music_playlists.json',playlists),('dougies_story.json',doug),('aims_goals.json',goals),('stills_index.json',stills),('human_review_queue.json',review),('graph_nodes.json',nodes),('graph_edges.json',edges),('learned_predation_patterns.json',{'tones':TONES,'chains':chain_templates,'what_can_we_learn':['predation pressure curves','comedy reversal timing','song-to-action fit','action-to-song fit','team synergy behaviours','human acceptance priors','which website videos deserve front-page promotion','which prior menus map to new objectives']})]: write_json(out/name,obj)
    write_csv(out/'sql'/'song_action_recommendations.csv',recs,['score','song','action','video','rank','use','render_slug','song_path','video_path','song_duration_s','video_duration_s'])
    write_csv(out/'sql'/'event_chains.csv',chains,['chain_id','objective','steps','excellence','measure'])
    write_csv(out/'neo4j'/'neo4j_nodes.csv',nodes,['id','type','label'])
    write_csv(out/'neo4j'/'neo4j_edges.csv',edges,['source','target','type','weight'])
    cy="""LOAD CSV WITH HEADERS FROM 'file:///neo4j_nodes.csv' AS row\nMERGE (n:SuitsNode {id: row.id}) SET n.type=row.type, n.label=row.label;\nLOAD CSV WITH HEADERS FROM 'file:///neo4j_edges.csv' AS row\nMATCH (a:SuitsNode {id: row.source}) MATCH (b:SuitsNode {id: row.target})\nMERGE (a)-[r:SUITS_REL {type: row.type}]->(b) SET r.weight = toFloat(row.weight);\n"""
    (out/'neo4j'/'suits_v16_3_2_import.cypher').write_text(cy)
    (out/'neo4j'/'suits_v16_3_2_import_no_apoc.cypher').write_text(cy)
    # report
    (out/'report.html').write_text('<!doctype html><html><body style="background:#07111f;color:#e8f4ff;font-family:Arial"><h1>[o][o] $uits v16.3.2 Recursive ML WebUI Report</h1><pre>'+json.dumps(summary,indent=2)+'</pre></body></html>')
    # copy data to site
    datadir=site/'data'/'suits_v16_3_2'; datadir.mkdir(parents=True,exist_ok=True)
    for fp in out.glob('*.json'):
        (datadir/fp.name).write_text(fp.read_text())
    print('[o][o] complete')
    print('DB='+str(db)); print('WEBUI='+str(site/'suits_v16_3_2_dashboard.php'))
if __name__=='__main__': main()
