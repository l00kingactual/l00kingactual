<?php include 'suits_v16_3_2_nav.php'; suits_v1632_start('D0ug1e$ Story'); $story=load_json('dougies_story.json') ?: []; $menus=load_json('combined_menu_manifest.json') ?: []; ?>
<div class='hero'><h1>D0ug1e$ Story</h1><p><?=h($story['opening'] ?? 'The story layer is waiting for the processor run.')?></p><p class='muted'>This page now combines the previous menus, the new processor menus, and the movie-production intelligence menus into one story command map.</p></div>
<h2>Combined Menus</h2>
<div class='storyMenu'>
<?php foreach($menus as $m): ?>
  <a href='<?=h($m['href'])?>'><b><?=h($m['title'])?></b><span><?=h($m['comment'])?></span></a>
<?php endforeach; ?>
</div>
<h2>Chapters</h2>
<div class='grid'>
<?php foreach(($story['chapters'] ?? []) as $ch): ?>
  <div class='card'><h3><?=h($ch['title'])?></h3><p><?=h($ch['text'])?></p></div>
<?php endforeach; ?>
</div>
<div class='card'><h2>The Story Engine</h2><p>D0ug1e$ Story is not just prose. It is a navigation layer over files, videos, stills, playlists, action chains, Neo4j graph memory, and human review. Every menu is a doorway into the production chain.</p></div>
<?php suits_v1632_end(); ?>
