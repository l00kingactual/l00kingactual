<?php
function suits_v1632_start($title){
  echo "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>".htmlspecialchars($title)."</title><link rel='stylesheet' href='css/suits_v16_3_2.css'></head><body><div class='layout'><aside class='side'><a class='brand' href='suits_v16_3_2_dashboard.php' title='Home'><img src='images/suits_v16_3_2_icons/suits_v16_3_2_logo.svg'><h1>\$uit\$<br>v16.3.2</h1></a><a class='homeButton' href='suits_v16_3_2_dashboard.php'>⌂ Home / Command Deck</a><nav class='nav'>";
  $groups = [
    'Core' => [
      ['suits_v16_3_2_dashboard.php','Dashboard'],
      ['suits_v16_3_2_dougies_story.php','D0ug1e$ Story'],
      ['suits_v16_3_2_aims_goals.php','Aims / Goals / KRAs'],
    ],
    'Media Direction' => [
      ['suits_v16_3_2_videos.php','Video Theatre'],
      ['suits_v16_3_2_song_action.php','Song → Action'],
      ['suits_v16_3_2_action_song.php','Action → Song'],
      ['suits_v16_3_2_playlists.php','Playlists'],
      ['suits_v16_3_2_stills.php','Stills / Evidence'],
    ],
    'Predation Intelligence' => [
      ['suits_v16_3_2_event_chains.php','Event Chains'],
      ['suits_v16_3_2_graph.php','Neo4j Graph'],
      ['suits_v16_3_2_review.php','Human Review'],
    ],
    'Previous Menus' => [
      ['index.html','Old Home'],
      ['maxims.html','Maxims'],
      ['videos.html','Old Videos'],
      ['roles.html','Roles'],
      ['members_v2.php','Members'],
      ['graph_view.php','Legacy Graph'],
      ['render_browser.php','Render Browser'],
      ['questionnaire_servers.html','Server Questionnaire'],
      ['join.php','Join'],
      ['login.php','Login'],
    ],
  ];
  foreach($groups as $g=>$links){ echo "<div class='navGroup'><h3>".htmlspecialchars($g)."</h3>"; foreach($links as $l){ echo "<a href='".htmlspecialchars($l[0])."'>".htmlspecialchars($l[1])."</a>"; } echo "</div>"; }
  echo "</nav></aside><main class='main'><div class='topbar'><a href='suits_v16_3_2_dashboard.php'>⌂ Home</a><a href='suits_v16_3_2_videos.php'>Video Theatre</a><a href='suits_v16_3_2_dougies_story.php'>D0ug1e$ Story</a><a href='suits_v16_3_2_graph.php'>Neo4j</a><a href='suits_v16_3_2_review.php'>Review</a></div>";
}
function suits_v1632_end(){echo "<div class='footer'>[o][o] \$uit\$ recursive ML WebUI — every page has navigation, home, and mouse behaviour.</div></main></div><script src='js/suits_mouse_nav_v16_3_2.js'></script></body></html>";}
function load_json($name){$p=__DIR__.'/data/suits_v16_3_2/'.$name; if(!file_exists($p)) return null; return json_decode(file_get_contents($p), true);} 
function h($s){return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');}
?>
