<?php include 'suits_v16_3_2_nav.php'; suits_v1632_start('$uit$ Video Theatre'); $videos=load_json('website_videos_index.json') ?: []; ?>
<div class='hero'><h1>Video Theatre</h1><p class='muted'>Scanned from <code>susitsmafia_website/videos</code>. Click a sidebar clip to load it into the main player. Metadata comments are processor-generated from filename, duration, path, and tone clues.</p></div>
<div class='videoShell'>
  <div class='videoList'>
    <?php foreach($videos as $i=>$v): $url='videos/'.ltrim($v['rel_path'],'/'); ?>
      <div class='videoItem' onclick="loadSuitsVideo(<?=json_encode($url)?>,<?=json_encode($v['name'])?>,<?=json_encode($v['metadata_comment'])?>)">
        <video muted preload='metadata' src='<?=h($url)?>'></video>
        <div><b><?=h($v['name'])?></b><div class='comment'><?=h($v['metadata_comment'])?></div><div><?php foreach(($v['tones']??[]) as $t): ?><span class='pill'><?=h($t)?></span><?php endforeach; ?></div></div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class='playerCard card'>
    <h2 id='videoTitle'><?=count($videos)?h($videos[0]['name']):'No .mp4 found yet'?></h2>
    <video id='mainVideo' controls src='<?=count($videos)?h('videos/'.ltrim($videos[0]['rel_path'],'/')):''?>'></video>
    <p id='videoComment' class='comment'><?=count($videos)?h($videos[0]['metadata_comment']):'Run the processor to build the video index.'?></p>
  </div>
</div>
<script>
function loadSuitsVideo(src,title,comment){
  const v=document.getElementById('mainVideo');
  document.getElementById('videoTitle').textContent=title;
  document.getElementById('videoComment').textContent=comment;
  v.src=src; v.load(); v.play().catch(()=>{});
}
</script>
<?php suits_v1632_end(); ?>
