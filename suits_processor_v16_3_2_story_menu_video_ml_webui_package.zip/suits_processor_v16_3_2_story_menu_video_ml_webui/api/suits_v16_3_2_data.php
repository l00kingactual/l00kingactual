<?php
$name = preg_replace('/[^a-zA-Z0-9_\-.]/','', $_GET['file'] ?? 'summary.json');
$path = dirname(__DIR__).'/data/suits_v16_3_2/'.$name;
header('Content-Type: application/json');
if(!file_exists($path)){ http_response_code(404); echo json_encode(['error'=>'missing']); exit; }
readfile($path);
