# Cymru Hive OS v5 · SPACE WALE$ Pathway League

Retains: zoomable Wales map, £2.5bn/year capped sliders, 25,000 staff model, provider/consumer population model, 1/5/10/25-year horizons, 2D/3D charting and auto-running 24 auto-tunes.

Adds: Cubs, Brownies, Scouts, Guides, adventures, CCF-style leadership, astronomy, sport, maths, physics, languages, chemistry, biology, farm twins, terrain-map projects, badges, competitions and ROI scoring.

Run:
```bash
python3 -m http.server 8088
```
Open http://127.0.0.1:8088/


## v5.1 value-slider and charting upgrade

Adds:

- all sidebar dropdowns start collapsed
- clicking any auto-tune restarts the running simulation
- budget allocation sliders remain capped to £2.5bn/year
- staff allocation sliders are now explicit and capped to 25,000 staff
- competition budget sliders are capped to the current Pathway League allocation
- badge ROI-weight sliders
- population provider/consumer sliders for each cohort
- new charts for staff, competition budgets, badge ROI weights and provider/consumer values
- JSON export now includes budget values, staff values, competition values, badge weights and cohort provider/consumer settings
- SQL and Neo4j extensions for value-slider ledgers
