<#
[o][o] $uits Processor v16.4.1 Enhanced installer for Windows / WSL.

Recommended use on Windows: run this from PowerShell after unzipping the package.
It installs the package into Documents\suitsmafia and creates helper launchers.
The actual media processor is designed for the Linux/WSL project path:
  /home/andy/Documents/suitsmafia
so the Windows launcher calls WSL when available.
#>
param(
  [string]$InstallRoot = "$env:USERPROFILE\Documents\suitsmafia",
  [string]$WslDistro = "",
  [switch]$NoWslLauncher
)

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProcessorName = "suits_processor_v16_4_1_ml_movie_factory_webui"
$ProcessorTarget = Join-Path $InstallRoot "processors\$ProcessorName"
$ToolsTarget = Join-Path $InstallRoot "tools"
$SiteTarget = Join-Path $InstallRoot "susitsmafia_website"

Write-Host "[o][o] Installing $ProcessorName" -ForegroundColor Cyan
Write-Host "Package: $PackageRoot"
Write-Host "Target : $ProcessorTarget"

New-Item -ItemType Directory -Force -Path $ProcessorTarget, $ToolsTarget, $SiteTarget, (Join-Path $SiteTarget "css"), (Join-Path $SiteTarget "js"), (Join-Path $SiteTarget "api"), (Join-Path $SiteTarget "data\suits_v16_4_1"), (Join-Path $SiteTarget "videos") | Out-Null

Copy-Item -Path (Join-Path $PackageRoot "*") -Destination $ProcessorTarget -Recurse -Force
if (Test-Path (Join-Path $PackageRoot "web")) { Copy-Item -Path (Join-Path $PackageRoot "web\*") -Destination $SiteTarget -Recurse -Force }
if (Test-Path (Join-Path $PackageRoot "css")) { Copy-Item -Path (Join-Path $PackageRoot "css\*") -Destination (Join-Path $SiteTarget "css") -Recurse -Force }
if (Test-Path (Join-Path $PackageRoot "js")) { Copy-Item -Path (Join-Path $PackageRoot "js\*") -Destination (Join-Path $SiteTarget "js") -Recurse -Force }
if (Test-Path (Join-Path $PackageRoot "api")) { Copy-Item -Path (Join-Path $PackageRoot "api\*") -Destination (Join-Path $SiteTarget "api") -Recurse -Force }

$PsLauncher = Join-Path $ToolsTarget "suits_processor_v16_4_1_ml_movie_factory.ps1"
@"
param([Parameter(ValueFromRemainingArguments=`$true)][string[]]`$Args)
`$ErrorActionPreference = "Stop"
`$Script = "$ProcessorTarget\tools\suits_processor_v16_4_1_ml_movie_factory.py"
python `"`$Script`" @Args
"@ | Set-Content -Path $PsLauncher -Encoding UTF8

$BatLauncher = Join-Path $ToolsTarget "suits_processor_v16_4_1_ml_movie_factory.bat"
@"
@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0suits_processor_v16_4_1_ml_movie_factory.ps1" %*
"@ | Set-Content -Path $BatLauncher -Encoding ASCII

if (-not $NoWslLauncher) {
  $WslLauncher = Join-Path $ToolsTarget "suits_processor_v16_4_1_ml_movie_factory_wsl.ps1"
  $DistroArg = if ($WslDistro.Trim().Length -gt 0) { "-d `"$WslDistro`"" } else { "" }
@"
param([Parameter(ValueFromRemainingArguments=`$true)][string[]]`$Args)
`$argLine = (`$Args | ForEach-Object { "'" + (`$_ -replace "'", "'\''") + "'" }) -join ' '
wsl $DistroArg bash -lc "/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_1_ml_movie_factory `$argLine"
"@ | Set-Content -Path $WslLauncher -Encoding UTF8
}

Write-Host "[o][o] Installed processor files." -ForegroundColor Green
Write-Host "PowerShell launcher: $PsLauncher"
Write-Host "Batch launcher     : $BatLauncher"
Write-Host "WSL launcher       : $(Join-Path $ToolsTarget 'suits_processor_v16_4_1_ml_movie_factory_wsl.ps1')"
Write-Host ""
Write-Host "For the darkstar Linux project, use WSL/Linux path and run:" -ForegroundColor Yellow
Write-Host "/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_1_ml_movie_factory --smoke --ml-update --build-webui --build-graphs --build-charts --plan-12-movies --no-probe-media --progress-every 100"
