param([switch]$Wsl)
if ($Wsl) {
  wsl bash -lc "/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_1_ml_movie_factory --ml-update --build-webui --build-graphs --build-charts --plan-12-movies --no-probe-media --progress-every 250"
} else {
  python .\tools\suits_processor_v16_4_1_ml_movie_factory.py --ml-update --build-webui --build-graphs --build-charts --plan-12-movies --no-probe-media --progress-every 250
}
