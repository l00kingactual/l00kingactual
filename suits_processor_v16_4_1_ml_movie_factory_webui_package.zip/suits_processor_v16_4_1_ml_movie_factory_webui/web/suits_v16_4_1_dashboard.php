<?php include 'suits_v16_4_1_common.php'; suits_header('$uits v16.4.1 Dashboard'); ?>
<div class='grid' id='metrics'></div><div class='card'><h2>Latest 12 movie plan</h2><table id='movies'></table></div>
<script>
(async()=>{let s=await loadJson('data/suits_v16_4_1/summary.json');let m=await loadJson('data/suits_v16_4_1/movie_factory_12.json');metrics.innerHTML=['songs','videos','matches','event_chains','planned_movies','previous_outputs'].map(k=>`<div class='card'><div class='metric'>${s[k]||0}</div><b>${k}</b></div>`).join('');movies.innerHTML='<tr><th>Story</th><th>Song</th><th>Video</th><th>Score</th></tr>'+m.map(x=>`<tr><td>${x.story_variant}</td><td>${x.song_name}</td><td>${x.video_name}</td><td>${x.match_score}</td></tr>`).join('');})();
</script><?php suits_footer(); ?>
