# [o][o] $uits Processor v16.4.1 Enhanced — ML Movie Factory WebUI

This enhanced v16.4.1 package keeps the progress-safe scanner and adds a stronger predation/comedy animal-archetype model:

- `lone_wolf`
- `tiger_stalk`
- `lion_pack_pressure`
- `sheep_flock_panic`
- `goat_stubborn_luck`
- `duck_waddle_escape`
- `swan_grace_escape`
- `eagle_overwatch`
- `hawk_strike`
- `raven_aftermath`
- `cuckoo_deception`
- plus crocodile/fox-style strategic patterns for chokepoints and deception.

The processor recursively scans `/home/andy/Documents/suitsmafia`, learns from previous output metadata, profiles audio/video/stills/APNG/log/data, builds graph/chart/WebUI data, creates song-to-action and action-to-song recommendations, and can plan/render 12 full-audio dramatic story movies to the website `videos/` folder.

## Linux / darkstar install

```bash
cd /home/andy/Downloads
unzip -o /mnt/data/suits_processor_v16_4_1_ml_movie_factory_webui_package.zip
cd suits_processor_v16_4_1_ml_movie_factory_webui
chmod +x scripts/*.sh tools/*.py *.sh
./scripts/install_v16_4_1.sh
```

## Windows / PowerShell install

From PowerShell after unzipping:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
cd $env:USERPROFILE\Downloads\suits_processor_v16_4_1_ml_movie_factory_webui
.\install_v16_4_1.ps1
```

The Windows installer copies the package to `Documents\suitsmafia`, installs WebUI files, and creates PowerShell/BAT launchers. For the main Linux project on darkstar, use WSL or run the Linux installer on darkstar.

WSL helper example:

```powershell
.\run_v16_4_1_smoke.ps1 -Wsl
.\run_v16_4_1_ml_update.ps1 -Wsl
```

## First run: smoke test

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_1_ml_movie_factory \
  --smoke \
  --ml-update \
  --build-webui \
  --build-graphs \
  --build-charts \
  --plan-12-movies \
  --no-probe-media \
  --progress-every 100
```

## Fast full update

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_1_ml_movie_factory \
  --ml-update \
  --build-webui \
  --build-graphs \
  --build-charts \
  --plan-12-movies \
  --no-probe-media \
  --progress-every 250
```

## Render and publish 12 movies

```bash
xdg-open /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_1_ml_movie_factory/report.html
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_1_ml_movie_factory/render_12_full_movies.sh
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_1_ml_movie_factory/publish_movies_to_site.sh
```

## WebUI

```bash
cd /home/andy/Documents/suitsmafia/susitsmafia_website
php -S 127.0.0.1:8081
```

Open:

- `http://127.0.0.1:8081/suits_v16_4_1_dashboard.php`
- `http://127.0.0.1:8081/suits_v16_4_1_processor_control.php`
- `http://127.0.0.1:8081/suits_v16_4_1_movie_factory.php`
- `http://127.0.0.1:8081/suits_v16_4_1_videos.php`
- `http://127.0.0.1:8081/suits_v16_4_1_charts.php`
- `http://127.0.0.1:8081/suits_v16_4_1_graph.php`

## New model outputs

The enhanced taxonomy appears in:

```text
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_1_ml_movie_factory/predation_comedy_taxonomy.json
/home/andy/Documents/suitsmafia/susitsmafia_website/data/suits_v16_4_1/predation_comedy_taxonomy.json
```

Match rows now include:

```text
song_archetype
video_archetype
predation_model_group
```

Event chains now include animal-model story logic, for example:

```text
lone_wolf      -> isolated_actor, silent_route, single_vector_pressure, decisive_move, fade_out
tiger_stalk    -> territory_marked, low_motion_wait, stalk, burst, aftermath
hawk_strike    -> fast_lock, sharp_angle, strike, impact, recovery
raven_aftermath-> dark_signal, wreckage, silence, memory, myth
cuckoo_deception -> false_pattern, misread, switch, blunder, comic_release
goat_stubborn_luck -> stubborn_hold, bad_position, el_dollo_luck, escape_gap, victory_laugh
```

[o][o] The wee machine now has predator, prey, comedy, luck, and aftermath archetypes for richer GTA:RP movie direction.
