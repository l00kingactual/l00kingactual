#!/usr/bin/env bash
set -euo pipefail
python3 tools/suits_processor_v16_4_1_ml_movie_factory.py --ml-update --build-webui --build-graphs --build-charts "$@"
