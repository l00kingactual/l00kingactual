#!/usr/bin/env python3
import argparse, csv, datetime as dt, hashlib, html, json, os, random, re, shutil, sqlite3, subprocess, sys
from pathlib import Path
VERSION='v16.4.1.2'
SCHEMA='suits_ml_movie_factory_v16_4_1'
BASE=Path('/home/andy/Documents/suitsmafia')
SITE=BASE/'susitsmafia_website'
OUT=BASE/'outputs'/'suits_processor_v16_4_1_ml_movie_factory'
DATA_DIR=SITE/'data'/'suits_v16_4_1'
VIDEO_SITE=SITE/'videos'
MEDIA_EXT={'.mp4','.mkv','.webm','.mov','.m4v','.avi'}
AUDIO_EXT={'.mp3','.wav','.m4a','.flac','.aac','.ogg','.opus','.webm'}
IMAGE_EXT={'.png','.jpg','.jpeg','.webp','.gif','.apng'}
DATA_EXT={'.json','.jsonl','.csv','.txt','.log','.md','.html','.htm','.sql','.cypher','.yml','.yaml','.ini','.cfg'}
STORY_VARIANTS=['predation_pressure','shot_fired','hit_confirmed','comedy_blunder','graphic_intensity_review','chase_escape','dark_aftermath','hero_intro','vehicle_pressure','ambush_trap','route_prey','finale_collapse','lone_wolf_hunt','tiger_stalk','eagle_overwatch','hawk_strike','raven_aftermath','cuckoo_deception','sheep_panic','goat_stubborn_luck','duck_waddle_escape','swan_grace_escape']
PRED_TERMS=['predation','predator','prey','kill','shot','hit','gun','weapon','ambush','chase','war','mafia','suits','disciples','crips','fight','notorious','pressure','graphic','intensity','dramatic','wolf','tiger','eagle','hawk','raven','cuckoo','sheep','goat','duck','swan']
COMEDY_TERMS=['funny','comedy','blunder','dumb','stupid','panic','fail','worst','upset','duck','goat','cuckoo','el_dollo','dollo','lucky','luck']
ANIMAL_ARCHETYPES={
    'lone_wolf': ['lone','wolf','solo','alone','one man','single','isolated'],
    'tiger_stalk': ['tiger','stalk','stalking','silent','territory','territorial'],
    'lion_pack_pressure': ['lion','pack','crew','team','chapter','family','mafia','suits','disciples'],
    'eagle_overwatch': ['eagle','overwatch','high ground','sniper','watch','lookout','scout'],
    'hawk_strike': ['hawk','strike','fast','dive','snap','hit','trickshot','shot'],
    'raven_aftermath': ['raven','aftermath','reaper','dark','hell','death','grave','black'],
    'cuckoo_deception': ['cuckoo','deception','bait','fake','trick','wrong','switch'],
    'sheep_flock_panic': ['sheep','flock','panic','scatter','crowd','herd'],
    'goat_stubborn_luck': ['goat','stubborn','lucky','luck','dollo','el_dollo','escape'],
    'duck_waddle_escape': ['duck','waddle','sitting duck','water','goofy'],
    'swan_grace_escape': ['swan','grace','clean','smooth','elegant'],
    'crocodile_chokepoint': ['crocodile','choke','bridge','gate','corner','trap'],
    'fox_deception': ['fox','deceive','bait','flank','smart','sly'],
}

def now(): return dt.datetime.now(dt.UTC).isoformat().replace('+00:00','Z')
def sid(s): return hashlib.sha1(str(s).encode('utf-8','ignore')).hexdigest()[:12]
def safe_slug(s):
    s=re.sub(r'[^A-Za-z0-9]+','_',str(s).lower()).strip('_')
    return s[:70] or 'asset'
def run(cmd, timeout=12):
    try:
        r=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
        return r.stdout.strip(), r.stderr.strip(), r.returncode
    except Exception as e:
        return '', str(e), 1

def ffprobe(path, enabled=True):
    if not enabled:
        return {'probe_skipped': True, 'duration_s': 0}
    out,err,rc=run(['ffprobe','-v','error','-show_entries','format=duration,bit_rate','-show_streams','-of','json',str(path)],timeout=10)
    d={}
    if rc==0 and out:
        try:
            j=json.loads(out); fmt=j.get('format',{})
            d['duration_s']=float(fmt.get('duration') or 0)
            d['bit_rate']=int(fmt.get('bit_rate') or 0) if fmt.get('bit_rate') else 0
            for st in j.get('streams',[]):
                if st.get('codec_type')=='video' and 'video_codec' not in d:
                    d['video_codec']=st.get('codec_name',''); d['width']=st.get('width',0); d['height']=st.get('height',0)
                    fr=st.get('avg_frame_rate') or st.get('r_frame_rate') or '0/1'
                    try:
                        a,b=fr.split('/'); d['fps']=round(float(a)/float(b),3) if float(b) else 0
                    except Exception: d['fps']=0
                if st.get('codec_type')=='audio' and 'audio_codec' not in d:
                    d['audio_codec']=st.get('codec_name','')
        except Exception as e:
            d['probe_error']=str(e)
    else:
        d['probe_error']=err[:200]
    return d

def score_terms(name):
    low=name.lower(); hits=[]; score=0
    for t in PRED_TERMS:
        if t in low: hits.append(t); score+=3
    for t in COMEDY_TERMS:
        if t in low: hits.append(t); score+=4
    return score, sorted(set(hits))
def tone_scores(name):
    low=name.lower()
    return {
        'shot_fired': int(any(x in low for x in ['shot','shoot','gun','trickshot','fire'])),
        'hit_confirmed': int(any(x in low for x in ['hit','blooded','damage'])),
        'graphic_intensity_review': 2 if any(x in low for x in ['graphic','intensity','brutal']) else 0,
        'comedy_blunder': int(any(x in low for x in COMEDY_TERMS)),
        'predation_pressure': int(any(x in low for x in ['predation','war','mafia','fight','disciples','crips','suits','notorious','pressure','chase'])),
        'chase_escape': int(any(x in low for x in ['chase','escape','fired','kidnapped'])),
        'dark_aftermath': int(any(x in low for x in ['hell','bells','dark','farewell','fallout','death','reaper'])),
        'hero_intro': int(any(x in low for x in ['intro','joins','official','trailer','back in black','hero']))
    }


def archetype_scores(name):
    low=str(name).lower().replace('~','_').replace('$','s').replace('0','o').replace('1','i')
    scores={}
    for label,terms in ANIMAL_ARCHETYPES.items():
        score=0
        for t in terms:
            if t in low:
                score += 2 if len(t) > 3 else 1
        scores[label]=score
    # inferred archetypes from existing GTA/FiveM language
    if any(x in low for x in ['mafia','suits','crew','family','chapter','team']): scores['lion_pack_pressure'] += 2
    if any(x in low for x in ['sniper','trickshot','shot','hit']): scores['hawk_strike'] += 2
    if any(x in low for x in ['funny','stupid','dumb','fail','panic']): scores['cuckoo_deception'] += 1; scores['duck_waddle_escape'] += 1
    if any(x in low for x in ['hell','reaper','black','dark']): scores['raven_aftermath'] += 2
    primary=max(scores.items(), key=lambda kv: kv[1])[0] if scores else 'unclassified'
    if scores.get(primary,0)==0: primary='unclassified'
    return scores, primary

def predation_group_from_archetype(primary):
    if primary in ('lone_wolf','tiger_stalk','hawk_strike','eagle_overwatch','crocodile_chokepoint','fox_deception'):
        return 'predator_strategy'
    if primary in ('sheep_flock_panic','goat_stubborn_luck','duck_waddle_escape','swan_grace_escape'):
        return 'prey_or_escape_behaviour'
    if primary in ('raven_aftermath','cuckoo_deception'):
        return 'comedy_or_aftermath_signal'
    if primary == 'lion_pack_pressure':
        return 'pack_pressure'
    return 'unclassified'

def asset_record(p, kind, probe_media=True):
    st=p.stat(); pr={}
    if kind in ('video','audio'): pr=ffprobe(p, enabled=probe_media)
    score,hits=score_terms(p.name)
    arch,primary=archetype_scores(p.name+' '+str(p.parent))
    rec={'asset_id':sid(p),'path':str(p),'name':p.name,'slug':safe_slug(p.stem),'ext':p.suffix.lower(),'kind':kind,'size_bytes':st.st_size,'mtime_utc':dt.datetime.fromtimestamp(st.st_mtime,dt.UTC).isoformat().replace('+00:00','Z'),'term_score':score,'term_hits':'|'.join(hits),'tone_scores':tone_scores(p.name),'archetype_scores':arch,'primary_archetype':primary,'predation_model_group':predation_group_from_archetype(primary)}
    rec.update(pr)
    return rec

def scan_all(limit=0, probe_media=True, progress_every=500, deep=False):
    all_files=[]; music=[]; videos=[]; images=[]; data=[]; stills=[]
    # Skip folders that explode the file count or repeat processor packages. Deep mode can include more later.
    skip={'.git','node_modules','__pycache__','.cache','.venv','venv','myfirstproject','site-packages','dist-info','__MACOSX'}
    skip_name_prefix=('suits_processor_v16_2_1_cinematic_song_story_package (2)',)
    count=0
    print('[scan] recursive scan started', flush=True)
    for p in BASE.rglob('*'):
        if not p.is_file(): continue
        parts=set(p.parts)
        if parts & skip: continue
        if any(str(part).startswith(skip_name_prefix) for part in p.parts): continue
        ext=p.suffix.lower(); kind=None
        is_under_site_video = str(p).startswith(str(SITE/'videos'))
        if ext in MEDIA_EXT:
            kind='video'; rec=asset_record(p,kind,probe_media=probe_media); videos.append(rec); all_files.append(rec)
        elif ext in AUDIO_EXT and not ext in MEDIA_EXT:
            kind='audio'; rec=asset_record(p,kind,probe_media=probe_media); music.append(rec); all_files.append(rec)
        elif ext in IMAGE_EXT:
            kind='image'; rec=asset_record(p,kind,probe_media=probe_media); images.append(rec); all_files.append(rec)
            if 'still' in p.name.lower() or 'stills' in str(p).lower(): stills.append(rec)
        elif ext in DATA_EXT:
            kind='data';
            try:
                txt=p.read_text(errors='ignore')[:50000]
            except Exception: txt=''
            score,hits=score_terms(p.name+' '+txt[:2000])
            arch,primary=archetype_scores(p.name+' '+txt[:4000])
            st=p.stat(); rec={'asset_id':sid(p),'path':str(p),'name':p.name,'slug':safe_slug(p.stem),'ext':ext,'kind':'data','size_bytes':st.st_size,'mtime_utc':dt.datetime.fromtimestamp(st.st_mtime,dt.UTC).isoformat().replace('+00:00','Z'),'term_score':score,'term_hits':'|'.join(hits),'tone_scores':tone_scores(p.name+' '+txt[:1000]),'archetype_scores':arch,'primary_archetype':primary,'predation_model_group':predation_group_from_archetype(primary),'text_chars':len(txt)}
            data.append(rec); all_files.append(rec)
        count += 1
        if progress_every and len(all_files) and len(all_files) % progress_every == 0:
            print(f'[scan] assets={len(all_files)} music={len(music)} videos={len(videos)} images={len(images)} data={len(data)} last={p.name[:70]}', flush=True)
        if limit and len(all_files)>=limit:
            print(f'[scan] limit reached: {limit}', flush=True)
            break
    print(f'[scan] complete assets={len(all_files)} music={len(music)} videos={len(videos)} images={len(images)} data={len(data)} stills={len(stills)}', flush=True)
    return all_files,music,videos,images,data,stills

def load_previous():
    prev=[]
    for name in ['song_story_plan.json','song_video_match_plan.json','music_profile.json','video_profile.json','webui_song_story_index.json']:
        for p in BASE.rglob(name):
            try:
                j=json.loads(p.read_text(errors='ignore'))
                prev.append({'path':str(p),'name':name,'items': len(j) if isinstance(j,list) else len(j.keys()) if isinstance(j,dict) else 1})
            except Exception: pass
    return prev

def choose_story(ts):
    if ts.get('comedy_blunder'): return 'comedy_blunder'
    if ts.get('graphic_intensity_review'): return 'graphic_intensity_review'
    if ts.get('shot_fired'): return 'shot_fired'
    if ts.get('hit_confirmed'): return 'hit_confirmed'
    if ts.get('dark_aftermath'): return 'dark_aftermath'
    if ts.get('predation_pressure'): return 'predation_pressure'
    return 'hero_intro'

def build_matches(music,videos, max_per_song=18):
    matches=[]
    vids=sorted(videos, key=lambda r:(r.get('term_score',0)+sum(r.get('tone_scores',{}).values())*5), reverse=True)
    for s in music:
        scored=[]; sts=s.get('tone_scores',{})
        for v in vids:
            vts=v.get('tone_scores',{})
            common=sum(min(sts.get(k,0),vts.get(k,0)) for k in set(sts)|set(vts))
            sarch=s.get('archetype_scores',{}) or {}; varch=v.get('archetype_scores',{}) or {}
            arch_common=sum(min(sarch.get(k,0),varch.get(k,0)) for k in set(sarch)|set(varch))
            dur_s=s.get('duration_s') or 0; dur_v=v.get('duration_s') or 0
            dur_fit=1.0 if dur_s and dur_v and dur_v>=min(dur_s,29) else 0.3
            score=s.get('term_score',0)*0.4+v.get('term_score',0)*1.4+common*8+arch_common*2.5+dur_fit*6
            story=choose_story(vts if sum(vts.values())>=sum(sts.values()) else sts)
            if v.get('primary_archetype') in ['lone_wolf','tiger_stalk','eagle_overwatch','hawk_strike','raven_aftermath','cuckoo_deception','sheep_flock_panic','goat_stubborn_luck','duck_waddle_escape','swan_grace_escape']:
                story=v.get('primary_archetype')
            scored.append((score,story,v))
        for rank,(score,story,v) in enumerate(scored[:max_per_song],1):
            matches.append({'song_id':s['asset_id'],'song_name':s['name'],'song_path':s['path'],'song_duration_s':s.get('duration_s',0),'song_archetype':s.get('primary_archetype','unclassified'),'video_id':v['asset_id'],'video_name':v['name'],'video_path':v['path'],'video_duration_s':v.get('duration_s',0),'video_archetype':v.get('primary_archetype','unclassified'),'predation_model_group':v.get('predation_model_group','unclassified'),'story_rank':rank,'story_variant':story,'match_score':round(score,3),'suggested_use':'full_song_story' if rank==1 else '29s_trailer' if rank<=3 else 'alternate_story_variant','render_slug':safe_slug(s['slug']+'__'+story+'__'+str(rank).zfill(2))})
    return matches

def build_event_chains(matches, max_chains=300):
    chains=[]
    for m in matches[:max_chains]:
        story=m['story_variant']
        steps=['establish_identity','route_pressure','action_change','impact_or_reversal','aftermath']
        if story=='comedy_blunder': steps=['setup','overconfidence','bad_turn','dumb_luck_or_fail','laugh_release']
        if story=='shot_fired': steps=['target_acquired','aim_vector','shot_fired_candidate','reaction','aftershock']
        if story=='hit_confirmed': steps=['pressure','impact_candidate','hit_confirmed','prey_state_change','result']
        if story=='lone_wolf': steps=['isolated_actor','silent_route','single_vector_pressure','decisive_move','fade_out']
        if story=='tiger_stalk': steps=['territory_marked','low_motion_wait','stalk','burst','aftermath']
        if story=='eagle_overwatch': steps=['high_ground','scan','target_selection','drop_to_action','clean_exit']
        if story=='hawk_strike': steps=['fast_lock','sharp_angle','strike','impact','recovery']
        if story=='raven_aftermath': steps=['dark_signal','wreckage','silence','memory','myth']
        if story=='cuckoo_deception': steps=['false_pattern','misread','switch','blunder','comic_release']
        if story=='sheep_flock_panic': steps=['group_pressure','scatter','route_loss','panic_turn','capture_or_escape']
        if story=='goat_stubborn_luck': steps=['stubborn_hold','bad_position','el_dollo_luck','escape_gap','victory_laugh']
        if story=='duck_waddle_escape': steps=['sitting_duck','slow_turn','absurd_gap','lucky_escape','comic_sting']
        if story=='swan_grace_escape': steps=['calm_entry','smooth_path','pressure_near_miss','graceful_exit','clean_title_card']
        chains.append({'chain_id':sid(m['render_slug']),'render_slug':m['render_slug'],'song_name':m['song_name'],'video_name':m['video_name'],'story_variant':story,'song_archetype':m.get('song_archetype','unclassified'),'video_archetype':m.get('video_archetype','unclassified'),'predation_model_group':m.get('predation_model_group','unclassified'),'match_score':m['match_score'],'objective':'full_audio_dramatic_movie' if m['story_rank']==1 else 'trailer_or_alt_scene','steps':steps,'ai_comment':f"{story}: {m['song_name']} drives {m['video_name']} through {', '.join(steps)}. Animal model: {m.get('video_archetype','unclassified')} / {m.get('predation_model_group','unclassified')}."})
    return chains

def select_12_movies(matches):
    chosen=[]; used_s=set(); used_v=set()
    for m in sorted(matches, key=lambda x:x['match_score'], reverse=True):
        if m['song_id'] in used_s or m['video_id'] in used_v: continue
        if len(chosen)>=12: break
        chosen.append(m); used_s.add(m['song_id']); used_v.add(m['video_id'])
    return chosen

def write_json(p,obj): p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(obj,indent=2),encoding='utf-8')
def write_csv(p,rows):
    p.parent.mkdir(parents=True, exist_ok=True)
    if not rows: p.write_text(''); return
    keys=[]
    for r in rows:
        for k in r.keys():
            if k not in keys and not isinstance(r[k],(dict,list)): keys.append(k)
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k:r.get(k,'') for k in keys})

def make_render_scripts(chosen):
    OUT.mkdir(parents=True,exist_ok=True)
    lines=['#!/usr/bin/env bash','set -euo pipefail',f'mkdir -p "{OUT}/renders_12_full_movies"']
    pub=['#!/usr/bin/env bash','set -euo pipefail',f'mkdir -p "{VIDEO_SITE}"']
    for i,m in enumerate(chosen,1):
        out=OUT/'renders_12_full_movies'/(f"movie_{i:02d}_{m['render_slug']}_full.mp4")
        dur=m.get('song_duration_s') or 180
        lines += [f'echo "[o][o] rendering movie {i:02d}: {m["render_slug"]}"',
                  'ffmpeg -y -hide_banner -loglevel warning \\\n  -stream_loop -1 -i '+json.dumps(m['video_path'])+' \\\n  -i '+json.dumps(m['song_path'])+f' \\\n  -t {float(dur):.3f} \\\n  -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1" \\\n  -map 0:v:0 -map 1:a:0 -shortest -c:v libx264 -preset veryfast -crf 23 -c:a aac -b:a 192k '+json.dumps(str(out))]
        pub.append(f'cp -v {json.dumps(str(out))} {json.dumps(str(VIDEO_SITE/(out.name)))}')
    (OUT/'render_12_full_movies.sh').write_text('\n'.join(lines)+'\n')
    (OUT/'publish_movies_to_site.sh').write_text('\n'.join(pub)+'\n')
    os.chmod(OUT/'render_12_full_movies.sh',0o755); os.chmod(OUT/'publish_movies_to_site.sh',0o755)

def build_graph(music,videos,matches,chains):
    nodes=[]; edges=[]
    def add_node(id,label,typ,extra=None):
        nodes.append({'id':id,'label':label,'type':typ,**(extra or {})})
    for s in music[:300]: add_node('song_'+s['asset_id'],s['name'],'Song',{'score':s.get('term_score',0)})
    for v in videos[:300]: add_node('video_'+v['asset_id'],v['name'],'Video',{'score':v.get('term_score',0)})
    for c in chains[:300]: add_node('chain_'+c['chain_id'],c['story_variant'],'EventChain',{'score':c['match_score']})
    for m in matches[:500]:
        edges.append({'source':'song_'+m['song_id'],'target':'video_'+m['video_id'],'type':'MATCHES_AS_'+m['story_variant'],'weight':m['match_score']})
    for c in chains[:300]: edges.append({'source':'chain_'+c['chain_id'],'target':'video_'+sid(c['video_name']),'type':'USES_VIDEO','weight':c['match_score']})
    return nodes,edges

def build_sql(matches,chains,music,videos):
    db=OUT/'sql'/'suits_v16_4_1_ml_movie_factory.sqlite3'; db.parent.mkdir(parents=True,exist_ok=True)
    if db.exists(): db.unlink()
    conn=sqlite3.connect(db)
    conn.execute('CREATE TABLE music(asset_id TEXT PRIMARY KEY,name TEXT,path TEXT,duration_s REAL,term_score REAL,term_hits TEXT)')
    conn.execute('CREATE TABLE video(asset_id TEXT PRIMARY KEY,name TEXT,path TEXT,duration_s REAL,term_score REAL,term_hits TEXT)')
    conn.execute('CREATE TABLE match_plan(song_id TEXT,video_id TEXT,story_variant TEXT,match_score REAL,suggested_use TEXT,render_slug TEXT,song_archetype TEXT,video_archetype TEXT,predation_model_group TEXT)')
    conn.execute('CREATE TABLE event_chain(chain_id TEXT PRIMARY KEY,render_slug TEXT,story_variant TEXT,match_score REAL,objective TEXT,ai_comment TEXT,song_archetype TEXT,video_archetype TEXT,predation_model_group TEXT)')
    for s in music: conn.execute('INSERT OR REPLACE INTO music VALUES(?,?,?,?,?,?)',(s['asset_id'],s['name'],s['path'],s.get('duration_s',0),s.get('term_score',0),s.get('term_hits','')))
    for v in videos: conn.execute('INSERT OR REPLACE INTO video VALUES(?,?,?,?,?,?)',(v['asset_id'],v['name'],v['path'],v.get('duration_s',0),v.get('term_score',0),v.get('term_hits','')))
    for m in matches: conn.execute('INSERT INTO match_plan VALUES(?,?,?,?,?,?,?,?,?)',(m['song_id'],m['video_id'],m['story_variant'],m['match_score'],m['suggested_use'],m['render_slug'],m.get('song_archetype',''),m.get('video_archetype',''),m.get('predation_model_group','')))
    for c in chains: conn.execute('INSERT OR REPLACE INTO event_chain VALUES(?,?,?,?,?,?,?,?,?)',(c['chain_id'],c['render_slug'],c['story_variant'],c['match_score'],c['objective'],c['ai_comment'],c.get('song_archetype',''),c.get('video_archetype',''),c.get('predation_model_group','')))
    conn.commit(); conn.close()

def build_web_data(music,videos,images,data,stills,matches,chains,prev,chosen,nodes,edges):
    DATA_DIR.mkdir(parents=True,exist_ok=True)
    summary={'version':VERSION,'created_utc':now(),'songs':len(music),'videos':len(videos),'images':len(images),'data_files':len(data),'stills':len(stills),'matches':len(matches),'event_chains':len(chains),'planned_movies':len(chosen),'previous_outputs':len(prev)}
    for name,obj in [('summary.json',summary),('music_profile_index.json',music),('video_profile_index.json',videos),('stills_index.json',stills),('song_action_recommendations.json',matches[:1500]),('action_event_chains.json',chains),('previous_output_learning.json',prev),('movie_factory_12.json',chosen),('graph_nodes.json',nodes),('graph_edges.json',edges),('predation_comedy_taxonomy.json',{'story_variants':STORY_VARIANTS,'animal_archetypes':ANIMAL_ARCHETYPES})]:
        write_json(DATA_DIR/name,obj); write_json(OUT/name,obj)
    write_csv(OUT/'sql'/'song_action_recommendations.csv',matches)
    write_csv(OUT/'sql'/'event_chains.csv',chains)
    write_csv(OUT/'sql'/'movie_factory_12.csv',chosen)
    # neo4j
    write_csv(OUT/'neo4j'/'neo4j_nodes.csv',nodes)
    write_csv(OUT/'neo4j'/'neo4j_edges.csv',edges)
    cy=['// $uits v16.4.1 Neo4j import','LOAD CSV WITH HEADERS FROM "file:///neo4j_nodes.csv" AS row','MERGE (n:SuitNode {id: row.id}) SET n.label=row.label, n.type=row.type;','LOAD CSV WITH HEADERS FROM "file:///neo4j_edges.csv" AS row','MATCH (a:SuitNode {id: row.source}),(b:SuitNode {id: row.target}) MERGE (a)-[r:SUITS_EDGE {type: row.type}]->(b) SET r.weight=toFloat(row.weight);']
    (OUT/'neo4j'/'suits_v16_4_1_import.cypher').parent.mkdir(parents=True,exist_ok=True)
    (OUT/'neo4j'/'suits_v16_4_1_import.cypher').write_text('\n'.join(cy)+'\n')

def report(summary,chosen):
    rows=''.join(f"<tr><td>{i+1}</td><td>{html.escape(m['story_variant'])}</td><td>{html.escape(m['song_name'])}</td><td>{html.escape(m['video_name'])}</td><td>{m['match_score']}</td></tr>" for i,m in enumerate(chosen))
    txt=f"""<!doctype html><html><head><meta charset='utf-8'><title>$uits v16.4.1 ML Movie Factory</title><style>body{{background:#07111f;color:#e8f4ff;font-family:Arial}}.wrap{{max-width:1200px;margin:30px auto}}.card{{background:#0d1b2f;border:1px solid #284766;border-radius:16px;padding:18px;margin:14px 0}}th,td{{border-bottom:1px solid #20364f;padding:8px;text-align:left}}table{{width:100%;border-collapse:collapse}}a{{color:#9dd7ff}}</style></head><body><div class='wrap'><h1>[o][o] $uits v16.4.1 ML Movie Factory</h1><div class='card'>Songs {summary['songs']} | Videos {summary['videos']} | Matches {summary['matches']} | Chains {summary['event_chains']} | Planned movies {summary['planned_movies']}</div><div class='card'><h2>12 planned full-audio dramatic movies</h2><table><tr><th>#</th><th>Story</th><th>Song</th><th>Video</th><th>Score</th></tr>{rows}</table></div></div></body></html>"""
    (OUT/'report.html').write_text(txt,encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(description='$uits Processor v16.4.1 ML Movie Factory')
    ap.add_argument('--ml-update',action='store_true')
    ap.add_argument('--build-webui',action='store_true')
    ap.add_argument('--build-graphs',action='store_true')
    ap.add_argument('--build-charts',action='store_true')
    ap.add_argument('--plan-12-movies',action='store_true')
    ap.add_argument('--limit-files',type=int,default=0)
    ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--no-probe-media',action='store_true', help='Skip ffprobe for faster indexing')
    ap.add_argument('--smoke',action='store_true', help='Fast smoke test: limit 750 files and skip ffprobe')
    ap.add_argument('--progress-every',type=int,default=250)
    ap.add_argument('--deep',action='store_true', help='Reserved deep mode')
    args=ap.parse_args()
    if args.smoke:
        args.limit_files = args.limit_files or 750
        args.no_probe_media = True
    print('[o][o] $uits Processor',VERSION, flush=True)
    print('SCRIPT=suits_processor_v16_4_1_ml_movie_factory.py', flush=True)
    print('SCHEMA='+SCHEMA, flush=True)
    print('ROOT='+str(BASE), flush=True)
    print('OUT='+str(OUT), flush=True)
    print(f'MODE smoke={args.smoke} no_probe_media={args.no_probe_media} limit_files={args.limit_files}', flush=True)
    OUT.mkdir(parents=True,exist_ok=True); DATA_DIR.mkdir(parents=True,exist_ok=True)
    all_files,music,videos,images,data,stills=scan_all(args.limit_files, probe_media=not args.no_probe_media, progress_every=args.progress_every, deep=args.deep)
    print('[stage] loading previous processor outputs', flush=True)
    # music includes video music files too: add youtube_music/music_mp4 videos with music-ish folder to music candidates
    musicish=[v for v in videos if any(x in v['path'] for x in ['/music_mp4/','/youtube_music/'])]
    music_all=music+musicish
    prev=load_previous()
    print(f'[stage] previous output files found: {len(prev)}', flush=True)
    print('[stage] building song/action matches', flush=True)
    matches=build_matches(music_all, videos, 18)
    print(f'[stage] matches built: {len(matches)}', flush=True)
    print('[stage] building event chains', flush=True)
    chains=build_event_chains(matches,600)
    chosen=select_12_movies(matches) if args.plan_12_movies or args.ml_update else []
    print('[stage] selecting 12 movie plans', flush=True)
    nodes,edges=build_graph(music_all,videos,matches,chains)
    print(f'[stage] graph nodes={len(nodes)} edges={len(edges)}', flush=True)
    summary={'songs':len(music_all),'videos':len(videos),'matches':len(matches),'event_chains':len(chains),'planned_movies':len(chosen)}
    print('[stage] writing WebUI data / JSON / CSV / Neo4j', flush=True)
    build_web_data(music_all,videos,images,data,stills,matches,chains,prev,chosen,nodes,edges)
    print('[stage] writing SQLite database', flush=True)
    build_sql(matches,chains,music_all,videos)
    if chosen: make_render_scripts(chosen)
    report({'songs':len(music_all),'videos':len(videos),'matches':len(matches),'event_chains':len(chains),'planned_movies':len(chosen)},chosen)
    print('[o][o] Done', flush=True)
    print('Report:',OUT/'report.html')
    print('WebUI:',SITE/'suits_v16_4_1_dashboard.php')
    if chosen:
        print('Render script:',OUT/'render_12_full_movies.sh')
        print('Publish script:',OUT/'publish_movies_to_site.sh')
if __name__=='__main__': main()
