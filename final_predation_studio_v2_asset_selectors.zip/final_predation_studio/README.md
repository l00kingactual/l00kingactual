# 🎬 Final Grade GTA/FiveM Predation Studio

Offline-first WebUI for **fictional GTA/FiveM gameplay-media analytics**.

It is designed for cinematic/machinima/gameplay analysis, not real-world tactical guidance.

## 🌈 Simple explanation

This tool is a local media workbench:

- 📁 **Finds videos** in a folder.
- 🎞️ **Lets you build playlists** for analysis.
- 👁️ **Looks at the video first**, because montage audio is often music.
- 🧠 **Scores dramatic gameplay moments** such as predation, team pressure, graphic/spectacle intensity, humour and chain value.
- 🏷️ **Adds CoRT60-style comments** such as `#AGO`, `#CAF`, `#FIP`, `#PMI`.
- 🌐 **Builds a curated webpage** with fewer, higher-quality assets.
- 🗄️ **Exports data** as JSON, SQLite SQL, Postgres SQL and Neo4j Cypher.

## ✨ What it does

- Scans folders for videos, audio and label files.
- Lets you create playlists and add/remove files for analytical processing.
- Runs a video-first tensor analysis because GTA montages often have music over the audio.
- Supports ground-truth strengthening from:
  - manual labels CSV/JSON
  - FiveM/server logs CSV/JSON
  - optional killfeed OCR if `pytesseract` and OS Tesseract are installed
- Always runs: if OpenCV, ffmpeg or OCR are unavailable, it falls back to metadata/manifest output rather than failing.

## 🌐 Curated webpage asset selectors

The WebUI now lets you choose the number of each media asset type:

- 🎬 dramatic clips
- 😂 funny clips
- 🦁 team-play clips
- 🩸 spectacular/graphic-intensity clips
- 🖼️ still frames
- 🔁 APNG loops

Default quality-over-quantity settings:

- Top 6 dramatic clips
- Top 3 funny clips
- Top 3 team-play clips
- Top 3 spectacular/graphic-intensity clips
- Top 3 still frames
- Top 3 APNG loops

## 🎞️ MP4 production controls

The WebUI now includes:

- clip duration selector from 1 second to **300 seconds / 5 minutes**
- clean MP4 export without subtitles
- subtitled MP4 export with burned-in CoRT60 kill/predation comments
- optional mute for exported clips
- external `.srt` subtitle files for serious and funny comment tracks

Typical outputs:

- `*_clean.mp4`
- `*_subtitled.mp4`
- `cort60_serious_subtitles.srt`
- `cort60_funny_subtitles.srt`

## 📦 Main exports

- `final_grade_predation_report.html`
- `predation_manifest.json`
- `cort60_serious_subtitles.srt`
- `cort60_funny_subtitles.srt`
- `predation_3nf_acid_sqlite.sql`
- `predation_3nf_acid_postgres.sql`
- `predation_neo4j.cypher`

## 🐧 Linux run

```bash
cd final_predation_studio
chmod +x run_linux.sh
./run_linux.sh
```

Open:

```text
http://127.0.0.1:8790
```

## 🪟 Windows run

Double-click:

```text
run_windows.bat
```

## 🧾 Manual label format

CSV columns accepted:

```text
timestamp,start,end,event_type,confidence,killer,victim,weapon,note
```

The same fields also work in JSON as a list of objects.

## 🖥️ Server log format

CSV columns accepted:

```text
timestamp,event_type,confidence,killer,victim,weapon,note
```

Use `server_logs_example.csv` as a guide.

## ✅ Ground-truth levels

- `video_inferred` — visual proxy only
- `ocr_confirmed` — optional OCR evidence matched by time
- `manual_confirmed` — manual label matched by time/window
- `server_confirmed` — FiveM/server log matched by time/window

## 🧩 Design notes

```text
video tensor -> smoothing/norming/scaling -> predation senses -> CoRT60 comments
-> quality gate -> curated media assets -> clean/subtitled MP4 -> SQL/Neo4j/HTML exports
```

The webpage is deliberately curated. It does not dump every detected event by default.
The full ledger remains in JSON/SQL/Cypher for audit and future WebUI analysis.
