-- Final Grade Predation Studio — 3NF / ACID SQLite schema
-- Fictional GTA/FiveM gameplay-media analytics.
PRAGMA foreign_keys = ON;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS media_asset (
  media_id TEXT PRIMARY KEY,
  path TEXT NOT NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  suffix TEXT,
  duration_seconds REAL DEFAULT 0,
  width INTEGER DEFAULT 0,
  height INTEGER DEFAULT 0,
  fps REAL DEFAULT 0,
  has_audio INTEGER DEFAULT 0 CHECK(has_audio IN (0,1)),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS playlist (
  playlist_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS playlist_item (
  playlist_id TEXT NOT NULL REFERENCES playlist(playlist_id) ON DELETE CASCADE,
  media_id TEXT NOT NULL REFERENCES media_asset(media_id) ON DELETE CASCADE,
  ordinal INTEGER NOT NULL,
  PRIMARY KEY(playlist_id, media_id)
);
CREATE TABLE IF NOT EXISTS predation_event (
  event_id TEXT PRIMARY KEY,
  media_id TEXT NOT NULL REFERENCES media_asset(media_id) ON DELETE CASCADE,
  start_seconds REAL NOT NULL,
  end_seconds REAL NOT NULL,
  peak_seconds REAL NOT NULL,
  event_type TEXT NOT NULL,
  score REAL NOT NULL CHECK(score >= 0 AND score <= 1),
  confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  ground_truth_level TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ground_truth_evidence (
  truth_id TEXT PRIMARY KEY,
  event_id TEXT REFERENCES predation_event(event_id) ON DELETE SET NULL,
  source_kind TEXT NOT NULL,
  source_path TEXT NOT NULL,
  timestamp_seconds REAL NOT NULL,
  event_type TEXT NOT NULL,
  killer TEXT,
  victim TEXT,
  weapon TEXT,
  confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  note TEXT
);
CREATE TABLE IF NOT EXISTS event_metric (
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  metric_name TEXT NOT NULL,
  metric_value REAL NOT NULL,
  metric_group TEXT NOT NULL,
  PRIMARY KEY(event_id, metric_name, metric_group)
);
CREATE TABLE IF NOT EXISTS cort60_card (
  event_id TEXT PRIMARY KEY REFERENCES predation_event(event_id) ON DELETE CASCADE,
  ago TEXT,
  caf_json TEXT,
  fip TEXT,
  apc_json TEXT,
  cs TEXT,
  opv_json TEXT,
  pmi_json TEXT,
  caption_serious TEXT,
  caption_funny TEXT
);
CREATE TABLE IF NOT EXISTS curated_asset (
  curated_id INTEGER PRIMARY KEY AUTOINCREMENT,
  curated_set TEXT NOT NULL,
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  rank INTEGER NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(curated_set, rank)
);
COMMIT;
