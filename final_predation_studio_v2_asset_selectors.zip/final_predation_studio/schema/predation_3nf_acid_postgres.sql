-- Final Grade Predation Studio — 3NF / ACID PostgreSQL schema
-- Fictional GTA/FiveM gameplay-media analytics.
BEGIN;
CREATE TABLE IF NOT EXISTS media_asset (
  media_id TEXT PRIMARY KEY,
  path TEXT NOT NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  suffix TEXT,
  duration_seconds DOUBLE PRECISION DEFAULT 0,
  width INTEGER DEFAULT 0,
  height INTEGER DEFAULT 0,
  fps DOUBLE PRECISION DEFAULT 0,
  has_audio BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS playlist (
  playlist_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS playlist_item (
  playlist_id TEXT NOT NULL REFERENCES playlist(playlist_id) ON DELETE CASCADE,
  media_id TEXT NOT NULL REFERENCES media_asset(media_id) ON DELETE CASCADE,
  ordinal INTEGER NOT NULL,
  PRIMARY KEY(playlist_id, media_id)
);
CREATE TABLE IF NOT EXISTS predation_event (
  event_id TEXT PRIMARY KEY,
  media_id TEXT NOT NULL REFERENCES media_asset(media_id) ON DELETE CASCADE,
  start_seconds DOUBLE PRECISION NOT NULL,
  end_seconds DOUBLE PRECISION NOT NULL,
  peak_seconds DOUBLE PRECISION NOT NULL,
  event_type TEXT NOT NULL,
  score DOUBLE PRECISION NOT NULL CHECK(score >= 0 AND score <= 1),
  confidence DOUBLE PRECISION NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  ground_truth_level TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ground_truth_evidence (
  truth_id TEXT PRIMARY KEY,
  event_id TEXT REFERENCES predation_event(event_id) ON DELETE SET NULL,
  source_kind TEXT NOT NULL,
  source_path TEXT NOT NULL,
  timestamp_seconds DOUBLE PRECISION NOT NULL,
  event_type TEXT NOT NULL,
  killer TEXT,
  victim TEXT,
  weapon TEXT,
  confidence DOUBLE PRECISION NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
  note TEXT
);
CREATE TABLE IF NOT EXISTS event_metric (
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  metric_name TEXT NOT NULL,
  metric_value DOUBLE PRECISION NOT NULL,
  metric_group TEXT NOT NULL,
  PRIMARY KEY(event_id, metric_name, metric_group)
);
CREATE TABLE IF NOT EXISTS cort60_card (
  event_id TEXT PRIMARY KEY REFERENCES predation_event(event_id) ON DELETE CASCADE,
  ago TEXT,
  caf_json JSONB,
  fip TEXT,
  apc_json JSONB,
  cs TEXT,
  opv_json JSONB,
  pmi_json JSONB,
  caption_serious TEXT,
  caption_funny TEXT
);
CREATE TABLE IF NOT EXISTS curated_asset (
  curated_id BIGSERIAL PRIMARY KEY,
  curated_set TEXT NOT NULL,
  event_id TEXT NOT NULL REFERENCES predation_event(event_id) ON DELETE CASCADE,
  rank INTEGER NOT NULL,
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(curated_set, rank)
);
COMMIT;
