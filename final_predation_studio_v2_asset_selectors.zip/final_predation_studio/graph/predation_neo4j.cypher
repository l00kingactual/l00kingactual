// Final Grade Predation Studio — Neo4j schema/template
// Run generated predation_neo4j.cypher after processing for data import.
CREATE CONSTRAINT media_id IF NOT EXISTS FOR (m:MediaAsset) REQUIRE m.media_id IS UNIQUE;
CREATE CONSTRAINT event_id IF NOT EXISTS FOR (e:PredationEvent) REQUIRE e.event_id IS UNIQUE;
CREATE CONSTRAINT truth_id IF NOT EXISTS FOR (t:GroundTruthEvidence) REQUIRE t.truth_id IS UNIQUE;
CREATE CONSTRAINT curated_name IF NOT EXISTS FOR (c:CuratedSet) REQUIRE c.name IS UNIQUE;
CREATE CONSTRAINT cort_factor IF NOT EXISTS FOR (f:CoRTFactor) REQUIRE f.name IS UNIQUE;
// Relationship model:
// (:MediaAsset)-[:HAS_EVENT]->(:PredationEvent)
// (:PredationEvent)-[:HAS_FACTOR]->(:CoRTFactor)
// (:GroundTruthEvidence)-[:CONFIRMS|SUPPORTS]->(:PredationEvent)
// (:CuratedSet)-[:SELECTS {rank}]->(:PredationEvent)
