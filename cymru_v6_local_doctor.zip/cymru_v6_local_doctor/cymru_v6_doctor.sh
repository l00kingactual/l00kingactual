#!/usr/bin/env bash
# Cymru Hive OS V6 local doctor
# Run from the folder containing cymru_hive_os_v6_advanced_fixed_webui.zip
set -u

ZIP_NAME="${1:-cymru_hive_os_v6_advanced_fixed_webui.zip}"
PORT="${PORT:-8099}"
CLEAN_DIR="${HOME}/Documents/cymru_v6_clean_test"

echo "============================================================"
echo " Cymru Hive OS V6 local doctor"
echo "============================================================"
echo "ZIP:        ${ZIP_NAME}"
echo "PORT:       ${PORT}"
echo "CLEAN_DIR:  ${CLEAN_DIR}"
echo

fail(){ echo "❌ $*"; exit 1; }
warn(){ echo "⚠️  $*"; }
ok(){ echo "✅ $*"; }

echo "== 1. Basic tools =="
command -v python3 >/dev/null 2>&1 && ok "python3 found: $(python3 --version 2>&1)" || fail "python3 not found"
command -v unzip >/dev/null 2>&1 && ok "unzip found" || fail "unzip not found: sudo apt install unzip"
command -v ss >/dev/null 2>&1 && ok "ss found" || warn "ss not found; cannot check ports"
echo

echo "== 2. ZIP check =="
[[ -f "${ZIP_NAME}" ]] || fail "ZIP not found in current folder: $(pwd)/${ZIP_NAME}"
ls -lh "${ZIP_NAME}"
unzip -t "${ZIP_NAME}" >/tmp/cymru_v6_unzip_test.txt 2>&1
if [[ $? -eq 0 ]]; then ok "ZIP integrity test passed"; else cat /tmp/cymru_v6_unzip_test.txt; fail "ZIP integrity test failed"; fi
echo

echo "== 3. Clean extract =="
rm -rf "${CLEAN_DIR}"
mkdir -p "${CLEAN_DIR}"
unzip -q "${ZIP_NAME}" -d "${CLEAN_DIR}" || fail "unzip failed"
find "${CLEAN_DIR}" -maxdepth 3 -type f -name index.html -print
SITE_DIR="$(find "${CLEAN_DIR}" -maxdepth 3 -type f -name index.html -printf '%h\n' | head -n 1)"
[[ -n "${SITE_DIR}" ]] || fail "No index.html found after unzip"
ok "Site directory: ${SITE_DIR}"
echo

echo "== 4. Required file checks =="
required=(
  "index.html"
  "assets/css/styles.css"
  "assets/js/data.js"
  "assets/js/engine.js"
  "assets/js/charts.js"
  "assets/js/chart_lab.js"
  "assets/js/map.js"
  "assets/js/app.js"
  "assets/js/v6_math_engine.js"
  "assets/js/v6_math_panel.js"
  "diagnostics.html"
)
missing=0
for f in "${required[@]}"; do
  if [[ -f "${SITE_DIR}/${f}" ]]; then
    echo "✅ ${f}"
  else
    echo "❌ missing ${f}"
    missing=1
  fi
done
[[ "${missing}" -eq 0 ]] || fail "One or more required files are missing"
echo

echo "== 5. JavaScript syntax check, if node exists =="
if command -v node >/dev/null 2>&1; then
  js_fail=0
  while IFS= read -r js; do
    node --check "$js" >/tmp/cymru_v6_node_check.txt 2>&1
    if [[ $? -eq 0 ]]; then
      echo "✅ $(basename "$js")"
    else
      echo "❌ $(basename "$js")"
      cat /tmp/cymru_v6_node_check.txt
      js_fail=1
    fi
  done < <(find "${SITE_DIR}/assets/js" -maxdepth 1 -type f -name '*.js' | sort)
  [[ "${js_fail}" -eq 0 ]] || fail "JavaScript syntax failed"
else
  warn "node not installed; skipping JS syntax check"
fi
echo

echo "== 6. Port check =="
if command -v ss >/dev/null 2>&1; then
  if ss -ltnp | grep -q ":${PORT} "; then
    warn "Port ${PORT} is already in use."
    echo "Processes using it:"
    ss -ltnp | grep ":${PORT} " || true
    echo
    warn "Trying to continue may fail. Set another port, e.g.: PORT=8101 bash cymru_v6_doctor.sh"
  else
    ok "Port ${PORT} is free"
  fi
fi
echo

echo "== 7. Start local server =="
cd "${SITE_DIR}" || fail "cannot cd to site dir"
echo "Serving from: $(pwd)"
echo
echo "Open these URLs:"
echo "  http://127.0.0.1:${PORT}/"
echo "  http://127.0.0.1:${PORT}/diagnostics.html"
echo
echo "IMPORTANT:"
echo "  - Do NOT open index.html directly as file://"
echo "  - Keep this terminal open while using the WebUI"
echo "  - Press CTRL+C here to stop the server"
echo
python3 -m http.server "${PORT}" --bind 127.0.0.1
