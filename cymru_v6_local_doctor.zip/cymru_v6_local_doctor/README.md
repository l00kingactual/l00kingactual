# Cymru Hive OS V6 local doctor

Put `cymru_v6_doctor.sh` in the same folder as:

```text
cymru_hive_os_v6_advanced_fixed_webui.zip
```

Then run:

```bash
bash cymru_v6_doctor.sh
```

It will:

- test the ZIP
- clean-extract it to `~/Documents/cymru_v6_clean_test`
- check required files
- run JavaScript syntax checks if `node` is installed
- check the chosen port
- start a clean local server

Default URL:

```text
http://127.0.0.1:8099/
```

Diagnostics:

```text
http://127.0.0.1:8099/diagnostics.html
```

Use a different port:

```bash
PORT=8101 bash cymru_v6_doctor.sh
```
