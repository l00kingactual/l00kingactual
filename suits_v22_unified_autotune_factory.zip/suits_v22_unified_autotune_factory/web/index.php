<?php
$dataRoot = __DIR__ . '/../data/v22_autotune';
function load_json($name){ global $dataRoot; $p=$dataRoot.'/'.$name; if(!file_exists($p)) return []; return json_decode(file_get_contents($p), true) ?: []; }
$summary = load_json('summary.json');
$pred = load_json('predation_autotunes.json');
$comedy = load_json('comedy_autotunes.json');
$mouse = load_json('mouse_behaviour_autotunes.json');
$pl = load_json('playlists.json');
?><!doctype html><html><head><meta charset="utf-8"><title>$uits v22 Autotune Factory</title><link rel="stylesheet" href="style.css"></head><body>
<header><div class="brand">[o][o] $uit$ Mafia</div><h1>🎬 v22 Unified Autotune Factory</h1><p>Video/audio playlists, action ⇄ music auto-tunes, predation, comedy, and m0u$e behaviour buttons.</p></header>
<nav><a href="index.php">🏠 Dashboard</a><a href="playlists.php">🎵 Playlists</a><a href="autotunes.php">🦁 Auto-tunes</a><a href="actions.php">🎬 Action ⇄ Music</a></nav>
<section class="cards"><div class="card">📦 Assets<br><b><?=htmlspecialchars($summary['assets'] ?? '0')?></b></div><div class="card">🎥 Videos<br><b><?=htmlspecialchars($summary['videos'] ?? '0')?></b></div><div class="card">🎵 Audio<br><b><?=htmlspecialchars($summary['audio'] ?? '0')?></b></div><div class="card">🎬 Playlists<br><b><?=count($pl)?></b></div></section>
<h2>🦁 Predation Auto-tune Buttons</h2><div class="grid"><?php foreach($pred as $r): ?><button><?=htmlspecialchars(($r['button'] ?? $r['label']))?></button><?php endforeach; ?></div>
<h2>😂 Comedy Buttons</h2><div class="grid"><?php foreach($comedy as $r): ?><button><?=htmlspecialchars(($r['button'] ?? $r['label']))?></button><?php endforeach; ?></div>
<h2>🐭 m0u$e Behaviour Buttons</h2><div class="grid"><?php foreach($mouse as $r): ?><button><?=htmlspecialchars(($r['button'] ?? $r['label']))?></button><?php endforeach; ?></div>
</body></html>
