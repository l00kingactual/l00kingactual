#!/usr/bin/env python3
"""
$uits v22 Unified Autotune Factory

Scans a folder of historical $uits zip packages and the live suitsmafia media tree,
selects the best current toolchain, creates action/music/predation/comedy/mouse
playlist plans, and publishes a branded WebsiteUI data pack.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VIDEO_EXT = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"}
AUDIO_EXT = {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".apng"}
DATA_EXT = {".json", ".jsonl", ".csv", ".sqlite", ".sqlite3", ".db", ".cypher", ".sql", ".html", ".md", ".txt", ".xml", ".yaml", ".yml"}
SCRIPT_EXT = {".py", ".sh", ".php", ".js", ".lua", ".c", ".cpp", ".h", ".hpp", ".java", ".ts", ".css"}

ANIMAL_RULES = [
    ("lion_pack_pressure", "🦁", ["pack", "pressure", "crew", "gang", "group", "push", "war", "disciples", "family", "moretti"]),
    ("hawk_strike", "🦅", ["strike", "shot", "hit", "trickshot", "snipe", "quick", "fast", "kill", "blooded"]),
    ("raven_aftermath", "🐦‍⬛", ["aftermath", "dark", "raven", "body", "wreck", "ending", "fallout", "midnight"]),
    ("fox_deception", "🦊", ["bait", "decoy", "fake", "deception", "trap", "lure"]),
    ("spider_web_control", "🕷️", ["web", "control", "block", "chokepoint", "route", "corner", "ambush"]),
    ("shark_pursuit", "🦈", ["pursuit", "chase", "follow", "hunt", "runaway", "race"]),
    ("crocodile_chokepoint", "🐊", ["bridge", "door", "alley", "tunnel", "choke", "gate", "roadblock"]),
    ("owl_intelligence", "🦉", ["intel", "analysis", "graph", "db", "qbe", "cypher", "neo4j", "strategy", "metadata"]),
    ("eagle_overwatch", "🦅", ["overwatch", "map", "overview", "camera", "rooftop", "heli", "drone"]),
    ("comedy_anomaly", "😂", ["funny", "comedy", "panic", "fail", "blunder", "goofy", "waddle", "luck", "bad_timing"]),
    ("goat_stubborn_luck", "🐐", ["goat", "stubborn", "luck", "survive", "escape"]),
    ("duck_waddle_escape", "🦆", ["duck", "waddle", "clumsy", "escape", "slow"]),
    ("swan_grace_escape", "🦢", ["swan", "grace", "smooth", "clean", "elegant"]),
    ("lone_wolf", "🐺", ["solo", "lone", "wolf", "alone", "flank"]),
    ("tiger_stalk", "🐯", ["stalk", "stealth", "wait", "ambush", "silent"]),
    ("cuckoo_deception", "🐦", ["cuckoo", "identity", "wrong", "infiltrate", "false"]),
    ("sheep_flock_panic", "🐑", ["flock", "panic", "crowd", "scatter", "fear"]),
]

COMEDY_RULES = [
    ("bad_timing", "⏱️", ["bad_timing", "timing", "wrong time", "late", "early"]),
    ("panic_turn", "😱", ["panic", "turn", "swerve", "run"]),
    ("physics_blunder", "🌀", ["ragdoll", "crash", "flip", "fall", "physics"]),
    ("stubborn_luck", "🐐", ["luck", "stubborn", "survive", "goat"]),
    ("duck_escape", "🦆", ["duck", "waddle", "clumsy"]),
    ("ironic_song_fit", "🎭", ["irony", "funny", "comedy", "good_4_u", "runaway"]),
]

MOUSE_RULES = [
    ("m0use_peek", "🐭", ["peek", "corner", "peekaboo", "look"]),
    ("m0use_scurry", "🐁", ["scurry", "run", "escape", "dash", "panic"]),
    ("m0use_hide", "🕳️", ["hide", "cover", "alley", "garage", "shadow"]),
    ("m0use_cheese_bait", "🧀", ["bait", "lure", "decoy", "trap"]),
    ("m0use_nest_route", "🧭", ["route", "path", "nest", "home", "safe"]),
]

BEST_PACKAGES = [
    ("suits_processor_v16_6_1_python", "🐍", "main processor brain"),
    ("suits_v16_6_1_websiteui", "🌐", "website client UI"),
    ("suits_v18_render_factory", "🎬", "stills clips movies renderer"),
    ("suits_v19_atomic_graph_builder", "🧬", "3NF and Neo4j memory"),
    ("suits_v20_qbe_cypher_webui", "🔎", "QBE SQL Cypher UI"),
    ("suits_v21_ai_ml_site_organizer", "🧠", "AI ML website organiser"),
    ("suits_processor_v16_6_dramatic_movie_theatre_webui", "🎭", "all-in-one fallback"),
    ("suits_processor_v16_5_server_resource_builder", "🏗️", "server resource builder"),
    ("suits_processor_v16_4_1_ml_movie_factory_webui", "🎞️", "older movie factory"),
]

@dataclass
class Asset:
    asset_id: str
    path: str
    relpath: str
    name: str
    ext: str
    kind: str
    size: int
    mtime: float
    group: str
    animal_class: str
    animal_icon: str
    comedy_value: str
    comedy_icon: str
    mouse_value: str
    mouse_icon: str
    energy: float
    darkness: float
    speed: float
    ml_score: float


def stable_id(text: str, prefix: str = "a") -> str:
    return prefix + hashlib.sha1(text.encode("utf-8", "ignore")).hexdigest()[:16]


def classify_kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in VIDEO_EXT: return "video"
    if ext in AUDIO_EXT: return "audio"
    if ext in IMAGE_EXT: return "image"
    if ext in DATA_EXT: return "data"
    if ext in SCRIPT_EXT: return "script"
    if ext in {".zip", ".tgz", ".gz", ".tar", ".7z"}: return "archive"
    return "other"


def score_terms(text: str, rules: List[Tuple[str, str, List[str]]], default: Tuple[str, str]) -> Tuple[str, str, int]:
    low = text.lower().replace("-", "_").replace(" ", "_")
    best = (default[0], default[1], 0)
    for label, icon, terms in rules:
        s = sum(1 for t in terms if t.lower().replace(" ", "_") in low)
        if s > best[2]:
            best = (label, icon, s)
    return best


def numeric_profile(path: Path, kind: str, size: int, text: str) -> Tuple[float, float, float, float]:
    low = text.lower()
    energy_terms = ["shoot", "shot", "hit", "kill", "war", "fight", "strike", "fast", "runaway", "bells", "thrill"]
    dark_terms = ["dark", "aftermath", "raven", "midnight", "hell", "blood", "rejects"]
    speed_terms = ["fast", "race", "run", "chase", "train", "rush", "quick", "29s"]
    e = min(1.0, (sum(t in low for t in energy_terms) + (kind == "video") + (size > 50_000_000)) / 5.0)
    d = min(1.0, (sum(t in low for t in dark_terms) + ("aftermath" in low)) / 4.0)
    sp = min(1.0, (sum(t in low for t in speed_terms) + (kind == "audio")) / 4.0)
    ml = round((e * 0.40 + d * 0.20 + sp * 0.25 + (1 if kind in {"video", "audio", "data"} else 0) * 0.15), 4)
    return round(e, 4), round(d, 4), round(sp, 4), ml


def iter_files(root: Path, exclude_backups: bool = True, limit: int = 0) -> Iterable[Path]:
    n = 0
    for dirpath, dirnames, filenames in os.walk(root):
        if exclude_backups:
            dirnames[:] = [d for d in dirnames if d.lower() not in {"backup", "backups", ".git", "__pycache__", ".cache"}]
        for fn in filenames:
            p = Path(dirpath) / fn
            yield p
            n += 1
            if limit and n >= limit:
                return


def scan_assets(root: Path, limit: int = 0) -> List[Asset]:
    assets: List[Asset] = []
    for p in iter_files(root, True, limit):
        try:
            st = p.stat()
        except OSError:
            continue
        rel = str(p.relative_to(root)) if p.is_relative_to(root) else str(p)
        kind = classify_kind(p)
        group = rel.split(os.sep)[0] if os.sep in rel else "root"
        text = f"{rel} {p.name} {group}"
        animal, animal_icon, _ = score_terms(text, ANIMAL_RULES, ("owl_intelligence", "🦉"))
        comedy, comedy_icon, _ = score_terms(text, COMEDY_RULES, ("none", "▫️"))
        mouse, mouse_icon, _ = score_terms(text, MOUSE_RULES, ("none", "▫️"))
        energy, darkness, speed, ml_score = numeric_profile(p, kind, st.st_size, text)
        assets.append(Asset(
            asset_id=stable_id(rel), path=str(p), relpath=rel, name=p.name, ext=p.suffix.lower(), kind=kind,
            size=st.st_size, mtime=st.st_mtime, group=group, animal_class=animal, animal_icon=animal_icon,
            comedy_value=comedy, comedy_icon=comedy_icon, mouse_value=mouse, mouse_icon=mouse_icon,
            energy=energy, darkness=darkness, speed=speed, ml_score=ml_score
        ))
    return assets


def discover_packages(zip_dir: Path) -> List[Dict[str, Any]]:
    rows = []
    if not zip_dir.exists():
        return rows
    for z in sorted(zip_dir.glob("*.zip")):
        name = z.name
        lower = name.lower()
        role = "archive"
        icon = "📦"
        rank = 0
        for idx, (key, ic, desc) in enumerate(BEST_PACKAGES):
            if key in lower:
                role = desc
                icon = ic
                rank = 100 - idx
                break
        try:
            with zipfile.ZipFile(z) as zz:
                names = zz.namelist()
                has_readme = any(n.lower().endswith("readme.md") for n in names)
                py_count = sum(n.lower().endswith(".py") for n in names)
                sh_count = sum(n.lower().endswith(".sh") for n in names)
                php_count = sum(n.lower().endswith(".php") for n in names)
        except Exception:
            has_readme = False; py_count = sh_count = php_count = 0
        rows.append({"zip": str(z), "name": name, "icon": icon, "role": role, "rank": rank, "has_readme": has_readme, "py": py_count, "sh": sh_count, "php": php_count})
    rows.sort(key=lambda r: (-r["rank"], r["name"]))
    return rows


def write_csv(path: Path, rows: List[Dict[str, Any]], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def asset_rows(assets: List[Asset]) -> List[Dict[str, Any]]:
    return [asdict(a) for a in assets]


def top_assets(assets: List[Asset], kind: str, n: int = 200) -> List[Asset]:
    return sorted([a for a in assets if a.kind == kind], key=lambda a: (-a.ml_score, -a.energy, -a.size))[:n]


def build_autotunes(assets: List[Asset]) -> Dict[str, Any]:
    videos = top_assets(assets, "video", 300)
    audios = top_assets(assets, "audio", 120)
    images = top_assets(assets, "image", 100)
    data = top_assets(assets, "data", 100)

    predation = []
    for label, icon, terms in ANIMAL_RULES:
        clips = [a for a in videos if a.animal_class == label]
        if not clips:
            clips = sorted(videos, key=lambda a: (-(sum(t in a.relpath.lower() for t in terms)), -a.ml_score))[:12]
        predation.append({
            "id": label,
            "icon": icon,
            "label": label.replace("_", " ").title(),
            "clips": [a.relpath for a in clips[:24]],
            "score": round(sum(a.ml_score for a in clips[:24]) / max(1, len(clips[:24])), 4),
            "button": f"{icon} Auto-tune {label.replace('_',' ')}"
        })

    comedy = []
    for label, icon, terms in COMEDY_RULES:
        clips = [a for a in videos if a.comedy_value == label]
        if not clips:
            clips = sorted(videos, key=lambda a: (-(sum(t in a.relpath.lower() for t in terms)), -a.ml_score))[:12]
        comedy.append({"id": label, "icon": icon, "label": label.replace("_", " ").title(), "clips": [a.relpath for a in clips[:24]], "button": f"{icon} Comedy tune {label.replace('_',' ')}"})

    mouse = []
    for label, icon, terms in MOUSE_RULES:
        clips = [a for a in videos if a.mouse_value == label]
        if not clips:
            clips = sorted(videos, key=lambda a: (-(sum(t in a.relpath.lower() for t in terms)), -a.ml_score))[:12]
        mouse.append({"id": label, "icon": icon, "label": label.replace("_", " ").replace("m0use", "m0u$e").title(), "clips": [a.relpath for a in clips[:24]], "button": f"{icon} m0u$e {label.replace('_',' ')}"})

    action_to_music = []
    for v in videos[:150]:
        best = sorted(audios, key=lambda a: (abs(a.energy - v.energy) + abs(a.speed - v.speed) + abs(a.darkness - v.darkness), -a.ml_score))[:8]
        action_to_music.append({"video": v.relpath, "animal": v.animal_class, "icon": v.animal_icon, "matches": [{"audio": a.relpath, "fit": round(1 - min(1, abs(a.energy-v.energy)+abs(a.speed-v.speed)+abs(a.darkness-v.darkness))/3, 4)} for a in best]})

    music_to_action = []
    for a in audios[:80]:
        best = sorted(videos, key=lambda v: (abs(a.energy - v.energy) + abs(a.speed - v.speed) + abs(a.darkness - v.darkness), -v.ml_score))[:18]
        music_to_action.append({"audio": a.relpath, "energy": a.energy, "speed": a.speed, "darkness": a.darkness, "matches": [{"video": v.relpath, "animal": v.animal_class, "icon": v.animal_icon} for v in best]})

    playlists = []
    for p in predation[:12]:
        # choose audio by matching average profile
        clips = [a for a in videos if a.relpath in set(p["clips"])]
        avg_e = sum(a.energy for a in clips) / max(1, len(clips)); avg_s = sum(a.speed for a in clips) / max(1, len(clips)); avg_d = sum(a.darkness for a in clips) / max(1, len(clips))
        songs = sorted(audios, key=lambda a: (abs(a.energy-avg_e)+abs(a.speed-avg_s)+abs(a.darkness-avg_d), -a.ml_score))[:5]
        playlists.append({"id": f"playlist_{p['id']}", "icon": p["icon"], "title": p["label"], "song_candidates": [s.relpath for s in songs], "clips": p["clips"][:18], "render_mode": "29s_and_full_song"})

    return {
        "predation_autotunes": predation,
        "comedy_autotunes": comedy,
        "mouse_behaviour_autotunes": mouse,
        "action_to_music": action_to_music,
        "music_to_action": music_to_action,
        "playlists": playlists,
        "render_queue": [{"playlist_id": p["id"], "mode": p["render_mode"], "songs": p["song_candidates"], "clips": p["clips"]} for p in playlists]
    }


def write_sqlite(db: Path, assets: List[Asset], autotunes: Dict[str, Any]) -> None:
    db.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db)
    cur = con.cursor()
    cur.executescript("""
    DROP TABLE IF EXISTS asset;
    DROP TABLE IF EXISTS autotune;
    DROP TABLE IF EXISTS playlist;
    CREATE TABLE asset(asset_id TEXT PRIMARY KEY, path TEXT, relpath TEXT, name TEXT, ext TEXT, kind TEXT, size INTEGER, mtime REAL, grp TEXT, animal_class TEXT, animal_icon TEXT, comedy_value TEXT, comedy_icon TEXT, mouse_value TEXT, mouse_icon TEXT, energy REAL, darkness REAL, speed REAL, ml_score REAL);
    CREATE TABLE autotune(id TEXT, family TEXT, icon TEXT, label TEXT, payload TEXT);
    CREATE TABLE playlist(id TEXT PRIMARY KEY, icon TEXT, title TEXT, payload TEXT);
    """)
    cur.executemany("INSERT INTO asset VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [
        (a.asset_id, a.path, a.relpath, a.name, a.ext, a.kind, a.size, a.mtime, a.group, a.animal_class, a.animal_icon, a.comedy_value, a.comedy_icon, a.mouse_value, a.mouse_icon, a.energy, a.darkness, a.speed, a.ml_score) for a in assets
    ])
    for family in ["predation_autotunes", "comedy_autotunes", "mouse_behaviour_autotunes"]:
        for row in autotunes[family]:
            cur.execute("INSERT INTO autotune VALUES (?,?,?,?,?)", (row["id"], family, row.get("icon",""), row.get("label",""), json.dumps(row, ensure_ascii=False)))
    for row in autotunes["playlists"]:
        cur.execute("INSERT INTO playlist VALUES (?,?,?,?)", (row["id"], row.get("icon",""), row.get("title",""), json.dumps(row, ensure_ascii=False)))
    con.commit(); con.close()


def write_webui(site_dir: Path) -> None:
    web = site_dir / "v22_autotune"
    web.mkdir(parents=True, exist_ok=True)
    # only create if missing; install package has the full UI too
    index = web / "index.php"
    if index.exists():
        return
    index.write_text("""<?php
$dataRoot = __DIR__ . '/../data/v22_autotune';
function load_json($name){ global $dataRoot; $p=$dataRoot.'/'.$name; if(!file_exists($p)) return []; return json_decode(file_get_contents($p), true) ?: []; }
$summary = load_json('summary.json');
$pred = load_json('predation_autotunes.json');
$comedy = load_json('comedy_autotunes.json');
$mouse = load_json('mouse_behaviour_autotunes.json');
$pl = load_json('playlists.json');
?><!doctype html><html><head><meta charset="utf-8"><title>$uits v22 Autotune Factory</title><link rel="stylesheet" href="style.css"></head><body>
<header><div class="brand">[o][o] $uit$ Mafia</div><h1>🎬 v22 Unified Autotune Factory</h1><p>Action → Music, Music → Action, Predation, Comedy, and m0u$e behaviour playlists.</p></header>
<section class="cards"><div class="card">📦 Assets<br><b><?=htmlspecialchars($summary['assets'] ?? '0')?></b></div><div class="card">🎥 Videos<br><b><?=htmlspecialchars($summary['videos'] ?? '0')?></b></div><div class="card">🎵 Audio<br><b><?=htmlspecialchars($summary['audio'] ?? '0')?></b></div><div class="card">🎬 Playlists<br><b><?=count($pl)?></b></div></section>
<nav><a href="index.php">🏠 Dashboard</a><a href="playlists.php">🎵 Playlists</a><a href="autotunes.php">🦁 Auto-tunes</a><a href="actions.php">🎬 Action ⇄ Music</a></nav>
<h2>🦁 Predation Auto-tune Buttons</h2><div class="grid"><?php foreach($pred as $r): ?><button><?=htmlspecialchars(($r['button'] ?? $r['label']))?></button><?php endforeach; ?></div>
<h2>😂 Comedy Buttons</h2><div class="grid"><?php foreach($comedy as $r): ?><button><?=htmlspecialchars(($r['button'] ?? $r['label']))?></button><?php endforeach; ?></div>
<h2>🐭 m0u$e Behaviour Buttons</h2><div class="grid"><?php foreach($mouse as $r): ?><button><?=htmlspecialchars(($r['button'] ?? $r['label']))?></button><?php endforeach; ?></div>
</body></html>
""", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.environ.get("SUITS_ROOT", "/home/andy/Documents/suitsmafia"))
    ap.add_argument("--zip-dir", default=os.environ.get("SUITS_ZIP_DIR", str(Path.home() / "Downloads")))
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--publish-webui", action="store_true")
    ap.add_argument("--build-playlists", action="store_true")
    ap.add_argument("--build-autotunes", action="store_true")
    args = ap.parse_args()

    root = Path(args.root).expanduser().resolve()
    zip_dir = Path(args.zip_dir).expanduser().resolve()
    out = root / "outputs" / "suits_v22_unified_autotune_factory"
    site = root / "susitsmafia_website"
    data_site = site / "data" / "v22_autotune"
    out.mkdir(parents=True, exist_ok=True)
    data_site.mkdir(parents=True, exist_ok=True)

    packages = discover_packages(zip_dir)
    assets = scan_assets(root, args.limit)
    autotunes = build_autotunes(assets)

    rows = asset_rows(assets)
    fields = list(rows[0].keys()) if rows else ["asset_id","path","relpath","name","ext","kind","size","mtime","group","animal_class","animal_icon","comedy_value","comedy_icon","mouse_value","mouse_icon","energy","darkness","speed","ml_score"]
    write_csv(out / "media_assets.csv", [r for r in rows if r.get("kind") != "audio"], fields)
    write_csv(out / "music_assets.csv", [r for r in rows if r.get("kind") == "audio"], fields)
    write_csv(out / "action_events.csv", rows, fields)

    for name in ["predation_autotunes", "comedy_autotunes", "mouse_behaviour_autotunes", "action_to_music", "music_to_action", "playlists", "render_queue"]:
        (out / f"{name}.json").write_text(json.dumps(autotunes[name], indent=2, ensure_ascii=False), encoding="utf-8")

    (out / "discovered_packages.json").write_text(json.dumps(packages, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "selected_best_stack.json").write_text(json.dumps(packages[:8], indent=2, ensure_ascii=False), encoding="utf-8")
    write_sqlite(out / "suits_v22_unified_autotune.sqlite3", assets, autotunes)

    counts = {"assets": len(assets), "videos": sum(a.kind=="video" for a in assets), "audio": sum(a.kind=="audio" for a in assets), "images": sum(a.kind=="image" for a in assets), "data": sum(a.kind=="data" for a in assets), "packages": len(packages), "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "root": str(root), "out": str(out)}
    (out / "summary.json").write_text(json.dumps(counts, indent=2, ensure_ascii=False), encoding="utf-8")

    report = f"""<!doctype html><html><head><meta charset='utf-8'><title>$uits v22 Report</title><style>body{{font-family:system-ui;background:#07111f;color:#e5eefc;padding:24px}}.card{{background:#10233f;padding:16px;border-radius:14px;margin:10px;display:inline-block}}code,pre{{background:#071827;padding:12px;border-radius:10px;display:block}}</style></head><body><h1>[o][o] $uits v22 Unified Autotune Factory</h1><div class='card'>📦 Assets<br><b>{counts['assets']}</b></div><div class='card'>🎥 Videos<br><b>{counts['videos']}</b></div><div class='card'>🎵 Audio<br><b>{counts['audio']}</b></div><div class='card'>🧩 Packages<br><b>{counts['packages']}</b></div><h2>Outputs</h2><pre>{html.escape(json.dumps(counts, indent=2))}</pre></body></html>"""
    (out / "report.html").write_text(report, encoding="utf-8")

    if args.publish_webui:
        write_webui(site)
        for p in out.glob("*.json"):
            shutil.copy2(p, data_site / p.name)
        for p in [out / "media_assets.csv", out / "music_assets.csv", out / "action_events.csv", out / "suits_v22_unified_autotune.sqlite3", out / "report.html"]:
            if p.exists(): shutil.copy2(p, data_site / p.name)

    print(f"[o][o] v22 assets={len(assets)} packages={len(packages)} out={out}")
    print(f"[o][o] webui={site / 'v22_autotune' / 'index.php'}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
