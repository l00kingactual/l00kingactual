#!/usr/bin/env bash
set -euo pipefail

ZIP_DIR="${1:-${SUITS_ZIP_DIR:-$HOME/Downloads}}"
ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
SITE="${SUITS_SITE_ROOT:-$ROOT/susitsmafia_website}"
TOOLS="$ROOT/tools"
OUT="$ROOT/outputs/suits_v22_unified_autotune_factory"
PKG_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mkdir -p "$TOOLS" "$SITE/v22_autotune" "$OUT" "$ROOT/processors" "$ROOT/outputs" "$ROOT/audio" "$ROOT/videos" "$ROOT/auto_mp4" "$ROOT/music_mp4"

cp "$PKG_ROOT/tools/suits_v22_unified_autotune_factory.py" "$TOOLS/"
chmod +x "$TOOLS/suits_v22_unified_autotune_factory.py"

rsync -a "$PKG_ROOT/web/" "$SITE/v22_autotune/"

cat > "$TOOLS/suits_v22_launch_autotune_webui" <<LAUNCH
#!/usr/bin/env bash
set -euo pipefail
cd "$SITE"
php -S 0.0.0.0:8098
LAUNCH
chmod +x "$TOOLS/suits_v22_launch_autotune_webui"

cat > "$TOOLS/suits_v22_run_autotune_factory" <<RUN
#!/usr/bin/env bash
set -euo pipefail
exec "$TOOLS/suits_v22_unified_autotune_factory.py" --root "$ROOT" --zip-dir "$ZIP_DIR" --publish-webui --build-playlists --build-autotunes "\$@"
RUN
chmod +x "$TOOLS/suits_v22_run_autotune_factory"

"$TOOLS/suits_v22_unified_autotune_factory.py" --root "$ROOT" --zip-dir "$ZIP_DIR" --publish-webui --build-playlists --build-autotunes

echo "[o][o] v22 installed"
echo "[o][o] run: $TOOLS/suits_v22_run_autotune_factory"
echo "[o][o] launch: $TOOLS/suits_v22_launch_autotune_webui"
