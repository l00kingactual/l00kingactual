# $uits v22 Unified Autotune Factory

This pack glues the strongest `$uits` processors together from a folder of zip packages and creates a branded WebUI for:

- video/audio playlists
- action -> music matching
- music -> action matching
- predation-type auto-tunes
- comedy-value auto-tunes
- mouse/m0u$e behaviour presets
- render-ready JSON/CSV outputs
- WebsiteUI publishing

It does **not** destroy your existing folder. It installs into `/home/andy/Documents/suitsmafia/tools` and publishes WebUI files into `/home/andy/Documents/suitsmafia/susitsmafia_website/v22_autotune`.

## Install from a folder of zips

Put all `$uits` zip packages into one folder, for example:

```bash
/home/andy/Downloads/suits_zips
```

Then run:

```bash
cd /home/andy/Downloads/suits_v22_unified_autotune_factory
chmod +x scripts/*.sh tools/*.py
./scripts/install_v22_unified_factory.sh /home/andy/Downloads/suits_zips
```

## Run the factory

```bash
/home/andy/Documents/suitsmafia/tools/suits_v22_unified_autotune_factory.py \
  --root /home/andy/Documents/suitsmafia \
  --zip-dir /home/andy/Downloads/suits_zips \
  --publish-webui \
  --build-playlists \
  --build-autotunes
```

## Launch the WebUI

```bash
/home/andy/Documents/suitsmafia/tools/suits_v22_launch_autotune_webui
```

Open:

```text
http://127.0.0.1:8098/v22_autotune/index.php
```

On VPS:

```text
http://217.154.62.118:8098/v22_autotune/index.php
```

## Main outputs

```text
/home/andy/Documents/suitsmafia/outputs/suits_v22_unified_autotune_factory/
  discovered_packages.json
  selected_best_stack.json
  media_assets.csv
  music_assets.csv
  action_events.csv
  predation_autotunes.json
  comedy_autotunes.json
  mouse_behaviour_autotunes.json
  action_to_music.json
  music_to_action.json
  playlists.json
  render_queue.json
  report.html
```

## Best stack selected

The installer prefers:

1. `suits_processor_v16_6_1_python.zip` for the processor brain
2. `suits_v16_6_1_websiteui.zip` for the WebUI client
3. `suits_v18_render_factory.zip` for stills/clips/movies
4. `suits_v19_atomic_graph_builder.zip` for SQLite/Neo4j memory
5. `suits_v20_qbe_cypher_webui.zip` for QBE/Cypher
6. `suits_v21_ai_ml_site_organizer.zip` for AI/ML website organisation
7. `suits_processor_v16_6_dramatic_movie_theatre_webui_package.zip` as fallback all-in-one

[o][o]
