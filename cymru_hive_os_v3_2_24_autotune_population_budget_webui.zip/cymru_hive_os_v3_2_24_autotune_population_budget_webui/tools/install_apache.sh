#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
sudo rsync -av --delete ./ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
echo 'Open http://localhost/'
