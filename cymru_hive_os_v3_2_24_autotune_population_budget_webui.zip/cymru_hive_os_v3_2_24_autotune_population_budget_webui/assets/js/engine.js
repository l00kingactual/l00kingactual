(function(){
const D = window.SPACE_WALES_DATA;
const clamp=(v,min=0,max=100)=>Math.max(min,Math.min(max,v));
const money=n=>n>=1e9?"£"+(n/1e9).toFixed(2).replace(/\.00$/,"")+"bn":"£"+Math.round(n).toLocaleString();
function normalisePct(list){
  const total = list.reduce((s,x)=>s+x.pct,0)||1;
  return list.map(x=>({...x,pct:x.pct*100/total,annual_gbp:D.budget.annual_gbp*(x.pct*100/total)/100,total_gbp:D.budget.total_gbp*(x.pct*100/total)/100}));
}
function tunedAllocation(tune, lensId){
  const lens = D.lenses.find(l=>l.id===lensId) || D.lenses.find(l=>l.name===tune.strategic_lens) || D.lenses[0];
  let rows = D.budget.allocations.map(a=>({...a}));
  rows.forEach(a=>{
    const mod = tune.allocation_modifiers[a.id] || 0;
    const bias = lens.allocation_bias[a.id] || 0;
    a.pct = Math.max(1, a.pct + mod + bias);
  });
  return normalisePct(rows);
}
function cohort(tune){return D.population.find(p=>p.id===tune.cohort)||D.population[0];}
function honeyFor(allocation,tune){
  const out = Object.fromEntries(D.honey_outputs.map(k=>[k,0]));
  allocation.forEach(a=>{
    const mapping = D.output_map[a.id] || {};
    Object.entries(mapping).forEach(([k,v])=>out[k]=(out[k]||0)+a.pct*v);
  });
  // Tune-specific social premium
  if(tune.stage==="Wonder"){out.knowledge+=3;out.wellbeing+=2}
  if(tune.stage==="Explorer"){out.sport+=3;out.civicPride+=2}
  if(tune.stage==="Team"){out.knowledge+=2;out.ecologicalRepair+=2}
  if(tune.stage==="Skill"){out.invention+=3;out.apprenticeships+=2}
  if(tune.stage==="Capstone"){out.food+=4;out.jobs+=3;out.peace+=2}
  const max = Math.max(...Object.values(out),1);
  Object.keys(out).forEach(k=>out[k]=clamp((out[k]/max)*100));
  return out;
}
function lensScores(tune){
  const scores = {};
  D.lenses.forEach(l=>{
    let score = 50;
    Object.entries(l.allocation_bias).forEach(([k,v])=>score += (tune.allocation_modifiers[k]||0)*v*1.2);
    if(l.name===tune.strategic_lens) score += 12;
    scores[l.name]=clamp(score);
  });
  return scores;
}
function tournament(tune){
  return D.lenses.map(l=>{
    const allocation=tunedAllocation(tune,l.id);
    const honey=honeyFor(allocation,tune);
    const avg=Object.values(honey).reduce((a,b)=>a+b,0)/Object.values(honey).length;
    const fit=Object.entries(l.allocation_bias).reduce((s,[k,v])=>s+(tune.allocation_modifiers[k]||0)*v,0);
    return {lens:l.name,icon:l.icon,score:Math.round(clamp(avg+fit)),allocation,honey,rule:l.rule};
  }).sort((a,b)=>b.score-a.score);
}
function recomputedPopulationInvestment(allocation){
  return D.population.map(p=>{
    let pct = 0;
    p.priority.forEach(id=>{
      const row = allocation.find(a=>a.id===id);
      if(row) pct += row.pct;
    });
    const annual = D.budget.annual_gbp * (pct/100) * (p.people/D.budget.population);
    return {...p,priorityPct:pct,annual_gbp:annual,per_person:annual/p.people};
  });
}
function buildBees(){
  return Array.from({length:48},(_,i)=>({
    id:"bee-"+String(i+1).padStart(3,"0"),
    x:Math.random()*900,y:Math.random()*560,
    tx:Math.random()*900,ty:Math.random()*560,
    speed:0.35+Math.random()*1.3,
    kind:i%7===0?"🌾":i%5===0?"🔭":i%3===0?"🍯":"🐝",
    score:0
  }));
}
function stepBees(bees,tune,nodes){
  bees.forEach((b,i)=>{
    const dx=b.tx-b.x,dy=b.ty-b.y,d=Math.hypot(dx,dy)||1;
    if(d<7){
      const n=nodes[(i+tune.number+Math.floor(Math.random()*nodes.length))%nodes.length];
      b.tx=n.x + (Math.random()-.5)*70; b.ty=n.y + (Math.random()-.5)*70;
      b.score += 1 + tune.number/24;
    } else { b.x += dx/d*b.speed; b.y += dy/d*b.speed; }
  });
}
window.SpaceWalesEngine={money,tunedAllocation,cohort,honeyFor,lensScores,tournament,recomputedPopulationInvestment,buildBees,stepBees};
})();