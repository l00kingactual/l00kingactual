(function(){
function clear(ctx){ctx.clearRect(0,0,ctx.canvas.width,ctx.canvas.height)}
function label(ctx,text,x,y,align="left"){ctx.fillStyle="#eaf2ff";ctx.font="13px system-ui";ctx.textAlign=align;ctx.fillText(text,x,y)}
function barChart(canvas, rows, valueKey, labelKey, opts={}){
  const ctx=canvas.getContext("2d"); clear(ctx);
  const w=canvas.width,h=canvas.height,p=42;
  const max=Math.max(...rows.map(r=>r[valueKey]),1);
  rows.forEach((r,i)=>{
    const y=p+i*((h-p*1.5)/rows.length);
    const bw=(w-p*2)*(r[valueKey]/max);
    const grad=ctx.createLinearGradient(p,y,p+bw,y); grad.addColorStop(0,"#39d5ff");grad.addColorStop(.65,"#facc15");grad.addColorStop(1,"#4ade80");
    ctx.fillStyle=grad;ctx.fillRect(p,y,bw,10);
    label(ctx,(r.icon?r.icon+" ":"")+(r[labelKey]||r.name||r.id),p,y-3);
    label(ctx,opts.format?opts.format(r[valueKey],r):Math.round(r[valueKey]),w-p,y+10,"right");
  });
}
function radarLike(canvas, obj){
  const rows=Object.entries(obj).map(([name,value])=>({name,value}));
  barChart(canvas,rows,"value","name",{format:v=>Math.round(v)});
}
function linePopulation(canvas, rows){
  const ctx=canvas.getContext("2d"); clear(ctx);
  const w=canvas.width,h=canvas.height,p=42; const max=Math.max(...rows.map(r=>r.per_person),1);
  ctx.strokeStyle="rgba(255,255,255,.18)";ctx.beginPath();ctx.moveTo(p,h-p);ctx.lineTo(w-p,h-p);ctx.stroke();
  rows.forEach((r,i)=>{
    const x=p+i*((w-p*2)/(rows.length-1||1)); const y=h-p-(r.per_person/max)*(h-p*2);
    ctx.fillStyle="#39d5ff";ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);ctx.fill();
    label(ctx,r.icon,x,y-10,"center"); label(ctx,"£"+Math.round(r.per_person),x,h-12,"center");
  });
}
window.SpaceCharts={barChart,radarLike,linePopulation};
})();