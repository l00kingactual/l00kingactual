(function(){
const D=window.SPACE_WALES_DATA,E=window.SpaceWalesEngine,C=window.SpaceCharts;
const $=id=>document.getElementById(id);
let tuneIndex=0,running=true,activeLensId=null,bees=E.buildBees(),tick=0,lastTournament=[];
const nodes=[
  {name:"Holyhead",x:210,y:65,icon:"🚆"},{name:"Bangor",x:360,y:85,icon:"🎓"},{name:"Wrexham",x:740,y:120,icon:"💼"},{name:"Aberystwyth",x:450,y:280,icon:"🔭"},
  {name:"Brecon",x:620,y:385,icon:"🌌"},{name:"Swansea",x:455,y:475,icon:"⚙️"},{name:"Cardiff",x:650,y:520,icon:"🏙️"},{name:"St David’s",x:145,y:425,icon:"✨"}
];
const img=new Image(); img.src="assets/img/wales.jpeg";
function currentTune(){return D.auto_tunes[tuneIndex]}
function currentLens(){const t=currentTune();return D.lenses.find(l=>l.id===activeLensId)||D.lenses.find(l=>l.name===t.strategic_lens)||D.lenses[0]}
function renderTuneButtons(){
  D.auto_tunes.forEach((t,i)=>{
    const host=$("tuneGroup-"+t.stage); if(!host) return;
    const b=document.createElement("button"); b.className="side-card"; b.innerHTML=`<strong>${t.icon} ${String(t.number).padStart(2,"0")} · ${t.name}</strong><small>${t.strategic_lens} · ${t.summary}</small>`;
    b.onclick=()=>{tuneIndex=i;activeLensId=null;renderAll()};
    host.appendChild(b);
  });
}
function showPanel(key){
  const title={overview:"Overview",budget:"Budget allocation",population:"Population cohorts",lenses:"Strategic thinker lenses"}[key]||"Overview";
  $("panelTitle").textContent=title;
  if(key==="budget") return $("panelBody").innerHTML=budgetHTML();
  if(key==="population") return $("panelBody").innerHTML=populationHTML();
  if(key==="lenses") return $("panelBody").innerHTML=lensesHTML();
  $("panelBody").innerHTML=overviewHTML();
}
function overviewHTML(){
  return `<div class="card"><h3>What v3.2 does</h3><p>It runs a 24-stage pathway over population cohorts and a £10bn/year budget. Each auto-tune changes allocation pressure. Strategic lenses reinterpret the budget. The tournament ranks those interpretations and re-presents the best scenario.</p></div>
  <pre>${JSON.stringify({activeTune:currentTune().name,lens:currentLens().name,budget:D.budget.annual_gbp,population:D.budget.population},null,2)}</pre>`;
}
function budgetHTML(){
  const alloc=E.tunedAllocation(currentTune(),currentLens().id);
  return alloc.map(a=>`<div class="allocation-row"><strong>${a.icon} ${a.name}</strong><span class="bar"><i style="width:${a.pct}%"></i></span><span>${a.pct.toFixed(1)}% · ${E.money(a.annual_gbp)}/yr</span></div>`).join("");
}
function populationHTML(){
  const alloc=E.tunedAllocation(currentTune(),currentLens().id), pop=E.recomputedPopulationInvestment(alloc);
  return `<table class="table"><thead><tr><th>Cohort</th><th>People</th><th>Priority investment</th><th>Per person/year</th><th>Needs</th></tr></thead><tbody>${pop.map(p=>`<tr><td>${p.icon} ${p.name}</td><td>${p.people.toLocaleString()}</td><td>${E.money(p.annual_gbp)}</td><td>£${Math.round(p.per_person).toLocaleString()}</td><td>${p.needs.join(", ")}</td></tr>`).join("")}</tbody></table>`;
}
function lensesHTML(){
  return `<table class="table"><thead><tr><th>Lens</th><th>Tools</th><th>Budget rule</th></tr></thead><tbody>${D.lenses.map(l=>`<tr><td>${l.icon} ${l.name}</td><td>${l.tools.join(", ")}</td><td>${l.rule}</td></tr>`).join("")}</tbody></table>`;
}
function renderHeader(){
  const t=currentTune(),l=currentLens(),co=E.cohort(t),alloc=E.tunedAllocation(t,l.id),honey=E.honeyFor(alloc,t);
  $("metricTune").textContent=String(t.number).padStart(2,"0")+"/24";
  $("metricHoney").textContent=Math.round(Object.values(honey).reduce((a,b)=>a+b,0)/Object.values(honey).length);
  $("tuneTitle").textContent=`${t.icon} ${t.name}`;
  $("tuneSummary").textContent=t.summary;
  $("tunePills").innerHTML=`<span class="pill">${t.stage}</span><span class="pill">${co.name}</span><span class="pill">${t.strategic_lens}</span>`;
  $("lensTitle").textContent=`${l.icon} ${l.name}`;
  $("lensRule").textContent=l.rule;
  $("lensTools").innerHTML=l.tools.map(x=>`<span class="pill">${x}</span>`).join("");
  $("cohortTitle").textContent=`${co.icon} ${co.name}`;
  $("cohortNeeds").textContent="Needs: "+co.needs.join(", ");
  $("cohortPeople").textContent=co.people.toLocaleString();
  $("cohortBar").style.width=(co.people/D.budget.population*100*4).toFixed(1)+"%";
}
function renderCharts(){
  const t=currentTune(), l=currentLens(), alloc=E.tunedAllocation(t,l.id), honey=E.honeyFor(alloc,t), lens=E.lensScores(t), pop=E.recomputedPopulationInvestment(alloc);
  C.barChart($("allocationChart"),alloc,"pct","name",{format:(v,r)=>`${v.toFixed(1)}% · ${E.money(r.annual_gbp)}`});
  C.radarLike($("honeyChart"),honey);
  C.radarLike($("lensChart"),lens);
  C.linePopulation($("populationChart"),pop);
}
function renderTournament(){
  if(!lastTournament.length) lastTournament=E.tournament(currentTune());
  $("tournamentPanel").innerHTML=lastTournament.slice(0,6).map((r,i)=>`<div class="allocation-row"><strong>${i+1}. ${r.icon} ${r.lens}</strong><span class="bar"><i style="width:${r.score}%"></i></span><span>${r.score}/100</span></div>`).join("") + `<p>${lastTournament[0].rule}</p>`;
}
function renderSimMetrics(){
  const avg=bees.reduce((s,b)=>s+b.score,0)/bees.length;
  $("simMetrics").innerHTML=`<div class="allocation-row"><strong>bee score</strong><span class="bar"><i style="width:${Math.min(100,avg*10)}%"></i></span><span>${avg.toFixed(1)}</span></div>
  <div class="allocation-row"><strong>exploration</strong><span class="bar"><i style="width:${55+currentTune().number}%"></i></span><span>${55+currentTune().number}%</span></div>
  <div class="allocation-row"><strong>exploitation</strong><span class="bar"><i style="width:${70-currentTune().number/2}%"></i></span><span>${Math.round(70-currentTune().number/2)}%</span></div>`;
}
function drawSim(){
  const c=$("simCanvas"),ctx=c.getContext("2d");ctx.clearRect(0,0,c.width,c.height);
  if(img.complete&&img.naturalWidth){ctx.globalAlpha=.72;ctx.drawImage(img,0,0,c.width,c.height);ctx.globalAlpha=1}else{ctx.fillStyle="#0b1220";ctx.fillRect(0,0,c.width,c.height)}
  nodes.forEach(n=>{ctx.fillStyle="rgba(7,17,31,.85)";ctx.beginPath();ctx.arc(n.x,n.y,19,0,Math.PI*2);ctx.fill();ctx.fillStyle="#fff";ctx.font="20px system-ui";ctx.textAlign="center";ctx.fillText(n.icon,n.x,n.y+7);ctx.font="11px system-ui";ctx.fillText(n.name,n.x,n.y+35)});
  ctx.strokeStyle="rgba(250,204,21,.42)";ctx.lineWidth=2;bees.slice(0,12).forEach((b,i)=>{ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.tx,b.ty);ctx.stroke()});
  bees.forEach(b=>{ctx.font="18px system-ui";ctx.fillText(b.kind,b.x,b.y)});
}
function step(){
  if(running){tick++;E.stepBees(bees,currentTune(),nodes);drawSim();if(tick%30===0){renderSimMetrics();}if(tick%900===0){tuneIndex=(tuneIndex+1)%D.auto_tunes.length;activeLensId=null;lastTournament=[];renderAll(false)}}
  requestAnimationFrame(step);
}
function renderAll(updatePanel=true){lastTournament=[];renderHeader();renderCharts();renderTournament();renderSimMetrics();drawSim();if(updatePanel)showPanel("overview")}
function bind(){
  $("playBtn").onclick=()=>{running=!running;$("playBtn").textContent=running?"▶ auto-running":"⏸ paused";$("playBtn").classList.toggle("active",running)};
  $("nextTuneBtn").onclick=()=>{tuneIndex=(tuneIndex+1)%D.auto_tunes.length;activeLensId=null;renderAll()};
  $("tournamentBtn").onclick=()=>{lastTournament=E.tournament(currentTune());const winner=D.lenses.find(l=>l.name===lastTournament[0].lens);activeLensId=winner.id;renderAll(false);showPanel("lenses")};
  $("exportBtn").onclick=()=>{const t=currentTune(),l=currentLens(),alloc=E.tunedAllocation(t,l.id);const payload={version:"3.2",tune:t,lens:l,allocation:alloc,honey:E.honeyFor(alloc,t),population:E.recomputedPopulationInvestment(alloc),tournament:E.tournament(t)};const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="space_wales_v3_2_scenario.json";a.click();URL.revokeObjectURL(a.href)};
  document.querySelectorAll("[data-panel]").forEach(b=>b.onclick=()=>showPanel(b.dataset.panel));
}
renderTuneButtons();bind();renderAll();step();
})();