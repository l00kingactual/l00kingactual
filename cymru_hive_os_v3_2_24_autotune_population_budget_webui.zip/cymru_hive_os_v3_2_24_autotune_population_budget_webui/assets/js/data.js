window.SPACE_WALES_DATA = {
  "budget": {
    "annual_gbp": 10000000000,
    "years": 25,
    "total_gbp": 250000000000,
    "population": 3200000,
    "per_person_year": 3125,
    "per_person_25yr": 78125,
    "allocations": [
      {
        "id": "compute",
        "icon": "🧠",
        "name": "Super-advanced compute + data",
        "pct": 20,
        "purpose": "data centres, HPC/AI, VDI, storage, public cloud, evidence engines",
        "annual_gbp": 2000000000,
        "total_gbp": 50000000000,
        "per_person_year": 625.0
      },
      {
        "id": "education",
        "icon": "🏫",
        "name": "Education + lifelong learning",
        "pct": 15,
        "purpose": "schools, libraries, curriculum, age-5 astronomy, Welsh learning tools",
        "annual_gbp": 1500000000,
        "total_gbp": 37500000000,
        "per_person_year": 468.75
      },
      {
        "id": "health",
        "icon": "🩺",
        "name": "Health + prevention",
        "pct": 12,
        "purpose": "GP prevention, sports health, active lives, mental wellbeing",
        "annual_gbp": 1200000000,
        "total_gbp": 30000000000,
        "per_person_year": 375.0
      },
      {
        "id": "agrarian",
        "icon": "🌾",
        "name": "Agrarian WALE$ infrastructure",
        "pct": 11,
        "purpose": "SPACE Farmers, farms, food, water, soil, orchards, meadows",
        "annual_gbp": 1100000000,
        "total_gbp": 27500000000,
        "per_person_year": 343.75
      },
      {
        "id": "transport",
        "icon": "🚌",
        "name": "Transport + service access",
        "pct": 9,
        "purpose": "bus, rail, community taxi, safe routes, emergency access",
        "annual_gbp": 900000000,
        "total_gbp": 22500000000,
        "per_person_year": 281.25
      },
      {
        "id": "enterprise",
        "icon": "💼",
        "name": "Enterprise + apprenticeships",
        "pct": 9,
        "purpose": "SME compute vouchers, maker hubs, start-ups, college-to-work routes",
        "annual_gbp": 900000000,
        "total_gbp": 22500000000,
        "per_person_year": 281.25
      },
      {
        "id": "spacegis",
        "icon": "🛰️",
        "name": "Space, GIS, sensors, astronomy",
        "pct": 7,
        "purpose": "satellite imagery, dark skies, OSGB/GPS, field sensors",
        "annual_gbp": 700000000,
        "total_gbp": 17500000000,
        "per_person_year": 218.75
      },
      {
        "id": "hives",
        "icon": "🏘️",
        "name": "Hives: hamlets, villages, towns, cities",
        "pct": 5,
        "purpose": "local hubs, parks, sports fields, civic assets",
        "annual_gbp": 500000000,
        "total_gbp": 12500000000,
        "per_person_year": 156.25
      },
      {
        "id": "animals",
        "icon": "🐑",
        "name": "Animal guilds + ecology",
        "pct": 5,
        "purpose": "sheep, cows, goats, chickens, ducks, geese, swans, donkeys, horses, ponies, bees",
        "annual_gbp": 500000000,
        "total_gbp": 12500000000,
        "per_person_year": 156.25
      },
      {
        "id": "cyber",
        "icon": "🔐",
        "name": "Cybersecurity + civil resilience",
        "pct": 4,
        "purpose": "identity, backup, continuity, civil data defence",
        "annual_gbp": 400000000,
        "total_gbp": 10000000000,
        "per_person_year": 125.0
      },
      {
        "id": "evidence",
        "icon": "🧾",
        "name": "Evidence, simulation, CoRT60, audit",
        "pct": 3,
        "purpose": "scenario tournament, honey ledger, audit, governance, safeguards",
        "annual_gbp": 300000000,
        "total_gbp": 7500000000,
        "per_person_year": 93.75
      }
    ]
  },
  "population": [
    {
      "id": "age_5_7",
      "icon": "🌙",
      "name": "Ages 5–7 Wonder Bees",
      "people": 160000,
      "needs": [
        "play",
        "family learning",
        "safe darkness",
        "movement"
      ],
      "priority": [
        "education",
        "health",
        "spacegis"
      ]
    },
    {
      "id": "age_8_10",
      "icon": "🧭",
      "name": "Ages 8–10 Explorer Bees",
      "people": 165000,
      "needs": [
        "sport",
        "maps",
        "clubs",
        "library"
      ],
      "priority": [
        "education",
        "transport",
        "health"
      ]
    },
    {
      "id": "age_11_13",
      "icon": "🔭",
      "name": "Ages 11–13 Team Bees",
      "people": 170000,
      "needs": [
        "ecology",
        "coding",
        "telescopes",
        "service"
      ],
      "priority": [
        "spacegis",
        "education",
        "animals"
      ]
    },
    {
      "id": "age_14_16",
      "icon": "🛰️",
      "name": "Ages 14–16 Skill Bees",
      "people": 165000,
      "needs": [
        "GIS",
        "health prevention",
        "enterprise",
        "sensors"
      ],
      "priority": [
        "compute",
        "enterprise",
        "health"
      ]
    },
    {
      "id": "age_16_24",
      "icon": "🌾",
      "name": "Ages 16–24 Apprentices + SPACE Farmers",
      "people": 330000,
      "needs": [
        "apprenticeships",
        "VDI",
        "farms",
        "SMEs"
      ],
      "priority": [
        "enterprise",
        "compute",
        "agrarian"
      ]
    },
    {
      "id": "adults",
      "icon": "⚙️",
      "name": "Adults 25–64 Work, Care + Enterprise",
      "people": 1650000,
      "needs": [
        "jobs",
        "health",
        "transport",
        "skills"
      ],
      "priority": [
        "health",
        "enterprise",
        "transport"
      ]
    },
    {
      "id": "elders",
      "icon": "📚",
      "name": "Elders 65+ Memory + Care Bees",
      "people": 560000,
      "needs": [
        "care",
        "libraries",
        "transport",
        "civic memory"
      ],
      "priority": [
        "health",
        "transport",
        "hives"
      ]
    }
  ],
  "auto_tunes": [
    {
      "id": "tune_01",
      "number": 1,
      "icon": "🌙",
      "name": "Age 5 Moon Wonder",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "strategic_lens": "De Bono",
      "summary": "curiosity, safe darkness, family sky diary",
      "allocation_modifiers": {
        "education": 4,
        "spacegis": 5,
        "health": 2,
        "evidence": 2
      }
    },
    {
      "id": "tune_02",
      "number": 2,
      "icon": "🌑",
      "name": "Age 5 Safe Darkness",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "strategic_lens": "Kotler",
      "summary": "parent trust, safety, story-led astronomy",
      "allocation_modifiers": {
        "health": 4,
        "spacegis": 3,
        "education": 2,
        "hives": 2
      }
    },
    {
      "id": "tune_03",
      "number": 3,
      "icon": "☀️",
      "name": "Age 6 Sun & Shadow Clock",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "strategic_lens": "Drucker",
      "summary": "observable learning objective from shadow-clock activity",
      "allocation_modifiers": {
        "education": 4,
        "spacegis": 3,
        "evidence": 2
      }
    },
    {
      "id": "tune_04",
      "number": 4,
      "icon": "🌳",
      "name": "Age 6 Park Play + Nature",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "strategic_lens": "Porter",
      "summary": "park, school, sport and ecology as one activity system",
      "allocation_modifiers": {
        "health": 5,
        "animals": 3,
        "hives": 3,
        "transport": 1
      }
    },
    {
      "id": "tune_05",
      "number": 5,
      "icon": "⭐",
      "name": "Age 7 Story Constellations",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "strategic_lens": "Kotler",
      "summary": "story, identity and family value proposition",
      "allocation_modifiers": {
        "education": 5,
        "spacegis": 4,
        "hives": 1
      }
    },
    {
      "id": "tune_06",
      "number": 6,
      "icon": "🩺",
      "name": "Age 7 Family Health Hive",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "strategic_lens": "Drucker",
      "summary": "wellbeing and prevention as explicit objectives",
      "allocation_modifiers": {
        "health": 6,
        "education": 2,
        "hives": 2,
        "evidence": 1
      }
    },
    {
      "id": "tune_07",
      "number": 7,
      "icon": "🤝",
      "name": "Age 8 Cubs/Brownies Team Play",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "strategic_lens": "Mintzberg",
      "summary": "local clubs adapt national pathway",
      "allocation_modifiers": {
        "health": 4,
        "education": 3,
        "transport": 2,
        "hives": 2
      }
    },
    {
      "id": "tune_08",
      "number": 8,
      "icon": "📚",
      "name": "Age 8 Library Stars",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "strategic_lens": "De Bono",
      "summary": "APC: library alternatives when school/home access is weak",
      "allocation_modifiers": {
        "education": 5,
        "compute": 2,
        "spacegis": 2,
        "hives": 2
      }
    },
    {
      "id": "tune_09",
      "number": 9,
      "icon": "🧭",
      "name": "Age 9 Map North Navigation",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "strategic_lens": "Ansimov",
      "summary": "safe future tech, OSGB/GPS and growth pathway",
      "allocation_modifiers": {
        "transport": 4,
        "spacegis": 4,
        "education": 2,
        "evidence": 1
      }
    },
    {
      "id": "tune_10",
      "number": 10,
      "icon": "⚽",
      "name": "Age 9 Sports Field Confidence",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "strategic_lens": "Drucker",
      "summary": "confidence and participation as measurable outcomes",
      "allocation_modifiers": {
        "health": 6,
        "hives": 2,
        "education": 1
      }
    },
    {
      "id": "tune_11",
      "number": 11,
      "icon": "🐝",
      "name": "Age 10 Pollinator Garden",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "strategic_lens": "Porter",
      "summary": "garden, bees, school, ecology and food linked as fit",
      "allocation_modifiers": {
        "animals": 5,
        "agrarian": 4,
        "education": 2,
        "spacegis": 1
      }
    },
    {
      "id": "tune_12",
      "number": 12,
      "icon": "🚌",
      "name": "Age 10 Transport Independence",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "strategic_lens": "De Bono",
      "summary": "CAF: access, safeguarding, disability, cost and reliability",
      "allocation_modifiers": {
        "transport": 6,
        "health": 1,
        "education": 1,
        "cyber": 1
      }
    },
    {
      "id": "tune_13",
      "number": 13,
      "icon": "🔭",
      "name": "Age 11 Telescope Basics",
      "cohort": "age_11_13",
      "stage": "Team",
      "strategic_lens": "Ansimov",
      "summary": "future science with safe civic technology",
      "allocation_modifiers": {
        "spacegis": 6,
        "education": 4,
        "compute": 2
      }
    },
    {
      "id": "tune_14",
      "number": 14,
      "icon": "💧",
      "name": "Age 11 Water + Weather Fieldwork",
      "cohort": "age_11_13",
      "stage": "Team",
      "strategic_lens": "Mintzberg",
      "summary": "local terrain experiments inform national evidence",
      "allocation_modifiers": {
        "agrarian": 3,
        "animals": 3,
        "spacegis": 3,
        "evidence": 2
      }
    },
    {
      "id": "tune_15",
      "number": 15,
      "icon": "🌌",
      "name": "Age 12 Dark Sky Ecology",
      "cohort": "age_11_13",
      "stage": "Team",
      "strategic_lens": "Porter",
      "summary": "dark skies + ecology + tourism + learning fit",
      "allocation_modifiers": {
        "spacegis": 5,
        "animals": 3,
        "agrarian": 2,
        "hives": 1
      }
    },
    {
      "id": "tune_16",
      "number": 16,
      "icon": "🦉",
      "name": "Age 12 Zoo Biodiversity",
      "cohort": "age_11_13",
      "stage": "Team",
      "strategic_lens": "Kotler",
      "summary": "biodiversity offer by age and family segment",
      "allocation_modifiers": {
        "animals": 6,
        "education": 2,
        "health": 1,
        "evidence": 1
      }
    },
    {
      "id": "tune_17",
      "number": 17,
      "icon": "📈",
      "name": "Age 13 Coding Charts",
      "cohort": "age_11_13",
      "stage": "Team",
      "strategic_lens": "Drucker",
      "summary": "data literacy and evidence output objective",
      "allocation_modifiers": {
        "compute": 6,
        "education": 3,
        "evidence": 3
      }
    },
    {
      "id": "tune_18",
      "number": 18,
      "icon": "🤲",
      "name": "Age 13 Community Service",
      "cohort": "age_11_13",
      "stage": "Team",
      "strategic_lens": "De Bono",
      "summary": "OPV: child, parent, GP, volunteer, council",
      "allocation_modifiers": {
        "hives": 4,
        "health": 3,
        "transport": 2,
        "evidence": 2
      }
    },
    {
      "id": "tune_19",
      "number": 19,
      "icon": "🛰️",
      "name": "Age 14 Satellite GIS",
      "cohort": "age_14_16",
      "stage": "Skill",
      "strategic_lens": "Ansimov",
      "summary": "space tech with safeguards and growth route",
      "allocation_modifiers": {
        "compute": 6,
        "spacegis": 6,
        "education": 2,
        "cyber": 2
      }
    },
    {
      "id": "tune_20",
      "number": 20,
      "icon": "🏥",
      "name": "Age 14 GP Prevention Fitness",
      "cohort": "age_14_16",
      "stage": "Skill",
      "strategic_lens": "Drucker",
      "summary": "prevention metrics: activity, access, wellbeing",
      "allocation_modifiers": {
        "health": 7,
        "evidence": 3,
        "transport": 1,
        "compute": 1
      }
    },
    {
      "id": "tune_21",
      "number": 21,
      "icon": "📡",
      "name": "Age 15 Sensor Farm",
      "cohort": "age_14_16",
      "stage": "Skill",
      "strategic_lens": "Porter",
      "summary": "sensor farm links food, data, learning and enterprise",
      "allocation_modifiers": {
        "agrarian": 6,
        "compute": 4,
        "spacegis": 3,
        "animals": 3
      }
    },
    {
      "id": "tune_22",
      "number": 22,
      "icon": "💼",
      "name": "Age 15 Enterprise Challenge",
      "cohort": "age_14_16",
      "stage": "Skill",
      "strategic_lens": "Kotler",
      "summary": "SME, school, parent and employer value propositions",
      "allocation_modifiers": {
        "enterprise": 7,
        "compute": 3,
        "education": 2,
        "evidence": 2
      }
    },
    {
      "id": "tune_23",
      "number": 23,
      "icon": "🎓",
      "name": "Age 16 College Apprenticeship Taster",
      "cohort": "age_16_24",
      "stage": "Apprentice",
      "strategic_lens": "Mintzberg",
      "summary": "regional colleges adapt the national pathway",
      "allocation_modifiers": {
        "enterprise": 6,
        "education": 4,
        "compute": 3,
        "transport": 2
      }
    },
    {
      "id": "tune_24",
      "number": 24,
      "icon": "🌾",
      "name": "Age 16+ SPACE Farmer Capstone",
      "cohort": "age_16_24",
      "stage": "Capstone",
      "strategic_lens": "Porter",
      "summary": "land + sky + sport + animals + data + enterprise bundle",
      "allocation_modifiers": {
        "agrarian": 7,
        "enterprise": 5,
        "compute": 4,
        "spacegis": 4,
        "animals": 3,
        "evidence": 2
      }
    }
  ],
  "lenses": [
    {
      "id": "de_bono",
      "icon": "🧠",
      "name": "De Bono",
      "tools": [
        "PMI",
        "CAF",
        "C&S",
        "FIP",
        "APC",
        "OPV",
        "PISCO"
      ],
      "rule": "Stress-test each budget line with factors, alternatives, priorities and stakeholder views.",
      "allocation_bias": {
        "evidence": 3,
        "education": 2,
        "transport": 1
      }
    },
    {
      "id": "drucker",
      "icon": "📊",
      "name": "Drucker",
      "tools": [
        "objectives",
        "customer",
        "effectiveness",
        "measurement"
      ],
      "rule": "Fund explicit outcomes: health, learning, enterprise, access, food, invention and civic value.",
      "allocation_bias": {
        "health": 3,
        "education": 2,
        "enterprise": 2,
        "evidence": 2
      }
    },
    {
      "id": "mintzberg",
      "icon": "🌱",
      "name": "Mintzberg",
      "tools": [
        "deliberate strategy",
        "emergent strategy",
        "configuration"
      ],
      "rule": "Set national standards; let local hives adapt routes to terrain.",
      "allocation_bias": {
        "hives": 3,
        "transport": 2,
        "agrarian": 2,
        "education": 1
      }
    },
    {
      "id": "porter",
      "icon": "🔗",
      "name": "Porter",
      "tools": [
        "value chain",
        "activity-system fit",
        "trade-offs"
      ],
      "rule": "Fund mutually reinforcing bundles rather than isolated assets.",
      "allocation_bias": {
        "agrarian": 2,
        "health": 2,
        "enterprise": 2,
        "transport": 2,
        "compute": 1
      }
    },
    {
      "id": "ansimov",
      "icon": "🤖",
      "name": "Ansimov",
      "tools": [
        "Ansoff growth matrix",
        "Asimov safe-future technology"
      ],
      "rule": "Grow new pathways with safe advanced technology and civic safeguards.",
      "allocation_bias": {
        "compute": 4,
        "spacegis": 3,
        "cyber": 2,
        "enterprise": 1
      }
    },
    {
      "id": "kotler",
      "icon": "📣",
      "name": "Kotler",
      "tools": [
        "segmentation",
        "positioning",
        "value proposition",
        "channel fit"
      ],
      "rule": "Different population segments need different offers and messages.",
      "allocation_bias": {
        "education": 2,
        "health": 2,
        "enterprise": 2,
        "hives": 1,
        "transport": 1
      }
    }
  ],
  "honey_outputs": [
    "wellbeing",
    "knowledge",
    "sport",
    "jobs",
    "apprenticeships",
    "invention",
    "food",
    "ecologicalRepair",
    "civicPride",
    "peace"
  ],
  "output_map": {
    "compute": {
      "knowledge": 0.18,
      "invention": 0.28,
      "jobs": 0.18,
      "apprenticeships": 0.16,
      "peace": 0.08
    },
    "education": {
      "knowledge": 0.32,
      "apprenticeships": 0.16,
      "civicPride": 0.1,
      "wellbeing": 0.08
    },
    "health": {
      "wellbeing": 0.34,
      "sport": 0.2,
      "peace": 0.12,
      "civicPride": 0.08
    },
    "agrarian": {
      "food": 0.3,
      "jobs": 0.14,
      "ecologicalRepair": 0.2,
      "civicPride": 0.12
    },
    "transport": {
      "wellbeing": 0.14,
      "jobs": 0.16,
      "apprenticeships": 0.12,
      "peace": 0.15
    },
    "enterprise": {
      "jobs": 0.3,
      "apprenticeships": 0.2,
      "invention": 0.18,
      "civicPride": 0.08
    },
    "spacegis": {
      "knowledge": 0.18,
      "invention": 0.2,
      "ecologicalRepair": 0.16,
      "civicPride": 0.14
    },
    "hives": {
      "civicPride": 0.26,
      "wellbeing": 0.16,
      "peace": 0.16,
      "sport": 0.1
    },
    "animals": {
      "food": 0.2,
      "ecologicalRepair": 0.24,
      "wellbeing": 0.12,
      "civicPride": 0.14
    },
    "cyber": {
      "peace": 0.3,
      "invention": 0.1,
      "jobs": 0.08,
      "wellbeing": 0.06
    },
    "evidence": {
      "knowledge": 0.16,
      "peace": 0.12,
      "invention": 0.12,
      "civicPride": 0.1
    }
  },
  "sources_note": "Designed from uploaded behaviour-engine, swarm-intelligence, complex-adaptive-systems and neural-function-approximation documents."
};
