#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Running 3 songs x 29s + full with patient render. This can take a while."
./run_three_songs_both.sh "$@"
echo "Done. Open output folders under: /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8"
find /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 -path '*/renders/final/*.mp4' -print
