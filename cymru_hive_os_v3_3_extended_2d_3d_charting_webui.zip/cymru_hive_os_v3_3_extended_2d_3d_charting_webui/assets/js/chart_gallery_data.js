window.SPACE_WALES_CHART_GALLERY = [
  {
    "id": "allocation_bar_2d",
    "icon": "📊",
    "name": "2D Allocation Bar",
    "type": "2D",
    "category": "budget",
    "idea": "Baseline budget bars by allocation layer."
  },
  {
    "id": "allocation_stacked_2d",
    "icon": "🧱",
    "name": "2D Stacked Budget Wall",
    "type": "2D",
    "category": "budget",
    "idea": "One £10bn/year wall split into allocation blocks."
  },
  {
    "id": "honey_radar_2d",
    "icon": "🕸️",
    "name": "2D Honey Radar",
    "type": "2D",
    "category": "honey",
    "idea": "Radar plot of wellbeing, knowledge, jobs, food and peace."
  },
  {
    "id": "population_bubble_2d",
    "icon": "🫧",
    "name": "2D Population Bubble",
    "type": "2D",
    "category": "population",
    "idea": "Cohort population size and priority pressure as bubbles."
  },
  {
    "id": "budget_columns_3d",
    "icon": "🏛️",
    "name": "3D Budget Columns",
    "type": "3D",
    "category": "budget",
    "idea": "Isometric columns for budget allocation."
  },
  {
    "id": "honey_surface_3d",
    "icon": "⛰️",
    "name": "3D Honey Terrain",
    "type": "3D",
    "category": "honey",
    "idea": "Pseudo-3D terrain surface showing honey strength."
  },
  {
    "id": "cohort_ridges_3d",
    "icon": "🏔️",
    "name": "3D Cohort Ridges",
    "type": "3D",
    "category": "population",
    "idea": "Age cohort ridgelines across investment pressure."
  },
  {
    "id": "allocation_cube_3d",
    "icon": "🧊",
    "name": "3D Allocation Cube",
    "type": "3D",
    "category": "budget",
    "idea": "Budget layers as stacked cube slices."
  },
  {
    "id": "hive_network_2d",
    "icon": "🕸️",
    "name": "2D Hive Network",
    "type": "2D",
    "category": "graph",
    "idea": "Services, cohorts and allocation layers as a Welsh hive network."
  },
  {
    "id": "sankey_flow_2d",
    "icon": "🌊",
    "name": "2D Nectar Sankey",
    "type": "2D",
    "category": "flow",
    "idea": "Budget to nectar to honey flow bands."
  },
  {
    "id": "chord_ring_2d",
    "icon": "⭕",
    "name": "2D Chord Ring",
    "type": "2D",
    "category": "flow",
    "idea": "Circular relationships between population and budget layers."
  },
  {
    "id": "treemap_2d",
    "icon": "🧩",
    "name": "2D Budget Treemap",
    "type": "2D",
    "category": "budget",
    "idea": "Rectangular space-filling view of allocations."
  },
  {
    "id": "heatmap_2d",
    "icon": "🔥",
    "name": "2D Priority Heatmap",
    "type": "2D",
    "category": "matrix",
    "idea": "Cohort by allocation priority heatmap."
  },
  {
    "id": "timeline_2d",
    "icon": "⏳",
    "name": "2D 24-Tune Timeline",
    "type": "2D",
    "category": "time",
    "idea": "Auto-tunes across age bands."
  },
  {
    "id": "scatter_3d",
    "icon": "✨",
    "name": "3D Scenario Scatter",
    "type": "3D",
    "category": "scenario",
    "idea": "Pseudo-3D plot of cost, impact and risk."
  },
  {
    "id": "spiral_3d",
    "icon": "🌀",
    "name": "3D Pathway Spiral",
    "type": "3D",
    "category": "time",
    "idea": "24 auto-tunes as a developmental spiral."
  },
  {
    "id": "cylinders_3d",
    "icon": "🥫",
    "name": "3D Budget Cylinders",
    "type": "3D",
    "category": "budget",
    "idea": "Cylindrical tower plot of annual budget layers."
  },
  {
    "id": "sunburst_2d",
    "icon": "☀️",
    "name": "2D SPACE WALE$ Sunburst",
    "type": "2D",
    "category": "hierarchy",
    "idea": "SPACE to WALE$ to budget to honey hierarchy."
  },
  {
    "id": "force_graph_2d",
    "icon": "🧲",
    "name": "2D Force Graph",
    "type": "2D",
    "category": "graph",
    "idea": "Strategic lenses pull budget layers by bias strength."
  },
  {
    "id": "correlation_matrix_2d",
    "icon": "🔲",
    "name": "2D Correlation Matrix",
    "type": "2D",
    "category": "matrix",
    "idea": "Allocation to honey relationship matrix."
  },
  {
    "id": "waterfall_2d",
    "icon": "💧",
    "name": "2D Budget Waterfall",
    "type": "2D",
    "category": "budget",
    "idea": "Sequential build-up from £0 to £10bn/year."
  },
  {
    "id": "gantt_2d",
    "icon": "📅",
    "name": "2D 25-Year Gantt",
    "type": "2D",
    "category": "time",
    "idea": "Infrastructure phases over 25 years."
  },
  {
    "id": "pareto_2d",
    "icon": "📈",
    "name": "2D Pareto Honey",
    "type": "2D",
    "category": "honey",
    "idea": "Top budget layers contributing to honey."
  },
  {
    "id": "agent_trails_2d",
    "icon": "🐝",
    "name": "2D Agent Trails",
    "type": "2D",
    "category": "agent",
    "idea": "Bee/person movement trails through service hives."
  },
  {
    "id": "pheromone_heat_2d",
    "icon": "🐜",
    "name": "2D Pheromone Heatmap",
    "type": "2D",
    "category": "agent",
    "idea": "ACO-like route intensity on the canvas."
  },
  {
    "id": "tournament_ladder_2d",
    "icon": "🏆",
    "name": "2D Thinker Tournament",
    "type": "2D",
    "category": "scenario",
    "idea": "Strategic lens ranking bracket."
  },
  {
    "id": "cort_wheel_2d",
    "icon": "🎡",
    "name": "2D CoRT60 Wheel",
    "type": "2D",
    "category": "strategy",
    "idea": "PMI, CAF, C&S, FIP, APC, OPV, PISCO sectors."
  },
  {
    "id": "porter_chain_2d",
    "icon": "🔗",
    "name": "2D Porter Value Chain",
    "type": "2D",
    "category": "strategy",
    "idea": "Sport to health to learning to enterprise to honey."
  },
  {
    "id": "thirteen_s_cube_3d",
    "icon": "🎲",
    "name": "3D 13S Synergy Cube",
    "type": "3D",
    "category": "strategy",
    "idea": "13S alignment as cube blocks."
  },
  {
    "id": "wales_hive_map_2d",
    "icon": "🗺️",
    "name": "2D Wales Hive Honey Map",
    "type": "2D",
    "category": "map",
    "idea": "Budget and honey values projected onto Welsh hives."
  },
  {
    "id": "risk_return_3d",
    "icon": "⚖️",
    "name": "3D Risk–Return Plane",
    "type": "3D",
    "category": "scenario",
    "idea": "Scenario impact, risk and investment in perspective."
  },
  {
    "id": "knowledge_tree_3d",
    "icon": "🌳",
    "name": "3D Knowledge Tree",
    "type": "3D",
    "category": "learning",
    "idea": "Education, astronomy, animals and enterprise as branches."
  }
];
