# Cymru Hive OS v3.3 · 24 Auto-Tune Population + Budget Engine

This package is a standalone WebUI for SPACE WALE$.

## Adds

- 24 auto-tunes across age stages
- £10bn/year budget model
- 25-year £250bn programme horizon
- 3.2m population cohort model
- De Bono, Drucker, Mintzberg, Porter, Ansimov and Kotler strategic lenses
- thinker tournament that re-ranks budget allocations
- bee/hive simulation canvas
- allocation, honey, lens and population charts
- JSON export
- SQL and Neo4j seed schema

## Run locally

```bash
cd cymru_hive_os_v3_2_24_autotune_population_budget_webui
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Apache

```bash
sudo rsync -av --delete ./ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
```

Open:

```text
http://localhost/
```


## v3.3 extended 2D/3D charting module

Adds `chart_gallery.html` with 32 local Canvas chart/plot/graph ideas:

- 2D budget bars, stacked wall, treemap, waterfall and Pareto views
- honey radar, honey terrain, matrix and heatmap views
- population bubbles and cohort ridges
- network, force, Sankey and chord views
- strategic CoRT wheel, Porter chain and 3D 13S synergy cube
- pseudo-3D budget columns, cylinders, allocation cube, scenario scatter, spiral, risk-return plane and knowledge tree
- Wales hive honey map
- SQL and Neo4j chart-gallery seeds
- JSON chart definitions in `data/chart_gallery_32.json`

Open `chart_gallery.html` from the main WebUI or directly through the local server. No CDN is required.
