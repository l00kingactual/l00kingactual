# Final Grade GTA/FiveM Predation Studio

Offline-first WebUI for **fictional GTA/FiveM gameplay-media analytics**.

It is designed for cinematic/machinima/gameplay analysis, not real-world tactical guidance.

## What it does

- Scans folders for videos, audio and label files.
- Lets you create playlists and add/remove files for analytical processing.
- Runs a video-first tensor analysis because GTA montages often have music over the audio.
- Uses optional audio mainly as beat/context, not proof of gunfire.
- Supports ground-truth strengthening from:
  - manual labels CSV/JSON
  - FiveM/server logs CSV/JSON
  - optional killfeed OCR if `pytesseract` and OS Tesseract are installed
- Always runs: if OpenCV, ffmpeg or OCR are unavailable, it falls back to metadata/manifest output rather than failing.
- Exports curated webpage media using **quality over quantity**:
  - Top 6 dramatic clips
  - Top 3 funny clips
  - Top 3 team-play clips
  - Top 3 spectacular/graphic-intensity clips
  - Top 3 still frames
  - Top 3 APNG loops
- Exports:
  - `final_grade_predation_report.html`
  - `predation_manifest.json`
  - `cort60_serious_subtitles.srt`
  - `cort60_funny_subtitles.srt`
  - `predation_3nf_acid_sqlite.sql`
  - `predation_3nf_acid_postgres.sql`
  - `predation_neo4j.cypher`

## Linux run

```bash
cd final_predation_studio
chmod +x run_linux.sh
./run_linux.sh
```

Open:

```text
http://127.0.0.1:8790
```

## Windows run

Double-click:

```text
run_windows.bat
```

## Manual label format

CSV columns accepted:

```text
timestamp,start,end,event_type,confidence,killer,victim,weapon,note
```

The same fields also work in JSON as a list of objects.

## Server log format

CSV columns accepted:

```text
timestamp,event_type,confidence,killer,victim,weapon,note
```

Use `server_logs_example.csv` as a guide.

## Ground-truth levels

- `video_inferred` — visual proxy only
- `ocr_confirmed` — optional OCR evidence matched by time
- `manual_confirmed` — manual label matched by time/window
- `server_confirmed` — FiveM/server log matched by time/window

## Design notes

This package operationalises:

```text
video tensor -> smoothing/norming/scaling -> predation senses -> CoRT60 comments
-> quality gate -> curated media assets -> SQL/Neo4j/HTML exports
```

The webpage is deliberately curated. It does not dump every detected event by default.
The full ledger remains in JSON/SQL/Cypher for audit and future WebUI analysis.
