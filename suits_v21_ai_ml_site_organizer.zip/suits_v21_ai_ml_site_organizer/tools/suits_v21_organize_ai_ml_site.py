#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

ANIMAL_CLASSES = {
    "lone_wolf": "🐺", "tiger_stalk": "🐯", "lion_pack_pressure": "🦁",
    "sheep_flock_panic": "🐑", "goat_stubborn_luck": "🐐", "duck_waddle_escape": "🦆",
    "swan_grace_escape": "🦢", "eagle_overwatch": "🦅", "hawk_strike": "🦅",
    "raven_aftermath": "🐦‍⬛", "cuckoo_deception": "🐦", "crocodile_chokepoint": "🐊",
    "fox_deception": "🦊", "spider_web_control": "🕷️", "shark_pursuit": "🦈",
    "owl_intelligence": "🦉", "comedy_anomaly": "😂",
}

EVENT_HINTS = {
    "shot_fired": ["shot", "gun", "fire", "shoot", "kill", "hit_confirmed"],
    "vehicle_chase": ["chase", "pursuit", "drive", "car", "bike", "vehicle"],
    "song_movie": ["song", "music", "cue", "bpm", "full_song"],
    "render_job": ["render", "movie_factory", "full_film", "29s", "apng", "still"],
    "graph_metadata": ["neo4j", "cypher", "graph", "nodes", "edges"],
    "database_metadata": ["sqlite", "mysql", "csv", "json", "metadata", "3nf", "atomic"],
    "strategy_note": ["sun_tzu", "strategy", "debono", "cort", "predation", "prey"],
}

KIND_EXT = {
    "video": {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"},
    "audio": {".mp3", ".wav", ".flac", ".aac", ".m4a", ".ogg"},
    "image": {".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".apng"},
    "data": {".json", ".jsonl", ".csv", ".tsv", ".sqlite", ".sqlite3", ".db", ".cypher", ".sql"},
    "script": {".py", ".sh", ".php", ".js", ".lua", ".ps1", ".bat", ".html", ".css"},
    "document": {".md", ".txt", ".odt", ".docx", ".pdf", ".rtf"},
    "archive": {".zip", ".tgz", ".gz", ".tar", ".7z", ".rar"},
}

ICONS = {
    "video": "🎥", "audio": "🎵", "image": "🖼️", "data": "📊", "script": "🐍",
    "document": "📄", "archive": "📦", "other": "🧱",
    "render": "🎬", "website": "🌐", "database": "🗃️", "graph": "🕸️", "ml": "🧠",
}

@dataclass
class FileRow:
    asset_id: str
    path: str
    rel_path: str
    group_name: str
    kind: str
    ext: str
    size_bytes: int
    mtime: float
    sha1_path: str
    animal_class: str
    animal_icon: str
    event_type: str
    ml_score: float
    website_role: str


def kind_for(path: Path) -> str:
    ext = path.suffix.lower()
    for kind, exts in KIND_EXT.items():
        if ext in exts:
            return kind
    return "other"


def group_for(rel: str) -> str:
    parts = rel.split(os.sep)
    if not parts:
        return "root"
    if parts[0] in {"outputs", "susitsmafia_website", "videos", "audio", "auto_mp4"} and len(parts) > 1:
        return "/".join(parts[:2])
    return parts[0]


def detect_animal(rel_lower: str) -> Tuple[str, str]:
    for name, icon in ANIMAL_CLASSES.items():
        if name in rel_lower:
            return name, icon
    if any(x in rel_lower for x in ["pack", "pressure", "gang", "crew"]):
        return "lion_pack_pressure", ANIMAL_CLASSES["lion_pack_pressure"]
    if any(x in rel_lower for x in ["aftermath", "raven", "dark"]):
        return "raven_aftermath", ANIMAL_CLASSES["raven_aftermath"]
    if any(x in rel_lower for x in ["strike", "trickshot", "headshot"]):
        return "hawk_strike", ANIMAL_CLASSES["hawk_strike"]
    if any(x in rel_lower for x in ["funny", "comedy", "panic", "blunder"]):
        return "comedy_anomaly", ANIMAL_CLASSES["comedy_anomaly"]
    return "unknown", "❔"


def detect_event(rel_lower: str, kind: str) -> str:
    for event, hints in EVENT_HINTS.items():
        if any(h in rel_lower for h in hints):
            return event
    if kind == "video":
        return "media_video"
    if kind == "audio":
        return "media_audio"
    if kind == "image":
        return "media_image"
    if kind == "script":
        return "automation_script"
    if kind == "data":
        return "metadata_file"
    return "asset"


def website_role(rel_lower: str, kind: str) -> str:
    if "susitsmafia_website" in rel_lower or rel_lower.endswith(('.php','.html','.css','.js')):
        return "website_ui"
    if "outputs" in rel_lower:
        return "processor_output"
    if "render" in rel_lower:
        return "render_asset"
    if kind in {"video", "audio", "image"}:
        return "media_library"
    if kind in {"data", "script"}:
        return "ml_metadata"
    return "project_asset"


def ml_score(rel_lower: str, kind: str, size: int, animal: str, event: str) -> float:
    score = 0.10
    if kind in {"video", "audio", "image", "data", "script"}:
        score += 0.15
    if animal != "unknown":
        score += 0.25
    if event not in {"asset", "media_video", "media_audio", "media_image"}:
        score += 0.25
    if any(x in rel_lower for x in ["movie_factory", "song_action", "render_jobs", "graph_nodes", "graph_edges", "chart_specs", "metadata", "predation"]):
        score += 0.20
    if size > 50_000_000:
        score += 0.05
    return round(min(score, 0.99), 3)


def iter_files(root: Path, skip_backups=True) -> Iterable[Path]:
    skip_names = {".git", "node_modules", "__pycache__", ".venv", "venv"}
    if skip_backups:
        skip_names.add("backups")
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip_names and not (skip_backups and d.lower() == "backups")]
        for f in filenames:
            yield Path(dirpath) / f


def scan(root: Path, limit: int = 0, skip_backups=True) -> List[FileRow]:
    rows: List[FileRow] = []
    for idx, path in enumerate(iter_files(root, skip_backups=skip_backups), 1):
        try:
            st = path.stat()
        except OSError:
            continue
        rel = str(path.relative_to(root))
        low = rel.lower()
        kind = kind_for(path)
        animal, icon = detect_animal(low)
        event = detect_event(low, kind)
        aid = hashlib.sha1(rel.encode("utf-8", "ignore")).hexdigest()[:16]
        rows.append(FileRow(
            asset_id=f"asset_{aid}", path=str(path), rel_path=rel, group_name=group_for(rel),
            kind=kind, ext=path.suffix.lower(), size_bytes=st.st_size, mtime=st.st_mtime,
            sha1_path=hashlib.sha1(str(path).encode()).hexdigest(), animal_class=animal,
            animal_icon=icon, event_type=event, ml_score=ml_score(low, kind, st.st_size, animal, event),
            website_role=website_role(low, kind)
        ))
        if limit and idx >= limit:
            break
    return rows


def write_csv(path: Path, rows: List[dict], fields: List[str]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def build_db(db: Path, rows: List[FileRow]):
    db.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db)
    cur = con.cursor()
    cur.executescript("""
    DROP TABLE IF EXISTS source_file;
    DROP TABLE IF EXISTS ml_feature;
    DROP TABLE IF EXISTS website_role;
    DROP TABLE IF EXISTS animal_class;
    DROP TABLE IF EXISTS event_type;
    CREATE TABLE source_file(
      asset_id TEXT PRIMARY KEY, path TEXT, rel_path TEXT, group_name TEXT, kind TEXT, ext TEXT,
      size_bytes INTEGER, mtime REAL, sha1_path TEXT
    );
    CREATE TABLE ml_feature(asset_id TEXT, animal_class TEXT, event_type TEXT, ml_score REAL, website_role TEXT);
    CREATE TABLE website_role(role TEXT PRIMARY KEY, count INTEGER);
    CREATE TABLE animal_class(animal_class TEXT PRIMARY KEY, icon TEXT, count INTEGER, avg_score REAL);
    CREATE TABLE event_type(event_type TEXT PRIMARY KEY, count INTEGER, avg_score REAL);
    """)
    for r in rows:
        cur.execute("INSERT INTO source_file VALUES (?,?,?,?,?,?,?,?,?)", (r.asset_id,r.path,r.rel_path,r.group_name,r.kind,r.ext,r.size_bytes,r.mtime,r.sha1_path))
        cur.execute("INSERT INTO ml_feature VALUES (?,?,?,?,?)", (r.asset_id,r.animal_class,r.event_type,r.ml_score,r.website_role))
    cur.execute("INSERT INTO website_role SELECT website_role, COUNT(*) FROM ml_feature GROUP BY website_role")
    cur.execute("INSERT INTO animal_class SELECT animal_class, MAX(CASE animal_class WHEN 'unknown' THEN '❔' ELSE '' END), COUNT(*), AVG(ml_score) FROM ml_feature GROUP BY animal_class")
    for name, icon in ANIMAL_CLASSES.items():
        cur.execute("UPDATE animal_class SET icon=? WHERE animal_class=?", (icon, name))
    cur.execute("INSERT INTO event_type SELECT event_type, COUNT(*), AVG(ml_score) FROM ml_feature GROUP BY event_type")
    con.commit(); con.close()


def make_summary(rows: List[FileRow]) -> dict:
    def counts(attr):
        d: Dict[str, int] = {}
        for r in rows:
            d[getattr(r, attr)] = d.get(getattr(r, attr), 0) + 1
        return dict(sorted(d.items(), key=lambda kv: kv[1], reverse=True))
    return {
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "asset_count": len(rows),
        "kind_counts": counts("kind"),
        "group_counts_top50": dict(list(counts("group_name").items())[:50]),
        "animal_counts": counts("animal_class"),
        "event_counts": counts("event_type"),
        "website_role_counts": counts("website_role"),
    }


def write_dashboard(site: Path):
    php = r'''<?php
$dataFile = __DIR__ . '/data/v21_ai_ml/summary.json';
$summary = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];
function h($s){return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');}
function table_counts($title, $arr){
  echo "<section class='card'><h2>".h($title)."</h2><table><tr><th>Name</th><th>Count</th></tr>";
  foreach(($arr ?: []) as $k=>$v){echo "<tr><td>".h($k)."</td><td>".h($v)."</td></tr>";}
  echo "</table></section>";
}
?><!doctype html><html><head><meta charset="utf-8"><title>$uits v21 AI/ML Metadata</title>
<style>
body{font-family:system-ui;background:#07111f;color:#dbeafe;margin:0;padding:24px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}.card{background:#0d1b2f;border:1px solid #23405f;border-radius:16px;padding:18px}a{color:#93c5fd}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #23405f;padding:6px;text-align:left}.hero{font-size:42px}code{background:#10233d;padding:2px 6px;border-radius:6px}</style></head><body>
<div class='hero'>🧠 $uits v21 AI/ML Metadata WebUI</div>
<p>Root: <code>/home/andy/Documents/suitsmafia</code></p>
<p>Assets indexed: <strong><?php echo h($summary['asset_count'] ?? 0); ?></strong></p>
<p><a href="data/v21_ai_ml/file_profile.csv">📄 file_profile.csv</a> · <a href="data/v21_ai_ml/summary.json">🧾 summary.json</a> · <a href="data/v21_ai_ml/suits_v21_ai_ml.sqlite3">🗃️ SQLite</a></p>
<div class='grid'>
<?php table_counts('📦 Kind counts', $summary['kind_counts'] ?? []); ?>
<?php table_counts('🦁 Animal class counts', $summary['animal_counts'] ?? []); ?>
<?php table_counts('🔥 Event counts', $summary['event_counts'] ?? []); ?>
<?php table_counts('🌐 Website role counts', $summary['website_role_counts'] ?? []); ?>
</div>
</body></html>
'''
    site.mkdir(parents=True, exist_ok=True)
    (site / "v21_ai_ml_dashboard.php").write_text(php, encoding="utf-8")


def write_apache_hint(out: Path, domain: str, site: Path):
    text = f"""# Apache/Plesk hint for {domain}
# Preferred: in Plesk, set document root or alias to:
# {site}

Alias /suits {site}
<Directory {site}>
    Options FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>

# Then open:
# https://{domain}/suits/v21_ai_ml_dashboard.php
"""
    (out / "apache_suits_alias.conf.example").write_text(text, encoding="utf-8")


def maybe_run(cmd: List[str], label: str):
    try:
        print(f"[o][o] running {label}: {' '.join(cmd)}")
        subprocess.run(cmd, check=False)
    except Exception as e:
        print(f"[warn] {label} failed: {e}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="/home/andy/Documents/suitsmafia")
    ap.add_argument("--site-domain", default="suitsmafia.com")
    ap.add_argument("--out", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--include-backups", action="store_true")
    ap.add_argument("--publish", action="store_true")
    ap.add_argument("--run-v19", action="store_true")
    ap.add_argument("--run-v18", action="store_true")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    out = Path(args.out) if args.out else root / "outputs" / "suits_v21_ai_ml_site_organizer"
    site = root / "susitsmafia_website"
    data_site = site / "data" / "v21_ai_ml"
    out.mkdir(parents=True, exist_ok=True)
    data_site.mkdir(parents=True, exist_ok=True)

    print(f"[o][o] scanning {root}")
    rows = scan(root, limit=args.limit, skip_backups=not args.include_backups)
    dicts = [asdict(r) for r in rows]
    fields = list(dicts[0].keys()) if dicts else list(FileRow.__annotations__.keys())
    write_csv(out / "file_profile.csv", dicts, fields)
    build_db(out / "suits_v21_ai_ml.sqlite3", rows)
    summary = make_summary(rows)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_dashboard(site)
    write_apache_hint(out, args.site_domain, site)

    if args.publish:
        for src in [out / "file_profile.csv", out / "summary.json", out / "suits_v21_ai_ml.sqlite3"]:
            shutil.copy2(src, data_site / src.name)
        print(f"[o][o] published metadata to {data_site}")

    if args.run_v19:
        tool = root / "tools" / "suits_v19_atomic_graph_builder.py"
        if tool.exists(): maybe_run([sys.executable, str(tool), "--root", str(root)], "v19 atomic graph")
    if args.run_v18:
        tool = root / "tools" / "suits_v18_render_factory.py"
        if tool.exists(): maybe_run([sys.executable, str(tool), "--root", str(root), "--max-songs", "18", "--all"], "v18 render factory")

    print(json.dumps(summary, indent=2)[:3000])
    print(f"[o][o] dashboard: {site / 'v21_ai_ml_dashboard.php'}")

if __name__ == "__main__":
    main()
