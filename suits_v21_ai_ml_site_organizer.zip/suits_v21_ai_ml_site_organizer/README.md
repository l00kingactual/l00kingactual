# $uits v21 AI/ML Site Organizer

Organises `/home/andy/Documents/suitsmafia` into an AI/ML-friendly metadata layer and publishes website/server UI resources for `suitsmafia.com`.

## What it does

- Scans `/home/andy/Documents/suitsmafia` recursively.
- Skips backup folders by default.
- Profiles files by kind, extension, size, modified time, path group, and ML signals.
- Builds a SQLite catalog and JSON/CSV metadata outputs.
- Builds WebsiteUI-ready data under `susitsmafia_website/data/v21_ai_ml`.
- Creates an Apache/Plesk-friendly site alias plan for `suitsmafia.com`.
- Publishes a simple dashboard index for the metadata.
- Optionally runs v19 atomic graph builder and v18 render factory if installed.

## Install on VPS

```bash
cd /root
unzip -o suits_v21_ai_ml_site_organizer.zip
cd suits_v21_ai_ml_site_organizer
chmod +x scripts/*.sh tools/*.py
sudo ./scripts/install_v21_organizer.sh
```

## Run scan/organise/publish

```bash
/home/andy/Documents/suitsmafia/tools/suits_v21_organize_ai_ml_site \
  --root /home/andy/Documents/suitsmafia \
  --site-domain suitsmafia.com \
  --publish
```

## Run as `andy`

```bash
suits_v21_organize_ai_ml_site --publish
```

Outputs go to:

```text
/home/andy/Documents/suitsmafia/outputs/suits_v21_ai_ml_site_organizer
/home/andy/Documents/suitsmafia/susitsmafia_website/data/v21_ai_ml
/home/andy/Documents/suitsmafia/susitsmafia_website/v21_ai_ml_dashboard.php
```

## Apache/Plesk

The script does not remove Plesk. It writes an Apache include suggestion and creates/updates the local WebUI files. Use Plesk to point `suitsmafia.com` document root or alias to:

```text
/home/andy/Documents/suitsmafia/susitsmafia_website
```

or symlink from the Plesk document root:

```bash
sudo ln -sfn /home/andy/Documents/suitsmafia/susitsmafia_website /var/www/vhosts/suitsmafia.com/httpdocs/suits
```

Then open:

```text
https://suitsmafia.com/suits/v21_ai_ml_dashboard.php
```
