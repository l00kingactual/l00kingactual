#!/usr/bin/env bash
set -euo pipefail

SUITS_ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
SUITS_SITE_ROOT="${SUITS_SITE_ROOT:-$SUITS_ROOT/susitsmafia_website}"
SUITS_TOOLS="$SUITS_ROOT/tools"
SUITS_OUT="$SUITS_ROOT/outputs/suits_v21_ai_ml_site_organizer"

mkdir -p "$SUITS_TOOLS" "$SUITS_SITE_ROOT/data/v21_ai_ml" "$SUITS_OUT"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cp "$SCRIPT_DIR/tools/suits_v21_organize_ai_ml_site.py" "$SUITS_TOOLS/suits_v21_organize_ai_ml_site.py"
chmod +x "$SUITS_TOOLS/suits_v21_organize_ai_ml_site.py"

cat >/usr/local/bin/suits_v21_organize_ai_ml_site <<EOF
#!/usr/bin/env bash
exec /opt/suitsmafia/venv/bin/python "$SUITS_TOOLS/suits_v21_organize_ai_ml_site.py" --root "$SUITS_ROOT" "\$@"
EOF
chmod +x /usr/local/bin/suits_v21_organize_ai_ml_site

cat >"$SUITS_TOOLS/suits_v21_run_publish.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
suits_v21_organize_ai_ml_site --site-domain suitsmafia.com --publish "\$@"
EOF
chmod +x "$SUITS_TOOLS/suits_v21_run_publish.sh"

# Keep login rsync clean: no echo here.
if ! grep -q 'SUITS_ROOT=/home/andy/Documents/suitsmafia' /home/andy/.bashrc 2>/dev/null; then
cat >>/home/andy/.bashrc <<'EOF'

# $uit$ Mafia environment
export SUITS_ROOT=/home/andy/Documents/suitsmafia
export SUITS_SITE_ROOT=/home/andy/Documents/suitsmafia/susitsmafia_website
export SUITS_OUTPUT_ROOT=/home/andy/Documents/suitsmafia/outputs
export SUITS_TOOLS_ROOT=/home/andy/Documents/suitsmafia/tools
export SUITS_VENV=/opt/suitsmafia/venv
if [ -d "$SUITS_VENV/bin" ]; then export PATH="$SUITS_VENV/bin:$PATH"; fi
alias suits='cd /home/andy/Documents/suitsmafia'
alias suitssite='cd /home/andy/Documents/suitsmafia/susitsmafia_website'
alias suitsout='cd /home/andy/Documents/suitsmafia/outputs'
alias suitstools='cd /home/andy/Documents/suitsmafia/tools'
alias py='/opt/suitsmafia/venv/bin/python'
alias pip='py -m pip'
EOF
fi

chown -R suits:suits "$SUITS_ROOT" 2>/dev/null || true
setfacl -R -m u:andy:rwx "$SUITS_ROOT" 2>/dev/null || true
setfacl -R -d -m u:andy:rwx "$SUITS_ROOT" 2>/dev/null || true

cat <<MSG
[o][o] installed v21 organiser
run: suits_v21_organize_ai_ml_site --publish
web: $SUITS_SITE_ROOT/v21_ai_ml_dashboard.php
MSG
