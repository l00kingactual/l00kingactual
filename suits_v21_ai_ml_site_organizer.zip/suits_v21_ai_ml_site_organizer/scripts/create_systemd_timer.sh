#!/usr/bin/env bash
set -euo pipefail
cat >/etc/systemd/system/suits-v21-organise.service <<'SERVICE'
[Unit]
Description=$uits v21 AI/ML site organise and publish
After=network.target

[Service]
Type=oneshot
User=andy
Environment=SUITS_ROOT=/home/andy/Documents/suitsmafia
ExecStart=/usr/local/bin/suits_v21_organize_ai_ml_site --publish
SERVICE

cat >/etc/systemd/system/suits-v21-organise.timer <<'TIMER'
[Unit]
Description=Run $uits v21 AI/ML organiser every 30 minutes

[Timer]
OnBootSec=5min
OnUnitActiveSec=30min
Persistent=true

[Install]
WantedBy=timers.target
TIMER

systemctl daemon-reload
systemctl enable suits-v21-organise.timer
systemctl start suits-v21-organise.timer
systemctl status suits-v21-organise.timer --no-pager
