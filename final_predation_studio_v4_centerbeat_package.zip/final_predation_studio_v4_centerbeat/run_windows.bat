@echo off
cd /d "%~dp0"
py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python predation_studio_v4.py serve --host 127.0.0.1 --port 8790
pause
