# Programmatic description: Bat Out of Hell music-led GTA/FiveM edit

No lyrics are used or embedded. This is a timing/content cue description for an uploaded music file with measured duration **490.928 seconds**.

## Editorial shape

```text
ride → kill grammar → tension → hard burst → reset → mixed evidence board → team-play rise → chaos/funny switch → apex finale → aftermath
```

## Content-control model

Each section is a cue requirement. The renderer should use only assets from the inclusion list whose metadata satisfies the cue:

- time range
- scene and theme
- wanted content tags
- required event types
- allowed asset type: MP4, PNG, APNG
- subtitle mode
- sync anchor
- confidence gates
- graphic-intensity ceiling

## Key sync rule

For kill sections:

```text
kill_peak or kill_shot → strong beat / drop / phrase hit
```

For still sections:

```text
still_card → pause / phrase end / final beat
```

For funny sections:

```text
punchline_time → beat-punchline
```

## Shot-fire rule

`shot_fire` is video-first:

```text
centre pixels changed + white flash + centre motion + shotline + HUD mutation
```

Audio can support the decision, but it must be downweighted because montage audio is often music.
