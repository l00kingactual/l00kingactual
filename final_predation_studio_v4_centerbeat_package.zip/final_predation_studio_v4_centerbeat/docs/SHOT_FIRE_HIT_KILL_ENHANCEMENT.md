# Shot-fire, shot-hit and kill-shot enhancement

## Core correction

`shot_fire` should be detected primarily by **centre pixels changing**, not by audio.

Montage audio is often music, so audio is only supporting evidence.

## `shot_fire`

```text
ShotFire(t) = σ(
  centre_luminance_delta
+ centre_white_flash
+ centre_saturation_shift
+ recoil/centre-motion
+ shotline_edge_score
+ HUD_mutation
+ audio_impulse × audio_reliability
)
```

## `shot_hit`

A hit is a causal bridge after a shot:

```text
ShotHit(s,h) = ShotFire(s) × HitEvidence(h) × TimeFit(h-s) × ShotLineFit(s,h)
```

Evidence:

- red-impact / hit marker proxy
- target jolt / motion disruption
- impact flash
- shotline-to-target intersection
- OCR/server/manual truth boost when available

## `kill_shot`

A kill-shot is stricter:

```text
KillShot(s,k) = ShotFire(s) × KillEvidence(k) × TimeFit(k-s) × HitBridge(s,k) × TruthBoost
```

Truth hierarchy:

```text
server-confirmed > manual-labelled > OCR-confirmed > video-strong > video-inferred
```

## Finite-state model

```text
SEARCH → AIM/OPPORTUNITY → SHOT_FIRE → SHOT_HIT → WOUND/WING → KILL_SHOT → AFTERMATH → CHAIN_CONTINUE or CHAIN_BREAK
```

This reduces false positives: a red frame alone is not a kill; a centre-pixel shot impulse plus hit evidence plus kill confirmation is much stronger.
