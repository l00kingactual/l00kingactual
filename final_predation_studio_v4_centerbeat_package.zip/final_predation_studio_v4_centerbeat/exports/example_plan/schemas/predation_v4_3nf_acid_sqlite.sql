-- Final Predation Studio v4 — 3NF ACID SQLite schema
PRAGMA foreign_keys = ON;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS media_source(
  media_id TEXT PRIMARY KEY,
  path TEXT NOT NULL UNIQUE,
  filename TEXT NOT NULL,
  media_type TEXT NOT NULL,
  duration REAL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS music_track(
  music_id TEXT PRIMARY KEY,
  path TEXT NOT NULL UNIQUE,
  title TEXT,
  duration REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS music_beat(
  beat_id INTEGER PRIMARY KEY AUTOINCREMENT,
  music_id TEXT NOT NULL REFERENCES music_track(music_id) ON DELETE CASCADE,
  beat_time REAL NOT NULL,
  beat_strength REAL DEFAULT 1.0,
  beat_type TEXT DEFAULT 'beat'
);
CREATE TABLE IF NOT EXISTS cue_requirement(
  cue_id TEXT PRIMARY KEY,
  music_id TEXT REFERENCES music_track(music_id),
  start_time REAL NOT NULL,
  end_time REAL NOT NULL,
  scene TEXT NOT NULL,
  theme TEXT,
  subtitle_mode TEXT,
  sync_anchor TEXT,
  max_assets INTEGER DEFAULT 6,
  min_kill_confidence REAL DEFAULT 0,
  min_media_clarity REAL DEFAULT 0,
  max_graphic_intensity REAL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS cue_tag_requirement(
  cue_id TEXT NOT NULL REFERENCES cue_requirement(cue_id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  tag_role TEXT DEFAULT 'wanted',
  PRIMARY KEY(cue_id, tag, tag_role)
);
CREATE TABLE IF NOT EXISTS media_asset(
  asset_id TEXT PRIMARY KEY,
  media_id TEXT REFERENCES media_source(media_id),
  asset_path TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  duration REAL DEFAULT 0,
  source_truth TEXT DEFAULT 'video_inferred'
);
CREATE TABLE IF NOT EXISTS asset_tag(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  PRIMARY KEY(asset_id, tag)
);
CREATE TABLE IF NOT EXISTS event_anchor(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  anchor_name TEXT NOT NULL,
  anchor_time REAL NOT NULL,
  PRIMARY KEY(asset_id, anchor_name)
);
CREATE TABLE IF NOT EXISTS asset_score(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  score_name TEXT NOT NULL,
  score_value REAL NOT NULL CHECK(score_value >= 0 AND score_value <= 1),
  PRIMARY KEY(asset_id, score_name)
);
CREATE TABLE IF NOT EXISTS cue_asset_selection(
  selection_id INTEGER PRIMARY KEY AUTOINCREMENT,
  cue_id TEXT NOT NULL REFERENCES cue_requirement(cue_id) ON DELETE CASCADE,
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  rank_order INTEGER NOT NULL,
  match_score REAL NOT NULL,
  beat_fit REAL DEFAULT 0,
  planned_duration REAL DEFAULT 0,
  subtitle_text TEXT
);
COMMIT;
