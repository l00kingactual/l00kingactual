// Final Predation Studio v4 — Neo4j graph schema and static ontology
CREATE CONSTRAINT media_asset_id IF NOT EXISTS FOR (a:MediaAsset) REQUIRE a.asset_id IS UNIQUE;
CREATE CONSTRAINT cue_id IF NOT EXISTS FOR (c:CueRequirement) REQUIRE c.cue_id IS UNIQUE;
CREATE CONSTRAINT music_id IF NOT EXISTS FOR (m:MusicTrack) REQUIRE m.music_id IS UNIQUE;
CREATE CONSTRAINT tag_name IF NOT EXISTS FOR (t:Tag) REQUIRE t.name IS UNIQUE;

MERGE (:PredationType {name:'snake', label:'patient line-hold / trap'});
MERGE (:PredationType {name:'leopard', label:'ambush / hidden-angle strike'});
MERGE (:PredationType {name:'lion', label:'team-pack pressure'});
MERGE (:PredationType {name:'hyena', label:'poach / finishing opportunism'});
MERGE (:PredationType {name:'wasp', label:'harassment / chip-pressure'});
MERGE (:PredationType {name:'shark', label:'vehicle/chase/circling pressure'});
MERGE (:PredationType {name:'kill-chain', label:'continuation without reload/death candidate'});
MERGE (:PredationType {name:'graphic_spectacle', label:'red-impact / visual spectacle'});

MERGE (:AutoTune {name:'beat_synced_kill_chain'});
MERGE (:AutoTune {name:'serious_apex'});
MERGE (:AutoTune {name:'funny_poach'});
MERGE (:AutoTune {name:'graphic_spectacle'});

// Example import shape:
// (:MusicTrack)-[:HAS_CUE]->(:CueRequirement)-[:WANTS_TAG]->(:Tag)
// (:CueRequirement)-[:SELECTS {rank,score,beat_fit}]->(:MediaAsset)
// (:MediaAsset)-[:HAS_TAG]->(:Tag)
// (:MediaAsset)-[:HAS_ANCHOR {time}]->(:Anchor {name:'kill_peak'})
// (:MediaAsset)-[:CLASSIFIED_AS]->(:PredationType)
