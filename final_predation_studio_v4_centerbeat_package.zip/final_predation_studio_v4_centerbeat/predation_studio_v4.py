#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Final Predation Studio v4 — Centre-Pixel Beat-Sync Workbench
============================================================

Local/offline-first FastAPI + CLI workbench for fictional GTA/FiveM gameplay
media analytics and music-led montage production planning.

Boundary
--------
This is for fictional gameplay / machinima / media-analysis. It is not real-world
weapon guidance. Terms such as shot, kill, predation and prey are in-game media
labels and cinematic metaphors.

Core upgrade in v4
------------------
1. Centre-pixel / centre-patch shot_fire detector:
   shot_fire is driven mainly by centre-screen pixel change, not audio.
2. Content-aware music auto-tune:
   cue-sheet rows can specify time, theme, scene requirements, wanted tags,
   asset types, sync anchor, subtitle mode and confidence limits.
3. Beat-to-shot/kill synchronisation plan:
   music beats/drops/section markers are aligned to shot_fire, shot_hit,
   kill_shot, kill_peak, punchline or chain anchors.
4. Quality-not-quantity curation:
   defaults to 6 assets per media classification, including kill-chain.
5. Always-runs fallbacks:
   if OpenCV/numpy/ffmpeg are missing, the app still inventories files and emits
   JSON/HTML/SQL/Cypher planning assets.

Run WebUI
---------
    python3 predation_studio_v4.py serve --host 127.0.0.1 --port 8790

Run CLI plan/export
-------------------
    python3 predation_studio_v4.py build \
      --input-folder /mnt/data \
      --music "Meat Loaf - Bat Out of Hell (PCM Stereo) [3QGMCSCFoKA].webm" \
      --cue-sheet cue_sheets/bat_out_of_hell_programmatic_cue_sheet.json \
      --auto-tune beat_synced_kill_chain \
      --out-dir exports/bat_out_of_hell_plan
"""
from __future__ import annotations

import argparse
import csv
import dataclasses
import hashlib
import html
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

try:
    import cv2  # type: ignore
except Exception:  # pragma: no cover
    cv2 = None  # type: ignore

try:
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
    from pydantic import BaseModel
except Exception:  # pragma: no cover
    FastAPI = None  # type: ignore
    HTTPException = Exception  # type: ignore
    HTMLResponse = None  # type: ignore
    JSONResponse = None  # type: ignore
    FileResponse = None  # type: ignore
    BaseModel = object  # type: ignore

VIDEO_EXTS = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".apng"}
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".webm"}
MEDIA_EXTS = VIDEO_EXTS | IMAGE_EXTS
EPS = 1e-9

# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def clamp01(x: float) -> float:
    try:
        if math.isnan(x) or math.isinf(x):
            return 0.0
    except Exception:
        return 0.0
    return max(0.0, min(1.0, float(x)))


def sigmoid(x: float, k: float = 1.0, centre: float = 0.0) -> float:
    z = max(-60.0, min(60.0, k * (float(x) - centre)))
    return 1.0 / (1.0 + math.exp(-z))


def safe_slug(text: str, max_len: int = 96) -> str:
    text = re.sub(r"\[[A-Za-z0-9_-]{6,24}\]$", "", text)
    text = re.sub(r"[^a-zA-Z0-9]+", "_", text).strip("_").lower()
    return (text[:max_len].strip("_") or "asset")


def stable_id(path: Path) -> str:
    h = hashlib.sha1(str(path).encode("utf-8", "ignore")).hexdigest()[:10]
    return f"{safe_slug(path.stem, 54)}__{h}"


def parse_time(value: Any) -> float:
    """Parse seconds, MM:SS or HH:MM:SS into seconds."""
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip()
    if not s:
        return 0.0
    if ":" not in s:
        return float(s)
    parts = [float(p) for p in s.split(":")]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    raise ValueError(f"Bad time format: {value!r}")


def fmt_time(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    m = int(seconds // 60)
    s = seconds - m * 60
    return f"{m:02d}:{s:05.2f}"


def ffprobe_duration(path: Path) -> float:
    if shutil.which("ffprobe") is None:
        return 0.0
    try:
        out = subprocess.check_output([
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=nw=1:nk=1", str(path)
        ], text=True, stderr=subprocess.DEVNULL).strip()
        return float(out)
    except Exception:
        return 0.0


def run(cmd: Sequence[str], quiet: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(list(cmd), check=True, stdout=subprocess.DEVNULL if quiet else None,
                          stderr=subprocess.DEVNULL if quiet else None)

# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class CueRequirement:
    cue_id: str
    start: float
    end: float
    scene: str
    theme: str
    wanted_tags: List[str] = field(default_factory=list)
    required_event_types: List[str] = field(default_factory=list)
    allowed_asset_types: List[str] = field(default_factory=lambda: ["mp4"])
    subtitle_mode: str = "kill_comments"
    sync_anchor: str = "kill_peak"
    preferred_music_anchor: str = "beat_or_drop"
    min_kill_confidence: float = 0.0
    min_media_clarity: float = 0.0
    max_graphic_intensity: float = 1.0
    clip_duration_min: float = 2.0
    clip_duration_max: float = 12.0
    max_assets: int = 6
    notes: str = ""


@dataclass
class AssetMetadata:
    asset_id: str
    path: str
    filename: str
    asset_type: str
    duration: float = 0.0
    tags: List[str] = field(default_factory=list)
    anchors: Dict[str, float] = field(default_factory=dict)
    scores: Dict[str, float] = field(default_factory=dict)
    comments: Dict[str, str] = field(default_factory=dict)
    source_truth: str = "video_inferred"


@dataclass
class MusicBeatMap:
    path: str
    duration: float
    beats: List[float] = field(default_factory=list)
    strong_beats: List[float] = field(default_factory=list)
    energy_peaks: List[float] = field(default_factory=list)
    sections: List[Dict[str, Any]] = field(default_factory=list)

# ---------------------------------------------------------------------------
# Auto-tune presets
# ---------------------------------------------------------------------------

AUTO_TUNES: Dict[str, Dict[str, Any]] = {
    "beat_synced_kill_chain": {
        "label": "🎵⛓️ Beat-synced kill chain",
        "weights": {
            "tag_match": 1.30,
            "shot_fire_confidence": 0.90,
            "shot_hit_confidence": 1.05,
            "kill_shot_confidence": 1.50,
            "kill_chain_score": 1.45,
            "media_clarity": 1.25,
            "beat_sync": 1.60,
            "novelty": 0.80,
            "graphic_intensity": 0.35,
            "repetition_penalty": -1.15,
            "weak_evidence_penalty": -1.50,
        },
        "sync_anchor": "kill_peak",
        "subtitle_mode": "kill_comments",
    },
    "serious_apex": {
        "label": "🦁 Serious apex",
        "weights": {
            "kill_shot_confidence": 1.55,
            "shotline_quality": 1.25,
            "media_clarity": 1.50,
            "apex_ratio": 1.30,
            "chain_score": 1.00,
            "graphic_intensity": 0.25,
            "humour": -0.45,
            "weak_evidence_penalty": -1.40,
        },
        "sync_anchor": "kill_peak",
        "subtitle_mode": "serious_cort60",
    },
    "funny_poach": {
        "label": "😂🦝 Funny poach",
        "weights": {
            "hyena_poach": 1.50,
            "humour": 1.35,
            "reversal": 1.25,
            "beat_sync": 1.35,
            "media_clarity": 1.10,
            "kill_shot_confidence": 0.75,
            "graphic_intensity": 0.15,
        },
        "sync_anchor": "punchline_time",
        "subtitle_mode": "funny_comments",
    },
    "graphic_spectacle": {
        "label": "🩸 Graphic spectacle / red-impact",
        "weights": {
            "graphic_intensity": 1.40,
            "red_impact": 1.35,
            "kill_shot_confidence": 1.10,
            "media_clarity": 1.25,
            "visual_confusion": -1.20,
            "weak_evidence_penalty": -1.25,
        },
        "sync_anchor": "impact_peak",
        "subtitle_mode": "kill_comments",
    },
    "snake_trap": {
        "label": "🐍 Snake trap",
        "weights": {"snake": 1.40, "aim_stability": 1.30, "shotline_quality": 1.20, "media_clarity": 1.20},
        "sync_anchor": "shot_fire",
        "subtitle_mode": "serious_cort60",
    },
}

# ---------------------------------------------------------------------------
# Media scanning and centre-pixel / centre-patch analysis
# ---------------------------------------------------------------------------

class CentrePixelShotModel:
    """Video-first shot_fire model.

    shot_fire is treated as centre-patch pixel change:
        Δ centre luminance + white flash + centre colour/saturation shift
        + centre motion/recoil + shotline edge confidence + HUD change
        + audio impulse * audio reliability

    Audio is optional and intentionally downweighted under music masking.
    """

    def __init__(self, sample_fps: float = 8.0, max_seconds: float = 0.0) -> None:
        self.sample_fps = max(0.5, float(sample_fps))
        self.max_seconds = max(0.0, float(max_seconds))

    def analyse_video(self, path: Path) -> AssetMetadata:
        asset = AssetMetadata(
            asset_id=stable_id(path),
            path=str(path),
            filename=path.name,
            asset_type=path.suffix.lower().lstrip("."),
            duration=ffprobe_duration(path),
            tags=[],
            anchors={},
            scores={},
            comments={},
        )
        if cv2 is None or np is None or path.suffix.lower() not in VIDEO_EXTS:
            self._fallback_asset_tags(asset)
            return asset

        cap = cv2.VideoCapture(str(path))
        if not cap.isOpened():
            self._fallback_asset_tags(asset)
            return asset

        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        duration = asset.duration or (total / fps if fps else 0.0)
        asset.duration = duration
        step = max(1, int(round(fps / self.sample_fps)))
        max_frames = total
        if self.max_seconds > 0:
            max_frames = min(max_frames, int(self.max_seconds * fps))

        times: List[float] = []
        shot_fire_vals: List[float] = []
        shotline_vals: List[float] = []
        red_vals: List[float] = []
        hit_vals: List[float] = []
        motion_vals: List[float] = []
        clarity_vals: List[float] = []
        prev_centre_gray = None
        prev_gray = None
        prev_topright = None

        idx = 0
        while idx < max_frames:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ok, frame = cap.read()
            if not ok:
                break
            t = idx / fps
            small = cv2.resize(frame, (480, 270), interpolation=cv2.INTER_AREA)
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
            h, w = gray.shape[:2]
            # Centre pixels: tight crosshair patch + wider centre context.
            cx0, cx1 = int(w * 0.43), int(w * 0.57)
            cy0, cy1 = int(h * 0.40), int(h * 0.60)
            centre_gray = gray[cy0:cy1, cx0:cx1]
            centre_hsv = hsv[cy0:cy1, cx0:cx1]
            centre_bgr = small[cy0:cy1, cx0:cx1]

            # 1) centre pixel changes
            if prev_centre_gray is not None and prev_centre_gray.shape == centre_gray.shape:
                d = cv2.absdiff(centre_gray, prev_centre_gray)
                delta_luma = float(np.mean(d)) / 255.0
                white_flash = float(np.mean((centre_gray > 220).astype(np.float32)))
                recoil_motion = delta_luma  # pragmatic centre camera jerk proxy
            else:
                delta_luma = 0.0
                white_flash = float(np.mean((centre_gray > 220).astype(np.float32)))
                recoil_motion = 0.0

            # centre colour/saturation shift
            sat = float(np.mean(centre_hsv[:, :, 1])) / 255.0
            hue_shift = 0.0
            # red impact candidate in central/global lower area
            b, g, r = cv2.split(centre_bgr)
            red_dom = np.maximum(r.astype(np.float32) - np.maximum(g, b).astype(np.float32), 0)
            centre_red = float(np.mean(red_dom)) / 255.0
            # top-right HUD mutation proxy
            tr = gray[0:int(h * 0.25), int(w * 0.58):w]
            if prev_topright is not None and tr.shape == prev_topright.shape:
                hud_mut = float(np.mean(cv2.absdiff(tr, prev_topright))) / 255.0
            else:
                hud_mut = 0.0
            # shotline: central edge/line confidence
            shotline = self._shotline_score(gray, prev_gray)
            # hit evidence: red + central marker-like contrast + HUD change
            hit_marker = self._hit_marker_proxy(centre_gray)
            hit = clamp01(0.45 * hit_marker + 0.30 * centre_red * 3.0 + 0.25 * hud_mut * 3.0)
            # clarity: not too blurry/chaotic; enough contrast/edges
            clarity = self._clarity_score(gray)
            motion = delta_luma
            # audio intentionally absent here; audio handled separately with reliability.
            raw = (
                1.55 * delta_luma +
                1.10 * white_flash +
                0.45 * sat +
                1.15 * recoil_motion +
                1.40 * shotline +
                0.85 * hud_mut +
                0.40 * hit_marker
            )
            shot_fire = sigmoid(raw, k=3.0, centre=1.35)
            times.append(t)
            shot_fire_vals.append(shot_fire)
            shotline_vals.append(shotline)
            red_vals.append(clamp01(centre_red * 4.0))
            hit_vals.append(hit)
            motion_vals.append(motion)
            clarity_vals.append(clarity)
            prev_centre_gray = centre_gray.copy()
            prev_gray = gray.copy()
            prev_topright = tr.copy()
            idx += step
        cap.release()

        if not times:
            self._fallback_asset_tags(asset)
            return asset

        # Anchor extraction
        peak_idx = int(np.argmax(np.asarray(shot_fire_vals))) if np is not None else max(range(len(shot_fire_vals)), key=shot_fire_vals.__getitem__)
        shot_fire_t = times[peak_idx]
        hit_idx = self._nearest_future_peak(times, hit_vals, shot_fire_t, 1.25)
        hit_t = times[hit_idx] if hit_idx is not None else min(duration, shot_fire_t + 0.25)
        # kill_shot is a stricter causal bridge: shot_fire + hit + red/HUD/motion in a valid window.
        kill_score_vals = []
        for i, t in enumerate(times):
            dt = max(0.0, t - shot_fire_t)
            timefit = math.exp(-(dt * dt) / (2 * 0.90 * 0.90)) if 0 <= dt <= 2.5 else 0.0
            kill_score_vals.append(clamp01(0.40 * hit_vals[i] + 0.30 * red_vals[i] + 0.20 * shotline_vals[peak_idx] + 0.10 * timefit))
        kill_idx = self._nearest_future_peak(times, kill_score_vals, shot_fire_t, 2.5)
        kill_t = times[kill_idx] if kill_idx is not None else min(duration, shot_fire_t + 0.65)

        asset.anchors.update({
            "lead_in": max(0.0, shot_fire_t - 1.2),
            "shot_fire": shot_fire_t,
            "shot_hit": hit_t,
            "hit_peak": hit_t,
            "kill_shot": kill_t,
            "kill_peak": kill_t,
            "impact_peak": hit_t,
            "punchline_time": kill_t,
            "aftermath": min(duration, kill_t + 1.5),
        })
        shot_fire_conf = max(shot_fire_vals)
        hit_conf = max(hit_vals)
        kill_conf = max(kill_score_vals)
        graphic = clamp01(0.55 * max(red_vals) + 0.25 * max(motion_vals) + 0.20 * hit_conf)
        media_clarity = sum(clarity_vals) / max(1, len(clarity_vals))
        shotline_q = max(shotline_vals)
        chain_score = clamp01(0.35 * kill_conf + 0.25 * shotline_q + 0.20 * media_clarity + 0.20 * (1.0 - graphic * 0.35))
        asset.scores.update({
            "shot_fire_confidence": shot_fire_conf,
            "shot_hit_confidence": hit_conf,
            "kill_shot_confidence": kill_conf,
            "shotline_quality": shotline_q,
            "red_impact": max(red_vals),
            "graphic_intensity": graphic,
            "media_clarity": media_clarity,
            "kill_chain_score": chain_score,
            "chain_score": chain_score,
            "apex_ratio": clamp01((kill_conf + shotline_q + media_clarity) / 3.0),
            "humour": 0.0,
            "visual_confusion": clamp01(1.0 - media_clarity),
        })
        self._classify_tags(asset)
        return asset

    def _nearest_future_peak(self, times: List[float], vals: List[float], start: float, horizon: float) -> Optional[int]:
        candidates = [(i, v) for i, (t, v) in enumerate(zip(times, vals)) if start <= t <= start + horizon]
        if not candidates:
            return None
        return max(candidates, key=lambda x: x[1])[0]

    def _shotline_score(self, gray: Any, prev_gray: Any) -> float:
        if cv2 is None or np is None:
            return 0.0
        h, w = gray.shape[:2]
        cx0, cx1 = int(w * 0.28), int(w * 0.72)
        cy0, cy1 = int(h * 0.28), int(h * 0.72)
        roi = gray[cy0:cy1, cx0:cx1]
        edges = cv2.Canny(cv2.GaussianBlur(roi, (3, 3), 0), 80, 180)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=18, minLineLength=20, maxLineGap=6)
        if lines is None:
            return 0.0
        rh, rw = roi.shape[:2]
        rcx, rcy = rw / 2.0, rh / 2.0
        best = 0.0
        for line in lines[:, 0, :]:
            x1, y1, x2, y2 = map(float, line)
            length = math.hypot(x2 - x1, y2 - y1)
            if length < 12:
                continue
            denom = math.hypot(y2 - y1, x2 - x1) + EPS
            dist = abs((y2 - y1) * rcx - (x2 - x1) * rcy + x2 * y1 - y2 * x1) / denom
            centre_align = math.exp(-(dist * dist) / (2 * (0.12 * min(rh, rw)) ** 2 + EPS))
            len_score = clamp01(length / math.hypot(rw, rh) * 3.5)
            best = max(best, clamp01(0.55 * len_score + 0.45 * centre_align))
        return best

    def _hit_marker_proxy(self, centre_gray: Any) -> float:
        if cv2 is None or np is None:
            return 0.0
        edges = cv2.Canny(centre_gray, 80, 180)
        bright = float(np.mean((centre_gray > 210).astype(np.float32)))
        edge = float(np.mean((edges > 0).astype(np.float32)))
        contrast = float(np.std(centre_gray)) / 255.0
        return clamp01(0.45 * bright * 8.0 + 0.35 * edge * 5.0 + 0.20 * contrast)

    def _clarity_score(self, gray: Any) -> float:
        if cv2 is None or np is None:
            return 0.5
        lap = cv2.Laplacian(gray, cv2.CV_64F).var()
        edge_density = float(np.mean(cv2.Canny(gray, 80, 160) > 0))
        blur_score = clamp01(lap / 450.0)
        useful_edges = clamp01(edge_density * 8.0)
        return clamp01(0.55 * blur_score + 0.45 * useful_edges)

    def _classify_tags(self, asset: AssetMetadata) -> None:
        s = asset.scores
        tags = set(asset.tags)
        tags.add("video_inferred")
        tags.add("mp4" if asset.asset_type == "mp4" else asset.asset_type)
        if s.get("shot_fire_confidence", 0) >= 0.55:
            tags.add("shot_fire")
        if s.get("shot_hit_confidence", 0) >= 0.45:
            tags.add("shot_hit")
        if s.get("kill_shot_confidence", 0) >= 0.55:
            tags.add("kill_shot")
            tags.add("dramatic")
        if s.get("kill_chain_score", 0) >= 0.60:
            tags.add("kill-chain")
        if s.get("graphic_intensity", 0) >= 0.55:
            tags.add("graphic_spectacle")
            tags.add("red-impact")
        if s.get("shotline_quality", 0) >= 0.55:
            tags.add("shotline")
            tags.add("snake")
        if s.get("media_clarity", 0) >= 0.65 and s.get("kill_shot_confidence", 0) >= 0.55:
            tags.add("leopard")
        if s.get("chain_score", 0) >= 0.62:
            tags.add("lion")
        asset.tags = sorted(tags)
        asset.comments.update({
            "serious": "#FIP centre-pixel shot_fire · #CAF shotline + cover + vulnerability",
            "kill_comments": "#KILL-SHOT centre pixels changed · verify with OCR/server/manual truth",
            "funny": "#PO pattern-switch · the beat turns the hit into a punchline",
            "graphic": "#RED-IMPACT graphic spectacle cue · capped intensity",
        })

    def _fallback_asset_tags(self, asset: AssetMetadata) -> None:
        low = asset.filename.lower()
        tags = {asset.asset_type, "inventory_only"}
        for token in ["kill", "gunfire", "highlight", "montage", "disciples", "mc", "chain", "blood", "gta", "fivem"]:
            if token in low:
                tags.add(token)
        if asset.asset_type in {"png", "jpg", "jpeg", "webp"}:
            tags.add("still")
        elif asset.asset_type in {"gif", "apng"}:
            tags.add("apng_loop")
        else:
            tags.add("mp4")
            tags.add("video_inferred")
        asset.tags = sorted(tags)
        asset.scores.update({
            "shot_fire_confidence": 0.0,
            "shot_hit_confidence": 0.0,
            "kill_shot_confidence": 0.0,
            "media_clarity": 0.35,
            "graphic_intensity": 0.0,
            "kill_chain_score": 0.0,
        })
        asset.anchors.update({"lead_in": 0.0, "shot_fire": 1.0, "shot_hit": 1.2, "kill_peak": 1.5, "kill_shot": 1.5})

# ---------------------------------------------------------------------------
# Music beat map and cue matching
# ---------------------------------------------------------------------------

class MusicAnalyser:
    def analyse(self, path: Path, fallback_duration: float = 0.0) -> MusicBeatMap:
        duration = ffprobe_duration(path) or fallback_duration
        beats = self._audio_onsets(path, duration)
        if not beats:
            # Useful fallback: assume roughly 138 BPM rock grid for planning only.
            interval = 60.0 / 138.0
            beats = [round(i * interval, 3) for i in range(int(duration / interval) + 1)] if duration else []
        strong = beats[::4] if beats else []
        energy_peaks = beats[::16] if beats else []
        return MusicBeatMap(str(path), duration, beats, strong, energy_peaks, [])

    def _audio_onsets(self, path: Path, duration: float) -> List[float]:
        if np is None or shutil.which("ffmpeg") is None or not path.exists():
            return []
        import tempfile
        raw = Path(tempfile.mktemp(suffix=".raw"))
        try:
            subprocess.run([
                "ffmpeg", "-v", "error", "-y", "-i", str(path), "-ac", "1", "-ar", "16000",
                "-f", "s16le", str(raw)
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            data = np.fromfile(str(raw), dtype=np.int16).astype(np.float32) / 32768.0
        except Exception:
            return []
        finally:
            try:
                raw.unlink()
            except Exception:
                pass
        if data.size < 16000:
            return []
        sr = 16000
        win = int(0.050 * sr)
        hop = int(0.025 * sr)
        rms = []
        ts = []
        for start in range(0, len(data) - win, hop):
            seg = data[start:start+win]
            rms.append(float(np.sqrt(np.mean(seg * seg))))
            ts.append((start + win / 2) / sr)
        arr = np.asarray(rms)
        onset = np.maximum(0, np.diff(arr, prepend=arr[0]))
        if onset.size == 0:
            return []
        thresh = np.percentile(onset, 92)
        peaks: List[float] = []
        last = -999.0
        for i in range(1, len(onset)-1):
            if onset[i] >= thresh and onset[i] >= onset[i-1] and onset[i] >= onset[i+1]:
                t = ts[i]
                if t - last >= 0.18:  # suppress micro-double triggers
                    peaks.append(round(t, 3))
                    last = t
        return peaks[:3000]


def load_cue_sheet(path: Path) -> List[CueRequirement]:
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = data.get("cues", data if isinstance(data, list) else [])
    cues: List[CueRequirement] = []
    for idx, row in enumerate(rows, 1):
        cues.append(CueRequirement(
            cue_id=row.get("cue_id", f"cue_{idx:03d}"),
            start=parse_time(row.get("start", 0)),
            end=parse_time(row.get("end", 0)),
            scene=row.get("scene", row.get("theme", "scene")),
            theme=row.get("theme", ""),
            wanted_tags=list(row.get("wanted_tags", row.get("content_tags", []))),
            required_event_types=list(row.get("required_event_types", [])),
            allowed_asset_types=list(row.get("allowed_asset_types", row.get("asset_types", ["mp4"]))),
            subtitle_mode=row.get("subtitle_mode", "kill_comments"),
            sync_anchor=row.get("sync_anchor", "kill_peak"),
            preferred_music_anchor=row.get("preferred_music_anchor", "beat_or_drop"),
            min_kill_confidence=float(row.get("min_kill_confidence", 0.0)),
            min_media_clarity=float(row.get("min_media_clarity", 0.0)),
            max_graphic_intensity=float(row.get("max_graphic_intensity", 1.0)),
            clip_duration_min=float(row.get("clip_duration_min", 2.0)),
            clip_duration_max=float(row.get("clip_duration_max", 12.0)),
            max_assets=int(row.get("max_assets", 6)),
            notes=row.get("notes", ""),
        ))
    return cues


def scan_assets(folder: Path, sample_fps: float = 8.0, max_seconds: float = 0.0) -> List[AssetMetadata]:
    model = CentrePixelShotModel(sample_fps=sample_fps, max_seconds=max_seconds)
    assets: List[AssetMetadata] = []
    for p in sorted(folder.rglob("*")):
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        if ext in MEDIA_EXTS:
            if ext in VIDEO_EXTS:
                assets.append(model.analyse_video(p))
            else:
                a = AssetMetadata(stable_id(p), str(p), p.name, ext.lstrip("."), 0.0)
                a.tags = ["still" if ext not in {".gif", ".apng"} else "apng_loop", ext.lstrip("."), "image_asset"]
                a.scores = {"media_clarity": 0.65, "graphic_intensity": 0.0, "kill_shot_confidence": 0.0}
                a.anchors = {"still_card": 0.0, "punchline_time": 0.0, "kill_peak": 0.0}
                a.comments = {"serious": "#STILL impact card", "kill_comments": "#MEDIA evidence still"}
                assets.append(a)
    return assets


def score_asset_for_cue(asset: AssetMetadata, cue: CueRequirement, tune: Dict[str, Any], used_ids: set[str]) -> float:
    weights = tune.get("weights", {})
    asset_tags = set(t.lower() for t in asset.tags)
    wanted = set(t.lower() for t in cue.wanted_tags)
    required = set(t.lower() for t in cue.required_event_types)
    ext_ok = asset.asset_type.lower() in {x.lower().lstrip(".") for x in cue.allowed_asset_types}
    if not ext_ok:
        return -999.0
    if asset.scores.get("kill_shot_confidence", 0.0) < cue.min_kill_confidence:
        return -999.0
    if asset.scores.get("media_clarity", 0.0) < cue.min_media_clarity:
        return -999.0
    if asset.scores.get("graphic_intensity", 0.0) > cue.max_graphic_intensity:
        return -999.0
    if required and not required.intersection(asset_tags) and not any(r in asset.scores for r in required):
        # Soft fail: if required tags are absent, penalise heavily rather than hard fail.
        req_penalty = -1.0
    else:
        req_penalty = 0.0
    tag_match = len(wanted.intersection(asset_tags)) / max(1, len(wanted)) if wanted else 0.0
    novelty = 0.0 if asset.asset_id in used_ids else 1.0
    score = 0.0
    score += weights.get("tag_match", 1.0) * tag_match
    for k, v in asset.scores.items():
        score += weights.get(k, 0.0) * float(v)
    # alias mapping
    aliases = {
        "kill_chain_score": asset.scores.get("kill_chain_score", asset.scores.get("chain_score", 0.0)),
        "chain_score": asset.scores.get("chain_score", 0.0),
        "shotline_quality": asset.scores.get("shotline_quality", 0.0),
        "red_impact": asset.scores.get("red_impact", 0.0),
        "hyena_poach": 1.0 if "hyena" in asset_tags or "poach" in asset_tags else 0.0,
        "snake": 1.0 if "snake" in asset_tags else 0.0,
        "graphic_intensity": asset.scores.get("graphic_intensity", 0.0),
        "media_clarity": asset.scores.get("media_clarity", 0.0),
        "novelty": novelty,
    }
    for k, val in aliases.items():
        score += weights.get(k, 0.0) * float(val)
    score += req_penalty
    score += weights.get("repetition_penalty", -1.0) * (1.0 - novelty)
    score += weights.get("weak_evidence_penalty", -1.0) * (1.0 - asset.scores.get("media_clarity", 0.0)) * 0.25
    return score


def match_cues(assets: List[AssetMetadata], cues: List[CueRequirement], beatmap: MusicBeatMap, auto_tune: str) -> Dict[str, Any]:
    tune = AUTO_TUNES.get(auto_tune, AUTO_TUNES["beat_synced_kill_chain"])
    used: set[str] = set()
    cue_results = []
    for cue in cues:
        scored = []
        for asset in assets:
            s = score_asset_for_cue(asset, cue, tune, used)
            if s > -100:
                # beat fit: nearest beat to where the selected anchor would land in cue.
                anchor = asset.anchors.get(cue.sync_anchor, asset.anchors.get("kill_peak", 0.0))
                if beatmap.strong_beats:
                    target = cue.start + min(max(anchor, 0.0), max(0.0, cue.end - cue.start))
                    nearest = min(beatmap.strong_beats, key=lambda b: abs(b - target))
                    beat_fit = math.exp(-((nearest - target) ** 2) / (2 * 0.18 * 0.18))
                else:
                    beat_fit = 0.5
                s += tune.get("weights", {}).get("beat_sync", 0.0) * beat_fit
                scored.append((s, beat_fit, asset))
        scored.sort(key=lambda x: x[0], reverse=True)
        selected = []
        remaining_time = max(0.0, cue.end - cue.start)
        for s, beat_fit, asset in scored:
            if len(selected) >= cue.max_assets:
                break
            dur = asset.duration or cue.clip_duration_min
            usable_dur = min(max(cue.clip_duration_min, min(dur, cue.clip_duration_max)), remaining_time if remaining_time > 0 else cue.clip_duration_max)
            if usable_dur < cue.clip_duration_min * 0.7 and cue.allowed_asset_types and "mp4" in cue.allowed_asset_types:
                continue
            selected.append({
                "asset": asdict(asset),
                "match_score": round(s, 5),
                "beat_fit": round(beat_fit, 5),
                "planned_duration": round(usable_dur, 3),
                "subtitle": make_subtitle(asset, cue),
            })
            used.add(asset.asset_id)
            remaining_time -= usable_dur
            if remaining_time <= 0:
                break
        cue_results.append({"cue": asdict(cue), "selected_assets": selected})
    return {"auto_tune": auto_tune, "created_at": now_iso(), "cue_results": cue_results}


def make_subtitle(asset: AssetMetadata, cue: CueRequirement) -> str:
    tags = set(t.lower() for t in asset.tags)
    if cue.subtitle_mode == "none":
        return ""
    if cue.subtitle_mode == "funny_comments":
        return asset.comments.get("funny") or "#PO pattern-switch · #PMI funny timing"
    if cue.subtitle_mode == "serious_cort60":
        return asset.comments.get("serious") or "#FIP decisive shotline · #CAF cover + vulnerability"
    if "graphic_spectacle" in tags or "red-impact" in tags:
        return "#RED-IMPACT graphic spectacle cue · #PMI verify truth"
    if "kill-chain" in tags:
        return "#KILL-CHAIN no-reload/no-death candidate · #C&S next opportunity"
    return asset.comments.get("kill_comments") or "#KILL-SHOT centre pixels changed · verify truth"

# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------

def write_html_report(out: Path, result: Dict[str, Any], beatmap: MusicBeatMap) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    path = out / "curated_music_cue_report.html"
    cards = []
    for cr in result["cue_results"]:
        cue = cr["cue"]
        rows = []
        for item in cr["selected_assets"]:
            a = item["asset"]
            preview = ""
            if a["asset_type"] in {"mp4", "mkv", "webm", "mov"}:
                preview = f"<video controls preload='metadata' src='{html.escape(a['path'])}'></video>"
            elif a["asset_type"] in {"png", "jpg", "jpeg", "webp", "gif", "apng"}:
                preview = f"<img src='{html.escape(a['path'])}' />"
            rows.append(f"""
            <article class='asset'>{preview}<div class='pad'>
              <h4>{html.escape(a['filename'])}</h4>
              <p><b>Score:</b> {item['match_score']} · <b>Beat fit:</b> {item['beat_fit']} · <b>Plan:</b> {item['planned_duration']}s</p>
              <p><b>Tags:</b> {', '.join(html.escape(t) for t in a.get('tags', []))}</p>
              <p class='sub'>{html.escape(item.get('subtitle',''))}</p>
            </div></article>
            """)
        cards.append(f"""
        <section class='cue'>
          <h2>{fmt_time(cue['start'])}–{fmt_time(cue['end'])} · {html.escape(cue['scene'])}</h2>
          <p><b>Theme:</b> {html.escape(cue.get('theme',''))}</p>
          <p><b>Wanted:</b> {', '.join(html.escape(t) for t in cue.get('wanted_tags', []))}</p>
          <div class='grid'>{''.join(rows) or '<p>No matching assets selected.</p>'}</div>
        </section>
        """)
    path.write_text(f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
    <title>Final Predation Studio v4 Cue Report</title>
    <style>
    body{{margin:0;background:#07111f;color:#edf7ff;font-family:system-ui,Segoe UI,sans-serif}}.wrap{{max-width:1300px;margin:auto;padding:24px}}
    .hero{{background:linear-gradient(135deg,#13213b,#101827);border:1px solid #2c4468;border-radius:24px;padding:22px}}
    .cue{{margin-top:28px;border-top:1px solid #223855;padding-top:18px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:14px}}
    .asset{{background:#0e1a2c;border:1px solid #27415f;border-radius:18px;overflow:hidden}}video,img{{width:100%;max-height:260px;object-fit:cover;background:#02060b}}
    .pad{{padding:12px}}.sub{{color:#fbdf7a}}code{{background:#02060b;padding:2px 5px;border-radius:5px}}
    </style></head><body><div class='wrap'><section class='hero'><h1>🎵🎬 Final Predation Studio v4</h1>
    <p>Centre-pixel shot_fire + content-aware music cue-sheet report.</p>
    <p><b>Music duration:</b> {beatmap.duration:.2f}s · <b>Beats:</b> {len(beatmap.beats)} · <b>Auto-tune:</b> {html.escape(result.get('auto_tune',''))}</p>
    </section>{''.join(cards)}<section class='cue'><h2>Exports</h2><p>Full JSON, SQL and Cypher are written beside this report.</p></section></div></body></html>""", encoding="utf-8")
    return path


def write_srt(out: Path, result: Dict[str, Any]) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    p = out / "kill_comments_cort60_cue_sheet.srt"
    lines = []
    n = 1
    for cr in result["cue_results"]:
        cue = cr["cue"]
        start = float(cue["start"])
        for item in cr["selected_assets"]:
            dur = float(item.get("planned_duration", 4.0))
            end = min(float(cue["end"]), start + min(4.5, dur))
            text = item.get("subtitle") or "#KILL-SHOT centre pixels changed"
            lines.append(str(n))
            lines.append(f"{srt_time(start)} --> {srt_time(end)}")
            lines.append(text)
            lines.append("")
            n += 1
            start += dur
    p.write_text("\n".join(lines), encoding="utf-8")
    return p


def srt_time(t: float) -> str:
    h = int(t // 3600); t -= h * 3600
    m = int(t // 60); t -= m * 60
    s = int(t); ms = int(round((t-s)*1000))
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_sqlite_schema(out: Path) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    p = out / "predation_v4_3nf_acid_sqlite.sql"
    p.write_text("""-- Final Predation Studio v4 — 3NF ACID SQLite schema
PRAGMA foreign_keys = ON;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS media_source(
  media_id TEXT PRIMARY KEY,
  path TEXT NOT NULL UNIQUE,
  filename TEXT NOT NULL,
  media_type TEXT NOT NULL,
  duration REAL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS music_track(
  music_id TEXT PRIMARY KEY,
  path TEXT NOT NULL UNIQUE,
  title TEXT,
  duration REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS music_beat(
  beat_id INTEGER PRIMARY KEY AUTOINCREMENT,
  music_id TEXT NOT NULL REFERENCES music_track(music_id) ON DELETE CASCADE,
  beat_time REAL NOT NULL,
  beat_strength REAL DEFAULT 1.0,
  beat_type TEXT DEFAULT 'beat'
);
CREATE TABLE IF NOT EXISTS cue_requirement(
  cue_id TEXT PRIMARY KEY,
  music_id TEXT REFERENCES music_track(music_id),
  start_time REAL NOT NULL,
  end_time REAL NOT NULL,
  scene TEXT NOT NULL,
  theme TEXT,
  subtitle_mode TEXT,
  sync_anchor TEXT,
  max_assets INTEGER DEFAULT 6,
  min_kill_confidence REAL DEFAULT 0,
  min_media_clarity REAL DEFAULT 0,
  max_graphic_intensity REAL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS cue_tag_requirement(
  cue_id TEXT NOT NULL REFERENCES cue_requirement(cue_id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  tag_role TEXT DEFAULT 'wanted',
  PRIMARY KEY(cue_id, tag, tag_role)
);
CREATE TABLE IF NOT EXISTS media_asset(
  asset_id TEXT PRIMARY KEY,
  media_id TEXT REFERENCES media_source(media_id),
  asset_path TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  duration REAL DEFAULT 0,
  source_truth TEXT DEFAULT 'video_inferred'
);
CREATE TABLE IF NOT EXISTS asset_tag(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  PRIMARY KEY(asset_id, tag)
);
CREATE TABLE IF NOT EXISTS event_anchor(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  anchor_name TEXT NOT NULL,
  anchor_time REAL NOT NULL,
  PRIMARY KEY(asset_id, anchor_name)
);
CREATE TABLE IF NOT EXISTS asset_score(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  score_name TEXT NOT NULL,
  score_value REAL NOT NULL CHECK(score_value >= 0 AND score_value <= 1),
  PRIMARY KEY(asset_id, score_name)
);
CREATE TABLE IF NOT EXISTS cue_asset_selection(
  selection_id INTEGER PRIMARY KEY AUTOINCREMENT,
  cue_id TEXT NOT NULL REFERENCES cue_requirement(cue_id) ON DELETE CASCADE,
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  rank_order INTEGER NOT NULL,
  match_score REAL NOT NULL,
  beat_fit REAL DEFAULT 0,
  planned_duration REAL DEFAULT 0,
  subtitle_text TEXT
);
COMMIT;
""", encoding="utf-8")
    return p


def write_postgres_schema(out: Path) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    p = out / "predation_v4_3nf_acid_postgres.sql"
    p.write_text("""-- Final Predation Studio v4 — 3NF ACID PostgreSQL schema
BEGIN;
CREATE TABLE IF NOT EXISTS media_source(
  media_id TEXT PRIMARY KEY,
  path TEXT NOT NULL UNIQUE,
  filename TEXT NOT NULL,
  media_type TEXT NOT NULL,
  duration DOUBLE PRECISION DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE IF NOT EXISTS music_track(
  music_id TEXT PRIMARY KEY,
  path TEXT NOT NULL UNIQUE,
  title TEXT,
  duration DOUBLE PRECISION DEFAULT 0
);
CREATE TABLE IF NOT EXISTS music_beat(
  beat_id BIGSERIAL PRIMARY KEY,
  music_id TEXT NOT NULL REFERENCES music_track(music_id) ON DELETE CASCADE,
  beat_time DOUBLE PRECISION NOT NULL,
  beat_strength DOUBLE PRECISION DEFAULT 1.0,
  beat_type TEXT DEFAULT 'beat'
);
CREATE TABLE IF NOT EXISTS cue_requirement(
  cue_id TEXT PRIMARY KEY,
  music_id TEXT REFERENCES music_track(music_id),
  start_time DOUBLE PRECISION NOT NULL,
  end_time DOUBLE PRECISION NOT NULL,
  scene TEXT NOT NULL,
  theme TEXT,
  subtitle_mode TEXT,
  sync_anchor TEXT,
  max_assets INTEGER DEFAULT 6,
  min_kill_confidence DOUBLE PRECISION DEFAULT 0,
  min_media_clarity DOUBLE PRECISION DEFAULT 0,
  max_graphic_intensity DOUBLE PRECISION DEFAULT 1
);
CREATE TABLE IF NOT EXISTS cue_tag_requirement(
  cue_id TEXT NOT NULL REFERENCES cue_requirement(cue_id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  tag_role TEXT DEFAULT 'wanted',
  PRIMARY KEY(cue_id, tag, tag_role)
);
CREATE TABLE IF NOT EXISTS media_asset(
  asset_id TEXT PRIMARY KEY,
  media_id TEXT REFERENCES media_source(media_id),
  asset_path TEXT NOT NULL,
  asset_type TEXT NOT NULL,
  duration DOUBLE PRECISION DEFAULT 0,
  source_truth TEXT DEFAULT 'video_inferred'
);
CREATE TABLE IF NOT EXISTS asset_tag(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  PRIMARY KEY(asset_id, tag)
);
CREATE TABLE IF NOT EXISTS event_anchor(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  anchor_name TEXT NOT NULL,
  anchor_time DOUBLE PRECISION NOT NULL,
  PRIMARY KEY(asset_id, anchor_name)
);
CREATE TABLE IF NOT EXISTS asset_score(
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  score_name TEXT NOT NULL,
  score_value DOUBLE PRECISION NOT NULL CHECK(score_value >= 0 AND score_value <= 1),
  PRIMARY KEY(asset_id, score_name)
);
CREATE TABLE IF NOT EXISTS cue_asset_selection(
  selection_id BIGSERIAL PRIMARY KEY,
  cue_id TEXT NOT NULL REFERENCES cue_requirement(cue_id) ON DELETE CASCADE,
  asset_id TEXT NOT NULL REFERENCES media_asset(asset_id) ON DELETE CASCADE,
  rank_order INTEGER NOT NULL,
  match_score DOUBLE PRECISION NOT NULL,
  beat_fit DOUBLE PRECISION DEFAULT 0,
  planned_duration DOUBLE PRECISION DEFAULT 0,
  subtitle_text TEXT
);
COMMIT;
""", encoding="utf-8")
    return p


def write_cypher(out: Path) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    p = out / "predation_v4_neo4j.cypher"
    p.write_text("""// Final Predation Studio v4 — Neo4j graph schema and static ontology
CREATE CONSTRAINT media_asset_id IF NOT EXISTS FOR (a:MediaAsset) REQUIRE a.asset_id IS UNIQUE;
CREATE CONSTRAINT cue_id IF NOT EXISTS FOR (c:CueRequirement) REQUIRE c.cue_id IS UNIQUE;
CREATE CONSTRAINT music_id IF NOT EXISTS FOR (m:MusicTrack) REQUIRE m.music_id IS UNIQUE;
CREATE CONSTRAINT tag_name IF NOT EXISTS FOR (t:Tag) REQUIRE t.name IS UNIQUE;

MERGE (:PredationType {name:'snake', label:'patient line-hold / trap'});
MERGE (:PredationType {name:'leopard', label:'ambush / hidden-angle strike'});
MERGE (:PredationType {name:'lion', label:'team-pack pressure'});
MERGE (:PredationType {name:'hyena', label:'poach / finishing opportunism'});
MERGE (:PredationType {name:'wasp', label:'harassment / chip-pressure'});
MERGE (:PredationType {name:'shark', label:'vehicle/chase/circling pressure'});
MERGE (:PredationType {name:'kill-chain', label:'continuation without reload/death candidate'});
MERGE (:PredationType {name:'graphic_spectacle', label:'red-impact / visual spectacle'});

MERGE (:AutoTune {name:'beat_synced_kill_chain'});
MERGE (:AutoTune {name:'serious_apex'});
MERGE (:AutoTune {name:'funny_poach'});
MERGE (:AutoTune {name:'graphic_spectacle'});

// Example import shape:
// (:MusicTrack)-[:HAS_CUE]->(:CueRequirement)-[:WANTS_TAG]->(:Tag)
// (:CueRequirement)-[:SELECTS {rank,score,beat_fit}]->(:MediaAsset)
// (:MediaAsset)-[:HAS_TAG]->(:Tag)
// (:MediaAsset)-[:HAS_ANCHOR {time}]->(:Anchor {name:'kill_peak'})
// (:MediaAsset)-[:CLASSIFIED_AS]->(:PredationType)
""", encoding="utf-8")
    return p


def build_exports(input_folder: Path, music_path: Optional[Path], cue_sheet: Path, out_dir: Path, auto_tune: str, sample_fps: float = 8.0, max_seconds: float = 30.0) -> Dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    cues = load_cue_sheet(cue_sheet)
    assets = scan_assets(input_folder, sample_fps=sample_fps, max_seconds=max_seconds)
    beatmap = MusicAnalyser().analyse(music_path, fallback_duration=max(c.end for c in cues) if music_path else max(c.end for c in cues)) if music_path else MusicBeatMap("", max(c.end for c in cues), [], [], [], [])
    result = match_cues(assets, cues, beatmap, auto_tune)
    (out_dir / "asset_inventory.json").write_text(json.dumps([asdict(a) for a in assets], indent=2), encoding="utf-8")
    (out_dir / "music_beat_map.json").write_text(json.dumps(asdict(beatmap), indent=2), encoding="utf-8")
    (out_dir / "cue_match_plan.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    write_html_report(out_dir, result, beatmap)
    write_srt(out_dir, result)
    write_sqlite_schema(out_dir / "schemas")
    write_postgres_schema(out_dir / "schemas")
    write_cypher(out_dir / "graph")
    return {"out_dir": str(out_dir), "assets": len(assets), "cues": len(cues), "html": str(out_dir / "curated_music_cue_report.html")}

# ---------------------------------------------------------------------------
# WebUI
# ---------------------------------------------------------------------------

INDEX_HTML = r"""
<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Final Predation Studio v4</title>
<style>
:root{--bg:#07111f;--card:#0f1b2f;--line:#29415f;--txt:#edf7ff;--muted:#9fb5cf;--gold:#ffd66b;--cyan:#7dd3fc;--pink:#fb71c7;--green:#88f7a5}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top left,#13213a,#07111f 45%,#050913);color:var(--txt);font-family:system-ui,Segoe UI,sans-serif}.wrap{max-width:1420px;margin:auto;padding:22px}.hero{background:linear-gradient(135deg,#14233d,#101829);border:1px solid var(--line);border-radius:26px;padding:22px;box-shadow:0 20px 60px #0007}h1{margin:0;font-size:34px}h2{margin-top:0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(330px,1fr));gap:16px;margin-top:18px}.card{background:linear-gradient(180deg,#101d32,#0b1424);border:1px solid var(--line);border-radius:20px;padding:16px}.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.pill{padding:5px 10px;border:1px solid #3b587b;border-radius:999px;color:var(--cyan);font-size:13px}.btn{background:#1d4ed8;color:white;border:0;border-radius:12px;padding:10px 14px;cursor:pointer;font-weight:700}.btn.alt{background:#374151}.btn.good{background:#15803d}.btn.warn{background:#b45309}input,select,textarea{width:100%;background:#061020;border:1px solid #31506f;color:var(--txt);border-radius:12px;padding:10px;margin:6px 0}textarea{min-height:110px}pre{white-space:pre-wrap;background:#03070d;border:1px solid #1f344e;border-radius:12px;padding:12px;max-height:360px;overflow:auto}.small{color:var(--muted);font-size:13px}.tag{display:inline-block;border:1px solid #4f6784;border-radius:999px;padding:2px 7px;margin:2px;font-size:12px}.accent{color:var(--gold)}.pink{color:var(--pink)}.green{color:var(--green)}
</style></head><body><div class="wrap"><section class="hero"><h1>🎵🎬 Final Predation Studio v4</h1><p class="small">Centre-pixel <b>shot_fire</b> + content-cue music auto-tune + kill comments. Fictional gameplay/machinima media analytics only.</p><div class="row"><span class="pill">👁️ video-first</span><span class="pill">🎯 centre pixels changed</span><span class="pill">🎵 beat sync</span><span class="pill">⛓️ kill-chain</span><span class="pill">🩸 red-impact capped</span><span class="pill">🧭 CoRT60 captions</span></div></section>
<div class="grid">
<section class="card"><h2>📁 Asset scan</h2><label>Input folder</label><input id="folder" value="/mnt/data"><label>Sample FPS</label><input id="sample_fps" type="number" value="8"><label>Max seconds per video for fast analysis</label><input id="max_seconds" type="number" value="30"><button class="btn" onclick="scanAssets()">Scan / analyse centre pixels</button><p class="small">shot_fire is mostly centre-patch luminance/white flash/motion/shotline/HUD change. Audio is not trusted by default.</p></section>
<section class="card"><h2>🎵 Music + cue sheet</h2><label>Music path</label><input id="music" value="/mnt/data/Meat Loaf - Bat Out of Hell (PCM Stereo) [3QGMCSCFoKA].webm"><label>Cue sheet JSON path</label><input id="cue" value="cue_sheets/bat_out_of_hell_programmatic_cue_sheet.json"><label>Auto-tune</label><select id="auto"><option>beat_synced_kill_chain</option><option>serious_apex</option><option>funny_poach</option><option>graphic_spectacle</option><option>snake_trap</option></select><button class="btn good" onclick="buildPlan()">Build cue-match plan</button></section>
<section class="card"><h2>🎛️ Cue content requirements</h2><p class="small">Each cue can request scene/theme/kill types/content tags/asset types/subtitle style/sync anchor. Example row:</p><pre>{
  "start":"0:23", "end":"1:32",
  "scene":"kill type showcase",
  "wanted_tags":["snake","leopard","lion","hyena","kill-chain"],
  "required_event_types":["shot_fire","shot_hit","kill_shot"],
  "sync_anchor":"kill_peak",
  "subtitle_mode":"kill_comments"
}</pre></section>
<section class="card"><h2>🎯 Shot / hit / kill calibration</h2><div class="row"><span class="tag">shot_fire = centre pixels change</span><span class="tag">shot_hit = shot + hit evidence + time-fit</span><span class="tag">kill_shot = shot → hit → kill bridge</span></div><p class="small">Future sliders: shot threshold, hit delay, kill delay, red-impact weight, shotline weight, OCR/server/manual truth boost.</p></section>
</div><section class="card" style="margin-top:16px"><h2>Output</h2><pre id="out">Ready.</pre></section>
</div><script>
async function scanAssets(){let body={folder:folder.value,sample_fps:parseFloat(sample_fps.value),max_seconds:parseFloat(max_seconds.value)};out.textContent='Scanning...';let r=await fetch('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});out.textContent=JSON.stringify(await r.json(),null,2)}
async function buildPlan(){let body={folder:folder.value,music:music.value,cue_sheet:cue.value,auto_tune:auto.value,sample_fps:parseFloat(sample_fps.value),max_seconds:parseFloat(max_seconds.value)};out.textContent='Building plan...';let r=await fetch('/api/build',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});out.textContent=JSON.stringify(await r.json(),null,2)}
</script></body></html>
"""


def create_app() -> Any:
    if FastAPI is None:
        raise RuntimeError("FastAPI is not installed. Install requirements.txt or run CLI mode.")
    app = FastAPI(title="Final Predation Studio v4")

    class ScanReq(BaseModel):
        folder: str
        sample_fps: float = 8.0
        max_seconds: float = 30.0

    class BuildReq(BaseModel):
        folder: str
        music: str = ""
        cue_sheet: str = "cue_sheets/bat_out_of_hell_programmatic_cue_sheet.json"
        auto_tune: str = "beat_synced_kill_chain"
        sample_fps: float = 8.0
        max_seconds: float = 30.0
        out_dir: str = "exports/webui_build"

    @app.get("/", response_class=HTMLResponse)
    def index():
        return INDEX_HTML

    @app.post("/api/scan")
    def api_scan(req: ScanReq):
        folder = Path(req.folder).expanduser()
        if not folder.exists():
            raise HTTPException(status_code=404, detail=f"Folder not found: {folder}")
        assets = scan_assets(folder, req.sample_fps, req.max_seconds)
        return {"count": len(assets), "assets": [asdict(a) for a in assets[:200]]}

    @app.post("/api/build")
    def api_build(req: BuildReq):
        base = Path(__file__).resolve().parent
        folder = Path(req.folder).expanduser()
        cue = Path(req.cue_sheet)
        if not cue.is_absolute():
            cue = base / cue
        music = Path(req.music).expanduser() if req.music else None
        out = Path(req.out_dir)
        if not out.is_absolute():
            out = base / out
        if not folder.exists():
            raise HTTPException(status_code=404, detail=f"Folder not found: {folder}")
        if not cue.exists():
            raise HTTPException(status_code=404, detail=f"Cue sheet not found: {cue}")
        summary = build_exports(folder, music, cue, out, req.auto_tune, req.sample_fps, req.max_seconds)
        return summary

    @app.get("/api/auto_tunes")
    def api_auto_tunes():
        return AUTO_TUNES

    return app

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Final Predation Studio v4")
    sub = parser.add_subparsers(dest="cmd", required=True)
    serve = sub.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8790)
    build = sub.add_parser("build")
    build.add_argument("--input-folder", required=True)
    build.add_argument("--music", default="")
    build.add_argument("--cue-sheet", default="cue_sheets/bat_out_of_hell_programmatic_cue_sheet.json")
    build.add_argument("--auto-tune", default="beat_synced_kill_chain")
    build.add_argument("--out-dir", default="exports/cli_build")
    build.add_argument("--sample-fps", type=float, default=8.0)
    build.add_argument("--max-seconds", type=float, default=30.0)
    scan = sub.add_parser("scan")
    scan.add_argument("--input-folder", required=True)
    scan.add_argument("--out", default="asset_inventory.json")
    scan.add_argument("--sample-fps", type=float, default=8.0)
    scan.add_argument("--max-seconds", type=float, default=30.0)
    args = parser.parse_args(argv)
    if args.cmd == "serve":
        import uvicorn  # type: ignore
        uvicorn.run(create_app(), host=args.host, port=args.port)
        return 0
    if args.cmd == "scan":
        assets = scan_assets(Path(args.input_folder).expanduser(), args.sample_fps, args.max_seconds)
        Path(args.out).write_text(json.dumps([asdict(a) for a in assets], indent=2), encoding="utf-8")
        print(f"Wrote {args.out} ({len(assets)} assets)")
        return 0
    if args.cmd == "build":
        base = Path(__file__).resolve().parent
        cue = Path(args.cue_sheet)
        if not cue.is_absolute():
            cue = base / cue
        summary = build_exports(
            Path(args.input_folder).expanduser(),
            Path(args.music).expanduser() if args.music else None,
            cue,
            Path(args.out_dir).expanduser(),
            args.auto_tune,
            args.sample_fps,
            args.max_seconds,
        )
        print(json.dumps(summary, indent=2))
        return 0
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
