# Final Predation Studio v4 — Centrebeat

A local/offline-first WebUI + Python CLI for fictional GTA/FiveM gameplay-media analysis and music-led cue-sheet planning.

## What is new

- **Centre-pixel `shot_fire` detector**: mainly based on centre-screen pixel changes, white flash, centre motion, shotline and HUD mutation.
- **Content-cue music auto-tune**: each music section can request scene/theme/content requirements such as `snake`, `leopard`, `lion`, `hyena`, `kill-chain`, `graphic_spectacle`, `still`, `apng_loop`.
- **Beat-to-kill sync plan**: align `shot_fire`, `shot_hit`, `kill_shot`, `kill_peak`, `punchline_time` or `still_card` to beat/phrase/drop markers.
- **Programmatic Bat Out of Hell cue sheet** in `cue_sheets/bat_out_of_hell_programmatic_cue_sheet.json`.
- **3NF ACID SQL + Neo4j Cypher** exports.

## Run WebUI

Linux:

```bash
chmod +x run_linux.sh
./run_linux.sh
```

Windows:

```text
run_windows.bat
```

Open:

```text
http://127.0.0.1:8790
```

## CLI example

```bash
python3 predation_studio_v4.py build \
  --input-folder /mnt/data \
  --music "/mnt/data/Meat Loaf - Bat Out of Hell (PCM Stereo) [3QGMCSCFoKA].webm" \
  --cue-sheet cue_sheets/bat_out_of_hell_programmatic_cue_sheet.json \
  --auto-tune beat_synced_kill_chain \
  --out-dir exports/bat_out_of_hell_plan \
  --sample-fps 8 \
  --max-seconds 30
```

## Safety boundary

This is for fictional gameplay/machinima media analytics and editing. Labels such as kill, shot, predation, prey and gore/graphic are in-game/media classifications only.
