-- Cymru Hive OS v2 3NF seed schema
CREATE TABLE hive (
  hive_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  place_scale TEXT NOT NULL,
  gps_lat REAL,
  gps_lon REAL,
  osgb_easting INTEGER,
  osgb_northing INTEGER,
  map_x_percent REAL,
  map_y_percent REAL,
  capacity INTEGER,
  risk INTEGER,
  notes TEXT
);
CREATE TABLE service (service_id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT);
CREATE TABLE hive_service (hive_id TEXT REFERENCES hive(hive_id), service_id TEXT REFERENCES service(service_id), PRIMARY KEY(hive_id, service_id));
CREATE TABLE bee (bee_id TEXT PRIMARY KEY, age_stage TEXT, home_scale TEXT, current_hive_id TEXT REFERENCES hive(hive_id), role_id TEXT);
CREATE TABLE metric_key (metric_group TEXT, metric_key TEXT, PRIMARY KEY(metric_group, metric_key));
CREATE TABLE bee_metric (bee_id TEXT REFERENCES bee(bee_id), metric_group TEXT, metric_key TEXT, value REAL, PRIMARY KEY(bee_id, metric_group, metric_key));
CREATE TABLE auto_tune (tune_id TEXT PRIMARY KEY, tune_index INTEGER, age TEXT, name TEXT, age_stage TEXT, home_scale TEXT, description TEXT);
CREATE TABLE auto_tune_delta (tune_id TEXT REFERENCES auto_tune(tune_id), metric_group TEXT, metric_key TEXT, delta REAL, PRIMARY KEY(tune_id, metric_group, metric_key));
CREATE TABLE bee_event (event_id INTEGER PRIMARY KEY AUTOINCREMENT, bee_id TEXT, event_time TEXT, event_type TEXT, hive_id TEXT, tune_id TEXT, payload_json TEXT);


-- SPACE WALE$ v3 long-billion infrastructure budget extension
CREATE TABLE budget_model (
  budget_id TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  scale_note TEXT NOT NULL,
  total_gbp NUMERIC NOT NULL,
  total_long_billions REAL,
  years INTEGER,
  population_assumption INTEGER,
  annual_gbp NUMERIC,
  per_person_gbp NUMERIC,
  per_person_per_year_gbp NUMERIC
);

CREATE TABLE budget_allocation (
  allocation_id TEXT PRIMARY KEY,
  budget_id TEXT REFERENCES budget_model(budget_id),
  name TEXT NOT NULL,
  icon TEXT,
  percent REAL,
  amount_gbp NUMERIC,
  purpose TEXT
);

CREATE TABLE compute_depth_layer (
  compute_layer_id TEXT PRIMARY KEY,
  budget_id TEXT REFERENCES budget_model(budget_id),
  name TEXT NOT NULL,
  icon TEXT,
  amount_gbp NUMERIC,
  purpose TEXT
);

CREATE TABLE infrastructure_layer (
  layer_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  icon TEXT,
  purpose TEXT
);

CREATE TABLE infrastructure_layer_item (
  layer_id TEXT REFERENCES infrastructure_layer(layer_id),
  item_name TEXT NOT NULL,
  PRIMARY KEY(layer_id, item_name)
);

CREATE TABLE strategic_thinker (
  thinker_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tool TEXT,
  application TEXT
);

INSERT INTO budget_model (
  budget_id, label, scale_note, total_gbp, total_long_billions, years,
  population_assumption, annual_gbp, per_person_gbp, per_person_per_year_gbp
) VALUES (
  'space_wales_long_billion_v3',
  '£2.5bn WALE$ budget',
  'old long-scale billion: 1 billion = 10^12 pounds',
  2500000000000,
  2.5,
  25,
  3200000,
  100000000000,
  781250,
  31250
);
INSERT INTO budget_allocation VALUES ('compute_depth', 'space_wales_long_billion_v3', 'Super-advanced compute depth', '🧠', 18, 450000000000, 'Sovereign cloud, HPC, AI, data centres, virtual workstations, storage and backup.');
INSERT INTO budget_allocation VALUES ('education_learning', 'space_wales_long_billion_v3', 'Education + lifelong learning', '🏫', 14, 350000000000, 'Schools, libraries, curriculum, Welsh-language tools, age-5 astronomy and lifelong accounts.');
INSERT INTO budget_allocation VALUES ('health_prevention', 'space_wales_long_billion_v3', 'Health + prevention', '🩺', 12, 300000000000, 'GP prevention, sports health, analytics, active lives, mental wellbeing and rural health access.');
INSERT INTO budget_allocation VALUES ('agrarian_wales', 'space_wales_long_billion_v3', 'Agrarian WALE$ infrastructure', '🌾', 12, 300000000000, 'SPACE Farmers, farms, animal guilds, food, water, soil, orchards, meadows and rural robotics.');
INSERT INTO budget_allocation VALUES ('transport_services', 'space_wales_long_billion_v3', 'Transport + service-comb access', '🚌', 10, 250000000000, 'Bus, rail, community taxi, school transport, ambulance/fire access and rural pickup points.');
INSERT INTO budget_allocation VALUES ('enterprise_apprenticeships', 'space_wales_long_billion_v3', 'Enterprise + apprenticeships', '💼', 10, 250000000000, 'SME compute vouchers, start-ups, maker hubs, farm tech, coaching businesses and college-to-work pipelines.');
INSERT INTO budget_allocation VALUES ('space_gis_sensors', 'space_wales_long_billion_v3', 'Space, GIS, sensors, astronomy', '🛰️', 8, 200000000000, 'Satellite imagery, Welsh dark skies, GIS, field sensors, astronomy pathway and Earth-observation tools.');
INSERT INTO budget_allocation VALUES ('hive_places', 'space_wales_long_billion_v3', 'Hives: hamlets, villages, towns, cities', '🏘️', 6, 150000000000, 'Local hubs, parks, sports fields, community halls, civic assets and regional place infrastructure.');
INSERT INTO budget_allocation VALUES ('animal_ecology', 'space_wales_long_billion_v3', 'Animal guilds + ecology', '🐑', 4, 100000000000, 'Sheep, cows, goats, chickens, ducks, geese, swans, donkeys, horses, ponies, bees and welfare systems.');
INSERT INTO budget_allocation VALUES ('cyber_resilience', 'space_wales_long_billion_v3', 'Cybersecurity + civil resilience', '🔐', 4, 100000000000, 'Identity, access control, secure backup, continuity, monitoring, emergency data and trusted infrastructure.');
INSERT INTO budget_allocation VALUES ('governance_evidence', 'space_wales_long_billion_v3', 'Governance, evidence, CoRT60, audit', '🧾', 2, 50000000000, 'Cymru Hive OS, SQL/Neo4j, honey reporting, audit, ethics, safeguards and programme evaluation.');
INSERT INTO compute_depth_layer VALUES ('national_data_centres', 'space_wales_long_billion_v3', 'National data centres', '🏛️', 120000000000, '3–5 sovereign compute cores, energy resilience, secure operations and Welsh public-service cloud.');
INSERT INTO compute_depth_layer VALUES ('regional_compute_hives', 'space_wales_long_billion_v3', 'Regional compute hives', '🏴', 80000000000, 'North, Mid, South West, South East and Valleys edge compute centres.');
INSERT INTO compute_depth_layer VALUES ('hpc_ai_gpu', 'space_wales_long_billion_v3', 'HPC / AI / GPU clusters', '🧠', 100000000000, 'Advanced simulation, health analytics, GIS, Welsh language AI, agritech and research workloads.');
INSERT INTO compute_depth_layer VALUES ('virtual_workstations', 'space_wales_long_billion_v3', 'Virtual workstation fabric', '💻', 80000000000, '4× i9-equivalent pooled VDI for advanced learners, apprentices, farms, SMEs and libraries.');
INSERT INTO compute_depth_layer VALUES ('storage_backup', 'space_wales_long_billion_v3', 'Storage + backup vaults', '🗄️', 40000000000, 'Citizen/project data, evidence archives, object storage, disaster recovery and long-term preservation.');
INSERT INTO compute_depth_layer VALUES ('cyber_hardening', 'space_wales_long_billion_v3', 'Cyber hardening', '🔐', 30000000000, 'Identity, access, monitoring, incident response, secure enclaves and continuity.');
INSERT INTO infrastructure_layer VALUES ('physical_hives', 'Physical hives', '🏘️', 'Places where people live, learn, play, receive care, travel and build civic identity.');
INSERT INTO infrastructure_layer_item VALUES ('physical_hives', 'household');
INSERT INTO infrastructure_layer_item VALUES ('physical_hives', 'hamlet');
INSERT INTO infrastructure_layer_item VALUES ('physical_hives', 'village');
INSERT INTO infrastructure_layer_item VALUES ('physical_hives', 'town');
INSERT INTO infrastructure_layer_item VALUES ('physical_hives', 'city');
INSERT INTO infrastructure_layer_item VALUES ('physical_hives', 'Wales');
INSERT INTO infrastructure_layer VALUES ('service_combs', 'Service combs', '🏥', 'Public and civic organs that make nectar accessible.');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'taxi');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'ambulance');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'fire');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'bus');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'train');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'school');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'college');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'university');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'library');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'GP');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'hospital');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'sportsField');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'park');
INSERT INTO infrastructure_layer_item VALUES ('service_combs', 'zoo');
INSERT INTO infrastructure_layer VALUES ('animal_guilds', 'Animal guilds', '🐑', 'Living curriculum, food systems, welfare practice, ecology and rural enterprise.');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'sheep');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'cows');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'goats');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'chickens');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'ducks');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'geese');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'swans');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'donkeys');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'horses');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'ponies');
INSERT INTO infrastructure_layer_item VALUES ('animal_guilds', 'bees');
INSERT INTO infrastructure_layer VALUES ('nectar_streams', 'Nectar streams', '🌸', 'Inputs received by each bee/person.');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'education');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'sport');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'health');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'learning');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'enterprise');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'ecology');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'astronomy');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'animalCare');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'foodSystems');
INSERT INTO infrastructure_layer_item VALUES ('nectar_streams', 'landStewardship');
INSERT INTO infrastructure_layer VALUES ('honey_outputs', 'Honey outputs', '🍯', 'Measurable civic value created by the system.');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'wellbeing');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'knowledge');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'sport');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'jobs');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'apprenticeships');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'invention');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'food');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'ecologicalRepair');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'civicPride');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'animalWelfare');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'ruralResilience');
INSERT INTO infrastructure_layer_item VALUES ('honey_outputs', 'WelshCulturalValue');
INSERT INTO infrastructure_layer VALUES ('data_compute', 'Data + compute', '💾', 'Infrastructure that makes learning, services, routes, honey and gaps visible.');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'SQL');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'Neo4j');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'GeoJSON');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'OSGB');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'GPS');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'VDI');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'HPC');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'AI');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'sensor data');
INSERT INTO infrastructure_layer_item VALUES ('data_compute', 'evidence ledger');
INSERT INTO strategic_thinker VALUES ('sun_tzu', 'Sun Tzu', 'Laying plans', 'Terrain first: read Wales as mountains, coast, valleys, farms, villages, services, routes, seasons and dark skies.');
INSERT INTO strategic_thinker VALUES ('de_bono', 'De Bono', 'CoRT60 cards', 'Every hive project receives PMI, CAF, C&S, AGO, FIP, APC, OPV and PISCO thinking metadata.');
INSERT INTO strategic_thinker VALUES ('mckinsey', 'McKinsey', '13S alignment', 'Align strategy, structure, systems, skills, staff, style, shared values, services, sites, sensors, safety, stories and surplus.');
INSERT INTO strategic_thinker VALUES ('porter', 'Porter', 'Activity-system fit', 'Sport, health, learning, agriculture, enterprise, transport and compute reinforce each other instead of fragmenting.');
INSERT INTO strategic_thinker VALUES ('drucker', 'Drucker', 'Management by objectives', 'Define customers, value, objectives and honey outputs while preventing data from replacing human judgement.');
INSERT INTO strategic_thinker VALUES ('kotler', 'Kotler', 'Value proposition', 'Different messages for children, parents, schools, farms, NHS, colleges, employers, councils and Wales.');
INSERT INTO strategic_thinker VALUES ('mintzberg', 'Mintzberg', 'Deliberate + emergent strategy', 'National standards and local invention: each hive adapts the pathway to its terrain.');


-- SPACE WALE$ v3.1 £10bn/year infrastructure budget model
INSERT INTO budget_model (
  budget_id, label, scale_note, total_gbp, total_long_billions, years,
  population_assumption, annual_gbp, per_person_gbp, per_person_per_year_gbp
) VALUES (
  'space_wales_10bn_year_v3_1',
  '£10bn/year WALE$ budget',
  'annual modern billion planning model: £10,000,000,000 per year',
  250000000000,
  0.25,
  25,
  3200000,
  10000000000,
  78125,
  3125
);
INSERT INTO budget_allocation VALUES ('v31_compute_depth', 'space_wales_10bn_year_v3_1', 'Super-advanced compute depth', '🧠', 18, 45000000000, 'Sovereign cloud, HPC, AI, data centres, virtual workstations, storage and backup.');
INSERT INTO budget_allocation VALUES ('v31_education_learning', 'space_wales_10bn_year_v3_1', 'Education + lifelong learning', '🏫', 14, 35000000000, 'Schools, libraries, curriculum, Welsh-language tools, age-5 astronomy and lifelong accounts.');
INSERT INTO budget_allocation VALUES ('v31_health_prevention', 'space_wales_10bn_year_v3_1', 'Health + prevention', '🩺', 12, 30000000000, 'GP prevention, sports health, analytics, active lives, mental wellbeing and rural health access.');
INSERT INTO budget_allocation VALUES ('v31_agrarian_wales', 'space_wales_10bn_year_v3_1', 'Agrarian WALE$ infrastructure', '🌾', 12, 30000000000, 'SPACE Farmers, farms, animal guilds, food, water, soil, orchards, meadows and rural robotics.');
INSERT INTO budget_allocation VALUES ('v31_transport_services', 'space_wales_10bn_year_v3_1', 'Transport + service-comb access', '🚌', 10, 25000000000, 'Bus, rail, community taxi, school transport, ambulance/fire access and rural pickup points.');
INSERT INTO budget_allocation VALUES ('v31_enterprise_apprenticeships', 'space_wales_10bn_year_v3_1', 'Enterprise + apprenticeships', '💼', 10, 25000000000, 'SME compute vouchers, start-ups, maker hubs, farm tech, coaching businesses and college-to-work pipelines.');
INSERT INTO budget_allocation VALUES ('v31_space_gis_sensors', 'space_wales_10bn_year_v3_1', 'Space, GIS, sensors, astronomy', '🛰️', 8, 20000000000, 'Satellite imagery, Welsh dark skies, GIS, field sensors, astronomy pathway and Earth-observation tools.');
INSERT INTO budget_allocation VALUES ('v31_hive_places', 'space_wales_10bn_year_v3_1', 'Hives: hamlets, villages, towns, cities', '🏘️', 6, 15000000000, 'Local hubs, parks, sports fields, community halls, civic assets and regional place infrastructure.');
INSERT INTO budget_allocation VALUES ('v31_animal_ecology', 'space_wales_10bn_year_v3_1', 'Animal guilds + ecology', '🐑', 4, 10000000000, 'Sheep, cows, goats, chickens, ducks, geese, swans, donkeys, horses, ponies, bees and welfare systems.');
INSERT INTO budget_allocation VALUES ('v31_cyber_resilience', 'space_wales_10bn_year_v3_1', 'Cybersecurity + civil resilience', '🔐', 4, 10000000000, 'Identity, access control, secure backup, continuity, monitoring, emergency data and trusted infrastructure.');
INSERT INTO budget_allocation VALUES ('v31_governance_evidence', 'space_wales_10bn_year_v3_1', 'Governance, evidence, CoRT60, audit', '🧾', 2, 5000000000, 'Cymru Hive OS, SQL/Neo4j, honey reporting, audit, ethics, safeguards and programme evaluation.');
INSERT INTO compute_depth_layer VALUES ('v31_national_data_centres', 'space_wales_10bn_year_v3_1', 'National data centres', '🏛️', 12000000015, '3–5 sovereign compute cores, energy resilience, secure operations and Welsh public-service cloud.');
INSERT INTO compute_depth_layer VALUES ('v31_regional_compute_hives', 'space_wales_10bn_year_v3_1', 'Regional compute hives', '🏴', 8000000010, 'North, Mid, South West, South East and Valleys edge compute centres.');
INSERT INTO compute_depth_layer VALUES ('v31_hpc_ai_gpu', 'space_wales_10bn_year_v3_1', 'HPC / AI / GPU clusters', '🧠', 9999999990, 'Advanced simulation, health analytics, GIS, Welsh language AI, agritech and research workloads.');
INSERT INTO compute_depth_layer VALUES ('v31_virtual_workstations', 'space_wales_10bn_year_v3_1', 'Virtual workstation fabric', '💻', 8000000010, '4× i9-equivalent pooled VDI for advanced learners, apprentices, farms, SMEs and libraries.');
INSERT INTO compute_depth_layer VALUES ('v31_storage_backup', 'space_wales_10bn_year_v3_1', 'Storage + backup vaults', '🗄️', 4000000005, 'Citizen/project data, evidence archives, object storage, disaster recovery and long-term preservation.');
INSERT INTO compute_depth_layer VALUES ('v31_cyber_hardening', 'space_wales_10bn_year_v3_1', 'Cyber hardening', '🔐', 2999999970, 'Identity, access, monitoring, incident response, secure enclaves and continuity.');
