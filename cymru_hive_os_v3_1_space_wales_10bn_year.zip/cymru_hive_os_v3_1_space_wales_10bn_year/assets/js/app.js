
(function(){
  const DATA = window.CYMRU_HIVE_DATA; const E = window.CymruEngine; const M = window.CymruMap; const UI = window.CymruUI; const $ = id => document.getElementById(id);
  const state = {bees:E.createBees(24), selectedBeeId:'bee-001', tuneIndex:0, running:true, tick:0, logLines:[]};
  function currentTune(){ return DATA.autoTunes[state.tuneIndex]; }
  function setTune(i, manual=false){
    state.tuneIndex = (i + DATA.autoTunes.length) % DATA.autoTunes.length;
    $('tuneMetric').textContent = `${state.tuneIndex+1}/24`; $('tuneSelect').value = String(state.tuneIndex);
    // Retarget all bees toward active hive types.
    const tune = currentTune(); const active = DATA.hives.filter(h => tune.activeHiveTypes.includes(h.type) || h.nectarTags.some(x => tune.activeHiveTypes.includes(x)));
    state.bees.forEach((b, idx) => { const target = (active.length ? active : DATA.hives)[idx % (active.length ? active.length : DATA.hives.length)]; b.targetHiveId = target.id; b.targetX = target.map.xPercent; b.targetY = target.map.yPercent; b.speed = 0.002 + Math.random()*0.004; });
    M.renderMarkers(state, hive => UI.selectHive(state, hive)); M.renderRoutes(state); UI.renderTuneButtons(state, setTune); UI.log(state, `${manual ? 'Manual' : 'Auto'} tune: ${tune.emoji} ${tune.name}`);
  }
  function reset(){ state.bees = E.createBees(24); state.selectedBeeId = 'bee-001'; setTune(0, true); UI.populateSelectors(state); UI.renderState(state); UI.log(state, 'All bee states reset'); }
  function step(){
    if(state.running){ state.tick++; const tune = currentTune(); state.bees.forEach((bee, idx) => E.stepBee(bee, tune, idx)); if(state.tick % 30 === 0) UI.renderState(state); M.renderBees(state, id => { state.selectedBeeId = id; UI.renderState(state); }); if(state.tick % 900 === 0) setTune(state.tuneIndex + 1); }
    requestAnimationFrame(step);
  }
  function bind(){
    $('playBtn').addEventListener('click', () => { state.running = !state.running; $('playBtn').textContent = state.running ? '▶ Auto-running' : '⏸ Paused'; $('playBtn').classList.toggle('active', state.running); UI.log(state, state.running ? 'Engine resumed' : 'Engine paused'); });
    $('nextTuneBtn').addEventListener('click', () => setTune(state.tuneIndex + 1, true)); $('resetBtn').addEventListener('click', reset); $('exportBtn').addEventListener('click', () => UI.exportState(state));
    $('beeSelect').addEventListener('change', e => { state.selectedBeeId = e.target.value; UI.renderState(state); }); $('tuneSelect').addEventListener('change', e => setTune(Number(e.target.value), true)); const strategyBtn = $('strategyBtn'); if (strategyBtn) strategyBtn.addEventListener('click', () => UI.showContent('strategy')); const budgetBtn = $('budgetBtn'); if (budgetBtn) budgetBtn.addEventListener('click', () => UI.showContent('budget'));
    document.querySelectorAll('[data-section]').forEach(b => b.addEventListener('click', () => UI.showContent(b.dataset.section)));
  }
  function init(){ UI.populateSelectors(state); bind(); setTune(0); UI.selectHive(state, DATA.hives[0]); UI.renderState(state); UI.showContent('overview'); UI.renderBudgetDashboard(); M.renderMarkers(state, hive => UI.selectHive(state, hive)); M.renderRoutes(state); M.renderBees(state, id => { state.selectedBeeId = id; UI.renderState(state); }); UI.log(state, 'Cymru Hive OS v3 SPACE WALE$ budget engine loaded'); step(); }
  init();
})();
