
(function(){
  const DATA = window.CYMRU_HIVE_DATA;
  const BUDGET = window.CYMRU_HIVE_BUDGET;
  const E = window.CymruEngine;
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  function preserveScroll(fn){
    const main = document.getElementById('mainScroll') || document.querySelector('.main');
    const mainTop = main ? main.scrollTop : 0;
    const winX = window.scrollX || 0;
    const winY = window.scrollY || 0;
    const active = document.activeElement;
    fn();
    if (main) main.scrollTop = mainTop;
    if (document.body.classList.contains('no-jump-app')) window.scrollTo(winX, winY);
    if (active && typeof active.blur === 'function' && active.classList && active.classList.contains('bee')) active.blur();
  }

  function money(n){
    if (n >= 1000000000000) return '£' + (n/1000000000000).toFixed(2).replace(/\.00$/,'') + 'tn';
    if (n >= 1000000000) return '£' + (n/1000000000).toFixed(1).replace(/\.0$/,'') + 'bn';
    if (n >= 1000000) return '£' + (n/1000000).toFixed(1).replace(/\.0$/,'') + 'm';
    return '£' + Math.round(n).toLocaleString();
  }
  function budgetCards(){
    const s = BUDGET.budget_semantics;
    return `<div class="card-grid">
      <div class="card"><h3>£ Total WALE$ budget</h3><p><strong>${money(s.total_gbp)}</strong></p><p>Annual model of £10bn/year; total over ${s.years} years is £${Math.round(s.total_modern_billions).toLocaleString()} modern billions.</p></div>
      <div class="card"><h3>📆 Annual civil build</h3><p><strong>${money(s.annual_gbp)} / year</strong></p><p>Fixed annual budget with a ${s.years}-year infrastructure horizon.</p></div>
      <div class="card"><h3>🐝 Per-person pathway value</h3><p><strong>£${Math.round(s.per_person_gbp).toLocaleString()}</strong></p><p>Approx. £${Math.round(s.per_person_per_year_gbp).toLocaleString()} per person per year using ${s.population_assumption.toLocaleString()} people.</p></div>
    </div>`;
  }
  function allocationBars(records, title='Strategic allocation'){
    const max = Math.max(...records.map(r => r.amount_gbp || 0));
    return `<div class="state-card"><h3>${title}</h3>${records.map(r => {
      const width = Math.round((r.amount_gbp / max) * 100);
      return `<div class="budget-row"><span>${r.icon || ''} ${esc(r.name || r.age_band)}</span><span class="bar"><i style="width:${width}%"></i></span><strong>${money(r.amount_gbp)}</strong><small>${esc(r.purpose || '')}</small></div>`;
    }).join('')}</div>`;
  }
  function budgetDashboardHTML(){
    return budgetCards() + `<div class="budget-split">${allocationBars(BUDGET.allocations, '🏗️ National infrastructure allocation')}</div>`;
  }
  function computeDepthHTML(){
    return `<div class="card-grid">
      <div class="card"><h3>💻 4× i9-equivalent VDI</h3><p>Delivered as pooled virtual workstation capability for advanced learners, apprentices, farms, SMEs, libraries and research users.</p></div>
      <div class="card"><h3>🧠 HPC + AI fabric</h3><p>Supports health modelling, GIS, Welsh language AI, agritech, SPACE Farmers, astronomy and enterprise simulation.</p></div>
      <div class="card"><h3>🔐 Resilient by design</h3><p>Data centres, regional hives, storage vaults, identity, access, monitoring and continuity.</p></div>
    </div>` + allocationBars(BUDGET.compute_depth, '🧠 Compute-in-depth split');
  }
  function ageBudgetHTML(){
    return `<div class="card-grid">
      <div class="card"><h3>🌙 Wonder → skill → apprenticeship</h3><p>The 24 auto-tunes become an investment ladder from age-5 Moon Wonder to SPACE Farmer capstone.</p></div>
      <div class="card"><h3>🍯 Funding follows pathway</h3><p>Budget is tied to age-stage capability: curiosity, sport, health, GIS, sensors, enterprise and apprenticeship conversion.</p></div>
      <div class="card"><h3>🧾 Evidence always</h3><p>Every tune can export bee state, honey output, service gaps and infrastructure requirements.</p></div>
    </div>` + allocationBars(BUDGET.age_band_budget, '🎚️ Age-stage investment ladder');
  }
  function infrastructureHTML(){
    return `<div class="card-grid">${BUDGET.infrastructure_layers.map(layer => `<div class="card"><h3>${layer.icon} ${esc(layer.name)}</h3><p>${esc(layer.purpose)}</p><p>${layer.items.map(x => `<span class="pill">${esc(x)}</span>`).join(' ')}</p></div>`).join('')}</div>`;
  }
  function thinkersHTML(){
    return `<table class="table"><thead><tr><th>Thinker</th><th>Tool</th><th>SPACE WALE$ infrastructure use</th></tr></thead><tbody>${BUDGET.strategic_thinkers.map(t => `<tr><td>${esc(t.thinker)}</td><td>${esc(t.tool)}</td><td>${esc(t.application)}</td></tr>`).join('')}</tbody></table>`;
  }
  function renderBudgetDashboard(){
    const el = document.getElementById('budgetDashboard');
    if (!el || !BUDGET) return;
    el.innerHTML = budgetDashboardHTML();
  }

  function log(state, msg){ state.logLines.unshift(`[${new Date().toLocaleTimeString()}] ${msg}`); state.logLines = state.logLines.slice(0, 14); $('consoleLog').textContent = state.logLines.join('\n'); }
  function selectedBee(state){ return state.bees.find(b => b.id === state.selectedBeeId) || state.bees[0]; }
  function renderBars(title, obj){
    return `<div class="state-card"><h3>${title}</h3>${Object.entries(obj).map(([k,v]) => `<div class="bar-row"><span>${esc(k)}</span><span class="bar"><i style="width:${Math.round(v)}%"></i></span><strong>${Math.round(v)}</strong></div>`).join('')}</div>`;
  }
  function renderState(state){
    const bee = selectedBee(state); if (!bee) return;
    preserveScroll(() => {
    $('beeSelect').value = bee.id; $('tuneSelect').value = String(state.tuneIndex);
    $('selectedBeeName').textContent = `${bee.emoji} ${bee.id}`;
    $('selectedBeeSummary').innerHTML = `${esc(bee.ageStage)} · role <strong>${esc(bee.role)}</strong> · home scale <strong>${esc(bee.homeScale)}</strong><br>hive <strong>${esc(bee.currentHive)}</strong> · GPS ${bee.gps.lat.toFixed(4)}, ${bee.gps.lon.toFixed(4)} · OSGB E ${bee.osgb36.easting} N ${bee.osgb36.northing}`;
    $('stateTitle').textContent = `${bee.id} · ${bee.ageStage} quantified pathway`;
    $('stateGrid').innerHTML = renderBars('🍯 Honey outputs', bee.honey)+renderBars('🌸 Nectar received', bee.nectar)+renderBars('🧠 Traits developed', bee.traits)+renderBars('🏡 Places moved through', bee.places)+renderBars('🏥 Service organs used', bee.services);
    const score = E.scoreBee(bee); $('honeyMetric').textContent = score.honeyIndex; $('traitMetric').textContent = score.traitIndex;
    });
  }
  function selectHive(state, hive){
    preserveScroll(() => {
    $('selectedHive').textContent = `${hive.icon} ${hive.name}`;
    $('selectedHiveText').innerHTML = `<strong>${esc(hive.type)}</strong> · ${esc(hive.placeScale)} hive node. ${esc(hive.notes)}`;
    $('gisTable').innerHTML = `<tr><th>GPS lat</th><td>${hive.gps.lat.toFixed(5)}</td></tr><tr><th>GPS lon</th><td>${hive.gps.lon.toFixed(5)}</td></tr><tr><th>OSGB E</th><td>${hive.osgb36.easting}</td></tr><tr><th>OSGB N</th><td>${hive.osgb36.northing}</td></tr><tr><th>Services</th><td>${hive.services.map(esc).join(', ')}</td></tr>`;
    log(state, `Hive selected: ${hive.name} GPS(${hive.gps.lat.toFixed(4)}, ${hive.gps.lon.toFixed(4)}) OSGB(${hive.osgb36.easting}, ${hive.osgb36.northing})`);
    });
  }
  function contentHTML(key){
    if (key === 'budget') return budgetDashboardHTML();
    if (key === 'allocations') return allocationBars(BUDGET.allocations, '🏗️ SPACE WALE$ strategic allocation');
    if (key === 'compute') return computeDepthHTML();
    if (key === 'ageBudget') return ageBudgetHTML();
    if (key === 'infrastructure') return infrastructureHTML();
    if (key === 'thinkers') return thinkersHTML();
    if (key === 'strategy') return `<div class="card-grid"><div class="card"><h3>🏴 National pathway map</h3><p>Every child can be mapped from age 5 into learning, sport, health, ecology, astronomy and enterprise pathways, with evidence of which services help them progress.</p></div><div class="card"><h3>🚑 Prevention engine</h3><p>Sport, GP prevention, parks, safe routes and health education become early wellbeing honey rather than late crisis response.</p></div><div class="card"><h3>🎓 Apprenticeship conversion</h3><p>College, university, libraries, transport and enterprise combs become visible bridges into apprenticeships, jobs and invention.</p></div><div class="card"><h3>🌾 SPACE Farmers</h3><p>Land, food, pollinators, water, astronomy, GIS, sensors and satellite data become one Welsh agrarian-technology curriculum.</p></div><div class="card"><h3>🚌 Rural access intelligence</h3><p>Transport gaps become visible: where buses, taxis, trains or service routes fail, the bee pathway weakens and can be repaired.</p></div><div class="card"><h3>🍯 Honey accounting</h3><p>Communities can track wellbeing, knowledge, sport, jobs, apprenticeships, invention, food, ecological repair and civic pride as measurable outputs.</p></div></div>`;
    if (key === 'architecture') return `<p>The package includes complete seed data in <code>/data</code> plus runtime data in <code>assets/js/data.js</code>.</p><div class="jsonbox">${esc(JSON.stringify(DATA.architecture, null, 2))}</div>`;
    if (key === 'schema') return `<div class="jsonbox">${esc(JSON.stringify(DATA.beeTemplate, null, 2))}</div>`;
    if (key === 'routes') return `<div class="jsonbox">${esc(JSON.stringify(DATA.pathways, null, 2))}</div>`;
    return `<div class="card-grid"><div class="card"><h3>🐝 Individual Bee</h3><p>Every learner/citizen is modelled as a bee with nectar, traits, places, service-comb use and honey outputs.</p></div><div class="card"><h3>🏡 Welsh Hive</h3><p>Hamlets, villages, towns and cities become living hives with services as combs and transport as nectar routes.</p></div><div class="card"><h3>🍯 Excellence Honey</h3><p>Honey is measurable: wellbeing, knowledge, sport, jobs, apprenticeships, invention, food, ecological repair and civic pride.</p></div></div>`;
  }
  function showContent(key){
    preserveScroll(() => {
      const titles = {overview:'Cymru Hive OS engine summary', strategy:'What v3 could achieve for Wales', budget:'£10bn/year WALE$ budget', allocations:'Strategic allocation', compute:'Super-advanced compute depth', ageBudget:'24 auto-tune investment ladder', infrastructure:'WALE$ infrastructure stack', thinkers:'Strategic thinkers', architecture:'Data architecture', schema:'Bee state schema', routes:'Pathway routes and scale ladder'};
      $('contentTitle').textContent = titles[key] || titles.overview; $('contentBody').innerHTML = contentHTML(key);
    });
  }
  function populateSelectors(state){
    $('beeSelect').innerHTML = state.bees.map(b => `<option value="${b.id}">${b.emoji} ${b.id}</option>`).join('');
    $('tuneSelect').innerHTML = DATA.autoTunes.map((t,i) => `<option value="${i}">${t.emoji} ${String(i+1).padStart(2,'0')} · ${t.name}</option>`).join('');
  }
  function renderTuneButtons(state, setTune){
    const root = $('tuneButtons'); root.innerHTML = '';
    DATA.autoTunes.forEach((t,i) => { const b = document.createElement('button'); b.className = 'side-card' + (i === state.tuneIndex ? ' active' : ''); b.innerHTML = `<strong>${t.emoji} ${String(i+1).padStart(2,'0')} · ${esc(t.name)}</strong><small>${esc(t.ageStage)} · age ${esc(t.age)} · ${esc(t.description)}</small>`; b.addEventListener('click', () => setTune(i, true)); root.appendChild(b); });
  }
  function exportState(state){
    const payload = {generatedAt:new Date().toISOString(), version:DATA.architecture.version, selectedBeeId:state.selectedBeeId, tuneIndex:state.tuneIndex, bees:state.bees};
    const blob = new Blob([JSON.stringify(payload, null, 2)], {type:'application/json'}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'cymru-hive-os-v2-state.json'; a.click(); URL.revokeObjectURL(url);
  }
  window.CymruUI = {log, selectedBee, renderState, selectHive, showContent, populateSelectors, renderTuneButtons, exportState, renderBudgetDashboard};
})();
