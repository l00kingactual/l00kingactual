window.CYMRU_HIVE_BUDGET = {
  "version": "3.1",
  "name": "SPACE WALE$ £10bn/year Budget Engine",
  "budget_semantics": {
    "label": "£10bn/year WALE$ budget",
    "meaning": "modern annual billion for planning clarity",
    "annual_gbp": 10000000000,
    "years": 25,
    "total_gbp": 250000000000,
    "total_modern_billions": 250.0,
    "total_long_billions": 0.25,
    "population_assumption": 3200000,
    "per_person_gbp": 78125.0,
    "per_person_per_year_gbp": 3125.0
  },
  "doctrine": [
    "Terrain first",
    "Children first",
    "Hives first",
    "Shared compute first",
    "Evidence always",
    "Local invention inside national standards",
    "Peace and prosperity as final honey"
  ],
  "allocations": [
    {
      "id": "compute_depth",
      "icon": "🧠",
      "name": "Super-advanced compute depth",
      "percent": 18,
      "annual_gbp": 1800000000,
      "amount_gbp": 45000000000,
      "amount_modern_bn": 45.0,
      "amount_long_bn": 0.045,
      "purpose": "Sovereign cloud, HPC, AI, data centres, virtual workstations, storage and backup."
    },
    {
      "id": "education_learning",
      "icon": "🏫",
      "name": "Education + lifelong learning",
      "percent": 14,
      "annual_gbp": 1400000000,
      "amount_gbp": 35000000000,
      "amount_modern_bn": 35.0,
      "amount_long_bn": 0.035,
      "purpose": "Schools, libraries, curriculum, Welsh-language tools, age-5 astronomy and lifelong accounts."
    },
    {
      "id": "health_prevention",
      "icon": "🩺",
      "name": "Health + prevention",
      "percent": 12,
      "annual_gbp": 1200000000,
      "amount_gbp": 30000000000,
      "amount_modern_bn": 30.0,
      "amount_long_bn": 0.03,
      "purpose": "GP prevention, sports health, analytics, active lives, mental wellbeing and rural health access."
    },
    {
      "id": "agrarian_wales",
      "icon": "🌾",
      "name": "Agrarian WALE$ infrastructure",
      "percent": 12,
      "annual_gbp": 1200000000,
      "amount_gbp": 30000000000,
      "amount_modern_bn": 30.0,
      "amount_long_bn": 0.03,
      "purpose": "SPACE Farmers, farms, animal guilds, food, water, soil, orchards, meadows and rural robotics."
    },
    {
      "id": "transport_services",
      "icon": "🚌",
      "name": "Transport + service-comb access",
      "percent": 10,
      "annual_gbp": 1000000000,
      "amount_gbp": 25000000000,
      "amount_modern_bn": 25.0,
      "amount_long_bn": 0.025,
      "purpose": "Bus, rail, community taxi, school transport, ambulance/fire access and rural pickup points."
    },
    {
      "id": "enterprise_apprenticeships",
      "icon": "💼",
      "name": "Enterprise + apprenticeships",
      "percent": 10,
      "annual_gbp": 1000000000,
      "amount_gbp": 25000000000,
      "amount_modern_bn": 25.0,
      "amount_long_bn": 0.025,
      "purpose": "SME compute vouchers, start-ups, maker hubs, farm tech, coaching businesses and college-to-work pipelines."
    },
    {
      "id": "space_gis_sensors",
      "icon": "🛰️",
      "name": "Space, GIS, sensors, astronomy",
      "percent": 8,
      "annual_gbp": 800000000,
      "amount_gbp": 20000000000,
      "amount_modern_bn": 20.0,
      "amount_long_bn": 0.02,
      "purpose": "Satellite imagery, Welsh dark skies, GIS, field sensors, astronomy pathway and Earth-observation tools."
    },
    {
      "id": "hive_places",
      "icon": "🏘️",
      "name": "Hives: hamlets, villages, towns, cities",
      "percent": 6,
      "annual_gbp": 600000000,
      "amount_gbp": 15000000000,
      "amount_modern_bn": 15.0,
      "amount_long_bn": 0.015,
      "purpose": "Local hubs, parks, sports fields, community halls, civic assets and regional place infrastructure."
    },
    {
      "id": "animal_ecology",
      "icon": "🐑",
      "name": "Animal guilds + ecology",
      "percent": 4,
      "annual_gbp": 400000000,
      "amount_gbp": 10000000000,
      "amount_modern_bn": 10.0,
      "amount_long_bn": 0.01,
      "purpose": "Sheep, cows, goats, chickens, ducks, geese, swans, donkeys, horses, ponies, bees and welfare systems."
    },
    {
      "id": "cyber_resilience",
      "icon": "🔐",
      "name": "Cybersecurity + civil resilience",
      "percent": 4,
      "annual_gbp": 400000000,
      "amount_gbp": 10000000000,
      "amount_modern_bn": 10.0,
      "amount_long_bn": 0.01,
      "purpose": "Identity, access control, secure backup, continuity, monitoring, emergency data and trusted infrastructure."
    },
    {
      "id": "governance_evidence",
      "icon": "🧾",
      "name": "Governance, evidence, CoRT60, audit",
      "percent": 2,
      "annual_gbp": 200000000,
      "amount_gbp": 5000000000,
      "amount_modern_bn": 5.0,
      "amount_long_bn": 0.005,
      "purpose": "Cymru Hive OS, SQL/Neo4j, honey reporting, audit, ethics, safeguards and programme evaluation."
    }
  ],
  "compute_depth": [
    {
      "id": "national_data_centres",
      "icon": "🏛️",
      "name": "National data centres",
      "amount_gbp": 12000000015,
      "annual_gbp": 480000001,
      "amount_modern_bn": 12.000000015,
      "purpose": "3–5 sovereign compute cores, energy resilience, secure operations and Welsh public-service cloud."
    },
    {
      "id": "regional_compute_hives",
      "icon": "🏴",
      "name": "Regional compute hives",
      "amount_gbp": 8000000010,
      "annual_gbp": 320000000,
      "amount_modern_bn": 8.00000001,
      "purpose": "North, Mid, South West, South East and Valleys edge compute centres."
    },
    {
      "id": "hpc_ai_gpu",
      "icon": "🧠",
      "name": "HPC / AI / GPU clusters",
      "amount_gbp": 9999999990,
      "annual_gbp": 400000000,
      "amount_modern_bn": 9.99999999,
      "purpose": "Advanced simulation, health analytics, GIS, Welsh language AI, agritech and research workloads."
    },
    {
      "id": "virtual_workstations",
      "icon": "💻",
      "name": "Virtual workstation fabric",
      "amount_gbp": 8000000010,
      "annual_gbp": 320000000,
      "amount_modern_bn": 8.00000001,
      "purpose": "4× i9-equivalent pooled VDI for advanced learners, apprentices, farms, SMEs and libraries."
    },
    {
      "id": "storage_backup",
      "icon": "🗄️",
      "name": "Storage + backup vaults",
      "amount_gbp": 4000000005,
      "annual_gbp": 160000000,
      "amount_modern_bn": 4.000000005,
      "purpose": "Citizen/project data, evidence archives, object storage, disaster recovery and long-term preservation."
    },
    {
      "id": "cyber_hardening",
      "icon": "🔐",
      "name": "Cyber hardening",
      "amount_gbp": 2999999970,
      "annual_gbp": 119999999,
      "amount_modern_bn": 2.99999997,
      "purpose": "Identity, access, monitoring, incident response, secure enclaves and continuity."
    }
  ],
  "age_band_budget": [
    {
      "id": "wonder_bees",
      "icon": "🌙",
      "age_band": "Ages 5–7",
      "tunes": 6,
      "percent": 15,
      "annual_gbp": 1500000000,
      "amount_gbp": 37500000000,
      "purpose": "Moon, stars, safe darkness, park play, stories, family health and curiosity."
    },
    {
      "id": "explorer_bees",
      "icon": "🧭",
      "age_band": "Ages 8–10",
      "tunes": 6,
      "percent": 15,
      "annual_gbp": 1500000000,
      "amount_gbp": 37500000000,
      "purpose": "Cubs/Brownies, libraries, navigation, sport confidence, pollinators and transport independence."
    },
    {
      "id": "team_bees",
      "icon": "🔭",
      "age_band": "Ages 11–13",
      "tunes": 6,
      "percent": 20,
      "annual_gbp": 2000000000,
      "amount_gbp": 50000000000,
      "purpose": "Telescopes, water/weather fieldwork, dark-sky ecology, biodiversity, coding and community service."
    },
    {
      "id": "skill_bees",
      "icon": "🛰️",
      "age_band": "Ages 14–16",
      "tunes": 5,
      "percent": 25,
      "annual_gbp": 2500000000,
      "amount_gbp": 62500000000,
      "purpose": "Satellite GIS, GP prevention fitness, sensor farms, enterprise challenges and college tasters."
    },
    {
      "id": "space_farmer_capstone",
      "icon": "🌾",
      "age_band": "Age 16+",
      "tunes": 1,
      "percent": 15,
      "annual_gbp": 1500000000,
      "amount_gbp": 37500000000,
      "purpose": "SPACE Farmer capstone: land + sky + sport + animals + data + enterprise + Wales."
    },
    {
      "id": "governance_resilience",
      "icon": "🧾",
      "age_band": "All ages",
      "tunes": 0,
      "percent": 10,
      "annual_gbp": 1000000000,
      "amount_gbp": 25000000000,
      "purpose": "Evidence, safeguarding, Welsh standards, animal welfare, cyber resilience and honey accounting."
    }
  ],
  "infrastructure_layers": [
    {
      "id": "physical_hives",
      "icon": "🏘️",
      "name": "Physical hives",
      "items": [
        "household",
        "hamlet",
        "village",
        "town",
        "city",
        "Wales"
      ],
      "purpose": "Places where people live, learn, play, receive care, travel and build civic identity."
    },
    {
      "id": "service_combs",
      "icon": "🏥",
      "name": "Service combs",
      "items": [
        "taxi",
        "ambulance",
        "fire",
        "bus",
        "train",
        "school",
        "college",
        "university",
        "library",
        "GP",
        "hospital",
        "sportsField",
        "park",
        "zoo"
      ],
      "purpose": "Public and civic organs that make nectar accessible."
    },
    {
      "id": "animal_guilds",
      "icon": "🐑",
      "name": "Animal guilds",
      "items": [
        "sheep",
        "cows",
        "goats",
        "chickens",
        "ducks",
        "geese",
        "swans",
        "donkeys",
        "horses",
        "ponies",
        "bees"
      ],
      "purpose": "Living curriculum, food systems, welfare practice, ecology and rural enterprise."
    },
    {
      "id": "nectar_streams",
      "icon": "🌸",
      "name": "Nectar streams",
      "items": [
        "education",
        "sport",
        "health",
        "learning",
        "enterprise",
        "ecology",
        "astronomy",
        "animalCare",
        "foodSystems",
        "landStewardship"
      ],
      "purpose": "Inputs received by each bee/person."
    },
    {
      "id": "honey_outputs",
      "icon": "🍯",
      "name": "Honey outputs",
      "items": [
        "wellbeing",
        "knowledge",
        "sport",
        "jobs",
        "apprenticeships",
        "invention",
        "food",
        "ecologicalRepair",
        "civicPride",
        "animalWelfare",
        "ruralResilience",
        "WelshCulturalValue"
      ],
      "purpose": "Measurable civic value created by the system."
    },
    {
      "id": "data_compute",
      "icon": "💾",
      "name": "Data + compute",
      "items": [
        "SQL",
        "Neo4j",
        "GeoJSON",
        "OSGB",
        "GPS",
        "VDI",
        "HPC",
        "AI",
        "sensor data",
        "evidence ledger"
      ],
      "purpose": "Infrastructure that makes learning, services, routes, honey and gaps visible."
    }
  ],
  "strategic_thinkers": [
    {
      "thinker": "Sun Tzu",
      "tool": "Laying plans",
      "application": "Terrain first: read Wales as mountains, coast, valleys, farms, villages, services, routes, seasons and dark skies."
    },
    {
      "thinker": "De Bono",
      "tool": "CoRT60 cards",
      "application": "Every hive project receives PMI, CAF, C&S, AGO, FIP, APC, OPV and PISCO thinking metadata."
    },
    {
      "thinker": "McKinsey",
      "tool": "13S alignment",
      "application": "Align strategy, structure, systems, skills, staff, style, shared values, services, sites, sensors, safety, stories and surplus."
    },
    {
      "thinker": "Porter",
      "tool": "Activity-system fit",
      "application": "Sport, health, learning, agriculture, enterprise, transport and compute reinforce each other instead of fragmenting."
    },
    {
      "thinker": "Drucker",
      "tool": "Management by objectives",
      "application": "Define customers, value, objectives and honey outputs while preventing data from replacing human judgement."
    },
    {
      "thinker": "Kotler",
      "tool": "Value proposition",
      "application": "Different messages for children, parents, schools, farms, NHS, colleges, employers, councils and Wales."
    },
    {
      "thinker": "Mintzberg",
      "tool": "Deliberate + emergent strategy",
      "application": "National standards and local invention: each hive adapts the pathway to its terrain."
    }
  ]
};
