# Cymru Hive OS v3.1 · Individual Bee Pathway Engine

This is a split-file WebUI package. It is not a single long HTML file.

## Run locally

```bash
cd cymru_hive_os_v2_engine
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Apache localhost

```bash
cd cymru_hive_os_v2_engine
sudo rsync -av --delete ./ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
```

Open:

```text
http://localhost/
```

## Architecture

Runtime files:

- `index.html`
- `assets/css/styles.css`
- `assets/js/data.js`
- `assets/js/engine.js`
- `assets/js/map.js`
- `assets/js/ui.js`
- `assets/js/app.js`
- `assets/img/wales.jpeg`

Data architecture:

- `data/hives.json`
- `data/hives.geojson`
- `data/auto_tunes.json`
- `data/bee_template.json`
- `data/roles.json`
- `data/matrices.json`
- `data/pathways.json`
- `data/services.json`
- `data/architecture.schema.json`

Database/graph seeds:

- `schema/cymru_hive_os.sql`
- `graph/cymru_hive_os.cypher`

## What it models

Individual Bee → receives nectar → develops traits → moves through household/hamlet/village/town/city/Wales → uses service organs → produces honey outputs.

Coordinates are WGS84 GPS plus approximate OSGB36 British National Grid seeds for planning/demo use, not survey-grade OS data.


## v2.1 stable-map patch

This build fixes the map jumping/scrolling problem by:

- removing the `<a>` wrapper around the live map overlays
- adding a separate **Open map image** button
- removing automatic `scrollIntoView()` calls from content updates
- rendering animated bees as non-focusable div elements instead of buttons
- disabling browser scroll anchoring around the live map layers

Run with:

```bash
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```


## v2.2 no-jump map fix

This build changes the page into a fixed app shell:

- no document-level scrolling on desktop
- sidebar and main panel scroll independently
- no hash anchor for the Wales strategy button
- no automatic scroll-to-panel calls
- live state rendering preserves scroll position
- animated bee rendering is throttled and non-focusable
- global scroll anchoring disabled inside the app shell

This specifically addresses the repeated jump to the **planning panel / Cymru Hive OS engine summary**.


## v3 SPACE WALE$ long-billion budget engine

This build adds the £2.5 old long-scale billion budget layer:

- total model: £2,500,000,000,000
- 25-year annual model: £100,000,000,000/year
- per-person indicative pathway value at 3.2m people: ~£781,250
- per-person/year equivalent: ~£31,250
- strategic allocation across compute, education, health, agrarian WALE$, transport, enterprise, space/GIS/sensors, hive places, animal guilds, cybersecurity and governance
- compute-depth model for data centres, regional compute hives, HPC/AI/GPU, virtual workstations, storage and cyber hardening
- 24-auto-tune age-stage investment ladder
- data exports in `/data/budget_model.json`, `/data/infrastructure_layers.json`, and `/data/strategic_thinkers.json`
- SQL and Neo4j budget extensions

Run:

```bash
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```


## v3.1 budget change

The WALE$ infrastructure budget is now set to:

- annual budget: £10,000,000,000/year
- planning horizon: 25 years
- total programme model: £250,000,000,000
- indicative per-person total at 3.2m people: ~£78,125
- indicative per-person/year: ~£3,125

The same allocation percentages are retained, but all allocation, compute-depth and age-stage investment values have been recalculated.
