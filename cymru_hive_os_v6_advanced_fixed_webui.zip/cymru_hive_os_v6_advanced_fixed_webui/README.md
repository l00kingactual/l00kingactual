# Cymru Hive OS V6 · Advanced Fixed WebUI

This package uses your uploaded **v5.4 64 Charts + Animated Graph Lab** as the base, but fixes the packaging problem by flattening the folder structure.

`index.html` is directly inside this folder.

## What was fixed

- v5.4 double-nested folder structure corrected.
- No WMS/WFS dependency.
- Existing v5.4 map/chart/app core preserved.
- Added V6 advanced maths panel without rewriting the old app core.
- Added diagnostics page.
- Added JS syntax and algorithm smoke checks before packaging.

## Run

```bash
cd cymru_hive_os_v6_advanced_fixed_webui
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

Diagnostics:

```text
http://127.0.0.1:8088/diagnostics.html
```

## Added files

```text
assets/js/v6_math_engine.js
assets/js/v6_math_panel.js
diagnostics.html
schema/cymru_hive_os_v6_advanced_math_registry.sql
graph/cymru_hive_os_v6_advanced_math_registry.cypher
```

## V6 maths implemented

- 0/1 knapsack
- near-target subset sum
- greedy maximal coverage
- ACO route construction
- BCO colony allocation
- PSO update
- predator/prey equations
- Mandelbrot/fractal pruning
- weighted ROI composition
