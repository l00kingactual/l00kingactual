#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_PARENT="${DEST_PARENT:-/home/andy/Documents/suitsmafia/py_script}"
DEST_DIR="$DEST_PARENT/suits_media_director_v8"
mkdir -p "$DEST_PARENT"
rm -rf "$DEST_DIR"
cp -a "$SRC_DIR" "$DEST_DIR"
chmod +x "$DEST_DIR"/*.sh
printf 'Installed to: %s\n' "$DEST_DIR"
printf 'Run:\n  cd %s\n  ./run_webui.sh\n' "$DEST_DIR"
