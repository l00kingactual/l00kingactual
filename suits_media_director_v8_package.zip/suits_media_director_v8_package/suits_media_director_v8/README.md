# $uits Media Director v8

Local-first fictional GTA/FiveM / machinima media director.

Boundary: predation, Sun Tzu, Janus, humour, tactics, prey and predator labels are editorial/media-analysis tags for fictional GTARP/FiveM footage. They are not real-world tactical guidance.

## Why this exists

The folder listing shows a rich `py_script` workspace with:

- `final_predation_studio_v4_centerbeat_package` for full-length cue planning
- `suits_rp_cinema_ai_workbench_v2_suntzu_serverlogs_package` for server logs, Sun Tzu dictionaries and workbench flow
- `gta_dramatic_engine_v1_2_webui_package` for modular ingest/media/perception/selection/storage/strategy pieces
- `suits_ai_ml_fivem_3d_webui_v4` for shotline/MIR/3D WebUI direction
- `suits_ai_doctrine_scanner_v7` and `suits_mafia_ai_interlace` for scanning and SQL/Neo4j interlace

This script is the orchestration layer: scan assets, scan songs, generate a media dictionary, generate cue plans, output JSON/CSV/HTML, and optionally render samples.

## Install

The script uses Python standard library only for scanning, planning and WebUI. FFmpeg/FFprobe are optional but recommended.

```bash
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8
./run_webui.sh
```

Open:

```text
http://127.0.0.1:8788
```

## Default paths

```text
Videos:
/home/andy/Documents/suitsmafia/videos
/home/andy/Documents/suitsmafia/videos/disciples
/home/andy/Documents/suitsmafia/videos/disciples/youtube
/home/andy/Documents/suitsmafia/videos/suits_youtube
/home/andy/Documents/suitsmafia/videos/youtube

Music:
/home/andy/Documents/suitsmafia/music_mp4

Outputs:
/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8
```

## Switch dictionary

| Switch | Meaning | Example |
|---|---|---|
| `--video-dir` | Folder to scan for videos. Repeatable. | `--video-dir /home/andy/Documents/suitsmafia/videos/youtube` |
| `--video-playlist` | Text/M3U/CSV/JSON file listing video files. Repeatable. | `--video-playlist playlists/disciples.txt` |
| `--music-dir` | Folder to scan for music. Repeatable. | `--music-dir /home/andy/Documents/suitsmafia/music_mp4` |
| `--music-playlist` | Text/M3U/CSV/JSON file listing music files. Repeatable. | `--music-playlist playlists/acdc.json` |
| `--mode` | `full-track`, `timings`, or `batch`. | `--mode full-track` |
| `--timings` | Inline cue windows. | `--timings '0-13=intro,13-31=build,31-52=impact'` |
| `--timing-json` | Cue sheet JSON. | `--timing-json cue_sheets/shoot_to_thrill.json` |
| `--out` | Output folder. | `--out outputs/shoot_to_thrill` |
| `--render` | Use FFmpeg to render sample clips/stills. | `--render` |
| `--webui` | Run browser UI. | `--webui --port 8788` |
| `--limit-assets` | Limit videos considered for cue matching. | `--limit-assets 200` |
| `--no-recursive` | Scan only top-level folder. | `--no-recursive` |
| `--print-switches` | Print JSON switch dictionary. | `--print-switches` |

## Example: full-track batch from default folders

```bash
python3 suits_media_director_v8.py \
  --mode full-track \
  --out /home/andy/Documents/suitsmafia/outputs/suits_media_director_v8
```

## Example: Shoot to Thrill with manual timings

```bash
python3 suits_media_director_v8.py \
  --video-dir /home/andy/Documents/suitsmafia/videos/youtube \
  --music-dir /home/andy/Documents/suitsmafia/music_mp4 \
  --mode timings \
  --timings '0-13=intro,13-31=build,31-52=impact,52-70=chain,70-90=aftermath' \
  --out /home/andy/Documents/suitsmafia/outputs/shoot_to_thrill_plan
```

## Example: Hells Bells full track, with sample rendering

```bash
python3 suits_media_director_v8.py \
  --video-dir /home/andy/Documents/suitsmafia/videos/disciples/youtube \
  --music-dir /home/andy/Documents/suitsmafia/music_mp4 \
  --mode full-track \
  --render \
  --out /home/andy/Documents/suitsmafia/outputs/hells_bells_plan
```

## Output files

```text
media_dictionary.json
video_assets.json
music_assets.json
video_assets.csv
music_assets.csv
edit_plan.json
cue_match_plan.json
cue_match_plan.csv
run_manifest.json
curated_music_cue_report.html
renders/clips/*.mp4        # only if --render and FFmpeg available
renders/stills/*.png       # only if --render and FFmpeg available
```

## What the WebUI does

- Scans configured video and music folders.
- Generates a cue plan for every detected music asset.
- Shows a browser report.
- Gives JSON endpoints for dictionary, assets and edit plan.
- Can generate output files from the browser.
- Can optionally ask FFmpeg to make sample clips and stills.

## Code explanation

### 1. Dictionary layer

`LABEL_DICTIONARY` is the doctrine layer. It stores:

- event classes: spectacular, funny, gory_bloody, accidental, plus_chain, team_play, controlled_burst, panic_event, odd_unusual
- prey types: exposed, isolated, panicked, wounded, winged, shelled, counter-threat, comedic, route, tunnel, reload, baited, trap
- predator archetypes: lion, leopard, snake, shark, hyena, wasp
- Sun Tzu, Janus, 13S, UQEBM, De Bono and ACO/BCO lenses
- auto-tunes for kill, wound, wing, comedy, tactical, strategic and odd clips
- song profiles for Shoot to Thrill and Hells Bells

### 2. Asset scan layer

`build_assets()` gathers video and music from folders and playlists. It creates `MediaAsset` rows with:

```text
asset_id, path, name, kind, extension, size, duration, tags, source
```

If `ffprobe` is available, it adds duration.

### 3. Playlist layer

`read_playlist()` accepts `.txt`, `.m3u`, `.m3u8`, `.csv`, and `.json` playlist files. This lets you keep hand-picked footage/music lists.

### 4. Cue layer

`auto_cues_for_music()` creates cue rows. In `full-track` mode it divides the whole song into proportional sections. In `timings` mode it uses your manual windows.

Cue rows contain:

```text
cue_id, start_s, end_s, theme, energy, song_profile,
allowed_asset_types, wanted_event_classes, subtitle_style,
max_clips, clip_duration_max_s, janus_modes, sun_tzu_tags
```

### 5. Scoring layer

`score_asset_for_cue()` scores each video against a cue using filename/folder tags and label overlap. This is intentionally interpretable: it gives reasons like `wanted_label_overlap`, `hard_energy_match`, `build_tension_match`, and `filename_guess`.

This is the place to later import stronger outputs from:

- `gta_dramatic_engine` tensors
- shotline detection
- server logs
- OCR/HUD
- human feedback

### 6. Output layer

`render_outputs()` writes JSON, CSV, HTML, and optional FFmpeg renders.

### 7. WebUI layer

The WebUI uses Python `http.server`, so it does not need FastAPI. It gives quick buttons for refresh, generate outputs, generate sample renders, open JSON and open the report.

## [o][o]

“Ju$t 0ff t00 $k1n up!” means the little machine has gone to skin the metadata, season the cue sheet, and bring back a plate of clips.

D0c0ti/iid machina piccolini: little doctor-machine, big appetite.

## Path fix / Downloads music import

If the package was extracted as:

```text
/home/andy/Documents/suitsmafia/py_script/suits_media_director_v8_package/suits_media_director_v8
```

run it from there:

```bash
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8_package/suits_media_director_v8
./run_webui.sh
```

Or install it into the simpler final path:

```bash
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8_package/suits_media_director_v8
./install_to_py_script.sh
cd /home/andy/Documents/suitsmafia/py_script/suits_media_director_v8
./run_webui.sh
```

The launcher now creates and writes to:

```text
/home/andy/Documents/suitsmafia/music_mp4
/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8
```

Before launch it imports supported music/video-music files from:

```text
/home/andy/Downloads
```

Supported extensions:

```text
.mp3 .wav .flac .m4a .aac .ogg .opus .webm .mp4 .mkv .mov
```

Skip the Downloads import with:

```bash
IMPORT_FROM_DOWNLOADS=0 ./run_webui.sh
```

Override paths with:

```bash
DOWNLOADS_DIR=/home/andy/Downloads \
MUSIC_DIR=/home/andy/Documents/suitsmafia/music_mp4 \
OUT_DIR=/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8 \
./run_webui.sh
```

The WebUI now ignores browser BrokenPipe refresh/cancel events and returns no-content for `/favicon.ico`, so those messages should not matter.
