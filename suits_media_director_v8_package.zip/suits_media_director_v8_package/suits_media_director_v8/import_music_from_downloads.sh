#!/usr/bin/env bash
set -euo pipefail

DOWNLOADS_DIR="${DOWNLOADS_DIR:-/home/andy/Downloads}"
MUSIC_DIR="${MUSIC_DIR:-/home/andy/Documents/suitsmafia/music_mp4}"
mkdir -p "$MUSIC_DIR"

printf '$uits import: Downloads -> music_mp4\n'
printf 'Downloads: %s\n' "$DOWNLOADS_DIR"
printf 'Music dir: %s\n' "$MUSIC_DIR"

if [ ! -d "$DOWNLOADS_DIR" ]; then
  echo "Downloads folder not found: $DOWNLOADS_DIR"
  exit 0
fi

count=0
while IFS= read -r -d '' f; do
  base="$(basename "$f")"
  dest="$MUSIC_DIR/$base"
  if [ -e "$dest" ]; then
    stem="${base%.*}"
    ext="${base##*.}"
    dest="$MUSIC_DIR/${stem}_from_downloads.$ext"
    n=2
    while [ -e "$dest" ]; do
      dest="$MUSIC_DIR/${stem}_from_downloads_$n.$ext"
      n=$((n+1))
    done
  fi
  cp -n "$f" "$dest" 2>/dev/null || cp "$f" "$dest"
  count=$((count+1))
  printf '  imported: %s\n' "$dest"
done < <(find "$DOWNLOADS_DIR" -maxdepth 1 -type f \( \
  -iname '*.mp3' -o -iname '*.wav' -o -iname '*.flac' -o -iname '*.m4a' -o \
  -iname '*.aac' -o -iname '*.ogg' -o -iname '*.opus' -o -iname '*.webm' -o \
  -iname '*.mp4' -o -iname '*.mkv' -o -iname '*.mov' \
\) -print0)

printf 'Imported %s music/video-music files.\n' "$count"
