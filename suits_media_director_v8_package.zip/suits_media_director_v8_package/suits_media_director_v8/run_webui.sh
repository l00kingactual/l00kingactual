#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

DOWNLOADS_DIR="${DOWNLOADS_DIR:-/home/andy/Downloads}"
MUSIC_DIR="${MUSIC_DIR:-/home/andy/Documents/suitsmafia/music_mp4}"
OUT_DIR="${OUT_DIR:-/home/andy/Documents/suitsmafia/outputs/suits_media_director_v8}"
mkdir -p "$MUSIC_DIR" "$OUT_DIR"

# Keep the music library topped up from Downloads.
# Set IMPORT_FROM_DOWNLOADS=0 to skip this pre-import.
if [ "${IMPORT_FROM_DOWNLOADS:-1}" = "1" ]; then
  DOWNLOADS_DIR="$DOWNLOADS_DIR" MUSIC_DIR="$MUSIC_DIR" ./import_music_from_downloads.sh || true
fi

printf '$uits Media Director v8 WebUI: http://127.0.0.1:8788\n'
printf 'Package dir: %s\n' "$SCRIPT_DIR"
printf 'Music dir: %s\n' "$MUSIC_DIR"
printf 'Outputs: %s\n' "$OUT_DIR"

python3 suits_media_director_v8.py \
  --webui \
  --video-dir /home/andy/Documents/suitsmafia/videos \
  --video-dir /home/andy/Documents/suitsmafia/videos/disciples \
  --video-dir /home/andy/Documents/suitsmafia/videos/disciples/youtube \
  --video-dir /home/andy/Documents/suitsmafia/videos/suits_youtube \
  --video-dir /home/andy/Documents/suitsmafia/videos/youtube \
  --music-dir "$MUSIC_DIR" \
  --music-dir "$DOWNLOADS_DIR" \
  --out "$OUT_DIR" \
  --mode full-track \
  --host 127.0.0.1 \
  --port 8788
