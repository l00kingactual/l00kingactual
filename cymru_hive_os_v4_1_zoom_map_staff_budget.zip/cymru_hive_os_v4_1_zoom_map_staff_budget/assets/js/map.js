(function(){
const D=window.SPACE_WALES_V41_DATA,E=window.SpaceWalesV41Engine;
let canvas,ctx,img=new Image(),scale=1,panX=0,panY=0,drag=false,last={x:0,y:0},selected=null,bees=[];
function init(){
 canvas=document.getElementById("walesMap"); if(!canvas)return; ctx=canvas.getContext("2d");
 img.src=D.map_asset; img.onload=draw; img.onerror=draw;
 bees=Array.from({length:64},(_,i)=>({x:Math.random()*canvas.width,y:Math.random()*canvas.height,tx:Math.random()*canvas.width,ty:Math.random()*canvas.height,icon:i%5===0?"🔭":i%4===0?"🌾":i%3===0?"🍯":"🐝"}));
 canvas.addEventListener("wheel",e=>{e.preventDefault();const before=screenToWorld(e.offsetX,e.offsetY);scale*=e.deltaY<0?1.12:.88;scale=Math.max(.55,Math.min(5,scale));const after=screenToWorld(e.offsetX,e.offsetY);panX+=(after.x-before.x)*scale;panY+=(after.y-before.y)*scale;draw()},{passive:false});
 canvas.addEventListener("mousedown",e=>{drag=true;last={x:e.offsetX,y:e.offsetY}});
 canvas.addEventListener("mouseup",()=>drag=false); canvas.addEventListener("mouseleave",()=>drag=false);
 canvas.addEventListener("mousemove",e=>{if(drag){panX+=e.offsetX-last.x;panY+=e.offsetY-last.y;last={x:e.offsetX,y:e.offsetY};draw()}});
 canvas.addEventListener("click",e=>{const p=screenToWorld(e.offsetX,e.offsetY);const hit=D.hives.find(h=>Math.hypot(p.x-h.x*canvas.width/100,p.y-h.y*canvas.height/100)<24/scale);if(hit){selected=hit;renderSelected(hit);draw()}});
 document.getElementById("zoomInBtn").onclick=()=>{scale=Math.min(5,scale*1.2);draw()};
 document.getElementById("zoomOutBtn").onclick=()=>{scale=Math.max(.55,scale/1.2);draw()};
 document.getElementById("resetMapBtn").onclick=()=>{scale=1;panX=0;panY=0;draw()};
}
function screenToWorld(x,y){return{x:(x-panX)/scale,y:(y-panY)/scale}}
function renderSelected(h){document.getElementById("selectedHive").textContent=h.icon+" "+h.name;document.getElementById("selectedHiveText").innerHTML=`<strong>${h.type}</strong> hive<br>GPS ${h.lat.toFixed(4)}, ${h.lon.toFixed(4)}`;document.getElementById("mapMetrics").innerHTML=`<div class="barrow"><strong>budget heading</strong><span class="bar"><i style="width:70%"></i></span><span>${h.type}</span></div>`}
function step(tune,values){bees.forEach((b,i)=>{if(Math.hypot(b.tx-b.x,b.ty-b.y)<8){const h=D.hives[(i+tune.number+Math.floor(Math.random()*D.hives.length))%D.hives.length];b.tx=h.x*canvas.width/100;b.ty=h.y*canvas.height/100}b.x+=(b.tx-b.x)*.008;b.y+=(b.ty-b.y)*.008});draw()}
function draw(){
 if(!canvas)return; ctx.clearRect(0,0,canvas.width,canvas.height); ctx.save(); ctx.translate(panX,panY); ctx.scale(scale,scale);
 const W=canvas.width,H=canvas.height; ctx.fillStyle="#081426";ctx.fillRect(0,0,W,H);
 if(img.complete&&img.naturalWidth){ctx.globalAlpha=.78;ctx.drawImage(img,0,0,W,H);ctx.globalAlpha=1}else{ctx.fillStyle="#31475e";ctx.fillRect(120,40,520,590);ctx.fillStyle="#eaf2ff";ctx.font="32px system-ui";ctx.fillText("WALES MAP",260,330)}
 D.hives.forEach(h=>{const x=h.x*W/100,y=h.y*H/100;ctx.fillStyle=selected&&selected.id===h.id?"#facc15":"rgba(7,17,31,.88)";ctx.beginPath();ctx.arc(x,y,18,0,Math.PI*2);ctx.fill();ctx.fillStyle=selected&&selected.id===h.id?"#07111f":"#fff";ctx.font="18px system-ui";ctx.textAlign="center";ctx.fillText(h.icon,x,y+7);ctx.font="11px system-ui";ctx.fillStyle="#fff";ctx.fillText(h.name,x,y+34)});
 bees.forEach(b=>{ctx.font="16px system-ui";ctx.fillText(b.icon,b.x,b.y)});
 ctx.restore(); document.getElementById("mapInfo").textContent=`zoom ${scale.toFixed(2)}× · pan ${Math.round(panX)}, ${Math.round(panY)}`;
}
window.SpaceMap={init,step,draw};
document.addEventListener("DOMContentLoaded",init);
})();