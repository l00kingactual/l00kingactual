(function(){
const D=window.SPACE_WALES_V41_DATA;
const CAP=D.budget.annual_gbp, STAFF=D.budget.staff_total;
const ids=D.allocations.map(a=>a.id);
const money=n=>n>=1e9?"£"+(n/1e9).toFixed(2).replace(/\.00$/,"")+"bn":n>=1e6?"£"+(n/1e6).toFixed(1)+"m":"£"+Math.round(n).toLocaleString();
const clamp=(v,min=0,max=100)=>Math.max(min,Math.min(max,v));
function baseline(){return Object.fromEntries(D.allocations.map(a=>[a.id,a.annual_gbp]));}
function normaliseBudget(values){
  const total=ids.reduce((s,k)=>s+(+values[k]||0),0);
  if(total<=CAP) return {...values};
  const scale=CAP/total; const out={}; ids.forEach(k=>out[k]=Math.round((+values[k]||0)*scale)); return out;
}
function applyTune(values,tune){
  const out={...values};
  Object.entries(tune.allocation_modifiers||{}).forEach(([k,v])=>{out[k]=(out[k]||0)+v*7_500_000});
  return normaliseBudget(out);
}
function totals(values){
  const total=ids.reduce((s,k)=>s+(+values[k]||0),0); return {total,remaining:CAP-total,over:Math.max(0,total-CAP)};
}
function pct(values,k){return ((values[k]||0)/CAP)*100}
function staffFromBudget(values){
  const total=ids.reduce((s,k)=>s+(+values[k]||0),0)||1;
  const out={}; ids.forEach(k=>out[k]=Math.round(STAFF*((values[k]||0)/total)));
  let diff=STAFF-Object.values(out).reduce((a,b)=>a+b,0);
  if(diff!==0) out[ids[0]]+=diff;
  return out;
}
function cohort(tune){return D.population.find(p=>p.id===tune.cohort)||D.population[0]}
function providerConsumer(tune,values){
  const c=cohort(tune);
  const prioritySpend=c.priority.reduce((s,k)=>s+(values[k]||0),0);
  const consumerDemand=(c.consumer_need/100)*(c.people/D.budget.population)*(prioritySpend/CAP)*100;
  const providerValue=(c.producer_capacity/100)*(c.people/D.budget.population)*(Object.values(values).reduce((a,b)=>a+b,0)/CAP)*160;
  return {cohort:c,consumerDemand:clamp(consumerDemand*10),providerValue:clamp(providerValue*10),prioritySpend};
}
function honey(values, eco=50){
  const map={
    compute:{knowledge:.18,invention:.28,jobs:.18,apprenticeships:.16,peace:.08},
    education:{knowledge:.32,apprenticeships:.16,civicPride:.10,wellbeing:.08},
    health:{wellbeing:.34,sport:.20,peace:.12,civicPride:.08},
    agrarian:{food:.30,jobs:.14,ecologicalRepair:.20,civicPride:.12},
    transport:{wellbeing:.14,jobs:.16,apprenticeships:.12,peace:.15},
    enterprise:{jobs:.30,apprenticeships:.20,invention:.18,civicPride:.08},
    spacegis:{knowledge:.18,invention:.20,ecologicalRepair:.16,civicPride:.14},
    hives:{civicPride:.26,wellbeing:.16,peace:.16,sport:.10},
    animals:{food:.20,ecologicalRepair:.24,wellbeing:.12,civicPride:.14},
    cyber:{peace:.30,invention:.10,jobs:.08,wellbeing:.06},
    evidence:{knowledge:.16,peace:.12,invention:.12,civicPride:.10}
  };
  const out={wellbeing:0,knowledge:0,sport:0,jobs:0,apprenticeships:0,invention:0,food:0,ecologicalRepair:0,civicPride:0,peace:0};
  ids.forEach(k=>Object.entries(map[k]||{}).forEach(([o,v])=>out[o]+=pct(values,k)*v));
  out.ecologicalRepair+=(eco-50)*.1; out.food+=(eco-50)*.05;
  const max=Math.max(...Object.values(out),1); Object.keys(out).forEach(k=>out[k]=clamp(out[k]/max*100)); return out;
}
function horizons(values){
  return D.budget.horizons.map(y=>({years:y,total:Object.values(values).reduce((a,b)=>a+b,0)*y,perPerson:Object.values(values).reduce((a,b)=>a+b,0)*y/D.budget.population}));
}
window.SpaceWalesV41Engine={ids,money,baseline,normaliseBudget,applyTune,totals,pct,staffFromBudget,cohort,providerConsumer,honey,horizons};
})();