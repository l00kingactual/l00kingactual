window.SPACE_WALES_V41_DATA = {
  "version": "4.1",
  "budget": {
    "annual_gbp": 2500000000,
    "staff_total": 25000,
    "population": 3200000,
    "horizons": [
      1,
      5,
      10,
      25
    ]
  },
  "allocations": [
    {
      "id": "compute",
      "icon": "🧠",
      "name": "Super-advanced compute + data",
      "pct": 20,
      "staff_pct": 12,
      "purpose": "data centres, HPC/AI, VDI, storage, cyber-secure evidence engines",
      "annual_gbp": 500000000,
      "staff": 3000,
      "horizons": {
        "1": 500000000,
        "5": 2500000000,
        "10": 5000000000,
        "25": 12500000000
      }
    },
    {
      "id": "education",
      "icon": "🏫",
      "name": "Education + lifelong learning",
      "pct": 15,
      "staff_pct": 17,
      "purpose": "schools, libraries, curriculum, age-5 astronomy, Welsh learning tools",
      "annual_gbp": 375000000,
      "staff": 4250,
      "horizons": {
        "1": 375000000,
        "5": 1875000000,
        "10": 3750000000,
        "25": 9375000000
      }
    },
    {
      "id": "health",
      "icon": "🩺",
      "name": "Health + prevention",
      "pct": 12,
      "staff_pct": 14,
      "purpose": "GP prevention, sport-health, active lives, mental wellbeing",
      "annual_gbp": 300000000,
      "staff": 3500,
      "horizons": {
        "1": 300000000,
        "5": 1500000000,
        "10": 3000000000,
        "25": 7500000000
      }
    },
    {
      "id": "agrarian",
      "icon": "🌾",
      "name": "Agrarian WALE$ infrastructure",
      "pct": 11,
      "staff_pct": 12,
      "purpose": "SPACE Farmers, farms, food, water, soil, orchards, meadows",
      "annual_gbp": 275000000,
      "staff": 3000,
      "horizons": {
        "1": 275000000,
        "5": 1375000000,
        "10": 2750000000,
        "25": 6875000000
      }
    },
    {
      "id": "transport",
      "icon": "🚌",
      "name": "Transport + service access",
      "pct": 9,
      "staff_pct": 8,
      "purpose": "bus, rail, community taxi, safe routes, emergency access",
      "annual_gbp": 225000000,
      "staff": 2000,
      "horizons": {
        "1": 225000000,
        "5": 1125000000,
        "10": 2250000000,
        "25": 5625000000
      }
    },
    {
      "id": "enterprise",
      "icon": "💼",
      "name": "Enterprise + apprenticeships",
      "pct": 9,
      "staff_pct": 10,
      "purpose": "SME vouchers, maker hubs, start-ups, college-to-work routes",
      "annual_gbp": 225000000,
      "staff": 2500,
      "horizons": {
        "1": 225000000,
        "5": 1125000000,
        "10": 2250000000,
        "25": 5625000000
      }
    },
    {
      "id": "spacegis",
      "icon": "🛰️",
      "name": "Space, GIS, sensors, astronomy",
      "pct": 7,
      "staff_pct": 7,
      "purpose": "satellite imagery, dark skies, OSGB/GPS, field sensors",
      "annual_gbp": 175000000,
      "staff": 1750,
      "horizons": {
        "1": 175000000,
        "5": 875000000,
        "10": 1750000000,
        "25": 4375000000
      }
    },
    {
      "id": "hives",
      "icon": "🏘️",
      "name": "Hives: hamlets, villages, towns, cities",
      "pct": 5,
      "staff_pct": 6,
      "purpose": "local hubs, parks, sports fields, civic assets",
      "annual_gbp": 125000000,
      "staff": 1500,
      "horizons": {
        "1": 125000000,
        "5": 625000000,
        "10": 1250000000,
        "25": 3125000000
      }
    },
    {
      "id": "animals",
      "icon": "🐑",
      "name": "Animal guilds + ecology",
      "pct": 5,
      "staff_pct": 6,
      "purpose": "sheep, cows, goats, chickens, ducks, geese, swans, donkeys, horses, ponies, bees, fish, birds",
      "annual_gbp": 125000000,
      "staff": 1500,
      "horizons": {
        "1": 125000000,
        "5": 625000000,
        "10": 1250000000,
        "25": 3125000000
      }
    },
    {
      "id": "cyber",
      "icon": "🔐",
      "name": "Cybersecurity + civil resilience",
      "pct": 4,
      "staff_pct": 5,
      "purpose": "identity, backup, continuity, civil data defence",
      "annual_gbp": 100000000,
      "staff": 1250,
      "horizons": {
        "1": 100000000,
        "5": 500000000,
        "10": 1000000000,
        "25": 2500000000
      }
    },
    {
      "id": "evidence",
      "icon": "🧾",
      "name": "Evidence, simulation, CoRT60, audit",
      "pct": 3,
      "staff_pct": 3,
      "purpose": "scenario tournament, honey ledger, audit, governance, safeguards",
      "annual_gbp": 75000000,
      "staff": 750,
      "horizons": {
        "1": 75000000,
        "5": 375000000,
        "10": 750000000,
        "25": 1875000000
      }
    }
  ],
  "staff_roles": [
    {
      "id": "compute_engineers",
      "icon": "💾",
      "name": "Compute engineers + cloud operators",
      "allocation": "compute",
      "staff": 1600,
      "mission": "data centres, HPC, VDI, storage, automation"
    },
    {
      "id": "ai_ml_scientists",
      "icon": "🧠",
      "name": "AI/ML scientists + simulation engineers",
      "allocation": "compute",
      "staff": 900,
      "mission": "GA, ACO, BCO, PSO, ANN, Bayesian, digital twin"
    },
    {
      "id": "cyber_ops",
      "icon": "🔐",
      "name": "Cyber resilience operators",
      "allocation": "cyber",
      "staff": 1250,
      "mission": "identity, monitoring, continuity, incident response"
    },
    {
      "id": "teachers_curriculum",
      "icon": "🏫",
      "name": "Teachers, curriculum designers + library learning staff",
      "allocation": "education",
      "staff": 3500,
      "mission": "age-stage learning, Welsh language, astronomy, computing"
    },
    {
      "id": "coaches_health",
      "icon": "🏃",
      "name": "Sport coaches + health-prevention staff",
      "allocation": "health",
      "staff": 3000,
      "mission": "movement, GP prevention, confidence, wellbeing"
    },
    {
      "id": "space_farmers",
      "icon": "🌾",
      "name": "SPACE Farmer mentors + agritech field staff",
      "allocation": "agrarian",
      "staff": 3000,
      "mission": "farms, soil, water, orchards, meadows, food"
    },
    {
      "id": "animal_ecology",
      "icon": "🐑",
      "name": "Animal welfare, fish, bird + ecology staff",
      "allocation": "animals",
      "staff": 1500,
      "mission": "animal guilds, fish/birds, predator/prey, biodiversity"
    },
    {
      "id": "transport_access",
      "icon": "🚌",
      "name": "Transport access coordinators",
      "allocation": "transport",
      "staff": 2000,
      "mission": "bus, rail, taxi, service routes, rural pickup points"
    },
    {
      "id": "enterprise_apprentice",
      "icon": "💼",
      "name": "Enterprise + apprenticeship brokers",
      "allocation": "enterprise",
      "staff": 2500,
      "mission": "SMEs, maker hubs, apprenticeships, founders"
    },
    {
      "id": "gis_astronomy",
      "icon": "🛰️",
      "name": "GIS, sensor + astronomy specialists",
      "allocation": "spacegis",
      "staff": 1750,
      "mission": "OSGB/GPS, satellites, sensors, dark skies"
    },
    {
      "id": "hive_organisers",
      "icon": "🏘️",
      "name": "Local hive coordinators",
      "allocation": "hives",
      "staff": 1500,
      "mission": "hamlet/village/town/city service integration"
    },
    {
      "id": "evidence_audit",
      "icon": "🧾",
      "name": "Evidence, CoRT60, audit + governance analysts",
      "allocation": "evidence",
      "staff": 2500,
      "mission": "evaluation, budgets, safeguarding, reports"
    }
  ],
  "population": [
    {
      "id": "age_5_7",
      "icon": "🌙",
      "name": "Ages 5–7 Wonder Bees",
      "people": 160000,
      "producer_capacity": 10,
      "consumer_need": 90,
      "priority": [
        "education",
        "health",
        "spacegis"
      ],
      "provides": [
        "family wonder",
        "curiosity",
        "community participation"
      ],
      "consumes": [
        "education",
        "health",
        "safe routes"
      ]
    },
    {
      "id": "age_8_10",
      "icon": "🧭",
      "name": "Ages 8–10 Explorer Bees",
      "people": 165000,
      "producer_capacity": 18,
      "consumer_need": 82,
      "priority": [
        "education",
        "transport",
        "health"
      ],
      "provides": [
        "club energy",
        "teamwork",
        "local observation"
      ],
      "consumes": [
        "coaching",
        "transport",
        "library"
      ]
    },
    {
      "id": "age_11_13",
      "icon": "🔭",
      "name": "Ages 11–13 Team Bees",
      "people": 170000,
      "producer_capacity": 30,
      "consumer_need": 70,
      "priority": [
        "spacegis",
        "education",
        "animals"
      ],
      "provides": [
        "field data",
        "service projects",
        "coding evidence"
      ],
      "consumes": [
        "STEM",
        "ecology",
        "mentoring"
      ]
    },
    {
      "id": "age_14_16",
      "icon": "🛰️",
      "name": "Ages 14–16 Skill Bees",
      "people": 165000,
      "producer_capacity": 45,
      "consumer_need": 55,
      "priority": [
        "compute",
        "enterprise",
        "health"
      ],
      "provides": [
        "sensor work",
        "sports leadership",
        "prototype projects"
      ],
      "consumes": [
        "VDI",
        "enterprise coaching",
        "health prevention"
      ]
    },
    {
      "id": "age_16_24",
      "icon": "🌾",
      "name": "Ages 16–24 Apprentices + SPACE Farmers",
      "people": 330000,
      "producer_capacity": 70,
      "consumer_need": 50,
      "priority": [
        "enterprise",
        "compute",
        "agrarian"
      ],
      "provides": [
        "apprentice labour",
        "farm tech",
        "enterprise energy"
      ],
      "consumes": [
        "workstations",
        "college links",
        "mentors"
      ]
    },
    {
      "id": "adults",
      "icon": "⚙️",
      "name": "Adults 25–64 Work, Care + Enterprise",
      "people": 1650000,
      "producer_capacity": 85,
      "consumer_need": 55,
      "priority": [
        "health",
        "enterprise",
        "transport"
      ],
      "provides": [
        "tax base",
        "mentoring",
        "service work",
        "enterprise"
      ],
      "consumes": [
        "health",
        "transport",
        "skills"
      ]
    },
    {
      "id": "elders",
      "icon": "📚",
      "name": "Elders 65+ Memory + Care Bees",
      "people": 560000,
      "producer_capacity": 45,
      "consumer_need": 80,
      "priority": [
        "health",
        "transport",
        "hives"
      ],
      "provides": [
        "memory",
        "volunteering",
        "culture",
        "mentoring"
      ],
      "consumes": [
        "care",
        "transport",
        "community support"
      ]
    }
  ],
  "auto_tunes": [
    {
      "id": "tune_01",
      "number": 1,
      "icon": "🌙",
      "name": "Age 5 Moon Wonder",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "education": 4,
        "spacegis": 5,
        "health": 2,
        "evidence": 2
      },
      "summary": "curiosity, safe darkness, family sky diary"
    },
    {
      "id": "tune_02",
      "number": 2,
      "icon": "🌑",
      "name": "Age 5 Safe Darkness",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "health": 4,
        "spacegis": 3,
        "education": 2,
        "hives": 2
      },
      "summary": "parent trust, safety, story-led astronomy"
    },
    {
      "id": "tune_03",
      "number": 3,
      "icon": "☀️",
      "name": "Age 6 Sun & Shadow Clock",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "education": 4,
        "spacegis": 3,
        "evidence": 2
      },
      "summary": "observable learning from shadow-clock activity"
    },
    {
      "id": "tune_04",
      "number": 4,
      "icon": "🌳",
      "name": "Age 6 Park Play + Nature",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "health": 5,
        "animals": 3,
        "hives": 3,
        "transport": 1
      },
      "summary": "park, school, sport and ecology system"
    },
    {
      "id": "tune_05",
      "number": 5,
      "icon": "⭐",
      "name": "Age 7 Story Constellations",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "education": 5,
        "spacegis": 4,
        "hives": 1
      },
      "summary": "story, identity and family value"
    },
    {
      "id": "tune_06",
      "number": 6,
      "icon": "🩺",
      "name": "Age 7 Family Health Hive",
      "cohort": "age_5_7",
      "stage": "Wonder",
      "allocation_modifiers": {
        "health": 6,
        "education": 2,
        "hives": 2,
        "evidence": 1
      },
      "summary": "wellbeing and prevention objectives"
    },
    {
      "id": "tune_07",
      "number": 7,
      "icon": "🤝",
      "name": "Age 8 Cubs/Brownies Team Play",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "health": 4,
        "education": 3,
        "transport": 2,
        "hives": 2
      },
      "summary": "clubs adapt national pathway"
    },
    {
      "id": "tune_08",
      "number": 8,
      "icon": "📚",
      "name": "Age 8 Library Stars",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "education": 5,
        "compute": 2,
        "spacegis": 2,
        "hives": 2
      },
      "summary": "library alternatives for weak home access"
    },
    {
      "id": "tune_09",
      "number": 9,
      "icon": "🧭",
      "name": "Age 9 Map North Navigation",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "transport": 4,
        "spacegis": 4,
        "education": 2,
        "evidence": 1
      },
      "summary": "OSGB/GPS growth pathway"
    },
    {
      "id": "tune_10",
      "number": 10,
      "icon": "⚽",
      "name": "Age 9 Sports Field Confidence",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "health": 6,
        "hives": 2,
        "education": 1
      },
      "summary": "confidence and participation outcomes"
    },
    {
      "id": "tune_11",
      "number": 11,
      "icon": "🐝",
      "name": "Age 10 Pollinator Garden",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "animals": 5,
        "agrarian": 4,
        "education": 2,
        "spacegis": 1
      },
      "summary": "bees, school, ecology and food linked"
    },
    {
      "id": "tune_12",
      "number": 12,
      "icon": "🚌",
      "name": "Age 10 Transport Independence",
      "cohort": "age_8_10",
      "stage": "Explorer",
      "allocation_modifiers": {
        "transport": 6,
        "health": 1,
        "education": 1,
        "cyber": 1
      },
      "summary": "access, safeguarding, disability, reliability"
    },
    {
      "id": "tune_13",
      "number": 13,
      "icon": "🔭",
      "name": "Age 11 Telescope Basics",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "spacegis": 6,
        "education": 4,
        "compute": 2
      },
      "summary": "future science with safe civic technology"
    },
    {
      "id": "tune_14",
      "number": 14,
      "icon": "💧",
      "name": "Age 11 Water + Weather Fieldwork",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "agrarian": 3,
        "animals": 3,
        "spacegis": 3,
        "evidence": 2
      },
      "summary": "terrain experiments inform evidence"
    },
    {
      "id": "tune_15",
      "number": 15,
      "icon": "🌌",
      "name": "Age 12 Dark Sky Ecology",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "spacegis": 5,
        "animals": 3,
        "agrarian": 2,
        "hives": 1
      },
      "summary": "dark skies + ecology + tourism + learning"
    },
    {
      "id": "tune_16",
      "number": 16,
      "icon": "🦉",
      "name": "Age 12 Zoo Biodiversity",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "animals": 6,
        "education": 2,
        "health": 1,
        "evidence": 1
      },
      "summary": "biodiversity by age and family segment"
    },
    {
      "id": "tune_17",
      "number": 17,
      "icon": "📈",
      "name": "Age 13 Coding Charts",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "compute": 6,
        "education": 3,
        "evidence": 3
      },
      "summary": "data literacy and evidence output"
    },
    {
      "id": "tune_18",
      "number": 18,
      "icon": "🤲",
      "name": "Age 13 Community Service",
      "cohort": "age_11_13",
      "stage": "Team",
      "allocation_modifiers": {
        "hives": 4,
        "health": 3,
        "transport": 2,
        "evidence": 2
      },
      "summary": "OPV: child, parent, GP, volunteer, council"
    },
    {
      "id": "tune_19",
      "number": 19,
      "icon": "🛰️",
      "name": "Age 14 Satellite GIS",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "compute": 6,
        "spacegis": 6,
        "education": 2,
        "cyber": 2
      },
      "summary": "space tech with safeguards and growth"
    },
    {
      "id": "tune_20",
      "number": 20,
      "icon": "🏥",
      "name": "Age 14 GP Prevention Fitness",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "health": 7,
        "evidence": 3,
        "transport": 1,
        "compute": 1
      },
      "summary": "activity, access and wellbeing metrics"
    },
    {
      "id": "tune_21",
      "number": 21,
      "icon": "📡",
      "name": "Age 15 Sensor Farm",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "agrarian": 6,
        "compute": 4,
        "spacegis": 3,
        "animals": 3
      },
      "summary": "sensor farm links food, data, learning"
    },
    {
      "id": "tune_22",
      "number": 22,
      "icon": "💼",
      "name": "Age 15 Enterprise Challenge",
      "cohort": "age_14_16",
      "stage": "Skill",
      "allocation_modifiers": {
        "enterprise": 7,
        "compute": 3,
        "education": 2,
        "evidence": 2
      },
      "summary": "SME, school, parent, employer proposition"
    },
    {
      "id": "tune_23",
      "number": 23,
      "icon": "🎓",
      "name": "Age 16 College Apprenticeship Taster",
      "cohort": "age_16_24",
      "stage": "Apprentice",
      "allocation_modifiers": {
        "enterprise": 6,
        "education": 4,
        "compute": 3,
        "transport": 2
      },
      "summary": "college-to-work route"
    },
    {
      "id": "tune_24",
      "number": 24,
      "icon": "🌾",
      "name": "Age 16+ SPACE Farmer Capstone",
      "cohort": "age_16_24",
      "stage": "Capstone",
      "allocation_modifiers": {
        "agrarian": 7,
        "enterprise": 5,
        "compute": 4,
        "spacegis": 4,
        "animals": 3,
        "evidence": 2
      },
      "summary": "land + sky + sport + animals + data"
    }
  ],
  "hives": [
    {
      "id": "holyhead",
      "name": "Holyhead",
      "icon": "🚆",
      "x": 26,
      "y": 10,
      "type": "transport",
      "lat": 53.3103,
      "lon": -4.633
    },
    {
      "id": "bangor",
      "name": "Bangor",
      "icon": "🎓",
      "x": 44,
      "y": 13,
      "type": "education",
      "lat": 53.2274,
      "lon": -4.1293
    },
    {
      "id": "wrexham",
      "name": "Wrexham",
      "icon": "💼",
      "x": 85,
      "y": 20,
      "type": "enterprise",
      "lat": 53.0465,
      "lon": -2.9925
    },
    {
      "id": "aberystwyth",
      "name": "Aberystwyth",
      "icon": "🔭",
      "x": 51,
      "y": 50,
      "type": "spacegis",
      "lat": 52.4153,
      "lon": -4.0829
    },
    {
      "id": "brecon",
      "name": "Brecon",
      "icon": "🌌",
      "x": 72,
      "y": 71,
      "type": "spacegis",
      "lat": 51.947,
      "lon": -3.391
    },
    {
      "id": "cardigan",
      "name": "Cardigan",
      "icon": "🐝",
      "x": 31,
      "y": 65,
      "type": "animals",
      "lat": 52.0837,
      "lon": -4.6592
    },
    {
      "id": "carmarthen",
      "name": "Carmarthen",
      "icon": "🏫",
      "x": 36,
      "y": 76,
      "type": "education",
      "lat": 51.8576,
      "lon": -4.3121
    },
    {
      "id": "swansea",
      "name": "Swansea",
      "icon": "⚙️",
      "x": 51,
      "y": 86,
      "type": "enterprise",
      "lat": 51.6214,
      "lon": -3.9436
    },
    {
      "id": "cardiff",
      "name": "Cardiff",
      "icon": "🏙️",
      "x": 74,
      "y": 93,
      "type": "hives",
      "lat": 51.4816,
      "lon": -3.1791
    },
    {
      "id": "newport",
      "name": "Newport",
      "icon": "🚆",
      "x": 82,
      "y": 88,
      "type": "transport",
      "lat": 51.5842,
      "lon": -2.9977
    },
    {
      "id": "monmouth",
      "name": "Monmouth",
      "icon": "🌳",
      "x": 90,
      "y": 78,
      "type": "animals",
      "lat": 51.8126,
      "lon": -2.7136
    },
    {
      "id": "st_davids",
      "name": "St David’s",
      "icon": "✨",
      "x": 11,
      "y": 75,
      "type": "spacegis",
      "lat": 51.882,
      "lon": -5.269
    }
  ],
  "species": {
    "fish": [
      {
        "id": "salmon",
        "icon": "🐟",
        "name": "Atlantic salmon",
        "role": "migratory fish / river health indicator"
      },
      {
        "id": "trout",
        "icon": "🐟",
        "name": "Brown trout",
        "role": "freshwater resilience species"
      },
      {
        "id": "mackerel",
        "icon": "🐟",
        "name": "Mackerel",
        "role": "coastal food-web species"
      }
    ],
    "birds": [
      {
        "id": "red_kite",
        "icon": "🦅",
        "name": "Red kite",
        "role": "raptor / upland indicator"
      },
      {
        "id": "heron",
        "icon": "🐦",
        "name": "Heron",
        "role": "fish predator / wetland indicator"
      },
      {
        "id": "owl",
        "icon": "🦉",
        "name": "Owl",
        "role": "night predator / dark-sky indicator"
      },
      {
        "id": "swan",
        "icon": "🦢",
        "name": "Swan",
        "role": "protected wetland civic guild"
      },
      {
        "id": "geese",
        "icon": "🪿",
        "name": "Geese",
        "role": "guard/grazing guild"
      }
    ],
    "predators": [
      {
        "id": "otter",
        "icon": "🦦",
        "name": "Otter",
        "role": "river predator / water-quality signal"
      },
      {
        "id": "fox",
        "icon": "🦊",
        "name": "Fox",
        "role": "farm-edge predator"
      },
      {
        "id": "raptor",
        "icon": "🦅",
        "name": "Raptor",
        "role": "upland balance predator"
      }
    ],
    "prey": [
      {
        "id": "aquatic_insects",
        "icon": "🦟",
        "name": "Aquatic insects",
        "role": "river food base"
      },
      {
        "id": "small_mammals",
        "icon": "🐁",
        "name": "Small mammals",
        "role": "field/woodland prey base"
      },
      {
        "id": "pollinators",
        "icon": "🐝",
        "name": "Pollinators",
        "role": "farm and ecology support"
      },
      {
        "id": "grass",
        "icon": "🌱",
        "name": "Grass/pasture",
        "role": "grazing base"
      }
    ]
  },
  "map_asset": "assets/img/wales.jpeg"
};
