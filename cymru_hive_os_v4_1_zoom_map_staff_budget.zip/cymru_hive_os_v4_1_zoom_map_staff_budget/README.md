# Cymru Hive OS v4.1 · Zoom Map + Staff Budget Sliders

Fixes requested:

- restored Wales map as zoomable / pannable canvas
- budget sliders for every allocation heading
- annual allocation total capped at £2.5bn
- sums shown per heading
- 1, 5, 10 and 25-year budget horizons
- population/individual bees are both resource consumers and value providers
- 25,000 staff plan
- 2D and pseudo-3D charting for budgets
- staff and provider/consumer dashboards
- fish, birds, predator/prey ecology panel
- JSON, SQL, Cypher and CSV exports

## Run

```bash
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Apache

```bash
sudo rsync -av --delete ./ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
```

Open:

```text
http://localhost/
```
