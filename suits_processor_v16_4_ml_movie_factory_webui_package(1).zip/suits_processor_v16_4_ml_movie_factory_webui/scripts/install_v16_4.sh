#!/usr/bin/env bash
set -euo pipefail
BASE="/home/andy/Documents/suitsmafia"
PROC_DIR="$BASE/processors/suits_processor_v16_4_ml_movie_factory_webui"
TOOLS_DIR="$BASE/tools"
SITE="$BASE/susitsmafia_website"
mkdir -p "$BASE/processors" "$TOOLS_DIR" "$SITE" "$SITE/api" "$SITE/css" "$SITE/js" "$SITE/data/suits_v16_4" "$SITE/videos"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
rsync -av --delete "$SRC_DIR/" "$PROC_DIR/"
cat > "$TOOLS_DIR/suits_processor_v16_4_ml_movie_factory" <<LAUNCH
#!/usr/bin/env bash
set -euo pipefail
cd "$PROC_DIR"
python3 tools/suits_processor_v16_4_ml_movie_factory.py "\$@"
LAUNCH
chmod +x "$TOOLS_DIR/suits_processor_v16_4_ml_movie_factory"
rsync -av "$SRC_DIR/web/" "$SITE/"
rsync -av "$SRC_DIR/api/" "$SITE/api/"
rsync -av "$SRC_DIR/css/" "$SITE/css/"
rsync -av "$SRC_DIR/js/" "$SITE/js/"
echo '[o][o] Installed $uit$ Processor v16.4 launcher:'
echo "  $TOOLS_DIR/suits_processor_v16_4_ml_movie_factory"
echo '[o][o] WebUI installed into:'
echo "  $SITE"
