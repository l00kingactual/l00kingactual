<?php
function suits_header($title){
$pages=[
 'Dashboard'=>'suits_v16_4_dashboard.php','Processor Control'=>'suits_v16_4_processor_control.php','Movie Factory'=>'suits_v16_4_movie_factory.php','Videos'=>'suits_v16_4_videos.php','Charts'=>'suits_v16_4_charts.php','Graph'=>'suits_v16_4_graph.php','D0ug1e$ Story'=>'suits_v16_4_dougies_story.php','Aims & Goals'=>'suits_v16_4_aims_goals.php'];
echo "<!doctype html><html><head><meta charset='utf-8'><title>$title</title><link rel='stylesheet' href='css/suits_v16_4.css'></head><body><div class='layout'><aside class='side'><a class='brand' href='suits_v16_4_dashboard.php'>[o][o] $uit$ Mafia</a><div class='nav'>";
foreach($pages as $k=>$v){echo "<a href='$v'>$k</a>";}
echo "</div></aside><main class='main'><div class='topbar'><a href='suits_v16_4_dashboard.php'>Home</a>";
foreach($pages as $k=>$v){echo "<a href='$v'>$k</a>";}
echo "</div><section class='hero'><h1>$title</h1><p>The $uit$ Mafia ML movie factory command deck: recursive metadata, predation patterning, action chains, playlists, charts, graphing, and story renders.</p></section>";
}
function suits_footer(){echo "</main></div><script src='js/suits_v16_4.js'></script></body></html>";}
?>
