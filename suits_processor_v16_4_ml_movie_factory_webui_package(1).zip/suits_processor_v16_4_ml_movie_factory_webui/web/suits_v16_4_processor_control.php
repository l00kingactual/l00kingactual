<?php include 'suits_v16_4_common.php'; suits_header('Processor Control — Switches'); ?>
<div class='card'><p>This page writes a suggested command. Run it in terminal on darkstar.</p><div class='switch-grid'>
<?php $sw=['--ml-update','--build-webui','--build-graphs','--build-charts','--plan-12-movies','--limit-files 5000']; foreach($sw as $s){echo "<label class='switch'><input type='checkbox' checked value='$s'> $s</label>";} ?>
</div><br><button class='btn' onclick='buildCmd()'>Build command</button><pre id='cmd'></pre></div>
<script>function buildCmd(){let vals=[...document.querySelectorAll('input:checked')].map(x=>x.value).join(' ');cmd.textContent='/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_ml_movie_factory '+vals+'\n\nbash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_ml_movie_factory/render_12_full_movies.sh\nbash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_ml_movie_factory/publish_movies_to_site.sh';}buildCmd();</script>
<?php suits_footer(); ?>
