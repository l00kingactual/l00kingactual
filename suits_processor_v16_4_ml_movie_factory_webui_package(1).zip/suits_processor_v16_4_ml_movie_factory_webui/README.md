# [o][o] $uits Processor v16.4 — ML Movie Factory WebUI

Recursive ML/update processor for the $uit$ Mafia media project.

It scans `/home/andy/Documents/suitsmafia`, learns from previous processor output metadata, profiles audio/video/stills/APNG/log/data, builds graph/chart/WebUI data, creates a WebUI switch-control panel, and can plan/render 12 full-audio dramatic story movies to the website `videos/` folder.

## Install

```bash
cd /home/andy/Downloads
unzip -o /mnt/data/suits_processor_v16_4_ml_movie_factory_webui_package.zip
cd suits_processor_v16_4_ml_movie_factory_webui
chmod +x scripts/*.sh tools/*.py *.sh
./scripts/install_v16_4.sh
```

## Run ML update + build WebUI data

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_ml_movie_factory --ml-update --build-webui --build-graphs --build-charts
```

## Plan 12 full-audio movies, then render/copy to website videos

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_4_ml_movie_factory --ml-update --plan-12-movies --build-webui --build-graphs --build-charts
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_ml_movie_factory/render_12_full_movies.sh
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_4_ml_movie_factory/publish_movies_to_site.sh
```

## Local WebUI

```bash
cd /home/andy/Documents/suitsmafia/susitsmafia_website
php -S 127.0.0.1:8081
```

Open:

- `http://127.0.0.1:8081/suits_v16_4_dashboard.php`
- `http://127.0.0.1:8081/suits_v16_4_processor_control.php`
- `http://127.0.0.1:8081/suits_v16_4_movie_factory.php`
- `http://127.0.0.1:8081/suits_v16_4_videos.php`
- `http://127.0.0.1:8081/suits_v16_4_charts.php`
- `http://127.0.0.1:8081/suits_v16_4_graph.php`
