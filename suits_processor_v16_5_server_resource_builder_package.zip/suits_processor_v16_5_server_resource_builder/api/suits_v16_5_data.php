<?php
header('Content-Type: application/json');
$allowed=['summary','music_profile_index','video_profile_index','image_profile_index','song_action_recommendations','action_event_chains','chart_specs_64','graph_nodes','graph_edges','movie_factory_12','predation_comedy_taxonomy'];
$q=$_GET['q'] ?? 'summary';
if(!in_array($q,$allowed,true)){ http_response_code(400); echo json_encode(['error'=>'bad query']); exit; }
$p=__DIR__.'/../data/suits_v16_5/'.$q.'.json';
if(!file_exists($p)){ echo json_encode(['error'=>'not generated yet','path'=>$p]); exit; }
readfile($p);
