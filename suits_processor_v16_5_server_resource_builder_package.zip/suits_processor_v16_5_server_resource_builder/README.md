# [o][o] $uits Processor v16.5 — Server Resource Builder

Builds website/server resources for the `$uit$ Mafia WebUI:

- recursive scan of `/home/andy/Documents/suitsmafia`
- media/profile metadata index
- previous output metadata learning
- SQLite database
- JSON resources for WebUI
- CSV exports
- Neo4j CSV + Cypher
- 64 chart specs
- 12 full-audio movie render jobs
- publish script to copy rendered movies into `susitsmafia_website/videos`

## Install on Linux / darkstar

```bash
cd /home/andy/Downloads
unzip -o /mnt/data/suits_processor_v16_5_server_resource_builder_package.zip
cd suits_processor_v16_5_server_resource_builder
chmod +x scripts/*.sh tools/*.py *.sh
./scripts/install_v16_5.sh
```

## Smoke test

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_5_server_resource_builder \
  --smoke \
  --ml-update \
  --build-webui \
  --build-graphs \
  --build-charts \
  --plan-12-movies \
  --no-probe-media \
  --progress-every 100
```

## Full fast server-resource build

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_5_server_resource_builder \
  --ml-update \
  --build-webui \
  --build-graphs \
  --build-charts \
  --plan-12-movies \
  --no-probe-media \
  --progress-every 250
```

## Outputs

```text
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_5_server_resource_builder
```

Key outputs:

```text
summary.json
music_profile_index.json
video_profile_index.json
image_profile_index.json
song_action_recommendations.json
action_event_chains.json
chart_specs_64.json
graph_nodes.json
graph_edges.json
movie_factory_12.json
predation_comedy_taxonomy.json
sql/suits_server_resource_builder_v16_5.sqlite3
sql/source_files.csv
sql/song_action_recommendations.csv
sql/event_chains.csv
sql/movie_factory_12.csv
neo4j/neo4j_nodes.csv
neo4j/neo4j_edges.csv
neo4j/suits_v16_5_import.cypher
render_12_full_audio_movies.sh
publish_movies_to_site.sh
```

## WebUI pages

```text
/suits_v16_5_dashboard.php
/suits_v16_5_server_resources.php
/suits_v16_5_charts.php
/suits_v16_5_graph.php
/suits_v16_5_videos.php
/suits_v16_5_playlists.php
/suits_v16_5_processor_control.php
```

Start locally:

```bash
cd /home/andy/Documents/suitsmafia/susitsmafia_website
php -S 127.0.0.1:8081
```

## Render and publish movies

After reviewing the report:

```bash
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_5_server_resource_builder/render_12_full_audio_movies.sh
bash /home/andy/Documents/suitsmafia/outputs/suits_processor_v16_5_server_resource_builder/publish_movies_to_site.sh
```

## Windows PowerShell

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
cd $env:USERPROFILE\Downloads\suits_processor_v16_5_server_resource_builder
.\install_v16_5.ps1
```

For WSL from PowerShell:

```powershell
.\install_v16_5.ps1 -Wsl
.\run_v16_5_smoke.ps1 -Wsl
```
