#!/usr/bin/env bash
set -euo pipefail
ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
SITE="${SUITS_SITE:-$ROOT/susitsmafia_website}"
PROC_DIR="$ROOT/processors/suits_processor_v16_5_server_resource_builder"
TOOLS_DIR="$ROOT/tools"
mkdir -p "$PROC_DIR" "$TOOLS_DIR" "$SITE/css" "$SITE/js" "$SITE/api" "$SITE/data/suits_v16_5"
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
rsync -av "$BASE_DIR/" "$PROC_DIR/"
rsync -av "$BASE_DIR/web/" "$SITE/"
rsync -av "$BASE_DIR/api/" "$SITE/api/"
rsync -av "$BASE_DIR/css/" "$SITE/css/"
rsync -av "$BASE_DIR/js/" "$SITE/js/"
cat > "$TOOLS_DIR/suits_processor_v16_5_server_resource_builder" <<EOF
#!/usr/bin/env bash
exec python3 "$PROC_DIR/tools/suits_server_resource_builder_v16_5.py" "\$@"
EOF
chmod +x "$TOOLS_DIR/suits_processor_v16_5_server_resource_builder" "$PROC_DIR/tools/suits_server_resource_builder_v16_5.py"
echo "[o][o] Installed suits processor v16.5 server resource builder"
echo "  $TOOLS_DIR/suits_processor_v16_5_server_resource_builder"
echo "[o][o] WebUI pages installed into $SITE"
