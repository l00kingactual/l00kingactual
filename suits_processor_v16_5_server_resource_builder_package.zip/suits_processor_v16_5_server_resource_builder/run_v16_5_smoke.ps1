param([switch]$Wsl)
if($Wsl){ wsl bash -lc "/home/andy/Documents/suitsmafia/tools/suits_processor_v16_5_server_resource_builder --smoke --ml-update --build-webui --build-graphs --build-charts --plan-12-movies --no-probe-media --progress-every 100"; exit }
& "$env:USERPROFILE\Documents\suitsmafia\tools\suits_processor_v16_5_server_resource_builder.bat" --smoke --ml-update --build-webui --build-graphs --build-charts --plan-12-movies --no-probe-media --progress-every 100
