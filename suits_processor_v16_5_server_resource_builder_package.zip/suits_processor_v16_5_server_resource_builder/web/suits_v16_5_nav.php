<?php
function suits_v16_5_head($title='$uits v16.5'){
  echo "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>".htmlspecialchars($title)."</title><link rel='stylesheet' href='/css/suits_v16_5.css'><script defer src='/js/suits_v16_5.js'></script></head><body><div class='top'><div class='top-inner'><a class='brand' href='/suits_v16_5_dashboard.php'>[o][o] $uit$ Mafia</a><nav class='nav'><a href='/index.html'>Home</a><a href='/suits_v16_5_dashboard.php'>Dashboard</a><a href='/suits_v16_5_server_resources.php'>Server Resources</a><a href='/suits_v16_5_charts.php'>64 Charts</a><a href='/suits_v16_5_graph.php'>Graph</a><a href='/suits_v16_5_videos.php'>Videos</a><a href='/suits_v16_5_playlists.php'>Playlists</a><a href='/suits_v16_5_processor_control.php'>Processor</a></nav></div></div>";
}
function suits_v16_5_foot(){ echo "</body></html>"; }
function data_path($name){ return __DIR__.'/data/suits_v16_5/'.$name; }
function load_json($name,$fallback=[]){ $p=__DIR__.'/data/suits_v16_5/'.$name; if(!file_exists($p)) return $fallback; $j=json_decode(file_get_contents($p),true); return $j?:$fallback; }
?>
