<?php require __DIR__.'/suits_v16_5_nav.php'; suits_v16_5_head('$uits Server Resources'); $s=load_json('summary.json',[]); ?>
<div class='layout'><aside class='side'><h3>Resources</h3><p>Files generated for the website UI.</p></aside><main class='main'><h1>Server Resources</h1><div class='card'><pre><?=htmlspecialchars(json_encode($s,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre></div><div class='card'><h2>Expected data folder</h2><pre>/data/suits_v16_5/
summary.json
music_profile_index.json
video_profile_index.json
image_profile_index.json
song_action_recommendations.json
action_event_chains.json
chart_specs_64.json
graph_nodes.json
graph_edges.json
movie_factory_12.json
predation_comedy_taxonomy.json</pre></div></main></div><?php suits_v16_5_foot(); ?>
