& "$PSScriptRoot\windows\Install-v16_5.ps1" @args
