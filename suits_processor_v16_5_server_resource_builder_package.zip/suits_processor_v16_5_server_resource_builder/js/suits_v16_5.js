(function(){
  document.addEventListener('mousemove', function(e){
    const d=document.createElement('div'); d.className='mouse-dot'; d.style.left=(e.clientX-5)+'px'; d.style.top=(e.clientY-5)+'px'; document.body.appendChild(d); setTimeout(()=>d.remove(),450);
  });
})();
async function jget(url){ const r=await fetch(url,{cache:'no-store'}); return r.ok?await r.json():null; }
function drawBars(canvas, rows, key='category', val='count'){
  if(!canvas||!rows)return; const ctx=canvas.getContext('2d'), w=canvas.width=canvas.clientWidth*2, h=canvas.height=canvas.clientHeight*2; ctx.clearRect(0,0,w,h); ctx.fillStyle='#061426'; ctx.fillRect(0,0,w,h); const max=Math.max(1,...rows.map(r=>Number(r[val]||0))); const bw=w/(rows.length||1); rows.forEach((r,i)=>{const x=i*bw+8, bh=(h-60)*(Number(r[val]||0)/max); ctx.fillStyle='#9dd7ff'; ctx.fillRect(x,h-34-bh,Math.max(4,bw-16),bh); ctx.fillStyle='#eaf6ff'; ctx.font='20px Arial'; ctx.save(); ctx.translate(x+4,h-10); ctx.rotate(-0.55); ctx.fillText(String(r[key]||'').slice(0,16),0,0); ctx.restore();});
}
