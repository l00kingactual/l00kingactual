#!/usr/bin/env bash
set -euo pipefail
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_5_server_resource_builder --ml-update --build-webui --build-graphs --build-charts --plan-12-movies --no-probe-media --progress-every 250
