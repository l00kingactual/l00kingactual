param(
  [string]$Root = "$env:USERPROFILE\Documents\suitsmafia",
  [switch]$Wsl
)
Write-Host "[o][o] Installing suits processor v16.5 server resource builder"
if ($Wsl) {
  wsl bash -lc "cd /mnt/c/Users/$env:USERNAME/Downloads/suits_processor_v16_5_server_resource_builder && chmod +x scripts/*.sh tools/*.py *.sh && ./scripts/install_v16_5.sh"
  exit
}
$pkg = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkg = Split-Path -Parent $pkg
$proc = Join-Path $Root "processors\suits_processor_v16_5_server_resource_builder"
$site = Join-Path $Root "susitsmafia_website"
$tools = Join-Path $Root "tools"
New-Item -ItemType Directory -Force -Path $proc,$site,$tools,(Join-Path $site "css"),(Join-Path $site "js"),(Join-Path $site "api"),(Join-Path $site "data\suits_v16_5") | Out-Null
Copy-Item -Recurse -Force (Join-Path $pkg "*") $proc
Copy-Item -Recurse -Force (Join-Path $pkg "web\*") $site
Copy-Item -Recurse -Force (Join-Path $pkg "css\*") (Join-Path $site "css")
Copy-Item -Recurse -Force (Join-Path $pkg "js\*") (Join-Path $site "js")
Copy-Item -Recurse -Force (Join-Path $pkg "api\*") (Join-Path $site "api")
$bat = Join-Path $tools "suits_processor_v16_5_server_resource_builder.bat"
"@echo off`r`npython `"$proc\tools\suits_server_resource_builder_v16_5.py`" %*`r`n" | Set-Content -Encoding ASCII $bat
Write-Host "Installed launcher: $bat"
