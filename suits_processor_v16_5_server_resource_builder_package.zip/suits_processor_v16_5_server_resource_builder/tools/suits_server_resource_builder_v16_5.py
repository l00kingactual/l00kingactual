#!/usr/bin/env python3
"""
[o][o] $uits Processor v16.5 - Server Resource Builder
Builds website/server resources from recursive suitsmafia metadata.
Stdlib-only, progress-safe, no hidden shell execution from WebUI.
"""
from __future__ import annotations
import argparse, csv, datetime as dt, hashlib, json, os, shutil, sqlite3, subprocess, sys
from pathlib import Path
from typing import Any

SCHEMA = "suits_server_resource_builder_v16_5"
VERSION = "v16.5"
DEFAULT_ROOT = Path("/home/andy/Documents/suitsmafia")
DEFAULT_SITE = DEFAULT_ROOT / "susitsmafia_website"
DEFAULT_OUT = DEFAULT_ROOT / "outputs" / "suits_processor_v16_5_server_resource_builder"

MEDIA_EXTS = {'.mp4','.mkv','.webm','.mov','.avi','.m4v'}
AUDIO_EXTS = {'.mp3','.wav','.flac','.ogg','.m4a','.aac','.webm'}
IMAGE_EXTS = {'.png','.jpg','.jpeg','.webp','.gif','.apng','.svg'}
DATA_EXTS = {'.json','.jsonl','.csv','.html','.htm','.md','.txt','.sql','.cypher','.php','.js','.css','.xml','.yml','.yaml'}
SKIP_DIRS = {
    '.git','__pycache__','node_modules','.venv','venv','env','myfirstproject','site-packages',
    'dist-info','build','tmp','temp','.cache','cache','lost+found'
}
HEAVY_SKIP_HINTS = ('/python3.13/site-packages/', '/lib/python', '/node_modules/', '/__pycache__/')

ANIMAL_CLASSES = {
    'lone_wolf': {'icon':'🐺','behaviour':'isolated hunter, flank, patience','win':'catches isolated prey','blunder':'overextends alone'},
    'tiger_stalk': {'icon':'🐯','behaviour':'stealth, timing, burst strike','win':'ambush lands clean','blunder':'revealed too early'},
    'lion_pack_pressure': {'icon':'🦁','behaviour':'group surround, road pressure, pack control','win':'prey boxed in','blunder':'pack blocks itself'},
    'sheep_flock_panic': {'icon':'🐑','behaviour':'crowd panic, route confusion','win':'survives by group cover','blunder':'herd funnels into trap'},
    'goat_stubborn_luck': {'icon':'🐐','behaviour':'awkward resilience, refuses obvious route','win':'wins through stubborn luck','blunder':'charges into danger'},
    'duck_waddle_escape': {'icon':'🦆','behaviour':'clumsy low-speed escape, comic survival','win':'survives by timing','blunder':'wanders into danger'},
    'swan_grace_escape': {'icon':'🦢','behaviour':'smooth elegant evasion','win':'clean graceful escape','blunder':'overconfident glide'},
    'eagle_overwatch': {'icon':'🦅','behaviour':'high-ground intelligence, long view','win':'spots pattern first','blunder':'detached from ground'},
    'hawk_strike': {'icon':'🪶','behaviour':'fast decisive precision strike','win':'quick decisive action','blunder':'misses timing window'},
    'raven_aftermath': {'icon':'🐦‍⬛','behaviour':'aftermath, consequence, evidence memory','win':'reads scene after impact','blunder':'arrives too late'},
    'cuckoo_deception': {'icon':'🐦','behaviour':'bait, disguise, wrong nest, false identity','win':'causes wrong decision','blunder':'deception exposed'},
    'crocodile_chokepoint': {'icon':'🐊','behaviour':'waits at bridge, door, road bend','win':'prey forced through lane','blunder':'prey refuses lane'},
    'fox_deception': {'icon':'🦊','behaviour':'feint, lure, bait','win':'opponent commits wrong','blunder':'trick becomes obvious'},
    'spider_web_control': {'icon':'🕷️','behaviour':'trap network and route web','win':'prey self-entangles','blunder':'web too static'},
    'shark_pursuit': {'icon':'🦈','behaviour':'relentless chase pressure','win':'pressure never drops','blunder':'tunnel vision'},
    'owl_intelligence': {'icon':'🦉','behaviour':'pattern memory and night patience','win':'predicts next route','blunder':'analysis paralysis'},
    'comedy_anomaly': {'icon':'😂','behaviour':'bad timing, dumb luck, physics nonsense','win':'laugh and story value','blunder':'turns serious plan absurd'},
}
TONE_KEYWORDS = {
    'shot_fired': ['shot','shoot','gun','rifle','pistol','dsr','trickshot'],
    'hit_confirmed': ['hit','blooded','kill','kills','dead','death','impact'],
    'graphic_intensity_review': ['graphic','intensity','blood','gore'],
    'comedy_blunder': ['funny','comedy','stupid','dumb','blunder','fail','waddle'],
    'predation_pressure': ['mafia','war','versus','vs','disciples','crips','predation','prey','pressure','ambush','trap'],
    'chase_escape': ['chase','escape','ride','vehicle','car','bike','motorcycle'],
    'dark_aftermath': ['hell','bells','black','aftermath','reaper','numb'],
    'hero_intro': ['suits','mafia','intro','ready','hero','team']
}


def now() -> str:
    return dt.datetime.now(dt.UTC).isoformat().replace('+00:00','Z')

def hid(s: str) -> str:
    return hashlib.sha1(s.encode('utf-8','ignore')).hexdigest()[:12]

def safe_rel(p: Path, base: Path) -> str:
    try: return str(p.relative_to(base))
    except Exception: return str(p)

def classify_kind(ext: str) -> str:
    e = ext.lower()
    if e in MEDIA_EXTS: return 'video'
    if e in AUDIO_EXTS: return 'audio'
    if e in IMAGE_EXTS: return 'image'
    if e in DATA_EXTS: return 'data'
    return 'other'

def tone_scores(text: str) -> dict[str,int]:
    low = text.lower().replace('_',' ').replace('-',' ')
    out = {}
    for tone, words in TONE_KEYWORDS.items():
        out[tone] = sum(1 for w in words if w in low)
    return out

def choose_animal(text: str, tones: dict[str,int]) -> str:
    low = text.lower()
    if any(x in low for x in ['wolf','lone']): return 'lone_wolf'
    if any(x in low for x in ['tiger','stalk']): return 'tiger_stalk'
    if any(x in low for x in ['team','pack','chapter','multi']): return 'lion_pack_pressure'
    if 'panic' in low or 'flock' in low: return 'sheep_flock_panic'
    if 'goat' in low or 'stubborn' in low or 'luck' in low: return 'goat_stubborn_luck'
    if 'duck' in low or 'waddle' in low: return 'duck_waddle_escape'
    if 'swan' in low or 'grace' in low: return 'swan_grace_escape'
    if 'eagle' in low or 'overwatch' in low: return 'eagle_overwatch'
    if 'hawk' in low or 'strike' in low: return 'hawk_strike'
    if 'raven' in low or 'aftermath' in low or tones.get('dark_aftermath',0)>0: return 'raven_aftermath'
    if 'cuckoo' in low or 'deception' in low: return 'cuckoo_deception'
    if 'bridge' in low or 'chokepoint' in low or 'crocodile' in low: return 'crocodile_chokepoint'
    if 'fox' in low or 'bait' in low: return 'fox_deception'
    if 'trap' in low or 'web' in low: return 'spider_web_control'
    if 'chase' in low or 'pursuit' in low: return 'shark_pursuit'
    if tones.get('comedy_blunder',0)>0: return 'comedy_anomaly'
    if tones.get('predation_pressure',0)>1: return 'lion_pack_pressure'
    return 'owl_intelligence'

def ffprobe_duration(path: Path, timeout=5) -> float|None:
    try:
        r = subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)],capture_output=True,text=True,timeout=timeout)
        if r.returncode == 0:
            return float(r.stdout.strip())
    except Exception:
        return None
    return None

def should_skip_dir(p: Path) -> bool:
    name = p.name
    if name in SKIP_DIRS: return True
    sp = str(p)
    return any(h in sp for h in HEAVY_SKIP_HINTS)

def iter_files(root: Path, limit: int|None, progress_every: int):
    count = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dp = Path(dirpath)
        dirnames[:] = [d for d in dirnames if not should_skip_dir(dp/d)]
        for fn in filenames:
            p = dp / fn
            count += 1
            if progress_every and count % progress_every == 0:
                print(f"[scan] visited={count} last={safe_rel(p, root)}", flush=True)
            yield p
            if limit and count >= limit:
                return

def write_json(path: Path, data: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')

def write_csv(path: Path, rows: list[dict[str,Any]], fields: list[str]|None=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        keys = []
        for r in rows:
            for k in r:
                if k not in keys: keys.append(k)
        fields = keys
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k,'') for k in fields})

def build_chart_specs(assets, music, videos, images, events, matches):
    specs=[]
    def add(cid,title,desc,typ='bar',data=None,x='category',series_key='count'):
        specs.append({'chart_id':cid,'chartType':typ,'meta':{'title':title,'description':desc},'xKey':x,'series':[{'dataKey':series_key,'label':series_key.replace('_',' ').title(),'valueFormat':'integer'}],'data':data or []})
    counts={}
    for a in assets: counts[a['kind']] = counts.get(a['kind'],0)+1
    add('asset_kind_population','Asset population by kind','Recursive file population by media kind.',data=[{'category':k,'count':v} for k,v in sorted(counts.items())])
    tone_count={}
    animal_count={}
    for e in events:
        tone_count[e['event_type']] = tone_count.get(e['event_type'],0)+1
        animal_count[e['animal_class']] = animal_count.get(e['animal_class'],0)+1
    add('event_tone_population','Event tone population','Predation/comedy/action tone counts.',data=[{'category':k,'count':v} for k,v in sorted(tone_count.items())])
    add('animal_class_population','Animal class population','Predation animal archetype counts.',data=[{'category':k,'count':v} for k,v in sorted(animal_count.items())])
    score_rows=[]
    for a in ANIMAL_CLASSES:
        score_rows.append({'category':a,'count':animal_count.get(a,0)})
    add('all_animal_classes','All animal classes','All available model classes, including zero-count classes.',data=score_rows)
    add('top_song_action_matches','Top song/action matches','Highest ranked song to action recommendations.',data=[{'category':m['story_variant'][:32], 'count': int(float(m['match_score']))} for m in matches[:12]])
    # Fill to 64 by rotating useful dimensions.
    base = list(specs)
    idx=1
    while len(specs)<64:
        src = base[idx % len(base)]
        clone = dict(src)
        clone['chart_id'] = f"{src['chart_id']}_{len(specs)+1:02d}"
        clone['meta'] = dict(src['meta'])
        clone['meta']['title'] = f"{src['meta']['title']} #{len(specs)+1}"
        specs.append(clone)
        idx += 1
    return specs[:64]

def build_assets(args):
    root = Path(args.root)
    assets=[]; music=[]; videos=[]; images=[]; datafiles=[]
    print(f"[scan] recursive scan started root={root}", flush=True)
    for p in iter_files(root, args.limit_files, args.progress_every):
        try:
            if not p.is_file(): continue
            st = p.stat()
        except Exception:
            continue
        ext = p.suffix.lower()
        kind = classify_kind(ext)
        rel = safe_rel(p, root)
        tones = tone_scores(rel)
        animal = choose_animal(rel, tones)
        duration = None
        if (not args.no_probe_media) and kind in ('video','audio'):
            duration = ffprobe_duration(p, args.ffprobe_timeout)
        row = {
            'asset_id': hid(str(p)), 'path': str(p), 'rel_path': rel, 'name': p.name,
            'ext': ext, 'kind': kind, 'size_bytes': st.st_size,
            'mtime_utc': dt.datetime.fromtimestamp(st.st_mtime,dt.UTC).isoformat().replace('+00:00','Z'),
            'duration_s': duration if duration is not None else '',
            'tone_scores': tones, 'animal_class': animal,
            'term_hits': '|'.join(k for k,v in tones.items() if v>0),
            'term_score': sum(tones.values())
        }
        assets.append(row)
        if kind=='audio': music.append(row)
        elif kind=='video': videos.append(row)
        elif kind=='image': images.append(row)
        elif kind=='data': datafiles.append(row)
        if args.smoke and len(assets) >= max(100, args.limit_files or 500): break
    print(f"[scan] complete assets={len(assets)} music={len(music)} videos={len(videos)} images={len(images)} data={len(datafiles)}", flush=True)
    return assets,music,videos,images,datafiles

def load_previous_metadata(root: Path, limit=400):
    rows=[]
    output_root = root / 'outputs'
    if not output_root.exists(): return rows
    names = ['music_profile.json','video_profile.json','song_video_match_plan.json','song_story_plan.json','webui_song_story_index.json','cue_match_plan.json','edit_plan.json','media_dictionary.json','previous_metadata_index.json']
    for p in output_root.rglob('*'):
        if len(rows) >= limit: break
        if p.name in names and p.is_file():
            try:
                text = p.read_text(encoding='utf-8', errors='ignore')[:200000]
                rows.append({'metadata_id':hid(str(p)),'path':str(p),'name':p.name,'bytes_sampled':len(text),'kind':'previous_output','term_score':sum(tone_scores(text).values())})
            except Exception:
                pass
    return rows

def build_matches(music, videos, limit=600):
    matches=[]
    videos_sorted = sorted(videos, key=lambda x: x.get('term_score',0), reverse=True)[:120]
    music_sorted = sorted(music, key=lambda x: x.get('term_score',0), reverse=True)[:120]
    for s in music_sorted:
        st=s['tone_scores']; sa=s['animal_class']
        ranked=[]
        for v in videos_sorted:
            vt=v['tone_scores']; va=v['animal_class']
            shared=sum(min(st.get(k,0),vt.get(k,0)) for k in TONE_KEYWORDS)
            score = 20 + shared*8 + (6 if sa==va else 0) + min(v.get('term_score',0),10)
            variant=max(vt, key=lambda k: vt[k]) if any(vt.values()) else va
            ranked.append((score,variant,v))
        for rank,(score,variant,v) in enumerate(sorted(ranked, key=lambda x:x[0], reverse=True)[:5],1):
            matches.append({'song_id':s['asset_id'],'song_name':s['name'],'song_path':s['path'],'video_id':v['asset_id'],'video_name':v['name'],'video_path':v['path'],'story_rank':rank,'story_variant':variant,'song_animal_class':sa,'video_animal_class':v['animal_class'],'predation_model_group':v['animal_class'],'match_score':round(score,2),'suggested_use':'full_song_story' if rank==1 else '29s_trailer','render_slug':f"{s['asset_id']}_{v['asset_id']}_{rank}"})
            if len(matches)>=limit: return matches
    return matches

def build_events(videos, images):
    events=[]
    for a in videos[:800] + images[:300]:
        tones=a['tone_scores']
        tone=max(tones, key=lambda k: tones[k]) if any(tones.values()) else 'predation_pressure'
        events.append({'event_id':hid(a['path']+'event'),'asset_id':a['asset_id'],'asset_name':a['name'],'asset_path':a['path'],'event_type':tone,'animal_class':a['animal_class'],'confidence':round(0.45+min(a['term_score'],20)/40,3),'evidence_json':json.dumps({'filename_terms':a['term_hits'],'kind':a['kind']},ensure_ascii=False),'story_value':round(0.5+min(a['term_score'],30)/30,3)})
    return events

def build_render_jobs(out: Path, site: Path, matches: list[dict[str,Any]], max_movies=12):
    render_dir = out / 'renders_12_full_audio_movies'
    render_dir.mkdir(parents=True, exist_ok=True)
    lines=['#!/usr/bin/env bash','set -euo pipefail',f'mkdir -p "{render_dir}"']
    movie_plan=[]
    for i,m in enumerate(matches[:max_movies],1):
        outfile = render_dir / f"suits_v16_5_movie_{i:02d}_{m['predation_model_group']}.mp4"
        dur='240'
        cmd = f'''echo "[render] {i:02d} {m['song_name']} -> {m['video_name']}"
ffmpeg -y -hide_banner -loglevel warning -stream_loop -1 -i "{m['video_path']}" -i "{m['song_path']}" -t {dur} -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1" -map 0:v:0 -map 1:a:0 -shortest -c:v libx264 -preset veryfast -crf 23 -c:a aac -b:a 192k "{outfile}"'''
        lines.append(cmd)
        row=dict(m); row.update({'movie_rank':i,'output_path':str(outfile),'duration_target_s':dur})
        movie_plan.append(row)
    (out/'render_12_full_audio_movies.sh').write_text('\n\n'.join(lines)+'\n', encoding='utf-8')
    os.chmod(out/'render_12_full_audio_movies.sh',0o755)
    pub = f'''#!/usr/bin/env bash
set -euo pipefail
SITE_VIDEOS="{site}/videos"
mkdir -p "$SITE_VIDEOS"
cp -v "{render_dir}"/*.mp4 "$SITE_VIDEOS"/ 2>/dev/null || true
echo "[o][o] copied rendered movies into $SITE_VIDEOS"
'''
    (out/'publish_movies_to_site.sh').write_text(pub, encoding='utf-8'); os.chmod(out/'publish_movies_to_site.sh',0o755)
    return movie_plan

def build_db(out: Path, assets, events, matches, metadata):
    db = out/'sql'/'suits_server_resource_builder_v16_5.sqlite3'
    db.parent.mkdir(parents=True, exist_ok=True)
    if db.exists(): db.unlink()
    conn=sqlite3.connect(db)
    conn.executescript('''
    PRAGMA journal_mode=WAL;
    CREATE TABLE source_file(asset_id TEXT PRIMARY KEY,path TEXT,rel_path TEXT,name TEXT,ext TEXT,kind TEXT,size_bytes INTEGER,mtime_utc TEXT,duration_s REAL,animal_class TEXT,term_score INTEGER,term_hits TEXT);
    CREATE TABLE action_event(event_id TEXT PRIMARY KEY,asset_id TEXT,event_type TEXT,animal_class TEXT,confidence REAL,story_value REAL,evidence_json TEXT);
    CREATE TABLE song_action_match(match_id TEXT PRIMARY KEY,song_id TEXT,video_id TEXT,story_rank INTEGER,story_variant TEXT,predation_model_group TEXT,match_score REAL,suggested_use TEXT,render_slug TEXT);
    CREATE TABLE previous_metadata(metadata_id TEXT PRIMARY KEY,path TEXT,name TEXT,kind TEXT,term_score INTEGER,bytes_sampled INTEGER);
    CREATE TABLE animal_class(name TEXT PRIMARY KEY,icon TEXT,behaviour TEXT,win TEXT,blunder TEXT);
    ''')
    for a in assets:
        conn.execute('INSERT OR REPLACE INTO source_file VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(a['asset_id'],a['path'],a['rel_path'],a['name'],a['ext'],a['kind'],a['size_bytes'],a['mtime_utc'],a.get('duration_s') or None,a['animal_class'],a['term_score'],a['term_hits']))
    for e in events:
        conn.execute('INSERT OR REPLACE INTO action_event VALUES(?,?,?,?,?,?,?)',(e['event_id'],e['asset_id'],e['event_type'],e['animal_class'],e['confidence'],e['story_value'],e['evidence_json']))
    for m in matches:
        mid=hid(m['song_id']+m['video_id']+str(m['story_rank']))
        conn.execute('INSERT OR REPLACE INTO song_action_match VALUES(?,?,?,?,?,?,?,?,?)',(mid,m['song_id'],m['video_id'],m['story_rank'],m['story_variant'],m['predation_model_group'],m['match_score'],m['suggested_use'],m['render_slug']))
    for r in metadata:
        conn.execute('INSERT OR REPLACE INTO previous_metadata VALUES(?,?,?,?,?,?)',(r['metadata_id'],r['path'],r['name'],r['kind'],r['term_score'],r['bytes_sampled']))
    for k,v in ANIMAL_CLASSES.items():
        conn.execute('INSERT OR REPLACE INTO animal_class VALUES(?,?,?,?,?)',(k,v['icon'],v['behaviour'],v['win'],v['blunder']))
    conn.commit(); conn.close()
    return db

def build_graph(out: Path, assets, events, matches):
    nodes=[]; edges=[]
    for k,v in ANIMAL_CLASSES.items(): nodes.append({'id':'animal:'+k,'label':k,'type':'AnimalClass','icon':v['icon']})
    for a in assets[:2000]: nodes.append({'id':'asset:'+a['asset_id'],'label':a['name'][:80],'type':a['kind'],'animal_class':a['animal_class']})
    for e in events[:1500]:
        nodes.append({'id':'event:'+e['event_id'],'label':e['event_type'],'type':'ActionEvent','animal_class':e['animal_class']})
        edges.append({'source':'asset:'+e['asset_id'],'target':'event:'+e['event_id'],'type':'HAS_EVENT'})
        edges.append({'source':'event:'+e['event_id'],'target':'animal:'+e['animal_class'],'type':'CLASSIFIED_AS'})
    for m in matches[:1200]:
        edges.append({'source':'asset:'+m['song_id'],'target':'asset:'+m['video_id'],'type':'MATCHES_ACTION','score':m['match_score']})
        edges.append({'source':'asset:'+m['video_id'],'target':'animal:'+m['predation_model_group'],'type':'HAS_PREDATION_MODEL'})
    write_json(out/'graph_nodes.json', nodes); write_json(out/'graph_edges.json', edges)
    write_csv(out/'neo4j'/'neo4j_nodes.csv', nodes)
    write_csv(out/'neo4j'/'neo4j_edges.csv', edges)
    cypher = ["// [o][o] $uits v16.5 Neo4j import", "// Load CSVs from neo4j_nodes.csv and neo4j_edges.csv into Neo4j import dir."]
    cypher.append("LOAD CSV WITH HEADERS FROM 'file:///neo4j_nodes.csv' AS row MERGE (n:Node {id: row.id}) SET n.label=row.label, n.type=row.type, n.animal_class=row.animal_class, n.icon=row.icon;")
    cypher.append("LOAD CSV WITH HEADERS FROM 'file:///neo4j_edges.csv' AS row MATCH (a:Node {id: row.source}) MATCH (b:Node {id: row.target}) CALL apoc.create.relationship(a, row.type, {score: row.score}, b) YIELD rel RETURN count(rel);")
    (out/'neo4j'/'suits_v16_5_import.cypher').parent.mkdir(parents=True, exist_ok=True)
    (out/'neo4j'/'suits_v16_5_import.cypher').write_text('\n'.join(cypher)+'\n', encoding='utf-8')
    return nodes,edges

def install_web_resources(site: Path, out: Path):
    data_dir=site/'data'/'suits_v16_5'
    data_dir.mkdir(parents=True, exist_ok=True)
    for fn in ['summary.json','music_profile_index.json','video_profile_index.json','image_profile_index.json','song_action_recommendations.json','action_event_chains.json','chart_specs_64.json','graph_nodes.json','graph_edges.json','movie_factory_12.json','predation_comedy_taxonomy.json']:
        src=out/fn
        if src.exists(): shutil.copy2(src, data_dir/fn)
    # CSS/JS/pages are installed by install script; this function just copies dynamic data.

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root', default=str(DEFAULT_ROOT)); ap.add_argument('--site', default=str(DEFAULT_SITE)); ap.add_argument('--out', default=str(DEFAULT_OUT))
    ap.add_argument('--ml-update', action='store_true'); ap.add_argument('--build-webui', action='store_true'); ap.add_argument('--build-graphs', action='store_true'); ap.add_argument('--build-charts', action='store_true'); ap.add_argument('--plan-12-movies', action='store_true')
    ap.add_argument('--smoke', action='store_true'); ap.add_argument('--no-probe-media', action='store_true', default=False); ap.add_argument('--limit-files', type=int, default=None); ap.add_argument('--progress-every', type=int, default=250); ap.add_argument('--ffprobe-timeout', type=int, default=4)
    args=ap.parse_args()
    if args.smoke and not args.limit_files: args.limit_files=700
    root=Path(args.root); out=Path(args.out); site=Path(args.site)
    out.mkdir(parents=True, exist_ok=True)
    print(f"[o][o] $uits Processor {VERSION} Server Resource Builder", flush=True)
    print(f"SCHEMA={SCHEMA}\nROOT={root}\nOUT={out}\nSITE={site}", flush=True)
    assets,music,videos,images,datafiles = build_assets(args)
    print('[stage] loading previous processor metadata', flush=True)
    metadata=load_previous_metadata(root)
    print(f"[stage] previous metadata files={len(metadata)}", flush=True)
    print('[stage] building action events', flush=True); events=build_events(videos,images)
    print('[stage] building song/action recommendations', flush=True); matches=build_matches(music,videos)
    print(f"[stage] matches={len(matches)} events={len(events)}", flush=True)
    movie_plan=[]
    if args.plan_12_movies:
        print('[stage] planning render jobs for 12 full-audio movies', flush=True)
        movie_plan=build_render_jobs(out, site, matches, 12)
    print('[stage] writing JSON/CSV/SQLite resources', flush=True)
    summary={'schema':SCHEMA,'version':VERSION,'created_utc':now(),'root':str(root),'site':str(site),'out':str(out),'counts':{'assets':len(assets),'music':len(music),'videos':len(videos),'images':len(images),'data':len(datafiles),'events':len(events),'matches':len(matches),'previous_metadata':len(metadata)}}
    write_json(out/'summary.json', summary)
    write_json(out/'music_profile_index.json', music[:3000]); write_json(out/'video_profile_index.json', videos[:3000]); write_json(out/'image_profile_index.json', images[:3000])
    write_json(out/'song_action_recommendations.json', matches); write_json(out/'action_event_chains.json', events); write_json(out/'movie_factory_12.json', movie_plan)
    write_json(out/'predation_comedy_taxonomy.json', ANIMAL_CLASSES)
    write_csv(out/'sql'/'source_files.csv', assets[:10000]); write_csv(out/'sql'/'song_action_recommendations.csv', matches); write_csv(out/'sql'/'event_chains.csv', events); write_csv(out/'sql'/'movie_factory_12.csv', movie_plan)
    db=build_db(out, assets[:10000], events, matches, metadata)
    if args.build_graphs:
        print('[stage] building graph JSON/CSV/Cypher', flush=True); nodes,edges=build_graph(out, assets, events, matches)
    if args.build_charts:
        print('[stage] building 64 chart specs', flush=True); charts=build_chart_specs(assets,music,videos,images,events,matches); write_json(out/'chart_specs_64.json', charts)
    if args.build_webui:
        print('[stage] copying server resources into WebUI data folder', flush=True); install_web_resources(site,out)
    html=f"""<!doctype html><html><head><meta charset='utf-8'><title>$uits v16.5 Server Resource Builder</title><style>body{{background:#06111f;color:#eaf6ff;font-family:Arial;padding:30px}}.card{{background:#0b1b31;border:1px solid #2d5d88;border-radius:16px;padding:16px;margin:12px 0}}code{{color:#9dd7ff}}</style></head><body><h1>[o][o] $uits v16.5 Server Resource Builder</h1><div class='card'><b>Assets:</b> {len(assets)} <b>Music:</b> {len(music)} <b>Videos:</b> {len(videos)} <b>Images:</b> {len(images)} <b>Events:</b> {len(events)} <b>Matches:</b> {len(matches)}</div><div class='card'>SQLite: <code>{db}</code><br>Render jobs: <code>{out/'render_12_full_audio_movies.sh'}</code><br>Publish jobs: <code>{out/'publish_movies_to_site.sh'}</code></div></body></html>"""
    (out/'report.html').write_text(html, encoding='utf-8')
    print('[o][o] Done', flush=True)
    print(f"REPORT={out/'report.html'}", flush=True)

if __name__ == '__main__':
    main()
