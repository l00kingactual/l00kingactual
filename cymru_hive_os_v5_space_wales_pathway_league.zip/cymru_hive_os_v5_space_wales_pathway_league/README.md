# Cymru Hive OS v5 · SPACE WALE$ Pathway League

Retains: zoomable Wales map, £2.5bn/year capped sliders, 25,000 staff model, provider/consumer population model, 1/5/10/25-year horizons, 2D/3D charting and auto-running 24 auto-tunes.

Adds: Cubs, Brownies, Scouts, Guides, adventures, CCF-style leadership, astronomy, sport, maths, physics, languages, chemistry, biology, farm twins, terrain-map projects, badges, competitions and ROI scoring.

Run:
```bash
python3 -m http.server 8088
```
Open http://127.0.0.1:8088/
