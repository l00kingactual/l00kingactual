
(function(){
  const DATA = window.CYMRU_HIVE_DATA;
  const E = window.CymruEngine;
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  function log(state, msg){ state.logLines.unshift(`[${new Date().toLocaleTimeString()}] ${msg}`); state.logLines = state.logLines.slice(0, 14); $('consoleLog').textContent = state.logLines.join('\n'); }
  function selectedBee(state){ return state.bees.find(b => b.id === state.selectedBeeId) || state.bees[0]; }
  function renderBars(title, obj){
    return `<div class="state-card"><h3>${title}</h3>${Object.entries(obj).map(([k,v]) => `<div class="bar-row"><span>${esc(k)}</span><span class="bar"><i style="width:${Math.round(v)}%"></i></span><strong>${Math.round(v)}</strong></div>`).join('')}</div>`;
  }
  function renderState(state){
    const bee = selectedBee(state); if (!bee) return;
    $('beeSelect').value = bee.id; $('tuneSelect').value = String(state.tuneIndex);
    $('selectedBeeName').textContent = `${bee.emoji} ${bee.id}`;
    $('selectedBeeSummary').innerHTML = `${esc(bee.ageStage)} · role <strong>${esc(bee.role)}</strong> · home scale <strong>${esc(bee.homeScale)}</strong><br>hive <strong>${esc(bee.currentHive)}</strong> · GPS ${bee.gps.lat.toFixed(4)}, ${bee.gps.lon.toFixed(4)} · OSGB E ${bee.osgb36.easting} N ${bee.osgb36.northing}`;
    $('stateTitle').textContent = `${bee.id} · ${bee.ageStage} quantified pathway`;
    $('stateGrid').innerHTML = renderBars('🍯 Honey outputs', bee.honey)+renderBars('🌸 Nectar received', bee.nectar)+renderBars('🧠 Traits developed', bee.traits)+renderBars('🏡 Places moved through', bee.places)+renderBars('🏥 Service organs used', bee.services);
    const score = E.scoreBee(bee); $('honeyMetric').textContent = score.honeyIndex; $('traitMetric').textContent = score.traitIndex;
  }
  function selectHive(state, hive){
    $('selectedHive').textContent = `${hive.icon} ${hive.name}`;
    $('selectedHiveText').innerHTML = `<strong>${esc(hive.type)}</strong> · ${esc(hive.placeScale)} hive node. ${esc(hive.notes)}`;
    $('gisTable').innerHTML = `<tr><th>GPS lat</th><td>${hive.gps.lat.toFixed(5)}</td></tr><tr><th>GPS lon</th><td>${hive.gps.lon.toFixed(5)}</td></tr><tr><th>OSGB E</th><td>${hive.osgb36.easting}</td></tr><tr><th>OSGB N</th><td>${hive.osgb36.northing}</td></tr><tr><th>Services</th><td>${hive.services.map(esc).join(', ')}</td></tr>`;
    log(state, `Hive selected: ${hive.name} GPS(${hive.gps.lat.toFixed(4)}, ${hive.gps.lon.toFixed(4)}) OSGB(${hive.osgb36.easting}, ${hive.osgb36.northing})`);
  }
  function contentHTML(key){
    if (key === 'strategy') return `<div class="card-grid"><div class="card"><h3>🏴 National pathway map</h3><p>Every child can be mapped from age 5 into learning, sport, health, ecology, astronomy and enterprise pathways, with evidence of which services help them progress.</p></div><div class="card"><h3>🚑 Prevention engine</h3><p>Sport, GP prevention, parks, safe routes and health education become early wellbeing honey rather than late crisis response.</p></div><div class="card"><h3>🎓 Apprenticeship conversion</h3><p>College, university, libraries, transport and enterprise combs become visible bridges into apprenticeships, jobs and invention.</p></div><div class="card"><h3>🌾 SPACE Farmers</h3><p>Land, food, pollinators, water, astronomy, GIS, sensors and satellite data become one Welsh agrarian-technology curriculum.</p></div><div class="card"><h3>🚌 Rural access intelligence</h3><p>Transport gaps become visible: where buses, taxis, trains or service routes fail, the bee pathway weakens and can be repaired.</p></div><div class="card"><h3>🍯 Honey accounting</h3><p>Communities can track wellbeing, knowledge, sport, jobs, apprenticeships, invention, food, ecological repair and civic pride as measurable outputs.</p></div></div>`;
    if (key === 'architecture') return `<p>The package includes complete seed data in <code>/data</code> plus runtime data in <code>assets/js/data.js</code>.</p><div class="jsonbox">${esc(JSON.stringify(DATA.architecture, null, 2))}</div>`;
    if (key === 'schema') return `<div class="jsonbox">${esc(JSON.stringify(DATA.beeTemplate, null, 2))}</div>`;
    if (key === 'routes') return `<div class="jsonbox">${esc(JSON.stringify(DATA.pathways, null, 2))}</div>`;
    return `<div class="card-grid"><div class="card"><h3>🐝 Individual Bee</h3><p>Every learner/citizen is modelled as a bee with nectar, traits, places, service-comb use and honey outputs.</p></div><div class="card"><h3>🏡 Welsh Hive</h3><p>Hamlets, villages, towns and cities become living hives with services as combs and transport as nectar routes.</p></div><div class="card"><h3>🍯 Excellence Honey</h3><p>Honey is measurable: wellbeing, knowledge, sport, jobs, apprenticeships, invention, food, ecological repair and civic pride.</p></div></div>`;
  }
  function showContent(key){
    const titles = {overview:'Cymru Hive OS engine summary', strategy:'What v2 could achieve for Wales', architecture:'Data architecture', schema:'Bee state schema', routes:'Pathway routes and scale ladder'};
    $('contentTitle').textContent = titles[key] || titles.overview; $('contentBody').innerHTML = contentHTML(key);
  }
  function populateSelectors(state){
    $('beeSelect').innerHTML = state.bees.map(b => `<option value="${b.id}">${b.emoji} ${b.id}</option>`).join('');
    $('tuneSelect').innerHTML = DATA.autoTunes.map((t,i) => `<option value="${i}">${t.emoji} ${String(i+1).padStart(2,'0')} · ${t.name}</option>`).join('');
  }
  function renderTuneButtons(state, setTune){
    const root = $('tuneButtons'); root.innerHTML = '';
    DATA.autoTunes.forEach((t,i) => { const b = document.createElement('button'); b.className = 'side-card' + (i === state.tuneIndex ? ' active' : ''); b.innerHTML = `<strong>${t.emoji} ${String(i+1).padStart(2,'0')} · ${esc(t.name)}</strong><small>${esc(t.ageStage)} · age ${esc(t.age)} · ${esc(t.description)}</small>`; b.addEventListener('click', () => setTune(i, true)); root.appendChild(b); });
  }
  function exportState(state){
    const payload = {generatedAt:new Date().toISOString(), version:DATA.architecture.version, selectedBeeId:state.selectedBeeId, tuneIndex:state.tuneIndex, bees:state.bees};
    const blob = new Blob([JSON.stringify(payload, null, 2)], {type:'application/json'}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'cymru-hive-os-v2-state.json'; a.click(); URL.revokeObjectURL(url);
  }
  window.CymruUI = {log, selectedBee, renderState, selectHive, showContent, populateSelectors, renderTuneButtons, exportState};
})();
