
(function(){
  const DATA = window.CYMRU_HIVE_DATA;
  function clear(el){ while(el.firstChild) el.removeChild(el.firstChild); }
  function markerClass(hive, tune){
    const active = tune.activeHiveTypes.includes(hive.type) || hive.nectarTags.some(t => tune.activeHiveTypes.includes(t));
    return 'marker' + (active ? ' active' : ' dim');
  }
  function renderMarkers(state, onHive){
    const layer = document.getElementById('markerLayer'); clear(layer);
    const tune = DATA.autoTunes[state.tuneIndex];
    DATA.hives.forEach(hive => {
      const btn = document.createElement('button');
      btn.className = markerClass(hive, tune);
      btn.style.left = hive.map.xPercent + '%';
      btn.style.top = hive.map.yPercent + '%';
      btn.innerHTML = `<span>${hive.icon}</span><span>${hive.name}</span>`;
      btn.addEventListener('mousedown', ev => ev.preventDefault()); btn.addEventListener('click', ev => { ev.preventDefault(); ev.stopPropagation(); onHive(hive); });
      layer.appendChild(btn);
    });
  }
  function renderRoutes(state){
    const layer = document.getElementById('routeLayer'); clear(layer);
    state.bees.slice(0, 16).forEach(bee => {
      const dx = bee.targetX - bee.mapX, dy = bee.targetY - bee.mapY;
      const len = Math.sqrt(dx*dx + dy*dy); const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      const line = document.createElement('div'); line.className = 'route-line';
      line.style.left = bee.mapX + '%'; line.style.top = bee.mapY + '%'; line.style.width = len + '%'; line.style.transform = `rotate(${angle}deg)`;
      layer.appendChild(line);
    });
  }
  function renderBees(state, onBee){
    const layer = document.getElementById('beeLayer'); clear(layer);
    state.bees.forEach(bee => {
      const x = bee.mapX + (bee.targetX - bee.mapX) * bee.progress;
      const y = bee.mapY + (bee.targetY - bee.mapY) * bee.progress;
      const el = document.createElement('div');
      el.className = 'bee' + (bee.id === state.selectedBeeId ? ' active' : '');
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', `${bee.id} · ${bee.ageStage}`);
      el.tabIndex = -1;
      el.style.left = x + '%';
      el.style.top = y + '%';
      el.textContent = bee.emoji;
      el.title = `${bee.id} · ${bee.ageStage}`;
      el.addEventListener('mousedown', ev => ev.preventDefault());
      el.addEventListener('click', ev => { ev.preventDefault(); ev.stopPropagation(); onBee(bee.id); });
      layer.appendChild(el);
    });
  }
  window.CymruMap = {renderMarkers, renderRoutes, renderBees};
})();
