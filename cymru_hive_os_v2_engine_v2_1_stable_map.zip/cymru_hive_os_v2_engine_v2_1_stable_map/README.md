# Cymru Hive OS v2 · Individual Bee Pathway Engine

This is a split-file WebUI package. It is not a single long HTML file.

## Run locally

```bash
cd cymru_hive_os_v2_engine
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Apache localhost

```bash
cd cymru_hive_os_v2_engine
sudo rsync -av --delete ./ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
```

Open:

```text
http://localhost/
```

## Architecture

Runtime files:

- `index.html`
- `assets/css/styles.css`
- `assets/js/data.js`
- `assets/js/engine.js`
- `assets/js/map.js`
- `assets/js/ui.js`
- `assets/js/app.js`
- `assets/img/wales.jpeg`

Data architecture:

- `data/hives.json`
- `data/hives.geojson`
- `data/auto_tunes.json`
- `data/bee_template.json`
- `data/roles.json`
- `data/matrices.json`
- `data/pathways.json`
- `data/services.json`
- `data/architecture.schema.json`

Database/graph seeds:

- `schema/cymru_hive_os.sql`
- `graph/cymru_hive_os.cypher`

## What it models

Individual Bee → receives nectar → develops traits → moves through household/hamlet/village/town/city/Wales → uses service organs → produces honey outputs.

Coordinates are WGS84 GPS plus approximate OSGB36 British National Grid seeds for planning/demo use, not survey-grade OS data.


## v2.1 stable-map patch

This build fixes the map jumping/scrolling problem by:

- removing the `<a>` wrapper around the live map overlays
- adding a separate **Open map image** button
- removing automatic `scrollIntoView()` calls from content updates
- rendering animated bees as non-focusable div elements instead of buttons
- disabling browser scroll anchoring around the live map layers

Run with:

```bash
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```
