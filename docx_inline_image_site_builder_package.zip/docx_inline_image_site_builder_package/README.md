# DOCX Inline Image Site Builder Package

This package converts Word `.docx` files into a grouped static website with inline extracted images.

## Install

```bash
cd /home/andy/Documents/0uch.me
python3 -m venv .venv
source .venv/bin/activate
pip install python-docx lxml
```

## Run

```bash
python3 docx_inline_image_site_builder.py --word-dir word_docs --out docx_static_site
```

## Preview

```bash
cd docx_static_site
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Apache localhost

```bash
sudo rsync -av --delete docx_static_site/ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
```

Open:

```text
http://localhost/
```
