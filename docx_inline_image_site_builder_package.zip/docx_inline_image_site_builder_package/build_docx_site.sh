#!/usr/bin/env bash
set -euo pipefail
WORD_DIR="${1:-word_docs}"
OUT_DIR="${2:-docx_static_site}"
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install python-docx lxml
python3 docx_inline_image_site_builder.py --word-dir "$WORD_DIR" --out "$OUT_DIR"
echo
echo "Preview:"
echo "  cd $OUT_DIR"
echo "  python3 -m http.server 8088"
echo "  http://127.0.0.1:8088/"
