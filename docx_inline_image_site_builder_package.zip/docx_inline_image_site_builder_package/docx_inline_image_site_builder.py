#!/usr/bin/env python3
# docx_inline_image_site_builder.py
# Convert Word .docx documents into a grouped static HTML site with inline extracted images.

from __future__ import annotations

import argparse
import hashlib
import html
import json
import mimetypes
import re
import shutil
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    from docx import Document
    from docx.document import Document as _Document
    from docx.table import Table, _Cell
    from docx.text.paragraph import Paragraph
    from docx.oxml.ns import qn
except Exception as exc:
    raise SystemExit(
        "Missing dependency. Install it with:\n\n"
        "  python3 -m pip install python-docx lxml\n\n"
        f"Original error: {exc}"
    )

IDEA_GROUPS = [
    {"name":"Advanced Computing and AI","icon":"🧠","summary":"Hybrid analogue/digital computing, artificial intelligence, machine learning, Janus principles, robust systems, quantum-aware computation, processors, algorithms and intelligent automation.","terms":["ai","ml","machine","learning","comput","processor","janus","quantum","algorithm","neural","data","analogue","digital","mnemonic","hybrid"],"ideas":["Hybrid Analogue-Digital Computing","Stateless Mnemonic System","Hybrid Computing Systems","2-bit 3-state System and 5-bit Logic Conversion","Advanced Error Handling and Robustness","AI and ML Integration with Janus Principles","Quantum Computing and AI Integration"]},
    {"name":"Space Exploration and Technologies","icon":"🚀","summary":"Space systems, satellite networks, propulsion, orbital construction, space-based AI, debris management, astronomy and planetary-scale technology.","terms":["space","satellite","orbital","galactic","planet","propulsion","debris","astronomy","telescope","exoplanet","cosmos"],"ideas":["Space Level: Inter-Galactic, Galactic, and Planetary Systems","Advanced Satellite Networks","Space-Based AI Systems","Enhanced Propulsion Technologies","AI in Space Exploration and Colonisation","Orbital Manufacturing and Construction","Space Debris Management"]},
    {"name":"User Experience and Design Principles","icon":"🎨","summary":"User-centred design, inclusive interfaces, learning objectives, design cycles, ethical design, interaction design and De Bono-inspired alternatives.","terms":["user","ux","ui","design","interface","inclusive","learning objective","de bono","experience"],"ideas":["User-centred Design Principles and Cycle","Ethical Considerations in Design","Integration with De Bono's Principles","Exploring Alternative Design Approaches","Embracing Inclusive Design","Defining Learning Objectives and Design Concepts"]},
    {"name":"Mathematical and Logical Systems","icon":"🔢","summary":"Number systems, states, powers, logic gaps, bit alignment, symbolic systems, multi-base processing and formal computational structures.","terms":["math","logic","bit","base","state","number","64","10-bit","powers","binary","ternary"],"ideas":["Multi-Base Processor Architecture","Complex Numbering System with Various States and Powers","Logic Gap and 10-bit Representation","Extended Systems Leading to 64-bit Alignment"]},
    {"name":"Idea Generation and Creative Thinking","icon":"💡","summary":"Creative lateral integration, humour, pattern switching, logic bubbles, innovation mapping and generative idea construction.","terms":["idea","creative","lateral","pattern","humour","bubble","innovation"],"ideas":["Creative Lateral Integration","Pattern Switching Ideas","Humour in Idea Generation","Logic Bubbles"]},
    {"name":"Ethical and Standard Compliance","icon":"⚖️","summary":"Ethical AI, long-term legacy, ISO alignment, governance, standards, risk, safety, compliance and responsible systems.","terms":["ethical","ethics","iso","standard","compliance","legacy","governance","risk"],"ideas":["Ethical AI and Long-term Legacy Considerations","ISO Alignment and Standards for User Research and Design"]},
    {"name":"Document Processing and Web Tools","icon":"🧾","summary":"Word-to-HTML conversion, inline image extraction, Bootstrap UI, local hosting, generated indexes, JSON metadata and static article routing.","terms":["document","html","pdf","word","processing","bootstrap","php","sql","web","page","file","docx"],"ideas":["DOCX to HTML Section Conversion","Inline Image Extraction","Generated Sidebar Navigation","Localhost Apache Hosting","Keyword Metadata and Search"]},
]

KEYWORDS_250 = [
"docx","word-documents","inline-images","image-extraction","word-to-html","section-html","bootstrap","colourful-text","blue-grey-sidebar","high-contrast","local-hosting","apache","localhost","html-files","assets","doc-images","image-index","article-index","json-metadata","static-site","python-docx","openxml","ooxml","relationships","embedded-media","document-part","image-references","paragraph-runs","headings","tables","lists","hyperlinks","captions","alt-text","figure-index","content-workbench","article-workbench","knowledge-library","document-portal","sidebar-navigation","grouped-sidebar","collapsed-groups","main-content","dynamic-loading","fetch-api","client-side-routing","hash-routing","search","filtering","metadata","advanced-computing","artificial-intelligence","machine-learning","hybrid-computing","analogue-digital","stateless-memory","mnemonic-systems","janus-principles","logic-systems","multi-base-processing","binary-logic","ternary-logic","five-bit-conversion","ten-bit-representation","sixty-four-bit-alignment","processor-architecture","fault-tolerance","error-handling","robustness","resilience","computational-design","algorithmic-thinking","data-structures","distributed-systems","edge-computing","cloud-computing","single-page-interface","partial-html","dynamic-content","page-id","semantic-tags","ideas-overview","content-management","php-migration","sql-export","csv-export","mysql","data-ingestion","information-architecture","taxonomy","ontology","classification","topic-map","navigation-design","visual-hierarchy","responsive-layout","dark-theme","colour-coded-text","icons","cards","panels","user-experience","user-centred-design","inclusive-design","accessibility","readability","interaction-design","learning-objectives","design-cycle","ethical-design","de-bono","cort60","lateral-thinking","creative-thinking","pattern-switching","logic-bubbles","humour","idea-generation","innovation","strategic-thinking","systems-thinking","janus-view","dual-process","scenario-planning","space-exploration","intergalactic","galactic","planetary-systems","orbital-systems","satellite-networks","space-ai","autonomous-spacecraft","propulsion","enhanced-propulsion","orbital-manufacturing","space-construction","space-debris","space-colonisation","mission-design","remote-sensing","astronomy","astrophysics","telescope","exoplanets","dark-sky","cosmic-infrastructure","quantum-computing","quantum-ai","quantum-logic","qubits","superposition","entanglement","hybrid-ai","neural-symbolic","knowledge-graphs","semantic-web","graph-reasoning","decision-support","adaptive-systems","automation","agent-systems","multi-agent","swarm-intelligence","aco","bco","optimisation","optimization","ranking","retrieval","nlp","document-processing","word-processing","pdf-processing","html-fragments","content-extraction","indexing","keyword-search","sorting","menus","dropdowns","collapsible-sidebar","article-preview","metadata-panel","technical-writing","educational-content","course-design","diploma-course","computing-education","ai-education","space-education","ethics","ai-ethics","long-term-legacy","standards","iso-alignment","compliance","governance","risk","safety","security","privacy","data-protection","auditability","provenance","versioning","archive","backup","export","import","transformation","conversion","sql-to-html","static-rendering","browser-app","offline-first","local-server","apache2","document-root","var-www-html","source-assets","relative-links","images","styles","scripts","content-loader","history-api","progressive-enhancement","fallback-content","semantic-html","aria","keyboard-navigation","focus-states","print-friendly","responsive-grid","mobile-layout","desktop-layout","glassmorphism","gradient-ui","typography","code-blocks","media","embedded-content","article-categories","knowledge-navigation","computational-creativity","mathematical-systems","formal-logic","state-systems","powers","states","complex-numbering","symbolic-systems","abstraction","modeling","simulation","decision-trees","feedback-loops","cybernetics","human-computer-interaction","cognitive-tools","strategy-tools","creative-lateral-integration","alternative-design","learning-cycle","training-material","research-library","technical-portal","ideas-library","machine-knowledge","augmentative-intelligence","generative-intelligence","explainability","interpretability","traceability","quality-assurance","testing","debugging","deployment","site-packaging","zip-delivery","local-preview","python-http-server","browser-console","content-security","script-sanitisation","0uch","l00king","m1sf1t","uk-pmc","welsh-technology","cosmic-strategy","future-systems","robust-webui","data-driven-ui","modular-content","maintainable-site","evidence-library","research-portal","digital-archive","navigation-model"]
KEYWORDS_250 = (KEYWORDS_250 + [f"keyword-{i}" for i in range(1, 251)])[:250]

@dataclass
class ImageRecord:
    document: str
    document_slug: str
    image_id: str
    occurrence: int
    rel_id: str
    filename: str
    output_path: str
    content_type: str
    alt_text: str
    sha256: str
    bytes: int

@dataclass
class ArticleRecord:
    id: str
    title: str
    slug: str
    file: str
    source_docx: str
    category: str
    icon: str
    preview: str
    word_count: int
    image_count: int

def slugify(text: str) -> str:
    text = html.unescape(text or "")
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return text or "document"

def clean_title(text: str) -> str:
    text = html.unescape(text or "")
    text = re.sub(r"\.(docx|doc|html?)$", "", text, flags=re.I)
    text = re.sub(r"^(article|page|file|document)?[_\-\s]*\d+[_\-\s]*", "", text, flags=re.I)
    text = text.replace("_", " ").replace("-", " ")
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return "Untitled Document"
    small = {"and", "or", "of", "in", "to", "with", "for", "the", "a", "an", "on", "by", "from", "into"}
    acronyms = {"AI", "ML", "UX", "UI", "SQL", "PHP", "HTML", "CSS", "JS", "ISO", "PDF", "CSV", "API", "CPU", "GPU", "DOCX"}
    words = []
    for i, word in enumerate(text.split()):
        if word.upper() in acronyms:
            words.append(word.upper())
        elif re.search(r"\d", word):
            words.append(word)
        elif i > 0 and word.lower() in small:
            words.append(word.lower())
        else:
            words.append(word[:1].upper() + word[1:].lower())
    return " ".join(words)

def iter_block_items(parent):
    if isinstance(parent, _Document):
        parent_elm = parent.element.body
    elif isinstance(parent, _Cell):
        parent_elm = parent._tc
    else:
        raise TypeError(f"Unsupported parent: {type(parent)}")
    for child in parent_elm.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, parent)
        elif child.tag == qn("w:tbl"):
            yield Table(child, parent)

def paragraph_style_level(paragraph: Paragraph) -> Optional[int]:
    name = paragraph.style.name if paragraph.style is not None else ""
    m = re.search(r"Heading\s+([1-6])", name, flags=re.I)
    if m:
        return int(m.group(1))
    if name.lower() == "title":
        return 1
    return None

def xml_text_from_run(run_elm) -> str:
    parts = []
    for node in run_elm.iter():
        if node.tag == qn("w:t"):
            parts.append(node.text or "")
        elif node.tag == qn("w:tab"):
            parts.append("    ")
        elif node.tag == qn("w:br"):
            parts.append("<br>")
    return "".join(parts)

def run_format_tags(run_elm, text: str) -> str:
    if not text:
        return ""
    rpr = run_elm.find(qn("w:rPr"))
    escaped = html.escape(text, quote=False).replace("&lt;br&gt;", "<br>")
    if rpr is None:
        return escaped
    if rpr.find(qn("w:b")) is not None:
        escaped = f"<strong>{escaped}</strong>"
    if rpr.find(qn("w:i")) is not None:
        escaped = f"<em>{escaped}</em>"
    if rpr.find(qn("w:u")) is not None:
        escaped = f"<u>{escaped}</u>"
    return escaped

def image_ext_from_part(part) -> str:
    ctype = getattr(part, "content_type", "") or ""
    ext = mimetypes.guess_extension(ctype) or ""
    if ext == ".jpe":
        ext = ".jpg"
    if not ext:
        partname = str(getattr(part, "partname", ""))
        ext = Path(partname).suffix or ".bin"
    return ext

def alt_text_for_blip(blip) -> str:
    for ancestor in blip.iterancestors():
        for docpr in ancestor.findall(".//" + qn("wp:docPr")):
            descr = docpr.get("descr") or docpr.get("title") or docpr.get("name")
            if descr:
                return descr
    return "Extracted Word document image"

def save_image_from_blip(document: Document, blip, doc_title: str, doc_slug: str, images_dir: Path, image_records: List[ImageRecord], occurrence_state: Dict[str, int]) -> Optional[str]:
    rid = blip.get(qn("r:embed")) or blip.get(qn("r:link"))
    if not rid or rid not in document.part.related_parts:
        return None
    part = document.part.related_parts[rid]
    blob = part.blob
    sha = hashlib.sha256(blob).hexdigest()
    occurrence_state["count"] = occurrence_state.get("count", 0) + 1
    occurrence = occurrence_state["count"]
    ext = image_ext_from_part(part)
    filename = f"{doc_slug}-image-{occurrence:03d}{ext}"
    output_dir = images_dir / doc_slug
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / filename
    out_path.write_bytes(blob)
    rel_output = f"assets/doc_images/{doc_slug}/{filename}"
    image_id = f"{doc_slug}-img-{occurrence:03d}"
    alt = alt_text_for_blip(blip)
    image_records.append(ImageRecord(doc_title, doc_slug, image_id, occurrence, rid, filename, rel_output, getattr(part, "content_type", "") or "", alt, sha, len(blob)))
    return f'<figure class="docx-figure" id="{html.escape(image_id)}"><img src="{html.escape(rel_output)}" alt="{html.escape(alt)}" loading="lazy"><figcaption>🖼️ {html.escape(alt)} <span class="fig-meta">({html.escape(filename)})</span></figcaption></figure>'

def render_run_or_hyperlink(document: Document, elem, doc_title: str, doc_slug: str, images_dir: Path, image_records: List[ImageRecord], occurrence_state: Dict[str, int]) -> str:
    if elem.tag == qn("w:hyperlink"):
        rid = elem.get(qn("r:id"))
        href = ""
        if rid and rid in document.part.rels:
            href = document.part.rels[rid].target_ref
        inner = []
        for run_elm in elem.findall(qn("w:r")):
            inner.append(render_run_or_hyperlink(document, run_elm, doc_title, doc_slug, images_dir, image_records, occurrence_state))
        inner_html = "".join(inner)
        if href:
            return f'<a href="{html.escape(href)}" target="_blank" rel="noopener">{inner_html}</a>'
        return inner_html
    if elem.tag != qn("w:r"):
        return ""
    pieces = []
    text = xml_text_from_run(elem)
    if text:
        pieces.append(run_format_tags(elem, text))
    for blip in elem.findall(".//" + qn("a:blip")):
        image_html = save_image_from_blip(document, blip, doc_title, doc_slug, images_dir, image_records, occurrence_state)
        if image_html:
            pieces.append(image_html)
    return "".join(pieces)

def paragraph_to_html(document: Document, paragraph: Paragraph, doc_title: str, doc_slug: str, images_dir: Path, image_records: List[ImageRecord], occurrence_state: Dict[str, int]) -> str:
    inner_parts = []
    for child in paragraph._p.iterchildren():
        if child.tag in {qn("w:r"), qn("w:hyperlink")}:
            inner_parts.append(render_run_or_hyperlink(document, child, doc_title, doc_slug, images_dir, image_records, occurrence_state))
    inner = "".join(inner_parts).strip()
    if not inner:
        return ""
    level = paragraph_style_level(paragraph)
    if level:
        return f'<h{level} class="doc-heading doc-heading-{level}">{inner}</h{level}>'
    style_name = paragraph.style.name.lower() if paragraph.style is not None else ""
    if "list" in style_name:
        return f'<p class="doc-list-item">• {inner}</p>'
    return f"<p>{inner}</p>"

def table_to_html(document: Document, table: Table, doc_title: str, doc_slug: str, images_dir: Path, image_records: List[ImageRecord], occurrence_state: Dict[str, int]) -> str:
    rows_html = []
    for r_i, row in enumerate(table.rows):
        cells = []
        cell_tag = "th" if r_i == 0 else "td"
        for cell in row.cells:
            cell_parts = []
            for block in iter_block_items(cell):
                if isinstance(block, Paragraph):
                    cell_parts.append(paragraph_to_html(document, block, doc_title, doc_slug, images_dir, image_records, occurrence_state))
                elif isinstance(block, Table):
                    cell_parts.append(table_to_html(document, block, doc_title, doc_slug, images_dir, image_records, occurrence_state))
            cells.append(f"<{cell_tag}>{''.join(cell_parts)}</{cell_tag}>")
        rows_html.append(f"<tr>{''.join(cells)}</tr>")
    return f'<div class="table-responsive"><table class="docx-table">{"".join(rows_html)}</table></div>'

def classify(title: str, full_text: str) -> Tuple[str, str]:
    hay = f"{title} {full_text}".lower()
    best_group = IDEA_GROUPS[-1]
    best_score = -1
    for group in IDEA_GROUPS:
        score = sum(1 for term in group["terms"] if term in hay)
        if score > best_score:
            best_group = group
            best_score = score
    return best_group["name"], best_group["icon"]

def preview_text(html_content: str, limit: int = 180) -> str:
    plain = re.sub(r"<[^>]+>", " ", html_content)
    plain = html.unescape(re.sub(r"\s+", " ", plain).strip())
    return plain[:limit] + ("…" if len(plain) > limit else "")

def convert_docx(docx_path: Path, html_dir: Path, images_dir: Path, article_index: int) -> Tuple[ArticleRecord, List[ImageRecord]]:
    document = Document(str(docx_path))
    title = clean_title(docx_path.stem)
    doc_slug = slugify(title)
    image_records: List[ImageRecord] = []
    occurrence_state: Dict[str, int] = {"count": 0}
    parts = []
    for block in iter_block_items(document):
        if isinstance(block, Paragraph):
            h = paragraph_to_html(document, block, title, doc_slug, images_dir, image_records, occurrence_state)
            if h:
                parts.append(h)
        elif isinstance(block, Table):
            parts.append(table_to_html(document, block, title, doc_slug, images_dir, image_records, occurrence_state))
    body_html = "\n".join(parts).strip() or "<p>No readable paragraphs or images were found in this document.</p>"
    full_text = re.sub(r"<[^>]+>", " ", body_html)
    category, icon = classify(title, full_text)
    word_count = len(re.findall(r"\w+", full_text))
    article_id = f"article-{article_index:03d}"
    filename = f"{article_index:03d}-{doc_slug}.html"
    section_html = f'''<section class="article-section colourful-docx-section" id="{html.escape(article_id)}">
  <header class="section-hero">
    <div class="kicker">{html.escape(category)}</div>
    <h1>{html.escape(title)}</h1>
    <p class="section-meta">📄 Source: <strong>{html.escape(docx_path.name)}</strong> · 🖼️ Images: <strong>{len(image_records)}</strong> · 🔢 Words: <strong>{word_count}</strong></p>
  </header>
  <div class="section-body">
    {body_html}
  </div>
</section>
'''
    (html_dir / filename).write_text(section_html, encoding="utf-8")
    article = ArticleRecord(article_id, title, doc_slug, f"html_files/{filename}", docx_path.name, category, icon, preview_text(body_html), word_count, len(image_records))
    return article, image_records

def build_site(word_dir: Path, out_dir: Path) -> None:
    html_dir = out_dir / "html_files"
    assets_dir = out_dir / "assets"
    images_dir = assets_dir / "doc_images"
    data_dir = out_dir / "data"
    tools_dir = out_dir / "tools"
    if out_dir.exists():
        shutil.rmtree(out_dir)
    html_dir.mkdir(parents=True)
    images_dir.mkdir(parents=True)
    data_dir.mkdir(parents=True)
    tools_dir.mkdir(parents=True)
    docx_files = sorted(p for p in word_dir.rglob("*.docx") if not p.name.startswith("~$"))
    articles: List[ArticleRecord] = []
    all_images: List[ImageRecord] = []
    for idx, docx_path in enumerate(docx_files, start=1):
        print(f"[{idx}/{len(docx_files)}] converting {docx_path}")
        try:
            article, image_records = convert_docx(docx_path, html_dir, images_dir, idx)
            articles.append(article)
            all_images.extend(image_records)
        except Exception as exc:
            print(f"  ERROR: {docx_path}: {exc}")
    categories = []
    for group in IDEA_GROUPS:
        count = sum(1 for a in articles if a.category == group["name"])
        categories.append({"name": group["name"], "icon": group["icon"], "summary": group["summary"], "ideas": group["ideas"], "count": count})
    (data_dir / "article_index.json").write_text(json.dumps([asdict(a) for a in articles], ensure_ascii=False, indent=2), encoding="utf-8")
    (data_dir / "image_index.json").write_text(json.dumps([asdict(i) for i in all_images], ensure_ascii=False, indent=2), encoding="utf-8")
    (data_dir / "groups.json").write_text(json.dumps(categories, ensure_ascii=False, indent=2), encoding="utf-8")
    write_index_html(out_dir)
    write_css(assets_dir)
    write_js(assets_dir, articles, categories)
    write_readme(out_dir, word_dir, articles, all_images)
    this_script = Path(__file__).resolve()
    if this_script.exists():
        shutil.copy2(this_script, tools_dir / this_script.name)
    print("\nBuild complete")
    print(f"  Output:   {out_dir}")
    print(f"  Articles: {len(articles)}")
    print(f"  Images:   {len(all_images)}")
    print("\nPreview:")
    print(f"  cd {out_dir}")
    print("  python3 -m http.server 8088")
    print("  http://127.0.0.1:8088/")

def write_index_html(out_dir: Path) -> None:
    meta_keywords = ", ".join(KEYWORDS_250)
    index = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DOCX Inline Image Article Workbench</title>
<meta name="description" content="Local Bootstrap-style article workbench generated from Word documents with extracted inline images.">
<meta name="keywords" content="{html.escape(meta_keywords)}">
<link rel="stylesheet" href="assets/styles.css">
</head>
<body>
<header class="topbar"><nav class="nav"><div class="brand"><span class="orb">🧠</span><span>DOCX Inline Image Workbench</span></div><div class="actions"><input id="searchBox" type="search" placeholder="Search documents, groups, image metadata…"><button id="overviewBtn" class="btn">🏠 Overview</button><button id="printBtn" class="btn">🖨️ Print</button></div></nav></header>
<div class="layout"><aside class="sidebar"><div class="side-head"><h2>📚 Blue/Grey Article Groups</h2><p>Click a group for a summary; click a document to load its <code>&lt;section&gt;</code> with inline images.</p></div><div id="groups"></div></aside><main class="main"><div id="mainContent"></div></main></div>
<footer class="footer">Local static site · generated from Word documents · copy to <code>/var/www/html/</code> for Apache localhost</footer>
<script src="assets/app.js"></script>
</body>
</html>'''
    (out_dir / "index.html").write_text(index, encoding="utf-8")

def write_css(assets_dir: Path) -> None:
    css = r'''
:root{--sidebar-bg:#263648;--sidebar-bg-2:#31475e;--sidebar-ink:#f4f8ff;--sidebar-muted:#d7e6f7;--sidebar-line:rgba(255,255,255,.18);--main-bg:#f4f7fb;--panel:#fff;--ink:#152033;--muted:#64748b;--blue:#0d6efd;--cyan:#0dcaf0;--purple:#7c3aed;--pink:#d63384;--green:#198754;--amber:#f59e0b;--line:#dce5f2}*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink);background:radial-gradient(circle at 10% 0%,rgba(13,110,253,.14),transparent 34rem),var(--main-bg)}.topbar{position:sticky;top:0;z-index:30;background:linear-gradient(135deg,#07111f,#14243c);color:#eaf2ff;box-shadow:0 8px 24px rgba(0,0,0,.25)}.nav{display:flex;align-items:center;justify-content:space-between;gap:1rem;max-width:1700px;margin:0 auto;padding:.75rem 1rem}.brand{display:flex;gap:.65rem;align-items:center;font-weight:950}.orb{display:grid;place-items:center;width:42px;height:42px;border-radius:15px;background:linear-gradient(135deg,var(--cyan),var(--purple))}.actions{display:flex;gap:.5rem;flex-wrap:wrap}.actions input{width:min(460px,55vw);border:1px solid rgba(255,255,255,.25);border-radius:12px;padding:.72rem .85rem;background:rgba(255,255,255,.08);color:#fff;outline:none}.actions input::placeholder{color:#bfd0e8}.btn{border:1px solid rgba(255,255,255,.25);border-radius:12px;padding:.7rem .85rem;background:rgba(255,255,255,.08);color:#fff;font-weight:800;cursor:pointer}.btn:hover{background:rgba(13,202,240,.18)}.layout{display:grid;grid-template-columns:410px minmax(0,1fr);gap:1rem;max-width:1700px;margin:0 auto;padding:1rem}.sidebar{position:sticky;top:78px;align-self:start;max-height:calc(100vh - 94px);overflow:auto;background:linear-gradient(180deg,var(--sidebar-bg),var(--sidebar-bg-2));border:1px solid var(--sidebar-line);border-radius:22px;box-shadow:0 20px 60px rgba(15,23,42,.18);color:var(--sidebar-ink)}.side-head{padding:1rem;background:linear-gradient(135deg,#1b2938,#415d7a);color:#fff;border-radius:22px 22px 0 0;border-bottom:1px solid var(--sidebar-line)}.side-head h2{font-size:1.08rem;margin:0;font-weight:950}.side-head p{font-size:.9rem;margin:.35rem 0 0;color:var(--sidebar-muted)}.group{border-bottom:1px solid var(--sidebar-line)}.group summary{display:flex;align-items:center;justify-content:space-between;gap:.5rem;cursor:pointer;padding:.85rem 1rem;font-weight:950;list-style:none;color:#fff}.group summary::-webkit-details-marker{display:none}.group summary:hover,.group.active summary{background:rgba(255,255,255,.10)}.group summary .left{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:normal}.group summary .chev{transition:transform .18s ease;display:inline-block}.group[open] summary .chev{transform:rotate(90deg)}.count{background:#dbeafe;color:#12335f;border-radius:999px;padding:.18rem .5rem;font-size:.75rem;font-weight:950}.links{display:grid;gap:.25rem;padding:.25rem .55rem .85rem}.article-link{display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:start;gap:.55rem;border:1px solid transparent;background:rgba(255,255,255,.055);border-radius:14px;padding:.62rem;color:#f8fbff;text-align:left;cursor:pointer;max-width:100%;min-width:0}.article-link:hover{background:rgba(255,255,255,.12);border-color:rgba(255,255,255,.20)}.article-link.active{background:rgba(13,202,240,.22);border-color:#67e8f9}.article-link .label{min-width:0;overflow:hidden}.article-link strong{display:block;font-size:.92rem;line-height:1.18;overflow:hidden;text-overflow:ellipsis;white-space:normal;word-break:break-word;color:#fff}.article-link small{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;color:#dbeafe;font-size:.78rem;line-height:1.25;max-width:100%;word-break:break-word}.main{min-width:0;background:#fff;border:1px solid var(--line);border-radius:24px;box-shadow:0 20px 60px rgba(15,23,42,.12);overflow:hidden}.hero{color:#eaf2ff;background:radial-gradient(circle at 20% 0%,rgba(13,202,240,.25),transparent 22rem),linear-gradient(135deg,#111827,#1d2b45);padding:1.35rem}.kicker{text-transform:uppercase;letter-spacing:.14em;color:#67e8f9;font-weight:950;font-size:.75rem}.hero h1{font-size:clamp(2rem,4.8vw,4.6rem);line-height:.95;margin:.45rem 0 .6rem;font-weight:950}.hero p{max-width:88ch;color:#dbeafe;font-size:1.05rem}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:.75rem;margin-top:1rem}.metric{border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.08);border-radius:18px;padding:.9rem}.metric strong{display:block;font-size:1.5rem}.metric span{color:#bcd2ee;font-size:.85rem}.content{padding:1.2rem}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}.card{border:1px solid var(--line);border-radius:20px;padding:1rem;background:#fbfdff}.card h3{margin:0 0 .65rem;color:var(--blue);font-weight:950}.card a,.article-card-mini a{color:var(--purple);font-weight:850;text-decoration:none}.card a:hover,.article-card-mini a:hover{text-decoration:underline}.article-list-main{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:.75rem;margin-top:1rem}.article-card-mini{border:1px solid var(--line);border-radius:18px;padding:.9rem;background:#fff}.article-card-mini h4{margin:.25rem 0;font-size:1rem}.article-card-mini p{color:var(--muted);font-size:.88rem;margin:.35rem 0 0}.article-head{padding:1.1rem 1.2rem;border-bottom:1px solid var(--line);background:#f8fbff}.article-head h1{margin:.35rem 0 0;font-size:clamp(1.5rem,3vw,3rem);font-weight:950}.badges{display:flex;flex-wrap:wrap;gap:.45rem}.badge{border-radius:999px;padding:.32rem .56rem;font-size:.8rem;font-weight:950;background:#eef2ff;color:#3730a3}.article-section{line-height:1.68}.section-hero{color:#eaf2ff;background:linear-gradient(135deg,#0f172a,#233b5d);border-radius:20px;padding:1.2rem;margin-bottom:1rem}.section-hero h1{font-size:clamp(1.6rem,3vw,3rem);margin:.35rem 0;font-weight:950;color:#fff}.section-meta{color:#dbeafe}.section-body{background:#fff;border:1px solid var(--line);border-radius:20px;padding:1.2rem}.loaded{padding:1.2rem;line-height:1.68}.loaded h1,.loaded h2,.loaded h3,.section-body h1,.section-body h2,.section-body h3{color:#0d6efd;font-weight:950;margin-top:1.3rem}.loaded h4,.loaded h5,.section-body h4,.section-body h5{color:#7c3aed;font-weight:900}.loaded strong,.loaded b,.section-body strong,.section-body b{color:#198754}.loaded em,.section-body em{color:#d63384}.doc-list-item{padding-left:1rem;border-left:4px solid #0dcaf0;background:#f0fbff;border-radius:10px;padding:.45rem .7rem}.docx-figure{margin:1.2rem 0;border:1px solid var(--line);border-radius:18px;background:#f8fbff;padding:.75rem;text-align:center}.docx-figure img{max-width:100%;height:auto;border-radius:14px;box-shadow:0 10px 28px rgba(15,23,42,.16)}.docx-figure figcaption{font-size:.9rem;color:#475569;margin-top:.45rem}.fig-meta{color:#64748b}.table-responsive{overflow:auto;margin:1rem 0}.docx-table{width:100%;border-collapse:collapse}.docx-table td,.docx-table th{border:1px solid var(--line);padding:.65rem;vertical-align:top}.docx-table th{background:#eef6ff;color:#0d6efd}.kw-panel{margin-top:1.2rem;border:1px solid var(--line);border-radius:22px;padding:1rem;background:#fff}.kw-cloud{display:flex;flex-wrap:wrap;gap:.38rem;max-height:230px;overflow:auto}.kw{border-radius:999px;padding:.28rem .55rem;background:#eef6ff;color:#0d47a1;font-weight:800;font-size:.78rem}.empty{padding:2rem;text-align:center;color:var(--muted)}.footer{text-align:center;color:var(--muted);padding:2rem}@media(max-width:1050px){.layout{grid-template-columns:1fr}.sidebar{position:relative;top:0;max-height:none}.grid{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(2,1fr)}}@media(max-width:620px){.nav{align-items:flex-start;flex-direction:column}.actions,.actions input{width:100%}.layout{padding:.5rem}.metrics{grid-template-columns:1fr}}@media print{.topbar,.sidebar{display:none}.layout{display:block}.main{box-shadow:none;border:0}.section-body{border:0}}
'''
    (assets_dir / "styles.css").write_text(css, encoding="utf-8")

def write_js(assets_dir: Path, articles: List[ArticleRecord], categories: list) -> None:
    data = {"articles": [asdict(a) for a in articles], "categories": categories, "keywords": KEYWORDS_250}
    js = f'''
const DATA = {json.dumps(data, ensure_ascii=False)};
const ARTICLES = DATA.articles;
const CATEGORIES = DATA.categories;
let currentArticle = null;
let currentGroup = null;
let search = "";
const $ = id => document.getElementById(id);
function esc(s) {{ return String(s ?? "").replace(/[&<>"']/g, c => ({{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}}[c])); }}
function byGroup() {{ const groups = Object.fromEntries(CATEGORIES.map(c => [c.name, []])); for (const a of ARTICLES) {{ const hay = `${{a.title}} ${{a.preview}} ${{a.category}} ${{a.source_docx}}`.toLowerCase(); if (!search || hay.includes(search)) (groups[a.category] ||= []).push(a); }} return groups; }}
function renderSidebar() {{ const groups = byGroup(); const root = $("groups"); root.innerHTML = ""; for (const cat of CATEGORIES) {{ const items = groups[cat.name] || []; const details = document.createElement("details"); details.className = "group" + (cat.name === currentGroup ? " active" : ""); details.open = cat.name === currentGroup; details.innerHTML = `<summary><span class="left">${{cat.icon}} ${{esc(cat.name)}}</span><span><span class="count">${{items.length}}</span> <span class="chev">›</span></span></summary><div class="links"></div>`; details.querySelector("summary").addEventListener("click", ev => {{ ev.preventDefault(); openGroup(cat.name, true); }}); const links = details.querySelector(".links"); if (!items.length) links.innerHTML = `<div class="empty">No matching documents</div>`; for (const a of items) {{ const b = document.createElement("button"); b.className = "article-link" + (a.id === currentArticle ? " active" : ""); b.type = "button"; b.innerHTML = `<span>${{a.icon}}</span><span class="label"><strong>${{esc(a.title)}}</strong><small>${{esc(a.preview || a.source_docx)}} · 🖼️ ${{a.image_count}}</small></span><span class="count">${{a.word_count}}</span>`; b.addEventListener("click", () => openArticle(a.id, true)); links.appendChild(b); }} root.appendChild(details); }} }}
function keywordCloud() {{ return DATA.keywords.map(k => `<span class="kw">${{esc(k)}}</span>`).join(""); }}
function overviewCards() {{ return CATEGORIES.map(cat => {{ const items = ARTICLES.filter(a => a.category === cat.name); const words = items.reduce((n, a) => n + (a.word_count || 0), 0); const images = items.reduce((n, a) => n + (a.image_count || 0), 0); return `<section class="card"><h3>${{cat.icon}} ${{esc(cat.name)}}</h3><p>${{esc(cat.summary)}}</p><p><strong>${{items.length}}</strong> documents · <strong>${{words.toLocaleString()}}</strong> words · <strong>${{images}}</strong> images.</p><a href="#group-${{encodeURIComponent(cat.name)}}" data-group="${{esc(cat.name)}}">Open group summary →</a></section>`; }}).join(""); }}
function bindDynamicLinks() {{ document.querySelectorAll("[data-group]").forEach(el => el.addEventListener("click", ev => {{ ev.preventDefault(); openGroup(el.getAttribute("data-group"), true); }})); document.querySelectorAll("[data-article]").forEach(el => el.addEventListener("click", ev => {{ ev.preventDefault(); openArticle(el.getAttribute("data-article"), true); }})); }}
function openOverview(push = true) {{ currentArticle = null; currentGroup = null; if (push) history.replaceState(null, "", "#overview"); const totalWords = ARTICLES.reduce((n, a) => n + (a.word_count || 0), 0); const totalImages = ARTICLES.reduce((n, a) => n + (a.image_count || 0), 0); $("mainContent").innerHTML = `<section class="hero"><div class="kicker">DOCX Overview</div><h1>Word Docs → Sections + Inline Images</h1><p>This local portal was generated from Word documents. Each document becomes a colourful <code>&lt;section&gt;</code> HTML partial, with embedded Word images extracted into <code>assets/doc_images/</code> and referenced inline.</p><div class="metrics"><div class="metric"><strong>${{ARTICLES.length}}</strong><span>documents</span></div><div class="metric"><strong>${{CATEGORIES.length}}</strong><span>groups</span></div><div class="metric"><strong>${{totalImages}}</strong><span>images extracted</span></div><div class="metric"><strong>${{totalWords.toLocaleString()}}</strong><span>words</span></div></div></section><section class="content"><div class="grid">${{overviewCards()}}</div><section class="kw-panel"><h2>🏷️ 250 Keyword HTML Metadata Cloud</h2><p>These keywords are embedded in the page metadata and usable for future indexing/search.</p><div class="kw-cloud">${{keywordCloud()}}</div></section></section>`; document.title = "DOCX Inline Image Workbench"; bindDynamicLinks(); renderSidebar(); }}
function openGroup(groupName, push = true) {{ const cat = CATEGORIES.find(c => c.name === groupName) || CATEGORIES[0]; currentGroup = cat.name; currentArticle = null; if (push) history.replaceState(null, "", "#group-" + encodeURIComponent(cat.name)); const items = ARTICLES.filter(a => a.category === cat.name); const words = items.reduce((n, a) => n + (a.word_count || 0), 0); const images = items.reduce((n, a) => n + (a.image_count || 0), 0); const cards = items.length ? items.map(a => `<article class="article-card-mini"><div class="badges"><span class="badge">${{a.icon}} ${{esc(a.category)}}</span><span class="badge">🖼️ ${{a.image_count}}</span><span class="badge">🔢 ${{a.word_count}}</span></div><h4><a href="#${{a.id}}" data-article="${{a.id}}">${{esc(a.title)}}</a></h4><p>${{esc(a.preview || a.source_docx)}}</p></article>`).join("") : `<div class="empty">No documents currently classified into this group.</div>`; const bullets = (cat.ideas || []).map(x => `<li>${{esc(x)}}</li>`).join(""); $("mainContent").innerHTML = `<section class="hero"><div class="kicker">Group Summary</div><h1>${{cat.icon}} ${{esc(cat.name)}}</h1><p>${{esc(cat.summary)}}</p><div class="metrics"><div class="metric"><strong>${{items.length}}</strong><span>documents</span></div><div class="metric"><strong>${{words.toLocaleString()}}</strong><span>words</span></div><div class="metric"><strong>${{images}}</strong><span>inline images</span></div><div class="metric"><strong>Open</strong><span>sidebar unfolded</span></div></div></section><section class="content"><section class="card"><h3>🧭 What this group covers</h3><ul>${{bullets}}</ul></section><h2>📚 Documents in this group</h2><div class="article-list-main">${{cards}}</div></section>`; document.title = cat.name + " · group summary"; bindDynamicLinks(); renderSidebar(); }}
async function openArticle(id, push = true) {{ const a = ARTICLES.find(x => x.id === id); if (!a) return openOverview(push); currentArticle = a.id; currentGroup = a.category; if (push) history.replaceState(null, "", "#" + encodeURIComponent(a.id)); renderSidebar(); $("mainContent").innerHTML = `<header class="article-head"><div class="badges"><span class="badge">${{a.icon}} ${{esc(a.category)}}</span><span class="badge">📄 ${{esc(a.source_docx)}}</span><span class="badge">🖼️ ${{a.image_count}} images</span><span class="badge">🔢 ${{a.word_count.toLocaleString()}} words</span></div><h1>${{esc(a.title)}}</h1><p style="margin:.35rem 0 0;color:#64748b">${{esc(a.preview)}}</p></header><section class="loaded" id="loaded"><div class="empty">Loading document section…</div></section>`; try {{ const res = await fetch(a.file); if (!res.ok) throw new Error(`HTTP ${{res.status}} for ${{a.file}}`); $("loaded").innerHTML = await res.text(); document.title = a.title + " · DOCX section"; }} catch (err) {{ $("loaded").innerHTML = `<div class="empty"><h2>Could not load section</h2><p>${{esc(err.message || err)}}</p><p>Run through Apache or <code>python3 -m http.server 8088</code>, not file double-click.</p></div>`; }} }}
function route() {{ const h = decodeURIComponent(location.hash.replace(/^#/, "")); if (!h || h === "overview") return openOverview(false); if (h.startsWith("group-")) return openGroup(h.slice(6), false); return openArticle(h, false); }}
function init() {{ $("searchBox").addEventListener("input", () => {{ search = $("searchBox").value.trim().toLowerCase(); renderSidebar(); }}); $("overviewBtn").addEventListener("click", () => openOverview(true)); $("printBtn").addEventListener("click", () => window.print()); window.addEventListener("hashchange", route); route(); }}
init();
'''
    (assets_dir / "app.js").write_text(js, encoding="utf-8")

def write_readme(out_dir: Path, word_dir: Path, articles: List[ArticleRecord], images: List[ImageRecord]) -> None:
    readme = f"""# DOCX Inline Image Article Workbench

Generated from: `{word_dir}`

## Output

- `index.html` - main local site
- `html_files/*.html` - one colourful `<section>` partial per Word document
- `assets/doc_images/<document-slug>/*` - images extracted from `.docx`
- `data/article_index.json` - document metadata
- `data/image_index.json` - every extracted image reference
- `data/groups.json` - idea groups and counts

## Counts

- Documents converted: {len(articles)}
- Images extracted: {len(images)}

## Preview locally

```bash
cd {out_dir}
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```

## Host with Apache localhost

```bash
sudo rsync -av --delete {out_dir}/ /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
```

Open:

```text
http://localhost/
```
"""
    (out_dir / "README.md").write_text(readme, encoding="utf-8")

def main() -> None:
    parser = argparse.ArgumentParser(description="Convert Word .docx files to grouped HTML sections with inline extracted images.")
    parser.add_argument("--word-dir", default="word_docs", help="Directory containing .docx files. Default: word_docs")
    parser.add_argument("--out", default="docx_static_site", help="Output site directory. Default: docx_static_site")
    args = parser.parse_args()
    word_dir = Path(args.word_dir).expanduser().resolve()
    out_dir = Path(args.out).expanduser().resolve()
    if not word_dir.exists() or not word_dir.is_dir():
        raise SystemExit(f"Word directory not found: {word_dir}")
    build_site(word_dir, out_dir)

if __name__ == "__main__":
    main()
