# Cymru Hive OS v5.3 · Map Key + Eco-ROI Movement

This build answers the map-behaviour question directly.

## What changed

- Added a collapsed **Map key / movement ROI** dropdown.
- Added map key panel with icon, movement logic and ROI meaning.
- Map agents now have explicit roles:
  - 🐝 BCO bees / opportunity scouts
  - 🍯 honey/output carriers
  - 🐜 ACO ants / pheromone route memory
  - 🦅 PSO birds / strategic scouts
  - 🐟 fish / water ecology
  - 🐁 prey / biodiversity base
  - 🦊 predators / ecological pressure
  - 🚜 farm twin tractors
  - 🎖️ pathway cadets
  - 🔭 astronomy/GIS scouts
- Movement changes with the selected auto-tune and slider values.
- Added movement ROI components:
  - ACO route score
  - BCO scout score
  - predator/prey ecology score
  - farm-twin movement score
  - tune value score
- Every auto-tune receives the same base tune ROI rate, then gains additional tune-value from the active budget fit.
- Export JSON now includes `mapMetrics`.

## Behaviour

The selected auto-tune still plays until changed. It does not step through all 24 automatically.

## Run

```bash
python3 -m http.server 8088
```

Open:

```text
http://127.0.0.1:8088/
```
