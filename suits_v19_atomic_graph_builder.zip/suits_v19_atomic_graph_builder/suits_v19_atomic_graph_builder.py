#!/usr/bin/env python3
"""
$uits v19 Atomic 3NF + Neo4j Graph Builder

Recursively scans a suitsmafia root for media, metadata, ML JSON/CSV, render plans,
charts, graph exports, scripts and reports. Produces:
  - 3NF-ish atomic CSV tables
  - SQLite database
  - Neo4j CSV import files
  - Cypher constraints/indexes/import script
  - JSON graph summary
  - HTML report

Designed for local path:
  /home/andy/Documents/suitsmafia
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import mimetypes
import os
import re
import sqlite3
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

AUDIO_EXT = {'.mp3', '.wav', '.flac', '.m4a', '.aac', '.ogg', '.opus'}
VIDEO_EXT = {'.mp4', '.mkv', '.webm', '.mov', '.avi', '.m4v'}
IMAGE_EXT = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.apng', '.bmp', '.svg'}
DATA_EXT = {'.json', '.jsonl', '.csv', '.tsv', '.sqlite', '.sqlite3', '.db', '.html', '.htm', '.md', '.txt', '.log', '.cypher'}
SCRIPT_EXT = {'.py', '.sh', '.php', '.js', '.ts', '.lua', '.ps1', '.sql'}
ARCHIVE_EXT = {'.zip', '.tar', '.gz', '.tgz', '.7z', '.rar'}

ANIMAL_CLASSES = [
    'lone_wolf','tiger_stalk','lion_pack_pressure','sheep_flock_panic','goat_stubborn_luck',
    'duck_waddle_escape','swan_grace_escape','eagle_overwatch','hawk_strike','raven_aftermath',
    'cuckoo_deception','crocodile_chokepoint','fox_deception','spider_web_control','shark_pursuit',
    'owl_intelligence','comedy_anomaly'
]
EVENT_TYPES = [
    'shot_fired','hit_confirmed','kill','dark_aftermath','hero_intro','predation_pressure',
    'chase_escape','comedy_blunder','team_play','graphic_intensity_review','opening','pressure',
    'impact','aftermath','reversal'
]
MOODS = ['fast','dark','dramatic','comedic','heroic','slow','aggressive','melancholy']

@dataclass
class Asset:
    asset_id: str
    path: str
    rel_path: str
    name: str
    ext: str
    kind: str
    size_bytes: int
    mtime_utc: str
    mime: str
    hash_prefix: str
    source_group: str


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')


def stable_id(prefix: str, *parts: str) -> str:
    h = hashlib.sha1('|'.join(parts).encode('utf-8', 'ignore')).hexdigest()[:16]
    return f'{prefix}_{h}'


def classify_kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in AUDIO_EXT: return 'audio'
    if ext in VIDEO_EXT: return 'video'
    if ext in IMAGE_EXT: return 'image'
    if ext in SCRIPT_EXT: return 'script'
    if ext in ARCHIVE_EXT: return 'archive'
    if ext in DATA_EXT: return 'data'
    return 'other'


def source_group_from_rel(rel: str) -> str:
    parts = Path(rel).parts
    if not parts: return 'root'
    # Keep first two levels when meaningful, otherwise first level.
    if parts[0] in {'outputs','videos','audio','music_mp4','susitsmafia_website','server_logs','client_logs','screen_recordings'} and len(parts) > 1:
        return '/'.join(parts[:2])
    return parts[0]


def safe_read_text(path: Path, max_bytes: int = 2_000_000) -> str:
    try:
        if path.stat().st_size > max_bytes:
            with path.open('rb') as f:
                data = f.read(max_bytes)
            return data.decode('utf-8', 'ignore')
        return path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return ''


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding='utf-8', errors='ignore'))
    except Exception:
        return None


def path_hash_prefix(path: Path, block: int = 65536) -> str:
    h = hashlib.sha1()
    try:
        with path.open('rb') as f:
            h.update(f.read(block))
        h.update(str(path.stat().st_size).encode())
        return h.hexdigest()[:16]
    except Exception:
        return stable_id('h', str(path))


def detect_terms(text: str, terms: Iterable[str]) -> List[str]:
    lower = text.lower()
    found = []
    for t in terms:
        if t.lower() in lower:
            found.append(t)
    return found


def vector_for_asset(asset: Asset, text_terms: Dict[str, int]) -> List[float]:
    # Small deterministic feature vector suitable for Neo4j property storage / future vector index.
    kind_order = ['audio','video','image','data','script','archive','other']
    ext_score = sum(ord(c) for c in asset.ext) % 997 / 997.0 if asset.ext else 0.0
    size_log = min(1.0, (len(str(max(asset.size_bytes,1))) / 12.0))
    kind_idx = kind_order.index(asset.kind) if asset.kind in kind_order else len(kind_order)-1
    return [round(kind_idx/10.0,4), round(size_log,4), round(ext_score,4), round(text_terms.get('animal_count',0)/10.0,4), round(text_terms.get('event_count',0)/10.0,4)]


def scan_assets(root: Path, skip_dirs: set[str]) -> List[Asset]:
    assets: List[Asset] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs and not d.startswith('.git') and d not in {'__pycache__','.venv','venv'}]
        for fn in filenames:
            p = Path(dirpath) / fn
            try:
                st = p.stat()
            except Exception:
                continue
            rel = str(p.relative_to(root))
            mime = mimetypes.guess_type(str(p))[0] or ''
            kind = classify_kind(p)
            hid = path_hash_prefix(p) if st.st_size < 50_000_000 else stable_id('big', rel, str(st.st_size), str(int(st.st_mtime)))
            asset_id = stable_id('asset', rel, str(st.st_size), hid)
            assets.append(Asset(
                asset_id=asset_id,
                path=str(p),
                rel_path=rel,
                name=fn,
                ext=p.suffix.lower(),
                kind=kind,
                size_bytes=st.st_size,
                mtime_utc=datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat().replace('+00:00','Z'),
                mime=mime,
                hash_prefix=hid,
                source_group=source_group_from_rel(rel),
            ))
    return assets


def extract_metadata(root: Path, assets: List[Asset]) -> Tuple[List[Dict[str,Any]], List[Dict[str,Any]], List[Dict[str,Any]]]:
    attributes: List[Dict[str,Any]] = []
    relationships: List[Dict[str,Any]] = []
    events: List[Dict[str,Any]] = []

    by_path = {a.path: a for a in assets}
    by_name = {a.name: a for a in assets}

    for a in assets:
        text = ''
        p = Path(a.path)
        if a.kind in {'data','script'} and p.suffix.lower() in {'.json','.jsonl','.csv','.tsv','.md','.txt','.html','.htm','.py','.sh','.php','.lua','.cypher'}:
            text = safe_read_text(p, 600_000)
        else:
            text = f'{a.name} {a.rel_path}'

        animals = detect_terms(text, ANIMAL_CLASSES)
        event_types = detect_terms(text, EVENT_TYPES)
        moods = detect_terms(text, MOODS)
        terms = {'animal_count': len(animals), 'event_count': len(event_types)}
        vec = vector_for_asset(a, terms)

        attributes.append({'entity_id': a.asset_id, 'key': 'vector5', 'value': json.dumps(vec), 'value_type': 'vector'})
        if animals:
            for animal in sorted(set(animals)):
                attributes.append({'entity_id': a.asset_id, 'key': 'animal_class', 'value': animal, 'value_type': 'label'})
                relationships.append({'source_id': a.asset_id, 'target_id': f'animal:{animal}', 'rel_type': 'MENTIONS_ANIMAL_CLASS', 'properties': '{}'})
        if event_types:
            for ev in sorted(set(event_types)):
                attributes.append({'entity_id': a.asset_id, 'key': 'event_type', 'value': ev, 'value_type': 'label'})
                relationships.append({'source_id': a.asset_id, 'target_id': f'event_type:{ev}', 'rel_type': 'MENTIONS_EVENT_TYPE', 'properties': '{}'})
        if moods:
            for mood in sorted(set(moods)):
                attributes.append({'entity_id': a.asset_id, 'key': 'mood', 'value': mood, 'value_type': 'label'})

        # JSON-specific extraction from existing processor outputs.
        if p.suffix.lower() == '.json':
            obj = read_json(p)
            if isinstance(obj, dict):
                # Summary/report counts.
                for k in ['schema','version','created_utc','root','site','out']:
                    if k in obj:
                        attributes.append({'entity_id': a.asset_id, 'key': k, 'value': str(obj[k]), 'value_type': 'json_scalar'})
                if isinstance(obj.get('counts'), dict):
                    for k,v in obj['counts'].items():
                        attributes.append({'entity_id': a.asset_id, 'key': f'count.{k}', 'value': str(v), 'value_type': 'count'})
                # Graph-like docs with movies/items.
                candidate_lists = []
                for lk in ['movies','items','clips','data','events','nodes','edges']:
                    if isinstance(obj.get(lk), list): candidate_lists.append((lk, obj[lk]))
                for lk, arr in candidate_lists:
                    for i, item in enumerate(arr[:5000]):
                        if isinstance(item, dict):
                            eid = item.get('event_id') or item.get('id') or item.get('movie_id') or item.get('playlist_id') or stable_id('jsonitem', a.asset_id, lk, str(i))
                            ent_id = str(eid).replace(' ', '_')
                            relationships.append({'source_id': a.asset_id, 'target_id': ent_id, 'rel_type': f'CONTAINS_{lk.upper()}', 'properties': json.dumps({'index': i})})
                            if 'animal_class' in item:
                                relationships.append({'source_id': ent_id, 'target_id': f"animal:{item['animal_class']}", 'rel_type': 'CLASSIFIED_AS', 'properties': '{}'})
                            if 'event_type' in item:
                                relationships.append({'source_id': ent_id, 'target_id': f"event_type:{item['event_type']}", 'rel_type': 'HAS_EVENT_TYPE', 'properties': '{}'})
                            if 'path' in item and isinstance(item['path'], str):
                                target = by_path.get(item['path']) or by_name.get(Path(item['path']).name)
                                if target:
                                    relationships.append({'source_id': ent_id, 'target_id': target.asset_id, 'rel_type': 'REFERENCES_ASSET', 'properties': '{}'})
                            if 'name' in item:
                                events.append({'event_id': ent_id, 'asset_id': a.asset_id, 'event_type': str(item.get('event_type','json_item')), 'label': str(item.get('name'))[:300], 'confidence': item.get('confidence') or item.get('score') or ''})
            elif isinstance(obj, list):
                for i, item in enumerate(obj[:10000]):
                    if isinstance(item, dict):
                        ent_id = str(item.get('event_id') or item.get('id') or item.get('movie_id') or item.get('playlist_id') or stable_id('jsonitem', a.asset_id, str(i))).replace(' ', '_')
                        relationships.append({'source_id': a.asset_id, 'target_id': ent_id, 'rel_type': 'CONTAINS_JSON_ITEM', 'properties': json.dumps({'index': i})})
                        if 'animal_class' in item:
                            relationships.append({'source_id': ent_id, 'target_id': f"animal:{item['animal_class']}", 'rel_type': 'CLASSIFIED_AS', 'properties': '{}'})
                        if 'event_type' in item:
                            relationships.append({'source_id': ent_id, 'target_id': f"event_type:{item['event_type']}", 'rel_type': 'HAS_EVENT_TYPE', 'properties': '{}'})
                        if 'path' in item and isinstance(item['path'], str):
                            target = by_path.get(item['path']) or by_name.get(Path(item['path']).name)
                            if target:
                                relationships.append({'source_id': ent_id, 'target_id': target.asset_id, 'rel_type': 'REFERENCES_ASSET', 'properties': '{}'})
                        if 'name' in item:
                            events.append({'event_id': ent_id, 'asset_id': a.asset_id, 'event_type': str(item.get('event_type','json_item')), 'label': str(item.get('name'))[:300], 'confidence': item.get('confidence') or item.get('score') or ''})

    return attributes, relationships, events


def write_csv(path: Path, rows: List[Dict[str,Any]], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, '') for k in fields})


def build_outputs(root: Path, out: Path, assets: List[Asset], attrs: List[Dict[str,Any]], rels: List[Dict[str,Any]], events: List[Dict[str,Any]]) -> None:
    out.mkdir(parents=True, exist_ok=True)
    csv_dir = out / 'csv_3nf'
    neo_dir = out / 'neo4j'

    # 3NF-ish tables.
    source_files = [a.__dict__ for a in assets]
    groups = []
    group_counts = Counter(a.source_group for a in assets)
    kind_counts = Counter(a.kind for a in assets)
    for g,c in sorted(group_counts.items()):
        groups.append({'group_id': stable_id('grp', g), 'group_name': g, 'asset_count': c})

    entity_rows = []
    seen_entities = set()
    for a in assets:
        entity_rows.append({'entity_id': a.asset_id, 'entity_type': 'Asset', 'label': a.name, 'source_asset_id': a.asset_id})
        seen_entities.add(a.asset_id)
    for animal in ANIMAL_CLASSES:
        eid=f'animal:{animal}'; entity_rows.append({'entity_id': eid, 'entity_type': 'AnimalClass', 'label': animal, 'source_asset_id': ''}); seen_entities.add(eid)
    for ev in EVENT_TYPES:
        eid=f'event_type:{ev}'; entity_rows.append({'entity_id': eid, 'entity_type': 'EventType', 'label': ev, 'source_asset_id': ''}); seen_entities.add(eid)
    for r in rels:
        for eid in [r['source_id'], r['target_id']]:
            if eid not in seen_entities:
                entity_rows.append({'entity_id': eid, 'entity_type': 'Concept', 'label': eid, 'source_asset_id': ''})
                seen_entities.add(eid)

    write_csv(csv_dir/'source_file.csv', source_files, ['asset_id','path','rel_path','name','ext','kind','size_bytes','mtime_utc','mime','hash_prefix','source_group'])
    write_csv(csv_dir/'source_file_group.csv', groups, ['group_id','group_name','asset_count'])
    write_csv(csv_dir/'entity.csv', entity_rows, ['entity_id','entity_type','label','source_asset_id'])
    write_csv(csv_dir/'attribute.csv', attrs, ['entity_id','key','value','value_type'])
    write_csv(csv_dir/'relationship.csv', rels, ['source_id','target_id','rel_type','properties'])
    write_csv(csv_dir/'event.csv', events, ['event_id','asset_id','event_type','label','confidence'])

    # Neo4j import CSV.
    node_rows = []
    for e in entity_rows:
        node_rows.append({
            'id:ID': e['entity_id'],
            'label': e['label'],
            ':LABEL': e['entity_type'],
            'source_asset_id': e.get('source_asset_id',''),
        })
    rel_rows = []
    for r in rels:
        rel_rows.append({':START_ID': r['source_id'], ':END_ID': r['target_id'], ':TYPE': re.sub(r'[^A-Za-z0-9_]', '_', r['rel_type']).upper(), 'properties': r.get('properties','{}')})
    write_csv(neo_dir/'neo4j_nodes.csv', node_rows, ['id:ID','label',':LABEL','source_asset_id'])
    write_csv(neo_dir/'neo4j_edges.csv', rel_rows, [':START_ID',':END_ID',':TYPE','properties'])

    cypher = """// $uits v19 Atomic Graph Builder
// Copy neo4j_nodes.csv and neo4j_edges.csv into Neo4j import dir, then run this.
CREATE CONSTRAINT suits_entity_id IF NOT EXISTS FOR (n:Entity) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT suits_asset_id IF NOT EXISTS FOR (n:Asset) REQUIRE n.id IS UNIQUE;
CREATE INDEX suits_label IF NOT EXISTS FOR (n) ON (n.label);

LOAD CSV WITH HEADERS FROM 'file:///neo4j_nodes.csv' AS row
CALL {
  WITH row
  MERGE (n:Entity {id: row.`id:ID`})
  SET n.label = row.label,
      n.entity_type = row.`:LABEL`,
      n.source_asset_id = row.source_asset_id
  WITH n, row
  CALL apoc.create.addLabels(n, [row.`:LABEL`]) YIELD node
  RETURN count(*) AS done
} IN TRANSACTIONS OF 1000 ROWS;

LOAD CSV WITH HEADERS FROM 'file:///neo4j_edges.csv' AS row
CALL {
  WITH row
  MATCH (a:Entity {id: row.`:START_ID`})
  MATCH (b:Entity {id: row.`:END_ID`})
  CALL apoc.create.relationship(a, row.`:TYPE`, {properties: row.properties}, b) YIELD rel
  RETURN count(*) AS done
} IN TRANSACTIONS OF 1000 ROWS;
"""
    (neo_dir/'suits_v19_import.cypher').write_text(cypher, encoding='utf-8')

    # APOC-free fallback with generic relationship.
    cypher_no_apoc = """// APOC-free import fallback.
LOAD CSV WITH HEADERS FROM 'file:///neo4j_nodes.csv' AS row
MERGE (n:Entity {id: row.`id:ID`})
SET n.label = row.label,
    n.entity_type = row.`:LABEL`,
    n.source_asset_id = row.source_asset_id;

LOAD CSV WITH HEADERS FROM 'file:///neo4j_edges.csv' AS row
MATCH (a:Entity {id: row.`:START_ID`})
MATCH (b:Entity {id: row.`:END_ID`})
MERGE (a)-[r:RELATED {type: row.`:TYPE`}]->(b)
SET r.properties = row.properties;
"""
    (neo_dir/'suits_v19_import_no_apoc.cypher').write_text(cypher_no_apoc, encoding='utf-8')

    # SQLite.
    db = out/'suits_v19_atomic_3nf.sqlite3'
    if db.exists(): db.unlink()
    con = sqlite3.connect(db)
    cur = con.cursor()
    cur.execute('CREATE TABLE source_file(asset_id TEXT PRIMARY KEY,path TEXT,rel_path TEXT,name TEXT,ext TEXT,kind TEXT,size_bytes INTEGER,mtime_utc TEXT,mime TEXT,hash_prefix TEXT,source_group TEXT)')
    cur.execute('CREATE TABLE source_file_group(group_id TEXT PRIMARY KEY,group_name TEXT,asset_count INTEGER)')
    cur.execute('CREATE TABLE entity(entity_id TEXT PRIMARY KEY,entity_type TEXT,label TEXT,source_asset_id TEXT)')
    cur.execute('CREATE TABLE attribute(entity_id TEXT,key TEXT,value TEXT,value_type TEXT)')
    cur.execute('CREATE TABLE relationship(source_id TEXT,target_id TEXT,rel_type TEXT,properties TEXT)')
    cur.execute('CREATE TABLE event(event_id TEXT PRIMARY KEY,asset_id TEXT,event_type TEXT,label TEXT,confidence TEXT)')
    for a in source_files:
        cur.execute('INSERT INTO source_file VALUES(?,?,?,?,?,?,?,?,?,?,?)', tuple(a[k] for k in ['asset_id','path','rel_path','name','ext','kind','size_bytes','mtime_utc','mime','hash_prefix','source_group']))
    for g in groups:
        cur.execute('INSERT INTO source_file_group VALUES(?,?,?)', (g['group_id'],g['group_name'],g['asset_count']))
    for e in entity_rows:
        cur.execute('INSERT OR IGNORE INTO entity VALUES(?,?,?,?)', (e['entity_id'],e['entity_type'],e['label'],e.get('source_asset_id','')))
    for at in attrs:
        cur.execute('INSERT INTO attribute VALUES(?,?,?,?)', (at['entity_id'], at['key'], at['value'], at['value_type']))
    for r in rels:
        cur.execute('INSERT INTO relationship VALUES(?,?,?,?)', (r['source_id'],r['target_id'],r['rel_type'],r.get('properties','{}')))
    for ev in events:
        cur.execute('INSERT OR IGNORE INTO event VALUES(?,?,?,?,?)', (ev['event_id'],ev['asset_id'],ev['event_type'],ev['label'],str(ev.get('confidence',''))))
    cur.execute('CREATE INDEX idx_source_kind ON source_file(kind)')
    cur.execute('CREATE INDEX idx_source_group ON source_file(source_group)')
    cur.execute('CREATE INDEX idx_attr_key_value ON attribute(key,value)')
    cur.execute('CREATE INDEX idx_rel_type ON relationship(rel_type)')
    con.commit(); con.close()

    summary = {
        'schema': 'suits_v19_atomic_3nf_graph',
        'created_utc': now_iso(),
        'root': str(root),
        'out': str(out),
        'counts': {
            'assets': len(assets),
            'entities': len(entity_rows),
            'attributes': len(attrs),
            'relationships': len(rels),
            'events': len(events),
            'groups': len(groups),
        },
        'kind_counts': dict(kind_counts),
        'top_groups': group_counts.most_common(25),
        'outputs': {
            'sqlite': str(db),
            'csv_3nf': str(csv_dir),
            'neo4j': str(neo_dir),
        }
    }
    (out/'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')

    report = f"""<!doctype html><html><head><meta charset='utf-8'><title>$uits v19 Atomic Graph Report</title>
<style>body{{font-family:system-ui;background:#07111f;color:#dbeafe;padding:24px}}code,pre{{background:#0f1e33;padding:12px;border-radius:10px;display:block;white-space:pre-wrap}}table{{border-collapse:collapse}}td,th{{padding:6px 12px;border-bottom:1px solid #234}}</style></head><body>
<h1>[o][o] $uits v19 Atomic 3NF + Neo4j Graph</h1>
<p>Root: <code>{html.escape(str(root))}</code></p>
<h2>Counts</h2><pre>{html.escape(json.dumps(summary['counts'], indent=2))}</pre>
<h2>Kind counts</h2><pre>{html.escape(json.dumps(summary['kind_counts'], indent=2))}</pre>
<h2>Outputs</h2><pre>{html.escape(json.dumps(summary['outputs'], indent=2))}</pre>
<h2>Neo4j import</h2><pre>Copy neo4j/*.csv to Neo4j import dir and run suits_v19_import.cypher.
If APOC is unavailable, run suits_v19_import_no_apoc.cypher.</pre>
</body></html>"""
    (out/'report.html').write_text(report, encoding='utf-8')


def main() -> int:
    ap = argparse.ArgumentParser(description='$uits v19 recursive atomic 3NF + Neo4j graph builder')
    ap.add_argument('--root', default='/home/andy/Documents/suitsmafia')
    ap.add_argument('--out', default=None)
    ap.add_argument('--skip-dir', action='append', default=['.git','__pycache__','.venv','venv','node_modules'])
    args = ap.parse_args()
    root = Path(args.root).expanduser().resolve()
    out = Path(args.out).expanduser().resolve() if args.out else root/'outputs'/'suits_v19_atomic_graph'
    if not root.exists():
        print(f'[error] root not found: {root}', file=sys.stderr)
        return 2
    print(f'[o][o] scanning {root}')
    assets = scan_assets(root, set(args.skip_dir))
    print(f'[stage] assets={len(assets)}')
    attrs, rels, events = extract_metadata(root, assets)
    print(f'[stage] attrs={len(attrs)} rels={len(rels)} events={len(events)}')
    build_outputs(root, out, assets, attrs, rels, events)
    print(f'[o][o] done out={out}')
    print(f'[report] {out / "report.html"}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
