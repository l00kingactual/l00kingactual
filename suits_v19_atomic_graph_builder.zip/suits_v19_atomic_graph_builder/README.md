# $uits v19 Atomic 3NF + Neo4j Graph Builder

Recursively scans `/home/andy/Documents/suitsmafia` for media, scripts, reports, JSON/CSV metadata, ML data, render jobs, graph exports, chart specs and event plans.

It creates an atomic/3NF-style database and a Neo4j graph export.

## Outputs

Default output folder:

```bash
/home/andy/Documents/suitsmafia/outputs/suits_v19_atomic_graph
```

Generated files:

```text
csv_3nf/source_file.csv
csv_3nf/source_file_group.csv
csv_3nf/entity.csv
csv_3nf/attribute.csv
csv_3nf/relationship.csv
csv_3nf/event.csv
suits_v19_atomic_3nf.sqlite3
neo4j/neo4j_nodes.csv
neo4j/neo4j_edges.csv
neo4j/suits_v19_import.cypher
neo4j/suits_v19_import_no_apoc.cypher
summary.json
report.html
```

## Run locally

```bash
cd ~/Downloads/suits_v19_atomic_graph_builder
chmod +x *.py *.sh
./run_v19_atomic_graph_local.sh
```

Or directly:

```bash
python3 suits_v19_atomic_graph_builder.py --root /home/andy/Documents/suitsmafia
```

## Neo4j import

Copy:

```text
neo4j/neo4j_nodes.csv
neo4j/neo4j_edges.csv
```

into your Neo4j import directory, then run:

```cypher
:source suits_v19_import.cypher
```

If APOC is not installed, use:

```cypher
:source suits_v19_import_no_apoc.cypher
```

## Design

Atomic tables:

- `source_file`: one row per discovered file
- `source_file_group`: path/group buckets
- `entity`: one row per asset/concept/event/animal/mood/type
- `attribute`: one attribute per row, including vector-like feature arrays
- `relationship`: atomic edge rows
- `event`: extracted event-ish items from JSON metadata

Graph concepts:

- assets become `Asset` nodes
- animal classes become `AnimalClass` nodes
- event types become `EventType` nodes
- JSON items become `Concept`/event nodes
- references become relationships
- vector-like metadata is stored as a JSON array attribute and can later be promoted to Neo4j vector properties/indexes
