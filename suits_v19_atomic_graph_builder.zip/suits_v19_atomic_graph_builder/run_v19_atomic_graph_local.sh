#!/usr/bin/env bash
set -euo pipefail
ROOT="${SUITS_ROOT:-/home/andy/Documents/suitsmafia}"
PY="${SUITS_PY:-python3}"
exec "$PY" "$(dirname "$0")/suits_v19_atomic_graph_builder.py" --root "$ROOT" "$@"
