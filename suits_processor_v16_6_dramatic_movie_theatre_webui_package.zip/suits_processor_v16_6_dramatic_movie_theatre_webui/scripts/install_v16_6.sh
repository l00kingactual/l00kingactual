#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/andy/Documents/suitsmafia"
PROC="$ROOT/processors/suits_processor_v16_6_dramatic_movie_theatre_webui"
TOOLS="$ROOT/tools"
SITE="$ROOT/susitsmafia_website"
mkdir -p "$PROC" "$TOOLS" "$SITE/css" "$SITE/js" "$SITE/api" "$SITE/data/suits_v16_6"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
rsync -av "$SCRIPT_DIR/" "$PROC/"
rsync -av "$SCRIPT_DIR/web/" "$SITE/"
rsync -av "$SCRIPT_DIR/css/" "$SITE/css/"
rsync -av "$SCRIPT_DIR/js/" "$SITE/js/"
rsync -av "$SCRIPT_DIR/api/" "$SITE/api/"
cat > "$TOOLS/suits_processor_v16_6_dramatic_movie_theatre" <<EOF
#!/usr/bin/env bash
python3 "$PROC/tools/suits_processor_v16_6_dramatic_movie_theatre.py" "\$@"
EOF
chmod +x "$TOOLS/suits_processor_v16_6_dramatic_movie_theatre"
cat > "$TOOLS/suits_v16_6_launch_theatre" <<EOF
#!/usr/bin/env bash
cd "$SITE"
echo "[o][o] launching $uit$ v16.6 theatre at http://127.0.0.1:8081/suits_v16_6_dashboard.php"
php -S 127.0.0.1:8081
EOF
chmod +x "$TOOLS/suits_v16_6_launch_theatre"
echo "[o][o] Installed v16.6 processor launcher: $TOOLS/suits_processor_v16_6_dramatic_movie_theatre"
echo "[o][o] Installed v16.6 theatre launcher: $TOOLS/suits_v16_6_launch_theatre"
echo "[o][o] WebUI installed into: $SITE"
