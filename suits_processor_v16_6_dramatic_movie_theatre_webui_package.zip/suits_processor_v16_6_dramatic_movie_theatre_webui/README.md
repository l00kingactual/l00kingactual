# $uits Processor v16.6 - Dramatic Movie Theatre + Story Factory WebUI

v16.6 is a server-resource processor and integrated website UI for the $uit$ Mafia / Dougie story theatre.

It scans the suitsmafia folder, profiles songs/videos/images/data, learns from existing metadata, classifies action videos into predation/comedy/story groups, builds song/action playlists, writes JSON/CSV/SQLite/Neo4j/chart resources, and generates render scripts for dramatic movies from grouped playlists.

## Install on Linux / darkstar

```bash
cd /home/andy/Downloads
unzip -o suits_processor_v16_6_dramatic_movie_theatre_webui_package.zip
cd suits_processor_v16_6_dramatic_movie_theatre_webui
chmod +x scripts/*.sh tools/*.py *.sh
./scripts/install_v16_6.sh
```

## Run server resource build

```bash
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_6_dramatic_movie_theatre \
  --ml-update --build-webui --build-graphs --build-charts --plan-movies --no-probe-media --progress-every 250
```

## Launch local WebUI

```bash
/home/andy/Documents/suitsmafia/tools/suits_v16_6_launch_theatre
```

Open:

```text
http://127.0.0.1:8081/suits_v16_6_dashboard.php
```

## Windows / PowerShell

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
cd $env:USERPROFILE\Downloads\suits_processor_v16_6_dramatic_movie_theatre_webui
.\install_v16_6.ps1 -Wsl
.\run_v16_6_smoke.ps1 -Wsl
```

## Outputs

```text
/home/andy/Documents/suitsmafia/outputs/suits_processor_v16_6_dramatic_movie_theatre
/home/andy/Documents/suitsmafia/susitsmafia_website/data/suits_v16_6
```
