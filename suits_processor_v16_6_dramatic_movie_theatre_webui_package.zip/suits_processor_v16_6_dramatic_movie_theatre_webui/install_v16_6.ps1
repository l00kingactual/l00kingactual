param([switch]$Wsl)
if ($Wsl) {
  wsl bash -lc "cd /mnt/c/Users/$env:USERNAME/Downloads/suits_processor_v16_6_dramatic_movie_theatre_webui 2>/dev/null || cd /home/andy/Downloads/suits_processor_v16_6_dramatic_movie_theatre_webui; chmod +x scripts/*.sh tools/*.py *.sh; ./scripts/install_v16_6.sh"
} else {
  Write-Host "This package targets the Linux/WSL suitsmafia tree. Use: .\install_v16_6.ps1 -Wsl"
}
