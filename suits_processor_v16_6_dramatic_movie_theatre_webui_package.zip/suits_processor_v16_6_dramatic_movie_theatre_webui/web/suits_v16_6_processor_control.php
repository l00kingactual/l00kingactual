<?php require __DIR__.'/suits_v16_6_nav.php'; suits_v16_6_nav('Processor Switchboard'); ?>
<section class="hero"><h1>Processor Switchboard</h1><p class="muted">For safety, the public PHP page does not execute shell commands. Copy this command into darkstar terminal.</p></section><pre id="cmd"></pre><script>control()</script><?php suits_v16_6_foot(); ?>
