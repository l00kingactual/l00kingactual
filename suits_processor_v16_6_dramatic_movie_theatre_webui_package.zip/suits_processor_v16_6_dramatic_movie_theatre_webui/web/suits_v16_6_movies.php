<?php require __DIR__.'/suits_v16_6_nav.php'; suits_v16_6_nav('Movie Factory'); ?>
<section class="hero"><h1>Movie Factory</h1><p class="muted">12 dramatic full-song movie plans built from grouped song/action playlists. Render with the generated shell script in the output folder.</p></section><section class="grid" id="movieCards"></section><script>movies()</script><?php suits_v16_6_foot(); ?>
