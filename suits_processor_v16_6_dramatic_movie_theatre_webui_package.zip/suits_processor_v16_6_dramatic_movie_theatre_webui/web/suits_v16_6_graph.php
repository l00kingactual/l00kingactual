<?php require __DIR__.'/suits_v16_6_nav.php'; suits_v16_6_nav('Graph Lab'); ?>
<section class="hero"><h1>Graph Lab</h1><p><span class="badge">nodes <b id="g_nodes">-</b></span><span class="badge">edges <b id="g_edges">-</b></span></p></section><pre id="graphDump"></pre><script>graph()</script><?php suits_v16_6_foot(); ?>
