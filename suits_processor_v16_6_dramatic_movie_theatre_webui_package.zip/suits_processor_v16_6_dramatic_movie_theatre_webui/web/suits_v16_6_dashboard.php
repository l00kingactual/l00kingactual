<?php require __DIR__.'/suits_v16_6_nav.php'; suits_v16_6_nav('v16.6 Dashboard'); ?>
<section class="hero"><h1>[o][o] $uits Dramatic Movie Theatre</h1><p class="muted">Server-built media intelligence: scan, classify, playlist, chart, graph, render, publish.</p></section><section class="grid">
<?php foreach(['assets','music','videos','images','events','matches','playlists','movies','charts','graph_nodes'] as $m): ?><div class="card"><div class="muted"><?php echo $m; ?></div><div class="metric" id="m_<?php echo $m; ?>">-</div></div><?php endforeach; ?>
</section><script>dashboard()</script><?php suits_v16_6_foot(); ?>
