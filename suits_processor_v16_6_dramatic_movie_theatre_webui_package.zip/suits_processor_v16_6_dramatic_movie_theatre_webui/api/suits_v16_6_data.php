<?php
$name = basename($_GET['file'] ?? 'summary.json');
$base = __DIR__ . '/../data/suits_v16_6/';
$path = realpath($base . $name);
if (!$path || strpos($path, realpath($base)) !== 0 || !preg_match('/\.json$/', $name)) { http_response_code(404); echo '{}'; exit; }
header('Content-Type: application/json'); readfile($path);
