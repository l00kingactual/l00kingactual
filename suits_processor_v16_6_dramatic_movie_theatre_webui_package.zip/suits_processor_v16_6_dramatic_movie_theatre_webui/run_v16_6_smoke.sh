#!/usr/bin/env bash
set -euo pipefail
/home/andy/Documents/suitsmafia/tools/suits_processor_v16_6_dramatic_movie_theatre --smoke --limit-files 900 --ml-update --build-webui --build-graphs --build-charts --plan-movies --no-probe-media --progress-every 100
