param([switch]$Wsl)
if ($Wsl) { wsl bash -lc "/home/andy/Documents/suitsmafia/tools/suits_processor_v16_6_dramatic_movie_theatre --smoke --limit-files 900 --ml-update --build-webui --build-graphs --build-charts --plan-movies --no-probe-media --progress-every 100" } else { Write-Host "Use -Wsl to run in the Linux suitsmafia environment." }
